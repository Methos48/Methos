@echo off
setlocal
cd /d "%~dp0"
echo ==========================================
echo             METHOS XDAT
echo ==========================================
py -3.12 --version >nul 2>nul
if errorlevel 1 (
  echo Se necesita Python 3.12 de 64 bits para CONSTRUIR el instalador.
  echo El usuario final no necesitara Python una vez instalado el programa.
  pause
  exit /b 1
)
py -3.12 -m pip install --upgrade pip
if errorlevel 1 goto error
py -3.12 -m pip install -r requirements-build.txt
if errorlevel 1 goto error
py -3.12 -m PyInstaller --noconfirm --clean --windowed --onedir --name "Methos XDAT" app.py
if errorlevel 1 goto error
echo.
echo Aplicacion creada en dist\Methos XDAT.
echo Ahora ejecuta installer\build_installer.bat para generar el instalador.
pause
exit /b 0
:error
echo ERROR durante la compilacion.
pause
exit /b 1
