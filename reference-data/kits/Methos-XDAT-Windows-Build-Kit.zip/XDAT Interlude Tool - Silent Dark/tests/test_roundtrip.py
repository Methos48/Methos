from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from xdat_core import compile_from_folder, decompile_to_folder


class SilentDarkRoundTripTest(unittest.TestCase):
    def test_original_xdat_and_parts_recompile_identically(self):
        original_path = ROOT / "xdat completo" / "interface.xdat"
        parts_path = ROOT / "xdat por partes"
        original = original_path.read_bytes()
        compiled, windows, shortcuts = compile_from_folder(parts_path, original)
        self.assertEqual((windows, shortcuts), (168, 8))
        self.assertEqual(compiled, original)

    def test_decompile_then_compile_is_identical(self):
        original_path = ROOT / "xdat completo" / "interface.xdat"
        original = original_path.read_bytes()
        import tempfile
        with tempfile.TemporaryDirectory() as temp:
            parts = Path(temp)
            windows, shortcuts = decompile_to_folder(original, parts)
            compiled, out_windows, out_shortcuts = compile_from_folder(parts, original)
            self.assertEqual((windows, shortcuts), (168, 8))
            self.assertEqual((out_windows, out_shortcuts), (168, 8))
            self.assertEqual(compiled, original)


if __name__ == "__main__":
    unittest.main()
