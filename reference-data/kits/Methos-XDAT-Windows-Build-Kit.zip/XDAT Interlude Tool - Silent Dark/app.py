from __future__ import annotations
import os, sys, shutil, zipfile, tempfile, traceback
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import xml.etree.ElementTree as ET

from xdat_core import decompile_to_folder, compile_from_folder, parse_xdat

APP_DIR = Path(__file__).resolve().parent
# Datos editables en Documentos: no requieren permisos de administrador.
DATA_DIR = Path.home() / 'Documents' / 'Methos XDAT'
COMPLETE_DIR = DATA_DIR / 'xdat completo'
PARTS_DIR = DATA_DIR / 'xdat por partes'
OUTPUT_NAME = 'interface_compilado.xdat'

class XdatApp:
    def __init__(self, root):
        self.root = root
        self.root.title('Methos XDAT | Lineage II Interlude')
        self.root.geometry('1060x760')
        self.root.minsize(900, 640)
        COMPLETE_DIR.mkdir(parents=True, exist_ok=True)
        PARTS_DIR.mkdir(parents=True, exist_ok=True)
        (PARTS_DIR / 'windows').mkdir(exist_ok=True)
        (PARTS_DIR / 'shortcuts').mkdir(exist_ok=True)
        self._style()
        self._build()
        self.refresh()

    def _style(self):
        style = ttk.Style()
        try: style.theme_use('clam')
        except tk.TclError: pass
        self.root.configure(bg='#f3f5f8')
        style.configure('TFrame', background='#f3f5f8')
        style.configure('Card.TFrame', background='#ffffff', relief='solid', borderwidth=1)
        style.configure('TLabel', background='#f3f5f8', foreground='#263445', font=('Segoe UI', 10))
        style.configure('Title.TLabel', background='#f3f5f8', foreground='#172b4d', font=('Segoe UI Semibold', 20))
        style.configure('Sub.TLabel', background='#f3f5f8', foreground='#607086', font=('Segoe UI', 9))
        style.configure('CardTitle.TLabel', background='#ffffff', foreground='#1c3557', font=('Segoe UI Semibold', 12))
        style.configure('Path.TLabel', background='#ffffff', foreground='#607086', font=('Segoe UI', 9))
        style.configure('TButton', font=('Segoe UI Semibold', 10), padding=(12, 8))
        style.configure('Primary.TButton', background='#2457a7', foreground='white')
        style.map('Primary.TButton', background=[('active','#1d4789'),('disabled','#aab6c5')], foreground=[('disabled','#f3f5f8')])
        style.configure('Success.TButton', background='#18794e', foreground='white')
        style.map('Success.TButton', background=[('active','#12613e'),('disabled','#aab6c5')])
        style.configure('Treeview', rowheight=25, font=('Segoe UI', 9), background='white', fieldbackground='white')
        style.configure('Treeview.Heading', font=('Segoe UI Semibold', 9), background='#e8edf4', foreground='#263445')
        style.configure('TCombobox', padding=5)
        style.configure('TProgressbar', thickness=8)

    def _build(self):
        outer = ttk.Frame(self.root, padding=18)
        outer.pack(fill='both', expand=True)

        header = ttk.Frame(outer)
        header.pack(fill='x', pady=(0, 14))
        ttk.Label(header, text='METHOS XDAT', style='Title.TLabel').pack(anchor='w')
        ttk.Label(header, text='Compilar y descompilar archivos XDAT de Lineage II Interlude', style='Sub.TLabel').pack(anchor='w', pady=(2,0))

        actions = ttk.Frame(outer)
        actions.pack(fill='x', pady=(0, 14))
        ttk.Button(actions, text='＋  Agregar XDAT completo', command=self.add_xdat).pack(side='left', padx=(0,8))
        ttk.Button(actions, text='＋  Agregar partes XML / ZIP', command=self.add_parts).pack(side='left', padx=(0,8))
        ttk.Button(actions, text='＋  Agregar carpeta de partes', command=self.add_parts_folder).pack(side='left', padx=(0,8))
        ttk.Button(actions, text='Actualizar lista', command=self.refresh).pack(side='left')

        cards = ttk.Frame(outer)
        cards.pack(fill='x', pady=(0, 14))
        cards.columnconfigure(0, weight=1)
        cards.columnconfigure(1, weight=1)

        self.complete_card = ttk.Frame(cards, style='Card.TFrame', padding=14)
        self.complete_card.grid(row=0, column=0, sticky='nsew', padx=(0,7))
        ttk.Label(self.complete_card, text='1. XDAT COMPLETO', style='CardTitle.TLabel').pack(anchor='w')
        ttk.Label(self.complete_card, text='Aquí se guardan los archivos .xdat.', style='Path.TLabel').pack(anchor='w', pady=(2,8))
        self.xdat_combo = ttk.Combobox(self.complete_card, state='readonly')
        self.xdat_combo.pack(fill='x', pady=(0,9))
        row = ttk.Frame(self.complete_card, style='Card.TFrame')
        row.pack(fill='x')
        ttk.Button(row, text='Abrir carpeta', command=lambda: self.open_folder(COMPLETE_DIR)).pack(side='left')
        ttk.Button(row, text='DESCOMPILAR', style='Primary.TButton', command=self.decompile).pack(side='right')

        self.parts_card = ttk.Frame(cards, style='Card.TFrame', padding=14)
        self.parts_card.grid(row=0, column=1, sticky='nsew', padx=(7,0))
        ttk.Label(self.parts_card, text='2. XDAT POR PARTES', style='CardTitle.TLabel').pack(anchor='w')
        ttk.Label(self.parts_card, text='Aquí se guardan las ventanas y accesos directos XML.', style='Path.TLabel').pack(anchor='w', pady=(2,8))
        self.parts_count = ttk.Label(self.parts_card, text='0 archivos XML', style='CardTitle.TLabel')
        self.parts_count.pack(anchor='w', pady=(0,9))
        row2 = ttk.Frame(self.parts_card, style='Card.TFrame')
        row2.pack(fill='x')
        ttk.Button(row2, text='Abrir carpeta', command=lambda: self.open_folder(PARTS_DIR)).pack(side='left')
        ttk.Button(row2, text='COMPILAR', style='Success.TButton', command=self.compile).pack(side='right')

        list_header = ttk.Frame(outer)
        list_header.pack(fill='x', pady=(0,6))
        ttk.Label(list_header, text='ARCHIVOS POR PARTES', style='CardTitle.TLabel').pack(side='left')
        ttk.Button(list_header, text='Quitar seleccionados', command=self.remove_selected).pack(side='right')

        table_frame = ttk.Frame(outer, style='Card.TFrame', padding=6)
        table_frame.pack(fill='both', expand=True)
        cols=('type','name','folder')
        self.tree=ttk.Treeview(table_frame,columns=cols,show='headings',selectmode='extended')
        self.tree.heading('type',text='TIPO')
        self.tree.heading('name',text='ARCHIVO')
        self.tree.heading('folder',text='CARPETA')
        self.tree.column('type',width=120,stretch=False)
        self.tree.column('name',width=330)
        self.tree.column('folder',width=450)
        vs=ttk.Scrollbar(table_frame,orient='vertical',command=self.tree.yview)
        hs=ttk.Scrollbar(table_frame,orient='horizontal',command=self.tree.xview)
        self.tree.configure(yscrollcommand=vs.set,xscrollcommand=hs.set)
        self.tree.grid(row=0,column=0,sticky='nsew')
        vs.grid(row=0,column=1,sticky='ns')
        hs.grid(row=1,column=0,sticky='ew')
        table_frame.rowconfigure(0,weight=1);table_frame.columnconfigure(0,weight=1)
        self.tree.bind('<Double-1>',self.open_selected_xml)

        footer=ttk.Frame(outer)
        footer.pack(fill='x',pady=(12,0))
        self.status=tk.StringVar(value='Methos XDAT listo. Agrega un XDAT completo o archivos XML para comenzar.')
        ttk.Label(footer,textvariable=self.status).pack(side='left',fill='x',expand=True)
        self.progress=ttk.Progressbar(footer,mode='determinate',length=170,maximum=100)
        self.progress.pack(side='right')

    def set_status(self,text,done=False):
        self.status.set(text)
        self.progress['value']=100 if done else 0
        self.root.update_idletasks()

    def open_folder(self,path):
        try:
            if sys.platform=='win32': os.startfile(str(path))
            elif sys.platform=='darwin': os.system(f'open "{path}"')
            else: os.system(f'xdg-open "{path}" >/dev/null 2>&1 &')
        except Exception as e: messagebox.showerror('No se pudo abrir',str(e))

    def backup_if_exists(self,path):
        path=Path(path)
        if path.exists():
            bak=path.with_suffix(path.suffix+'.bak')
            n=2
            while bak.exists():
                bak=path.with_suffix(path.suffix+f'.bak{n}'); n+=1
            shutil.copy2(path,bak)
            return bak
        return None

    def add_xdat(self):
        files=filedialog.askopenfilenames(title='Seleccionar archivo(s) XDAT',filetypes=[('Lineage II XDAT','*.xdat'),('Todos los archivos','*.*')])
        if not files:return
        copied=0
        for src in files:
            src=Path(src)
            if src.suffix.lower()!='.xdat':
                messagebox.showwarning('Archivo no válido',f'{src.name} no tiene extensión .xdat y se omitió.')
                continue
            dest=COMPLETE_DIR/src.name
            if dest.exists() and not messagebox.askyesno('Reemplazar archivo',f'Ya existe {dest.name}. ¿Quieres reemplazarlo? Se guardará una copia de seguridad.'):
                continue
            self.backup_if_exists(dest)
            shutil.copy2(src,dest); copied+=1
        self.refresh()
        self.set_status(f'{copied} archivo(s) XDAT agregado(s).',True)

    def _destination_for_root(self,root_tag):
        if root_tag=='ct0.Window': return PARTS_DIR/'windows'
        if root_tag=='ct0.Shortcut': return PARTS_DIR/'shortcuts'
        return None

    def _copy_xml_bytes(self,data,source_name):
        try: root=ET.fromstring(data)
        except Exception as e: raise ValueError(f'{source_name}: XML inválido ({e})')
        destdir=self._destination_for_root(root.tag)
        if destdir is None: raise ValueError(f'{source_name}: tipo {root.tag} no compatible. Se esperan ct0.Window o ct0.Shortcut.')
        destdir.mkdir(parents=True,exist_ok=True)
        stem=Path(source_name).stem
        if not stem: stem=(root.findtext('name') or root.findtext('unk0') or 'archivo')
        dest=destdir/(stem+'.xml')
        if dest.exists():
            # A name collision is resolved with a prompt rather than silently overwriting.
            if not messagebox.askyesno('Archivo repetido',f'Ya existe {dest.name}. ¿Quieres reemplazarlo?'):
                return False
            self.backup_if_exists(dest)
        dest.write_bytes(data)
        return True

    def add_parts(self):
        files=filedialog.askopenfilenames(title='Agregar XML o ZIP',filetypes=[('XML o ZIP','*.xml *.zip'),('Archivos XML','*.xml'),('Archivos ZIP','*.zip'),('Todos los archivos','*.*')])
        if not files:return
        added=0; skipped=0; errors=[]
        for filename in files:
            p=Path(filename)
            try:
                if p.suffix.lower()=='.zip':
                    with zipfile.ZipFile(p,'r') as z:
                        for info in z.infolist():
                            if info.is_dir() or not info.filename.lower().endswith('.xml'): continue
                            # Read XML data only; never extract arbitrary archive paths.
                            if info.file_size>32*1024*1024: raise ValueError(f'{info.filename}: XML demasiado grande')
                            try:
                                if self._copy_xml_bytes(z.read(info),Path(info.filename).name): added+=1
                                else: skipped+=1
                            except Exception as e: errors.append(str(e))
                elif p.suffix.lower()=='.xml':
                    if self._copy_xml_bytes(p.read_bytes(),p.name): added+=1
                    else: skipped+=1
                else: errors.append(f'{p.name}: formato no admitido')
            except Exception as e: errors.append(f'{p.name}: {e}')
        self.refresh()
        msg=f'{added} archivo(s) XML agregado(s).'
        if skipped: msg+=f' {skipped} omitido(s).'
        self.set_status(msg,True)
        if errors: messagebox.showwarning('Algunos archivos no se agregaron','\n'.join(errors[:12]))

    def add_parts_folder(self):
        folder=filedialog.askdirectory(title='Seleccionar carpeta que contiene los XML')
        if not folder:return
        added=0; skipped=0; errors=[]
        for p in Path(folder).rglob('*.xml'):
            try:
                if self._copy_xml_bytes(p.read_bytes(),p.name): added+=1
                else: skipped+=1
            except Exception as e: errors.append(f'{p.name}: {e}')
        self.refresh(); self.set_status(f'{added} archivo(s) XML agregado(s).',True)
        if errors: messagebox.showwarning('Algunos archivos no se agregaron','\n'.join(errors[:12]))

    def xdat_files(self):
        return sorted(COMPLETE_DIR.glob('*.xdat'),key=lambda p:p.name.casefold())

    def selected_xdat(self):
        name=self.xdat_combo.get()
        return COMPLETE_DIR/name if name else None

    def refresh(self):
        files=self.xdat_files()
        old=self.xdat_combo.get()
        self.xdat_combo['values']=[p.name for p in files]
        if old in [p.name for p in files]: self.xdat_combo.set(old)
        elif files: self.xdat_combo.current(0)
        else: self.xdat_combo.set('')
        for item in self.tree.get_children(): self.tree.delete(item)
        count=0
        for sub,kind in [('windows','Ventana'),('shortcuts','Acceso directo')]:
            for p in sorted((PARTS_DIR/sub).glob('*.xml'),key=lambda x:x.name.casefold()):
                self.tree.insert('', 'end', iid=str(p), values=(kind,p.name,sub)); count+=1
        self.parts_count.configure(text=f'{count} archivos XML')
        self.set_status(f'{len(files)} XDAT completo(s) · {count} archivos por partes.',True)

    def remove_selected(self):
        selected=self.tree.selection()
        if not selected:return
        if not messagebox.askyesno('Quitar archivos',f'¿Quieres quitar {len(selected)} archivo(s) XML de la carpeta de partes?'):
            return
        removed=0
        for iid in selected:
            p=Path(iid)
            try:
                if p.exists():p.unlink();removed+=1
            except Exception as e: messagebox.showerror('Error',str(e))
        self.refresh(); self.set_status(f'{removed} archivo(s) quitado(s).',True)

    def open_selected_xml(self,event=None):
        sel=self.tree.selection()
        if not sel:return
        p=Path(sel[0]); self.open_folder(p.parent)

    def decompile(self):
        source=self.selected_xdat()
        if not source or not source.exists():
            messagebox.showwarning('Falta XDAT','Primero agrega o selecciona un archivo .xdat en XDAT COMPLETO.')
            return
        existing=list((PARTS_DIR/'windows').glob('*.xml'))+list((PARTS_DIR/'shortcuts').glob('*.xml'))
        if existing and not messagebox.askyesno('Reemplazar partes',f'La carpeta contiene {len(existing)} XML. Descompilar reemplazará esos XML por los del archivo seleccionado. ¿Continuar?'):
            return
        try:
            self.set_status('Descompilando XDAT…')
            data=source.read_bytes()
            windows,shortcuts=decompile_to_folder(data,PARTS_DIR)
            self.refresh()
            self.set_status(f'Descompilación terminada: {windows} ventanas y {shortcuts} accesos directos.',True)
            messagebox.showinfo('Descompilación terminada',f'Se generaron {windows} ventanas y {shortcuts} accesos directos.\n\nLos XML están en la carpeta "xdat por partes".')
        except Exception as e:
            self.set_status('Error al descompilar.',False)
            messagebox.showerror('Error al descompilar',f'{e}\n\n{traceback.format_exc()}')

    def compile(self):
        xmls=list((PARTS_DIR/'windows').glob('*.xml'))+list((PARTS_DIR/'shortcuts').glob('*.xml'))
        if not xmls:
            messagebox.showwarning('No hay partes','Agrega archivos XML o descompila un XDAT antes de compilar.')
            return
        source=self.selected_xdat()
        original_data=None
        if source and source.exists():
            try: original_data=source.read_bytes()
            except Exception as e:
                messagebox.showerror('No se pudo leer el XDAT original',str(e)); return
        elif not (PARTS_DIR/'__xdat_meta.json').exists():
            if not messagebox.askyesno('Falta archivo original','No hay un XDAT original ni metadatos de descompilación. Se compilarán los XML con los valores predeterminados disponibles. ¿Continuar?'):
                return
        output=COMPLETE_DIR/OUTPUT_NAME
        if source and source.resolve()==output.resolve():
            output=COMPLETE_DIR/'interface_compilado_nuevo.xdat'
        if output.exists() and not messagebox.askyesno('Reemplazar compilado',f'Ya existe {output.name}. ¿Quieres reemplazarlo? Se guardará una copia .bak.'):
            return
        try:
            self.set_status(f'Compilando {len(xmls)} archivos XML…')
            data,windows,shortcuts=compile_from_folder(PARTS_DIR,original_data)
            # Final independent validation before writing anything.
            parsed=parse_xdat(data)
            if len(parsed['windows'])!=windows or len(parsed['shortcuts'])!=shortcuts:
                raise ValueError('La verificación final no coincide con el contenido esperado.')
            if output.exists(): self.backup_if_exists(output)
            temp=output.with_suffix(output.suffix+'.tmp')
            temp.write_bytes(data)
            if temp.read_bytes()!=data: raise ValueError('El archivo temporal no coincide con el resultado compilado.')
            temp.replace(output)
            self.refresh()
            self.xdat_combo.set(output.name)
            self.set_status(f'Compilación terminada: {windows} ventanas y {shortcuts} accesos directos.',True)
            messagebox.showinfo('Compilación terminada',f'Se creó:\n{output}\n\nVentanas: {windows}\nAccesos directos: {shortcuts}\nTamaño: {len(data):,} bytes\n\nEl archivo original se conservó sin cambios.')
        except Exception as e:
            self.set_status('Error al compilar. No se reemplazó ningún XDAT.',False)
            messagebox.showerror('Error al compilar',f'{e}\n\n{traceback.format_exc()}')


def main():
    root=tk.Tk()
    XdatApp(root)
    root.mainloop()

if __name__=='__main__': main()
