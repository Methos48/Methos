@echo off
setlocal
cd /d "%~dp0"
set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" (
  echo Instala Inno Setup 6 para crear el instalador: https://jrsoftware.org/isdl.php
  pause
  exit /b 1
)
"%ISCC%" MethosXDAT.iss
if errorlevel 1 goto error
echo Instalador creado en installer\output.
pause
exit /b 0
:error
echo Error creando el instalador.
pause
exit /b 1
