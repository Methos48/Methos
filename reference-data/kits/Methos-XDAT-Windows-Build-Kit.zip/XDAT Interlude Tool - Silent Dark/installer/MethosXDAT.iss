; Methos XDAT - Inno Setup
#define MyAppName "Methos XDAT"
#define MyAppVersion "1.0.0"
#define MyAppExeName "Methos XDAT.exe"

[Setup]
AppId={{9B8D3E6C-9F10-4D2D-AB6D-8E30A3E4C5D1}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
DefaultDirName={localappdata}\Programs\Methos XDAT
DefaultGroupName={#MyAppName}
OutputDir=output
OutputBaseFilename=Methos_XDAT_Setup_1.0.0
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=lowest
ArchitecturesInstallIn64BitMode=x64
UninstallDisplayIcon={app}\{#MyAppExeName}
DisableProgramGroupPage=yes

[Languages]
Name: "spanish"; MessagesFile: "compiler:Languages\Spanish.isl"

[Tasks]
Name: "desktopicon"; Description: "Crear un acceso directo en el escritorio"; GroupDescription: "Accesos directos:"; Flags: unchecked

[Files]
Source: "..\dist\Methos XDAT\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\xdat completo\*"; DestDir: "{userdocs}\Methos XDAT\xdat completo"; Flags: ignoreversion onlyifdoesntexist recursesubdirs createallsubdirs
Source: "..\xdat por partes\*"; DestDir: "{userdocs}\Methos XDAT\xdat por partes"; Flags: ignoreversion onlyifdoesntexist recursesubdirs createallsubdirs

[Dirs]
Name: "{userdocs}\Methos XDAT\xdat completo"
Name: "{userdocs}\Methos XDAT\xdat por partes\windows"
Name: "{userdocs}\Methos XDAT\xdat por partes\shortcuts"

[Icons]
Name: "{autoprograms}\Methos XDAT"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\Methos XDAT"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Abrir Methos XDAT"; Flags: postinstall nowait skipifsilent
