@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 app.py
  if not errorlevel 1 goto end
)
where python >nul 2>nul
if %errorlevel%==0 (
  python app.py
  if not errorlevel 1 goto end
)
echo.
echo No se encontro Python 3 instalado.
echo Este programa necesita Python 3.10 o superior.
echo Se abrira la pagina oficial para instalarlo.
start "" "https://www.python.org/downloads/windows/"
echo.
echo Instala Python marcando la opcion "Add Python to PATH" y vuelve a ejecutar Start.bat.
pause
:end
endlocal
