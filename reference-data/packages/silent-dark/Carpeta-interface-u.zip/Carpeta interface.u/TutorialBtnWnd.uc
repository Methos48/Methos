//================================================================================
// TutorialBtnWnd.
//================================================================================

class TutorialBtnWnd extends UICommonAPI;

function OnLoad ()
{
	RegisterEvent(1510);
}

function OnEvent (int Event_ID, string param)
{
	local int iEffectNumber;

	ParseInt(param,"QuestionID",iEffectNumber);
	switch (Event_ID)
	{
		case 1510:
		ShowWindowWithFocus("TutorialBtnWnd");
		Class'UIAPI_EFFECTBUTTON'.BeginEffect("TutorialBtnWnd.btnTutorial",iEffectNumber);
		break;
		default:
	}
}

function OnClickButton (string strID)
{
	switch (strID)
	{
		case "btnTutorial":
		HideWindow("TutorialBtnWnd");
		break;
		default:
	}
}

