//================================================================================
// ManorSeedInfoSettingWnd.
//================================================================================

class ManorSeedInfoSettingWnd extends UICommonAPI;

const DIALOG_ID_SETTODAY=666;
const DIALOG_ID_STOP=555;
const COLUMN_CNT=10;
const REWARD_TYPE_2=9;
const REWARD_TYPE_1=8;
const SEED_LEVEL=7;
const MAXIMUM_CROP_PRICE=6;
const MINIMUM_CROP_PRICE=5;
const TOMORROW_PRICE=4;
const TOMORROW_VOLUME_OF_SALES=3;
const TODAY_PRICE=2;
const TODAY_VOLUME_OF_SALES=1;
const SEED_NAME=0;
var int m_ManorID;
var int m_SumOfDefaultPrice;

function OnLoad ()
{
	RegisterEvent(2656);
	RegisterEvent(2657);
	RegisterEvent(2658);
	RegisterEvent(2659);
	RegisterEvent(1710);
	m_ManorID = -1;
	m_SumOfDefaultPrice = 0;
}

function OnEvent (int Event_ID, string a_Param)
{
	switch (Event_ID)
	{
		case 2656:
		HandleShow(a_Param);
		break;
		case 2657:
		HandleAddItem(a_Param);
		break;
		case 2658:
		CalculateSumOfDefaultPrice();
		ShowWindowWithFocus("ManorSeedInfoSettingWnd");
		break;
		case 2659:
		HandleChangeValue(a_Param);
		break;
		case 1710:
		HandleDialogOK();
		break;
		default:
	}
}

function HandleDialogOK ()
{
	local int dialogID;

	if ( UnknownFunction129(DialogIsMine()) )
	{
		return;
	}
	dialogID = DialogGetID();
	switch (dialogID)
	{
		case 555:
		HandleStop();
		break;
		case 666:
		HandleSetToday();
		break;
		default:
	}
}

function HandleStop ()
{
	local int i;
	local int RecordCnt;
	local LVDataRecord Record;
	local LVDataRecord recordClear;

	RecordCnt = Class'UIAPI_LISTCTRL'.GetRecordCount("ManorSeedInfoSettingWnd.ManorSeedInfoSettingListCtrl");
	Debug(UnknownFunction112("???:",string(RecordCnt)));
	i = 0;
	if ( UnknownFunction150(i,RecordCnt) )
	{
		Record = recordClear;
		Record = Class'UIAPI_LISTCTRL'.GetRecord("ManorSeedInfoSettingWnd.ManorSeedInfoSettingListCtrl",i);
		Record.LVDataList[3].szData = "0";
		Record.LVDataList[4].szData = "0";
		Class'UIAPI_LISTCTRL'.ModifyRecord("ManorSeedInfoSettingWnd.ManorSeedInfoSettingListCtrl",i,Record);
		UnknownFunction163(i);
		goto JL0067;
	}
	CalculateSumOfDefaultPrice();
}

function HandleSetToday ()
{
	local int i;
	local int RecordCnt;
	local LVDataRecord Record;
	local LVDataRecord recordClear;

	RecordCnt = Class'UIAPI_LISTCTRL'.GetRecordCount("ManorSeedInfoSettingWnd.ManorSeedInfoSettingListCtrl");
	i = 0;
	if ( UnknownFunction150(i,RecordCnt) )
	{
		Record = recordClear;
		Record = Class'UIAPI_LISTCTRL'.GetRecord("ManorSeedInfoSettingWnd.ManorSeedInfoSettingListCtrl",i);
		Record.LVDataList[3].szData = Record.LVDataList[1].szData;
		Record.LVDataList[4].szData = Record.LVDataList[2].szData;
		Class'UIAPI_LISTCTRL'.ModifyRecord("ManorSeedInfoSettingWnd.ManorSeedInfoSettingListCtrl",i,Record);
		UnknownFunction163(i);
		goto JL0052;
	}
	CalculateSumOfDefaultPrice();
}

function HandleShow (string a_Param)
{
	local int ManorID;
	local string ManorName;

	ParseInt(a_Param,"ManorID",ManorID);
	ParseString(a_Param,"ManorName",ManorName);
	m_ManorID = ManorID;
	Class'UIAPI_TEXTBOX'.SetText("ManorSeedInfoSettingWnd.txtManorName",ManorName);
	DeleteAll();
}

function HandleChangeValue (string a_Param)
{
	local int TomorrowSalesVolume;
	local int TomorrowPrice;
	local LVDataRecord Record;
	local int SelectedIndex;

	ParseInt(a_Param,"TomorrowSalesVolume",TomorrowSalesVolume);
	ParseInt(a_Param,"TomorrowPrice",TomorrowPrice);
	SelectedIndex = Class'UIAPI_LISTCTRL'.GetSelectedIndex("ManorSeedInfoSettingWnd.ManorSeedInfoSettingListCtrl");
	Record = Class'UIAPI_LISTCTRL'.GetSelectedRecord("ManorSeedInfoSettingWnd.ManorSeedInfoSettingListCtrl");
	Record.LVDataList[3].szData = string(TomorrowSalesVolume);
	Record.LVDataList[4].szData = string(TomorrowPrice);
	Class'UIAPI_LISTCTRL'.ModifyRecord("ManorSeedInfoSettingWnd.ManorSeedInfoSettingListCtrl",SelectedIndex,Record);
	CalculateSumOfDefaultPrice();
}

function DeleteAll ()
{
	Class'UIAPI_LISTCTRL'.DeleteAllItem("ManorSeedInfoSettingWnd.ManorSeedInfoSettingListCtrl");
}

function OnDBClickListCtrlRecord (string strID)
{
	switch (strID)
	{
		case "ManorSeedInfoSettingListCtrl":
		OnChangeBtn();
		break;
		default:
	}
}

function OnClickButton (string strID)
{
	Debug(UnknownFunction112(" ",strID));
	switch (strID)
	{
		case "btnChangeSell":
		OnChangeBtn();
		break;
		case "btnSetToday":
		DialogSetID(666);
		DialogShow(4,GetSystemMessage(1601));
		break;
		case "btnStop":
		DialogSetID(555);
		DialogShow(4,GetSystemMessage(1600));
		break;
		case "btnOk":
		OnOk();
		break;
		case "btnCancel":
		HideWindow("ManorSeedInfoSettingWnd");
		break;
		default:
	}
}

function OnOk ()
{
	local int RecordCount;
	local LVDataRecord Record;
	local LVDataRecord recordClear;
	local int i;
	local string param;

	RecordCount = Class'UIAPI_LISTCTRL'.GetRecordCount("ManorSeedInfoSettingWnd.ManorSeedInfoSettingListCtrl");
	ParamAdd(param,"ManorID",string(m_ManorID));
	ParamAdd(param,"SeedCnt",string(RecordCount));
	i = 0;
	if ( UnknownFunction150(i,RecordCount) )
	{
		Record = recordClear;
		Record = Class'UIAPI_LISTCTRL'.GetRecord("ManorSeedInfoSettingWnd.ManorSeedInfoSettingListCtrl",i);
		ParamAdd(param,UnknownFunction112("SeedID",string(i)),string(Record.nReserved1));
		ParamAdd(param,UnknownFunction112("TomorrowSalesVolume",string(i)),Record.LVDataList[3].szData);
		ParamAdd(param,UnknownFunction112("TomorrowPrice",string(i)),Record.LVDataList[4].szData);
		UnknownFunction163(i);
		goto JL0088;
	}
	RequestSetSeed(param);
	HideWindow("ManorSeedInfoSettingWnd");
}

function OnChangeBtn ()
{
	local LVDataRecord Record;
	local string param;

	Record = Class'UIAPI_LISTCTRL'.GetSelectedRecord("ManorSeedInfoSettingWnd.ManorSeedInfoSettingListCtrl");
	ParamAdd(param,"SeedName",Record.LVDataList[0].szData);
	ParamAdd(param,"TomorrowVolumeOfSales",Record.LVDataList[3].szData);
	ParamAdd(param,"TomorrowLimit",string(Record.nReserved2));
	ParamAdd(param,"TomorrowPrice",Record.LVDataList[4].szData);
	ParamAdd(param,"MinCropPrice",Record.LVDataList[5].szData);
	ParamAdd(param,"MaxCropPrice",Record.LVDataList[6].szData);
	ExecuteEvent(2660,param);
}

function HandleAddItem (string a_Param)
{
	local LVDataRecord Record;
	local int SeedID;
	local string SeedName;
	local int TodaySeedTotalCnt;
	local int TodaySeedPrice;
	local int NextSeedTotalCnt;
	local int NextSeedPrice;
	local int MinCropPrice;
	local int MaxCropPrice;
	local int SeedLevel;
	local string RewardType1;
	local string RewardType2;
	local int MaxSeedTotalCnt;
	local int DefaultSeedPrice;

	ParseInt(a_Param,"SeedID",SeedID);
	ParseString(a_Param,"SeedName",SeedName);
	ParseInt(a_Param,"TodaySeedTotalCnt",TodaySeedTotalCnt);
	ParseInt(a_Param,"TodaySeedPrice",TodaySeedPrice);
	ParseInt(a_Param,"TodayNextSeedTotalCnt",NextSeedTotalCnt);
	ParseInt(a_Param,"NextSeedPrice",NextSeedPrice);
	ParseInt(a_Param,"MinCropPrice",MinCropPrice);
	ParseInt(a_Param,"MaxCropPrice",MaxCropPrice);
	ParseInt(a_Param,"SeedLevel",SeedLevel);
	ParseString(a_Param,"RewardType1",RewardType1);
	ParseString(a_Param,"RewardType2",RewardType2);
	ParseInt(a_Param,"MaxSeedTotalCnt",MaxSeedTotalCnt);
	ParseInt(a_Param,"DefaultSeedPrice",DefaultSeedPrice);
	Record.LVDataList.Length = 10;
	Record.LVDataList[0].szData = SeedName;
	Record.LVDataList[1].szData = string(TodaySeedTotalCnt);
	Record.LVDataList[2].szData = string(TodaySeedPrice);
	Record.LVDataList[3].szData = string(NextSeedTotalCnt);
	Record.LVDataList[4].szData = string(NextSeedPrice);
	Record.LVDataList[5].szData = string(MinCropPrice);
	Record.LVDataList[6].szData = string(MaxCropPrice);
	Record.LVDataList[7].szData = string(SeedLevel);
	Record.LVDataList[8].szData = RewardType1;
	Record.LVDataList[9].szData = RewardType2;
	Record.nReserved1 = SeedID;
	Record.nReserved2 = MaxSeedTotalCnt;
	Record.nReserved3 = DefaultSeedPrice;
	Class'UIAPI_LISTCTRL'.InsertRecord("ManorSeedInfoSettingWnd.ManorSeedInfoSettingListCtrl",Record);
}

function CalculateSumOfDefaultPrice ()
{
	local LVDataRecord Record;
	local LVDataRecord recordClear;
	local int ItemCnt;
	local int i;
	local int tmpMulti;
	local string adenaString;

	m_SumOfDefaultPrice = 0;
	ItemCnt = Class'UIAPI_LISTCTRL'.GetRecordCount("ManorSeedInfoSettingWnd.ManorSeedInfoSettingListCtrl");
	i = 0;
	if ( UnknownFunction150(i,ItemCnt) )
	{
		Record = recordClear;
		Record = Class'UIAPI_LISTCTRL'.GetRecord("ManorSeedInfoSettingWnd.ManorSeedInfoSettingListCtrl",i);
		tmpMulti = UnknownFunction144(Record.nReserved3,int(Record.LVDataList[3].szData));
		UnknownFunction161(m_SumOfDefaultPrice,tmpMulti);
		UnknownFunction163(i);
		goto JL0059;
	}
	adenaString = MakeCostString(string(m_SumOfDefaultPrice));
	Class'UIAPI_TEXTBOX'.SetText("ManorSeedInfoSettingWnd.txtVarNextTotalExpense",adenaString);
}

