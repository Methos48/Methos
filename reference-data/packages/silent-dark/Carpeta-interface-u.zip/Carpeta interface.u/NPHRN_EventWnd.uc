//================================================================================
// NPHRN_EventWnd.
//================================================================================

class NPHRN_EventWnd extends UICommonAPI;

var WindowHandle Me;
var WindowHandle EventBox_Critical;
var WindowHandle EventBox_Resisted;
var TargetStatusWnd TargetStatusWnd;

function OnRegisterEvent ()
{
	RegisterEvent(290);
	RegisterEvent(2990);
	RegisterEvent(580);
}

function OnLoad ()
{
	if ( BoolEquals(GetOptionBool("Custom","ShowEvent"),True) )
	{
		UnknownFunction113('AdjustState');
	} else {
		UnknownFunction113('HidingState');
	}
	OnRegisterEvent();
	InitHandle();
}

function OnEnterState (name a_PreStateName)
{
	Me.SetTimer(10,500);
}

function OnTimer (int TimerID)
{
	switch (TimerID)
	{
		case 1:
		Me.KillTimer(1);
		EventBox_Critical.HideWindow();
		EventBox_Critical.SetAlpha(255);
		break;
		case 2:
		Me.KillTimer(2);
		EventBox_Resisted.HideWindow();
		EventBox_Resisted.SetAlpha(255);
		break;
		case 10:
		Me.KillTimer(10);
		InitHandle();
		break;
		case 11:
		Me.KillTimer(11);
		Class'UIAPI_WINDOW'.HideWindow("TargetStatusWnd.ReceiveMagicSkillUse");
		break;
		default:
	}
}

function InitHandle ()
{
	Me = GetHandle("NPHRN_EventWnd");
	EventBox_Critical = GetHandle("NPHRN_EventWnd.EventBox_Critical");
	EventBox_Resisted = GetHandle("NPHRN_EventWnd.EventBox_Resisted");
	TargetStatusWnd = TargetStatusWnd(GetScript("TargetStatusWnd"));
}

state HidingState
{
	function OnEvent (int Event_ID, string param)
	{
		if ( Equals(Event_ID,2990) )
		{
			UnknownFunction113('AdjustState');
		}
	}
	
}

state AdjustState
{
	function OnEvent (int Event_ID, string param)
	{
		switch (Event_ID)
		{
			case 2990:
			UnknownFunction113('HidingState');
			break;
			case 580:
			Resisted_Critical(param);
			break;
			case 290:
			t_RecvMagicSkillUse(param);
			break;
			default:
		}
	}
	
}

function Resisted_Critical (string param)
{
	local int Index;

	ParseInt(param,"Index",Index);
	switch (Index)
	{
		case 44:
		case 1280:
		if ( Class'UIAPI_WINDOW'.IsShowWindow("EventBox_Resisted") )
		{
			return;
		}
		EventBox_Critical.ShowWindow();
		EventBox_Critical.SetAlpha(0,2.0);
		Me.SetTimer(1,2000);
		break;
		case 139:
		EventBox_Resisted.ShowWindow();
		EventBox_Resisted.SetAlpha(0,2.0);
		Me.SetTimer(2,2000);
		break;
		default:
	}
}

function t_RecvMagicSkillUse (string param)
{
	local int SkillID;
	local int AttackerID;

	ParseInt(param,"SkillID",SkillID);
	ParseInt(param,"AttackerID",AttackerID);
	if ( Equals(AttackerID,TargetStatusWnd.m_targetID) )
	{
		if ( NotBool(IsConsumable(SkillID)) )
		{
			Class'UIAPI_TEXTURECTRL'.SetTexture("TargetStatusWnd.Tex",Class'UIDATA_SKILL'.GetIconName(SkillID,1));
			Class'UIAPI_WINDOW'.ShowWindow("TargetStatusWnd.ReceiveMagicSkillUse");
			Me.KillTimer(11);
			Me.SetTimer(11,2000);
		}
	}
}

