//================================================================================
// EnchantAIWnd.
//================================================================================

class EnchantAIWnd extends UICommonAPI;

var WindowHandle m_hHelpWnd;
var WindowHandle Me;
var bool IsMinimized;
var ButtonHandle b_GetNPCInfo;
var ButtonHandle b_SelectEdit;
var ButtonHandle b_CustomEdit;
var ButtonHandle b_BypassEdit;
var CheckBoxHandle checkScrollSave;
var CheckBoxHandle checkScrollDestroy;
var CheckBoxHandle checkScrollStack;
var ItemWindowHandle m_DragboxItem1;
var ItemWindowHandle m_DragboxItem11;
var ItemWindowHandle m_DragBoxItem2;
var ItemWindowHandle m_DragboxItem3;
var ItemWindowHandle m_DragBoxItem4;
var ItemWindowHandle m_DragBoxItem5;
var ItemWindowHandle m_InventoryList;
var array<string> InventorySlot;
var ItemInfo ScrollItemInfo;
var ItemInfo BlessScrollItemInfo;
var ItemInfo EquipItemInfo;
var ItemInfo WeaponItemInfo;
var ItemInfo LifeStoneItemInfo;
var ItemInfo GemStoneItemInfo;
var ItemInfo SkillInfo;
var int EquipItemServerID;
var int BlessScrollServerID;
var int ScrollServerID;
var int GemstoneCount;
var bool EnableEnchantProcess;
var bool EnableRefineryProcess;
var bool EnableSkillProcess;
var bool EnchantItem_UseOldScroll;
var bool EnchantItem_UseDestrItem;
var bool EnchantItem_IsStack;
var bool EnchantItem_UpdateBless;
var int EnchantItem_ResetTo;
var int EnchantItem_Power;
var int EnchantItem_Record;
var int EnchantItem_EnchantTo;
var int EnchantItem_EnchantSaveTo;
var int EnchantItem_CurrentEnchantLevel;
var int ComboEnchantSelect;
var int EnchantSkillLimit;
var TextBoxHandle m_InstructionText;
var TextBoxHandle m_InstructionText2;
var TextBoxHandle m_InstructionText3;
var bool SearchAll;
var bool SearchPassive;
var bool SearchActive;
var bool SearchChance;
var bool SearchStat;
var bool SearchSelect;
var bool SearchCustom;
var int SearchQuality;
var int TIMER_ENCHANT_DELAY;
var int TIMER_ENCHANT2_DELAY;
var int TIMER_REFINERY_NPCTALK_DELAY;
var int TIMER_REFINERY_UNREF_DELAY;
var int TIMER_REFINERY_WEAPON_DELAY;
var int TIMER_REFINERY_LIFESTONE_DELAY;
var int TIMER_REFINERY_GEMSTONE_DELAY;
var int TIMER_REFINERY_FINAL_DELAY;
var bool EnchantInUse;
var int TIMER_ENCHANTSKILL_DELAY;
var string EnchantInstruction_SelectScroll;
var string EnchantInstruction_SelectItem;
var string EnchantInstruction_CheckOption;
var string EnchantInstruction_Process;
var string EnchantInstruction_Result;
var string EnchantInstruction_Stop;
var string EnchantInstruction_Error_Destroy;
var string EnchantInstruction_Error_ScrollEnd;
var string DelayScroll;
var string DelayEnchant;
var string DelayScrollTooltip;
var string DelayEnchantTooltip;
var string Second;
var string Quantity;
var string NpcInfoDefault;
var string NpcInfoName;
var string NpcInfoID;
var string DelayNPC;
var string DelayUN;
var string DelayWP;
var string DelayLS;
var string DelayGS;
var string DelayConfirm;
var string DelayNPCTooltip;
var string DelayUNTooltip;
var string DelayWPTooltip;
var string DelayLSTooltip;
var string DelayGSTooltip;
var string DelayConfirmTooltip;
var string RefineryInstruction_SelectWeapon;
var string RefineryInstruction_SelectLS;
var string RefineryInstruction_CheckOption;
var string RefineryInstruction_Process;
var string RefineryInstruction_Stop;
var string RefineryInstruction_Result;
var string RefineryInstruction_Error_NPC;
var string RefineryInstruction_Error_LS;
var string RefineryInstruction_Error_GS;
var string RefineryInstruction_Error_Adena;
var string RefineryInstruction_Error_FULL;
var string RefineryBypass;
var string UnRefineryBypass;
var string SkillDelay;
var string SkillDelayTooltip;
var string SkillInstruction_Result;
var string SkillInstruction_CheckOption;
var string SkillInstruction_Process;
var string SkillInstruction_SelectSkill;
var string SkillInstruction_Error_NoEnchant;
var string SkillInstruction_Error_NoBook;
var string SkillInstruction_Error_EnchantLimit;
var UserInfo NPCInfo;
var bool UseNpcSimulation;
var string RefBypass_1;
var string RefBypass_2;
var string RefBypass_3;
var string UnRefBypass_1;
var string UnRefBypass_2;
var string UnRefBypass_3;
var string CryptRefBypass_1;
var string CryptRefBypass_2;
var string CryptRefBypass_3;
var string CryptUnRefBypass_1;
var string CryptUnRefBypass_2;
var string CryptUnRefBypass_3;
var bool UseRefinedBypass_1;
var bool UseRefinedBypass_2;
var bool UseRefinedBypass_3;
var bool UseUnRefinedBypass_1;
var bool UseUnRefinedBypass_2;
var bool UseUnRefinedBypass_3;
var bool UseRefinedBypass;
var bool UseUnRefinedBypass;
var bool UseCryptBypass;
const MULTY_LS_SlIDER=250;
const TIMER_SKILL_ID=10500;
const TIMER_REFINERY_UNREF_BYPASS_3_ID=10462;
const TIMER_REFINERY_UNREF_BYPASS_2_ID=10461;
const TIMER_REFINERY_UNREF_BYPASS_1_ID=10460;
const TIMER_REFINERY_REF_BYPASS_3_ID=10459;
const TIMER_REFINERY_REF_BYPASS_2_ID=10458;
const TIMER_REFINERY_REF_BYPASS_1_ID=10457;
const TIMER_REFINERY_FINAL_ID=10456;
const TIMER_REFINERY_GEMSTONE_ID=10455;
const TIMER_REFINERY_LIFESTONE_ID=10454;
const TIMER_REFINERY_WEAPON_ID=10453;
const TIMER_REFINERY_UNREF_ID=10452;
const TIMER_REFINERY_NPC_REF_ID=10451;
const TIMER_REFINERY_NPC_UNREF_ID=10450;
const TIMER_ENCHANT_FUN_ID=10301;
const TIMER_ENCHANT_ID=10300;

function OnLoad ()
{
	RegisterEvents();
	RegisterXmls();
	CheckFirst();
	Innit();
	Reset();
}

function RegisterXmls ()
{
	m_hHelpWnd = GetHandle("EnchantAIHelpWnd");
	Me = GetHandle("EnchantAIWnd");
	m_DragboxItem1 = ItemWindowHandle(GetHandle("EnchantAIWnd.ItemDragBoxe1Wnd.ItemDragBox1"));
	m_DragboxItem11 = ItemWindowHandle(GetHandle("EnchantAIWnd.ItemDragBox11Wnd.ItemDragBox11"));
	m_DragBoxItem2 = ItemWindowHandle(GetHandle("EnchantAIWnd.ItemDragBoxe2Wnd.ItemDragBox2"));
	m_DragboxItem3 = ItemWindowHandle(GetHandle("EnchantAIWnd.ItemDragBox3Wnd.ItemDragBox3"));
	m_DragBoxItem4 = ItemWindowHandle(GetHandle("EnchantAIWnd.ItemDragBox4Wnd.ItemDragBox4"));
	m_DragBoxItem5 = ItemWindowHandle(GetHandle("EnchantAIWnd.ItemDragBox5Wnd.ItemDragBox5"));
	m_InventoryList = ItemWindowHandle(GetHandle("InventoryWnd.InventoryItem"));
	checkScrollSave = CheckBoxHandle(GetHandle("InventoryWnd.checkSaveEnchant"));
	checkScrollDestroy = CheckBoxHandle(GetHandle("InventoryWnd.checkUseDestroyItem"));
	checkScrollStack = CheckBoxHandle(GetHandle("InventoryWnd.checkIsStuck"));
	b_GetNPCInfo = ButtonHandle(GetHandle("EnchantAIWnd.btnGetNPCInfo"));
	b_SelectEdit = ButtonHandle(GetHandle("EnchantAIWnd.btnSelectEdit"));
	b_CustomEdit = ButtonHandle(GetHandle("EnchantAIWnd.btnCustomEdit"));
	b_BypassEdit = ButtonHandle(GetHandle("EnchantAIWnd.btnBypassEdit"));
	m_InstructionText = TextBoxHandle(GetHandle("EnchantAIWnd.txtInstruction"));
	m_InstructionText2 = TextBoxHandle(GetHandle("EnchantAIWnd.txtInstruction2"));
	m_InstructionText3 = TextBoxHandle(GetHandle("EnchantAIWnd.txtInstruction3"));
}

function RegisterEvents ()
{
	RegisterEvent(2770);
	RegisterEvent(2780);
	RegisterEvent(2790);
	RegisterEvent(2800);
	RegisterEvent(2040);
	RegisterEvent(2890);
	RegisterEvent(580);
	RegisterEvent(980);
	RegisterEvent(990);
	RegisterEvent(2820);
	RegisterEvent(2830);
}

function OnHide ()
{
	if ( IsMinimized )
	{
		goto JL0012;
	}
	Reset();
}

function OnShow ()
{
	if ( IsMinimized )
	{
		IsMinimized = False;
	} else {
		Reset();
		IsMinimized = False;
	}
}

function OnMinimize ()
{
	IsMinimized = True;
}

function OnEvent (int a_EventID, string a_Param)
{
	switch (a_EventID)
	{
		case 580:
		if ( UnknownFunction129(EnchantInUse) )
		{
			HandleSystemMessage(a_Param);
		}
		break;
		case 2780:
		EV_GameStoneCheck(a_Param);
		break;
		case 980:
		TargetUpdate();
		break;
		case 990:
		ClearNpcInfo();
		break;
		case 2800:
		RefineryResult(a_Param);
		break;
		case 2820:
		RefineryCancelResult(a_Param);
		break;
		case 2830:
		OnUnRefineDoneResult(a_Param);
		break;
		default:
	}
}

function TargetUpdate ()
{
	local int m_nowTargetID;

	m_nowTargetID = Class'UIDATA_TARGET'.GetTargetID();
	if ( UnknownFunction155(NPCInfo.nID,m_nowTargetID) )
	{
		ClearNpcInfo();
	}
}

function Reset ()
{
	m_DragboxItem1.Clear();
	m_DragboxItem11.Clear();
	m_DragBoxItem2.Clear();
	m_DragboxItem1.EnableWindow();
	m_DragBoxItem2.DisableWindow();
	m_DragboxItem3.EnableWindow();
	m_DragBoxItem4.DisableWindow();
	m_InstructionText.SetText(EnchantInstruction_SelectScroll);
	m_InstructionText2.SetText(RefineryInstruction_SelectWeapon);
	m_InstructionText3.SetText(SkillInstruction_SelectSkill);
	Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.valRecord","");
	Class'UIAPI_EDITBOX'.SetString("EnchantAIWnd.editCount","0");
	Class'UIAPI_EDITBOX'.SetString("EnchantAIWnd.editEnchantLvl","0");
	ClearNpcInfo();
	ComboEnchantSelect = 0;
	UpdateEnchantSkillParam();
	Class'UIAPI_WINDOW'.SetAnchor("EnchantAIWnd.ItemEnchantTab.txtEquipItem","ItemDragBoxe2Wnd","TopCenter","TopCenter",0,40);
	Class'UIAPI_WINDOW'.SetAnchor("EnchantAIWnd.ItemEnchantTab.txtBlessScroll","ItemDragBoxe1Wnd","TopCenter","TopCenter",0,40);
	Class'UIAPI_WINDOW'.SetAnchor("EnchantAIWnd.SkillEnchantTab.txtSkillSlot","ItemDragBox5Wnd","TopCenter","TopCenter",0,40);
	EnchantInUse = True;
}

function Innit ()
{
	local int UseNpcSimulRef;
	local int CurrentTick;
	local int IntUseCryptBypass;
	local int IntUseRefinedBypass;
	local int IntUseRefinedBypass_1;
	local int IntUseRefinedBypass_2;
	local int IntUseRefinedBypass_3;
	local int IntUseUnRefinedBypass;
	local int IntUseUnRefinedBypass_1;
	local int IntUseUnRefinedBypass_2;
	local int IntUseUnRefinedBypass_3;

	GetINIBool("AutoRefinery","UseCryptBypass",IntUseCryptBypass,"Option");
	GetINIString("AutoRefinery","RefinedBypass_1",RefBypass_1,"Option");
	GetINIString("AutoRefinery","RefinedBypass_2",RefBypass_2,"Option");
	GetINIString("AutoRefinery","RefinedBypass_3",RefBypass_3,"Option");
	GetINIString("AutoRefinery","UnRefinedBypass_1",UnRefBypass_1,"Option");
	GetINIString("AutoRefinery","UnRefinedBypass_2",UnRefBypass_2,"Option");
	GetINIString("AutoRefinery","UnRefinedBypass_3",UnRefBypass_3,"Option");
	GetINIBool("AutoRefinery","UseRefinedBypass",IntUseRefinedBypass,"Option");
	GetINIBool("AutoRefinery","UseUnRefinedBypass",IntUseUnRefinedBypass,"Option");
	GetINIBool("AutoRefinery","UseRefinedBypass_1",IntUseRefinedBypass_1,"Option");
	GetINIBool("AutoRefinery","UseRefinedBypass_2",IntUseRefinedBypass_2,"Option");
	GetINIBool("AutoRefinery","UseRefinedBypass_3",IntUseRefinedBypass_3,"Option");
	GetINIBool("AutoRefinery","UseUnRefinedBypass_1",IntUseUnRefinedBypass_1,"Option");
	GetINIBool("AutoRefinery","UseUnRefinedBypass_2",IntUseUnRefinedBypass_2,"Option");
	GetINIBool("AutoRefinery","UseUnRefinedBypass_3",IntUseUnRefinedBypass_3,"Option");
	NPC_Simul_SetParam(False,bool(IntUseCryptBypass),bool(IntUseRefinedBypass),bool(IntUseRefinedBypass_1),bool(IntUseRefinedBypass_2),bool(IntUseRefinedBypass_3),bool(IntUseUnRefinedBypass),bool(IntUseUnRefinedBypass_1),bool(IntUseUnRefinedBypass_2),bool(IntUseUnRefinedBypass_3),RefBypass_1,RefBypass_2,RefBypass_3,UnRefBypass_1,UnRefBypass_2,UnRefBypass_3);
	EnchantItem_EnchantSaveTo = 3;
	EnchantItem_Power = 1;
	EnchantItem_ResetTo = 0;
	EnchantItem_UseOldScroll = False;
	EnchantItem_UseDestrItem = False;
	EnchantItem_IsStack = True;
	EnchantItem_UpdateBless = True;
	Class'UIAPI_CHECKBOX'.SetCheck("EnchantAIWnd.checkSaveEnchant",EnchantItem_UseOldScroll);
	Class'UIAPI_CHECKBOX'.SetCheck("EnchantAIWnd.checkUseDestroyItem",EnchantItem_UseDestrItem);
	Class'UIAPI_CHECKBOX'.SetCheck("EnchantAIWnd.checkIsStuck",EnchantItem_IsStack);
	Class'UIAPI_CHECKBOX'.SetCheck("EnchantAIWnd.checkBlessUpdate",EnchantItem_UpdateBless);
	Class'UIAPI_EDITBOX'.SetString("EnchantAIWnd.ScrollEnchantLvlEdit",string(EnchantItem_EnchantSaveTo));
	InvetorySlotName();
	InitLocalization();
	GetINIInt("AutoEnchant","Delay_ScrollSelect",CurrentTick,"Option");
	SetDelay("Delay_ScrollSelect",CurrentTick,250,TIMER_ENCHANT_DELAY);
	Class'UIAPI_SLIDERCTRL'.SetCurrentTick("EnchantAIWnd.EnchantDelay1SliderCtrl",CurrentTick);
	GetINIInt("AutoEnchant","Delay_EnchantItem",CurrentTick,"Option");
	SetDelay("Delay_EnchantItem",CurrentTick,250,TIMER_ENCHANT2_DELAY);
	Class'UIAPI_SLIDERCTRL'.SetCurrentTick("EnchantAIWnd.EnchantDelay2SliderCtrl",CurrentTick);
	GetINIInt("AutoRefinery","Delay_NPCTalk",CurrentTick,"Option");
	SetDelay("Delay_NPCTalk",CurrentTick,250,TIMER_REFINERY_NPCTALK_DELAY);
	Class'UIAPI_SLIDERCTRL'.SetCurrentTick("EnchantAIWnd.RefineryDelay1SliderCtrl",CurrentTick);
	GetINIInt("AutoRefinery","Delay_WP",CurrentTick,"Option");
	SetDelay("Delay_WP",CurrentTick,250,TIMER_REFINERY_WEAPON_DELAY);
	Class'UIAPI_SLIDERCTRL'.SetCurrentTick("EnchantAIWnd.RefineryDelay2SliderCtrl",CurrentTick);
	GetINIInt("AutoRefinery","Delay_LS",CurrentTick,"Option");
	SetDelay("Delay_LS",CurrentTick,250,TIMER_REFINERY_LIFESTONE_DELAY);
	Class'UIAPI_SLIDERCTRL'.SetCurrentTick("EnchantAIWnd.RefineryDelay3SliderCtrl",CurrentTick);
	GetINIInt("AutoRefinery","Delay_GS",CurrentTick,"Option");
	SetDelay("Delay_GS",CurrentTick,250,TIMER_REFINERY_GEMSTONE_DELAY);
	Class'UIAPI_SLIDERCTRL'.SetCurrentTick("EnchantAIWnd.RefineryDelay4SliderCtrl",CurrentTick);
	GetINIInt("AutoRefinery","Delay_UN",CurrentTick,"Option");
	SetDelay("Delay_UN",CurrentTick,250,TIMER_REFINERY_UNREF_DELAY);
	Class'UIAPI_SLIDERCTRL'.SetCurrentTick("EnchantAIWnd.RefineryDelay5SliderCtrl",CurrentTick);
	GetINIInt("AutoRefinery","Delay_Final",CurrentTick,"Option");
	SetDelay("Delay_Final",CurrentTick,250,TIMER_REFINERY_FINAL_DELAY);
	Class'UIAPI_SLIDERCTRL'.SetCurrentTick("EnchantAIWnd.RefineryDelay6SliderCtrl",CurrentTick);
	GetINIInt("AutoEnchantSkill","Delay_SkillEnchant",CurrentTick,"Option");
	SetDelay("Delay_SkillEnchant",CurrentTick,250,TIMER_ENCHANTSKILL_DELAY);
	Class'UIAPI_SLIDERCTRL'.SetCurrentTick("EnchantAIWnd.SkillEnchantDelay1SliderCtrl",CurrentTick);
	GetINIBool("AutoRefinery","UseNPCSimulation",UseNpcSimulRef,"Option");
	UseNpcSimulation = bool(UseNpcSimulRef);
	Class'UIAPI_CHECKBOX'.SetCheck("EnchantAIWnd.checkUseSimulRef",UseNpcSimulation);
	GetINIString("AutoRefinery","NPCSimulationBypass_Ref",RefineryBypass,"Option");
	GetINIString("AutoRefinery","NPCSimulationBypass_UnRef",UnRefineryBypass,"Option");
	ClearNpcInfo();
	SearchQuality = 0;
	ComboBox_Quality();
	ComboBoxParam();
}

function InitLocalization ()
{
	local string WindowName;
	local string RecommendPlace;
	local string MustPlace;
	local string EnchantTo;
	local string RecordEnchant;
	local string Scroll;
	local string ScrollBless;
	local string item;
	local string ScrollSave;
	local string ScrollSaveTxt;
	local string ScrollSaveTooltip;
	local string ScrollUseOtherEqipTooltip;
	local string ScrollUseOtherEqipTxt;
	local string ScrollIsStuckTooltip;
	local string ScrollIsStuckTxt;
	local string ScrollEcnhantBlessUpdate;
	local string TypeAll;
	local string TypePassive;
	local string TypeActive;
	local string TypeChance;
	local string TypeStat;
	local string TypeSelect;
	local string TypeCustom;
	local string Quality;
	local string UseNpcSimulation;
	local string EditSelectList;
	local string EditCustomList;
	local string EditBypass;
	local string GetNpcInfoTooltim;
	local string Skill;
	local string SkillRecommend;
	local string SkillType;
	local string SkillEnchantTo;

	WindowName = "Interface AI: Automatic enhancement";
	RecommendPlace = "Place only unequipped items!";
	MustPlace = "Please place only unequipped items!";
	EnchantTo = "Enchant to:";
	RecordEnchant = "Record:";
	DelayScroll = "Delay(scroll)";
	DelayEnchant = "Delay(item)";
	Second = "sec";
	Quantity = "qty.";
	Scroll = "Scroll";
	ScrollBless = "Bless\nScroll";
	item = "Item";
	ScrollSave = "Save Enchant:";
	ScrollSaveTxt = "Use ordinary scrolls?";
	ScrollSaveTooltip = "Use ordinary scrolls to the save level enchant?";
	ScrollUseOtherEqipTooltip = "Use other item (ID) if enchant fail?";
	ScrollUseOtherEqipTxt = "Use other item if fail?";
	ScrollIsStuckTooltip = "Scroll is stackable? (More than 1 in one slot)";
	ScrollIsStuckTxt = "Scroll is stackable?";
	ScrollEcnhantBlessUpdate = "Stopped on enchant process?";
	DelayScrollTooltip = "Delay to emulate pressing of scroll.";
	DelayEnchantTooltip = "Delay to emulate selection of item.";
	EnchantInstruction_SelectScroll = "Select the scroll to be enchanted.";
	EnchantInstruction_SelectItem = "Select the item to be enchanted.";
	EnchantInstruction_CheckOption = "Write how much enchant levels you want?";
	EnchantInstruction_Process = "Enchant in process...";
	EnchantInstruction_Result = "Congratulations!\nYou get";
	EnchantInstruction_Stop = "Enchant stopped.";
	EnchantInstruction_Error_Destroy = "Oops, the item was broken ...";
	EnchantInstruction_Error_ScrollEnd = "The scrolls of enchantment was ended!";
	TypeAll = "Type: All";
	TypePassive = "Type: Passive";
	TypeActive = "Type: Active";
	TypeChance = "Type: Chance";
	TypeStat = "Type: Stat";
	TypeSelect = "Select:";
	TypeCustom = "Type: Custom";
	Quality = "Quality:";
	UseNpcSimulation = "Use the dialog with NPC";
	NpcInfoDefault = "Undefined";
	NpcInfoName = "Name";
	NpcInfoID = "ID";
	DelayNPC = "Delay(NPC)";
	DelayUN = "Delay(Cancel)";
	DelayWP = "Delay(Weapon)";
	DelayLS = "Delay(LS)";
	DelayGS = "Delay(GemStone)";
	DelayConfirm = "Delay(Confirm)";
	DelayNPCTooltip = "Delay to simulate dialog with npc.";
	DelayUNTooltip = "Delay to cancel refinery.\nDefault 2 seconds.";
	DelayWPTooltip = "Delay to insert Weapon.";
	DelayLSTooltip = "Delay to insert LifeStone.";
	DelayGSTooltip = "Delay to insert GemStone.";
	DelayConfirmTooltip = "Delay to confirm refinery.\nDefault 1.9 seconds.";
	GetNpcInfoTooltim = "Get NPC Info.";
	EditSelectList = "Edit select list";
	EditCustomList = "Edit custom list";
	EditBypass = "Bypass Editor";
	RefineryInstruction_SelectWeapon = "Place Weapon to refined.";
	RefineryInstruction_SelectLS = "Place LifeStone.";
	RefineryInstruction_CheckOption = "Please, check the options.";
	RefineryInstruction_Process = "Refine in process...";
	RefineryInstruction_Stop = "Refinery stopped.";
	RefineryInstruction_Result = "Congratulations!\nYou get";
	RefineryInstruction_Error_NPC = "Please, target NPC-shop!";
	RefineryInstruction_Error_LS = "You used all LifeStones!";
	RefineryInstruction_Error_GS = "You used all GemStones!";
	RefineryInstruction_Error_Adena = "You do not have enough adena.";
	RefineryInstruction_Error_FULL = "Unknown error!\nPlease check the components and options!";
	Skill = "Skill";
	SkillRecommend = UnknownFunction168(UnknownFunction168("You need talk with \n","Enchant's Skills Master")," at least once!");
	SkillType = "Type of enchant:";
	SkillEnchantTo = "Enchant to:";
	SkillDelay = "Delay";
	SkillDelayTooltip = "Delay to enchant skill.";
	SkillInstruction_SelectSkill = "Place the skill you want to be enchanted.";
	SkillInstruction_CheckOption = "Please, select type of enchant\nand how muc enchant level's you want.";
	SkillInstruction_Process = "Skill enchant in process...";
	SkillInstruction_Result = "Congratulations!\nYou get";
	SkillInstruction_Error_NoEnchant = "You can't enchant this skill.";
	SkillInstruction_Error_NoBook = "You have ended the book!";
	SkillInstruction_Error_EnchantLimit = "You have to write the enchant limit!";
	Me.SetWindowTitle(WindowName);
	Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.ItemEnchantTab.txtWarns",RecommendPlace);
	Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.ItemEnchantTab.txtEnchantTo",EnchantTo);
	Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.ItemEnchantTab.txtRecord",RecordEnchant);
	Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.ItemEnchantTab.txtScroll",Scroll);
	Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.ItemEnchantTab.txtBlessScroll",ScrollBless);
	Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.ItemEnchantTab.txtEquipItem",item);
	Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.ItemEnchantTab.txtEnchantScroll",ScrollSave);
	Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.ItemEnchantTab.txtUseOrdinalScroll",ScrollSaveTxt);
	Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.ItemEnchantTab.txtUseDestroyItem",ScrollUseOtherEqipTxt);
	Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.ItemEnchantTab.txtIsStuck",ScrollIsStuckTxt);
	Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.ItemEnchantTab.txtBlessUpdate",ScrollEcnhantBlessUpdate);
	checkScrollSave.SetTooltipCustomType(SetTooltip(ScrollSaveTooltip));
	checkScrollDestroy.SetTooltipCustomType(SetTooltip(ScrollUseOtherEqipTooltip));
	checkScrollStack.SetTooltipCustomType(SetTooltip(ScrollIsStuckTooltip));
	Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.AugmentationTab.txtWarn",MustPlace);
	Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.AugmentationTab.txtTypeAll",TypeAll);
	Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.AugmentationTab.txtTypePassive",TypePassive);
	Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.AugmentationTab.txtTypeActive",TypeActive);
	Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.AugmentationTab.txtTypeChance",TypeChance);
	Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.AugmentationTab.txtTypeStat",TypeStat);
	Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.AugmentationTab.txtTypeSelect",TypeSelect);
	Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.AugmentationTab.txtTypeCustom",TypeCustom);
	Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.AugmentationTab.txtQuality",Quality);
	Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.AugmentationTab.txtUseSimulRef",UseNpcSimulation);
	b_GetNPCInfo.SetTooltipCustomType(SetTooltip(GetNpcInfoTooltim));
	b_SelectEdit.SetTooltipCustomType(SetTooltip(EditSelectList));
	b_CustomEdit.SetTooltipCustomType(SetTooltip(EditCustomList));
	b_BypassEdit.SetTooltipCustomType(SetTooltip(EditBypass));
	Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.SkillEnchantTab.txtRecomeds",SkillRecommend);
	Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.SkillEnchantTab.txtSkillSlot",Skill);
	Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.SkillEnchantTab.txtEnchantType",SkillType);
	Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.SkillEnchantTab.txtEnchantLevel",SkillEnchantTo);
}

function InvetorySlotName ()
{
	InventorySlot[0] = "InventoryItem";
	InventorySlot[1] = "EquipItem_LHand";
	InventorySlot[2] = "EquipItem_RHand";
	InventorySlot[3] = "EquipItem_Head";
	InventorySlot[4] = "EquipItem_Chest";
	InventorySlot[5] = "EquipItem_Legs";
	InventorySlot[6] = "EquipItem_Gloves";
	InventorySlot[7] = "EquipItem_Feet";
	InventorySlot[8] = "EquipItem_Neck";
	InventorySlot[9] = "EquipItem_REar";
	InventorySlot[10] = "EquipItem_LEar";
	InventorySlot[11] = "EquipItem_RFinger";
	InventorySlot[12] = "EquipItem_LFinger";
}

function OnClickCheckBox (string strID)
{
	switch (strID)
	{
		case "checkSaveEnchant":
		if ( Class'UIAPI_CHECKBOX'.IsChecked("EnchantAIWnd.checkSaveEnchant") )
		{
			EnchantItem_UseOldScroll = True;
		} else {
			EnchantItem_UseOldScroll = False;
		}
		break;
		case "checkUseDestroyItem":
		if ( Class'UIAPI_CHECKBOX'.IsChecked("EnchantAIWnd.checkUseDestroyItem") )
		{
			EnchantItem_UseDestrItem = True;
		} else {
			EnchantItem_UseDestrItem = False;
		}
		break;
		case "checkIsStuck":
		if ( Class'UIAPI_CHECKBOX'.IsChecked("EnchantAIWnd.checkIsStuck") )
		{
			EnchantItem_IsStack = True;
		} else {
			EnchantItem_IsStack = False;
		}
		break;
		case "checkBlessUpdate":
		if ( Class'UIAPI_CHECKBOX'.IsChecked("EnchantAIWnd.checkBlessUpdate") )
		{
			EnchantItem_UpdateBless = True;
		} else {
			EnchantItem_UpdateBless = False;
		}
		break;
		case "checkUseSimulRef":
		if ( Class'UIAPI_CHECKBOX'.IsChecked("EnchantAIWnd.checkUseSimulRef") )
		{
			UseNpcSimulation = True;
		} else {
			UseNpcSimulation = False;
		}
		SetINIBool("AutoRefinery","UseNPCSimulation",UseNpcSimulation,"Option");
		break;
		case "checkTypeAll":
		if ( Class'UIAPI_CHECKBOX'.IsChecked("EnchantAIWnd.checkTypeAll") )
		{
			Class'UIAPI_WINDOW'.DisableWindow("EnchantAIWnd.checkTypePassive");
			Class'UIAPI_WINDOW'.DisableWindow("EnchantAIWnd.checkTypeActive");
			Class'UIAPI_WINDOW'.DisableWindow("EnchantAIWnd.checkTypeChance");
			Class'UIAPI_WINDOW'.DisableWindow("EnchantAIWnd.checkTypeStat");
			Class'UIAPI_WINDOW'.DisableWindow("EnchantAIWnd.checkTypeSelect");
			Class'UIAPI_WINDOW'.DisableWindow("EnchantAIWnd.checkTypeCustom");
			Class'UIAPI_WINDOW'.DisableWindow("EnchantAIWnd.comboTypeAll");
			Class'UIAPI_CHECKBOX'.SetCheck("EnchantAIWnd.checkTypePassive",True);
			Class'UIAPI_CHECKBOX'.SetCheck("EnchantAIWnd.checkTypeActive",True);
			Class'UIAPI_CHECKBOX'.SetCheck("EnchantAIWnd.checkTypeChance",True);
			Class'UIAPI_CHECKBOX'.SetCheck("EnchantAIWnd.checkTypeStat",True);
			Class'UIAPI_CHECKBOX'.SetCheck("EnchantAIWnd.checkTypeSelect",True);
			Class'UIAPI_CHECKBOX'.SetCheck("EnchantAIWnd.checkTypeCustom",True);
		} else {
			Class'UIAPI_WINDOW'.EnableWindow("EnchantAIWnd.checkTypePassive");
			Class'UIAPI_WINDOW'.EnableWindow("EnchantAIWnd.checkTypeActive");
			Class'UIAPI_WINDOW'.EnableWindow("EnchantAIWnd.checkTypeChance");
			Class'UIAPI_WINDOW'.EnableWindow("EnchantAIWnd.checkTypeStat");
			Class'UIAPI_WINDOW'.EnableWindow("EnchantAIWnd.checkTypeSelect");
			Class'UIAPI_WINDOW'.EnableWindow("EnchantAIWnd.checkTypeCustom");
			Class'UIAPI_WINDOW'.EnableWindow("EnchantAIWnd.comboTypeAll");
			Class'UIAPI_CHECKBOX'.SetCheck("EnchantAIWnd.checkTypePassive",False);
			Class'UIAPI_CHECKBOX'.SetCheck("EnchantAIWnd.checkTypeActive",False);
			Class'UIAPI_CHECKBOX'.SetCheck("EnchantAIWnd.checkTypeChance",False);
			Class'UIAPI_CHECKBOX'.SetCheck("EnchantAIWnd.checkTypeStat",False);
			Class'UIAPI_CHECKBOX'.SetCheck("EnchantAIWnd.checkTypeSelect",False);
			Class'UIAPI_CHECKBOX'.SetCheck("EnchantAIWnd.checkTypeCustom",False);
		}
		break;
		case "checkTypeSelect":
		if ( Class'UIAPI_CHECKBOX'.IsChecked("EnchantAIWnd.checkTypeSelect") )
		{
			Class'UIAPI_WINDOW'.DisableWindow("EnchantAIWnd.checkTypePassive");
			Class'UIAPI_WINDOW'.DisableWindow("EnchantAIWnd.checkTypeActive");
			Class'UIAPI_WINDOW'.DisableWindow("EnchantAIWnd.checkTypeChance");
			Class'UIAPI_WINDOW'.DisableWindow("EnchantAIWnd.checkTypeStat");
			Class'UIAPI_WINDOW'.DisableWindow("EnchantAIWnd.checkTypeCustom");
			Class'UIAPI_WINDOW'.EnableWindow("EnchantAIWnd.comboTypeAll");
			Class'UIAPI_CHECKBOX'.SetCheck("EnchantAIWnd.checkTypeAll",False);
			Class'UIAPI_CHECKBOX'.SetCheck("EnchantAIWnd.checkTypePassive",False);
			Class'UIAPI_CHECKBOX'.SetCheck("EnchantAIWnd.checkTypeActive",False);
			Class'UIAPI_CHECKBOX'.SetCheck("EnchantAIWnd.checkTypeChance",False);
			Class'UIAPI_CHECKBOX'.SetCheck("EnchantAIWnd.checkTypeStat",False);
			Class'UIAPI_CHECKBOX'.SetCheck("EnchantAIWnd.checkTypeCustom",False);
		} else {
			Class'UIAPI_WINDOW'.EnableWindow("EnchantAIWnd.checkTypePassive");
			Class'UIAPI_WINDOW'.EnableWindow("EnchantAIWnd.checkTypeActive");
			Class'UIAPI_WINDOW'.EnableWindow("EnchantAIWnd.checkTypeChance");
			Class'UIAPI_WINDOW'.EnableWindow("EnchantAIWnd.checkTypeStat");
			Class'UIAPI_WINDOW'.EnableWindow("EnchantAIWnd.checkTypeCustom");
			Class'UIAPI_WINDOW'.EnableWindow("EnchantAIWnd.comboTypeAll");
			Class'UIAPI_CHECKBOX'.SetCheck("EnchantAIWnd.checkTypeAll",False);
			Class'UIAPI_CHECKBOX'.SetCheck("EnchantAIWnd.checkTypePassive",False);
			Class'UIAPI_CHECKBOX'.SetCheck("EnchantAIWnd.checkTypeActive",False);
			Class'UIAPI_CHECKBOX'.SetCheck("EnchantAIWnd.checkTypeChance",False);
			Class'UIAPI_CHECKBOX'.SetCheck("EnchantAIWnd.checkTypeStat",False);
			Class'UIAPI_CHECKBOX'.SetCheck("EnchantAIWnd.checkTypeCustom",False);
		}
		break;
		case "checkTypeCustom":
		if ( Class'UIAPI_CHECKBOX'.IsChecked("EnchantAIWnd.checkTypeCustom") )
		{
			Class'UIAPI_WINDOW'.DisableWindow("EnchantAIWnd.checkTypePassive");
			Class'UIAPI_WINDOW'.DisableWindow("EnchantAIWnd.checkTypeActive");
			Class'UIAPI_WINDOW'.DisableWindow("EnchantAIWnd.checkTypeChance");
			Class'UIAPI_WINDOW'.DisableWindow("EnchantAIWnd.checkTypeStat");
			Class'UIAPI_WINDOW'.DisableWindow("EnchantAIWnd.checkTypeSelect");
			Class'UIAPI_WINDOW'.DisableWindow("EnchantAIWnd.comboTypeAll");
			Class'UIAPI_CHECKBOX'.SetCheck("EnchantAIWnd.checkTypeAll",False);
			Class'UIAPI_CHECKBOX'.SetCheck("EnchantAIWnd.checkTypePassive",False);
			Class'UIAPI_CHECKBOX'.SetCheck("EnchantAIWnd.checkTypeActive",False);
			Class'UIAPI_CHECKBOX'.SetCheck("EnchantAIWnd.checkTypeChance",False);
			Class'UIAPI_CHECKBOX'.SetCheck("EnchantAIWnd.checkTypeStat",False);
			Class'UIAPI_CHECKBOX'.SetCheck("EnchantAIWnd.checkTypeSelect",False);
		} else {
			Class'UIAPI_WINDOW'.EnableWindow("EnchantAIWnd.checkTypePassive");
			Class'UIAPI_WINDOW'.EnableWindow("EnchantAIWnd.checkTypeActive");
			Class'UIAPI_WINDOW'.EnableWindow("EnchantAIWnd.checkTypeChance");
			Class'UIAPI_WINDOW'.EnableWindow("EnchantAIWnd.checkTypeStat");
			Class'UIAPI_WINDOW'.EnableWindow("EnchantAIWnd.checkTypeSelect");
			Class'UIAPI_WINDOW'.EnableWindow("EnchantAIWnd.comboTypeAll");
			Class'UIAPI_CHECKBOX'.SetCheck("EnchantAIWnd.checkTypeAll",False);
			Class'UIAPI_CHECKBOX'.SetCheck("EnchantAIWnd.checkTypePassive",False);
			Class'UIAPI_CHECKBOX'.SetCheck("EnchantAIWnd.checkTypeActive",False);
			Class'UIAPI_CHECKBOX'.SetCheck("EnchantAIWnd.checkTypeChance",False);
			Class'UIAPI_CHECKBOX'.SetCheck("EnchantAIWnd.checkTypeStat",False);
			Class'UIAPI_CHECKBOX'.SetCheck("EnchantAIWnd.checkTypeSelect",False);
		}
		break;
		default:
	}
}

function ShowBypassEdit ()
{
	if ( Class'UIAPI_WINDOW'.IsShowWindow("InterfaceAI_EditAugmentListWnd") )
	{
		Class'UIAPI_WINDOW'.HideWindow("InterfaceAI_EditAugmentListWnd");
	}
	if ( Class'UIAPI_WINDOW'.IsShowWindow("InterfaceAI_BypassEdit") )
	{
		Class'UIAPI_WINDOW'.HideWindow("InterfaceAI_BypassEdit");
	} else {
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceAI_BypassEdit");
	}
}

function ShowListEdit (int Type)
{
	if ( Class'UIAPI_WINDOW'.IsShowWindow("InterfaceAI_BypassEdit") )
	{
		Class'UIAPI_WINDOW'.HideWindow("InterfaceAI_BypassEdit");
	}
	if ( Class'UIAPI_WINDOW'.IsShowWindow("InterfaceAI_EditAugmentListWnd") )
	{
		if ( UnknownFunction154(Class'UIAPI_TABCTRL'.GetTopIndex("InterfaceAI_EditAugmentListWnd.TabListCtrl"),Type) )
		{
			Class'UIAPI_WINDOW'.HideWindow("InterfaceAI_EditAugmentListWnd");
		} else {
			Class'UIAPI_TABCTRL'.SetTopOrder("InterfaceAI_EditAugmentListWnd.TabListCtrl",Type,True);
		}
	} else {
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceAI_EditAugmentListWnd");
		Class'UIAPI_TABCTRL'.SetTopOrder("InterfaceAI_EditAugmentListWnd.TabListCtrl",Type,True);
	}
}

function OnClickButton (string strID)
{
	switch (strID)
	{
		case "btnEnchantOK":
		OnClickEnchantStart();
		break;
		case "btnEnchantPause":
		OnClickEnchantStop();
		break;
		case "btnRefineryOK":
		OnClickStartRefinery();
		break;
		case "btnRefineryCancel":
		OnClickStopRefinery();
		break;
		case "btnGetNPCInfo":
		GetNpcInfo();
		break;
		case "btnSkillOK":
		OnClickEnchantSkillStart();
		break;
		case "btnSkillCancel":
		OnClickEnchantSkillCancel();
		break;
		case "btnSelectEdit":
		ShowListEdit(0);
		break;
		case "btnCustomEdit":
		ShowListEdit(1);
		break;
		case "btnBypassEdit":
		ShowBypassEdit();
		break;
		default:
	}
}

function OnClickEnchantSkillStart ()
{
	m_InstructionText3.SetAnchor("ItemEnchantTab","BottomCenter","BottomCenter",0,-45);
	if ( UnknownFunction155(EnchantSkillLimit,0) )
	{
		EnchantSkill();
		EnableSkillProcess = True;
	} else {
		m_InstructionText.SetText(SkillInstruction_Error_EnchantLimit);
	}
}

function OnClickEnchantSkillCancel ()
{
	StopEnchantSkill();
}

function GetNpcInfo ()
{
	GetTargetInfo(NPCInfo);
	if ( UnknownFunction155(NPCInfo.nID,0) )
	{
		Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.AugmentationTab.txtNPCInfo",UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(NpcInfoName,": "),NPCInfo.Name)," "),NpcInfoID),": "),string(NPCInfo.nID)));
	} else {
		m_InstructionText2.SetText(RefineryInstruction_Error_NPC);
	}
}

function ClearNpcInfo ()
{
	NPCInfo.nID = 0;
	Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.AugmentationTab.txtNPCInfo",UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(NpcInfoName,": "),NpcInfoDefault)," "),NpcInfoID),": "),NpcInfoDefault));
}

function SetDelay (string Type, int CurrentTick, int TickAdd, out int Time)
{
	local string Seconds;
	local int CurrentTick_temp;

	Time = UnknownFunction144(CurrentTick,TickAdd);
	Seconds = string(UnknownFunction172(Time,1000));
	switch (Type)
	{
		case "Delay_ScrollSelect":
		Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.ItemEnchantTab.txtDelay1",UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(DelayScroll," "),Seconds)," "),Second));
		Class'UIAPI_WINDOW'.SetTooltipText("EnchantAIWnd.ItemEnchantTab.EnchantDelay1SliderCtrl",UnknownFunction168(UnknownFunction168(DelayScrollTooltip,Seconds),Second));
		SetINIInt("AutoEnchant",Type,CurrentTick,"Option");
		Time = UnknownFunction146(Time,TIMER_ENCHANT2_DELAY);
		break;
		case "Delay_EnchantItem":
		Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.ItemEnchantTab.txtDelay2",UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(DelayEnchant," "),Seconds)," "),Second));
		Class'UIAPI_WINDOW'.SetTooltipText("EnchantAIWnd.ItemEnchantTab.EnchantDelay2SliderCtrl",UnknownFunction168(UnknownFunction168(DelayEnchantTooltip,Seconds),Second));
		SetINIInt("AutoEnchant",Type,CurrentTick,"Option");
		GetINIInt("AutoEnchant","Delay_ScrollSelect",CurrentTick_temp,"Option");
		TIMER_ENCHANT_DELAY = UnknownFunction146(UnknownFunction144(CurrentTick_temp,TickAdd),Time);
		break;
		case "Delay_SkillEnchant":
		Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.SkillEnchantTab.txtSkillDelay1",UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(SkillDelay," "),Seconds)," "),Second));
		Class'UIAPI_WINDOW'.SetTooltipText("EnchantAIWnd.SkillEnchantTab.SkillEnchantDelay1SliderCtrl",UnknownFunction168(UnknownFunction168(SkillDelayTooltip,Seconds),Second));
		SetINIInt("AutoEnchantSkill",Type,CurrentTick,"Option");
		break;
		case "Delay_UN":
		Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.AugmentationTab.txtRefDelay5",UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(DelayUN," "),Seconds)," "),Second));
		Class'UIAPI_WINDOW'.SetTooltipText("EnchantAIWnd.AugmentationTab.RefineryDelay5SliderCtrl",UnknownFunction168(UnknownFunction168(DelayUNTooltip,Seconds),Second));
		SetINIInt("AutoRefinery",Type,CurrentTick,"Option");
		break;
		case "Delay_NPCTalk":
		Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.AugmentationTab.txtRefDelay1",UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(DelayNPC," "),Seconds)," "),Second));
		Class'UIAPI_WINDOW'.SetTooltipText("EnchantAIWnd.AugmentationTab.RefineryDelay1SliderCtrl",UnknownFunction168(UnknownFunction168(DelayNPCTooltip,Seconds),Second));
		SetINIInt("AutoRefinery",Type,CurrentTick,"Option");
		break;
		case "Delay_WP":
		Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.AugmentationTab.txtRefDelay2",UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(DelayWP," "),Seconds)," "),Second));
		Class'UIAPI_WINDOW'.SetTooltipText("EnchantAIWnd.AugmentationTab.RefineryDelay2SliderCtrl",UnknownFunction168(UnknownFunction168(DelayWPTooltip,Seconds),Second));
		SetINIInt("AutoRefinery",Type,CurrentTick,"Option");
		break;
		case "Delay_LS":
		Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.AugmentationTab.txtRefDelay3",UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(DelayLS," "),Seconds)," "),Second));
		Class'UIAPI_WINDOW'.SetTooltipText("EnchantAIWnd.AugmentationTab.RefineryDelay3SliderCtrl",UnknownFunction168(UnknownFunction168(DelayLSTooltip,Seconds),Second));
		SetINIInt("AutoRefinery",Type,CurrentTick,"Option");
		break;
		case "Delay_GS":
		Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.AugmentationTab.txtRefDelay4",UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(DelayGS," "),Seconds)," "),Second));
		Class'UIAPI_WINDOW'.SetTooltipText("EnchantAIWnd.AugmentationTab.RefineryDelay4SliderCtrl",UnknownFunction168(UnknownFunction168(DelayGSTooltip,Seconds),Second));
		SetINIInt("AutoRefinery",Type,CurrentTick,"Option");
		break;
		case "Delay_Final":
		Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.AugmentationTab.txtRefDelay6",UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(DelayConfirm," "),Seconds)," "),Second));
		Class'UIAPI_WINDOW'.SetTooltipText("EnchantAIWnd.AugmentationTab.RefineryDelay6SliderCtrl",UnknownFunction168(UnknownFunction168(DelayConfirmTooltip,Seconds),Second));
		SetINIInt("AutoRefinery",Type,CurrentTick,"Option");
		break;
		default:
	}
}

function OnComboBoxItemSelected (string a_ControlID, int a_SelectedIndex)
{
	if ( UnknownFunction122(a_ControlID,"comboSkillType") )
	{
		ComboEnchantSelect = a_SelectedIndex;
	}
}

function OnChangeEditBox (string strID)
{
	switch (strID)
	{
		case "editEnchantLvl":
		EnchantItem_EnchantTo = int(Class'UIAPI_EDITBOX'.GetString("EnchantAIWnd.editEnchantLvl"));
		break;
		case "ScrollEnchantLvlEdit":
		EnchantItem_EnchantSaveTo = int(Class'UIAPI_EDITBOX'.GetString("EnchantAIWnd.ScrollEnchantLvlEdit"));
		break;
		case "editSkillEnchant":
		EnchantSkillLimit = int(Class'UIAPI_EDITBOX'.GetString("EnchantAIWnd.editSkillEnchant"));
		break;
		default:
	}
}

function OnModifyCurrentTickSliderCtrl (string strID, int iCurrentTick)
{
	switch (strID)
	{
		case "EnchantDelay1SliderCtrl":
		SetDelay("Delay_ScrollSelect",iCurrentTick,250,TIMER_ENCHANT_DELAY);
		break;
		case "EnchantDelay2SliderCtrl":
		SetDelay("Delay_EnchantItem",iCurrentTick,250,TIMER_ENCHANT2_DELAY);
		break;
		case "SkillEnchantDelay1SliderCtrl":
		SetDelay("Delay_SkillEnchant",iCurrentTick,250,TIMER_ENCHANTSKILL_DELAY);
		break;
		case "RefineryDelay1SliderCtrl":
		SetDelay("Delay_NPCTalk",iCurrentTick,250,TIMER_REFINERY_NPCTALK_DELAY);
		break;
		case "RefineryDelay2SliderCtrl":
		SetDelay("Delay_WP",iCurrentTick,250,TIMER_REFINERY_WEAPON_DELAY);
		break;
		case "RefineryDelay3SliderCtrl":
		SetDelay("Delay_LS",iCurrentTick,250,TIMER_REFINERY_LIFESTONE_DELAY);
		break;
		case "RefineryDelay4SliderCtrl":
		SetDelay("Delay_GS",iCurrentTick,250,TIMER_REFINERY_GEMSTONE_DELAY);
		break;
		case "RefineryDelay5SliderCtrl":
		SetDelay("Delay_UN",iCurrentTick,250,TIMER_REFINERY_UNREF_DELAY);
		break;
		case "RefineryDelay6SliderCtrl":
		SetDelay("Delay_Final",iCurrentTick,250,TIMER_REFINERY_FINAL_DELAY);
		break;
		default:
	}
}

function OnDropItem (string a_WindowID, ItemInfo a_ItemInfo, int X, int Y)
{
	switch (a_WindowID)
	{
		case "ItemDragBox1":
		DragInsertBlessSrollItem(a_ItemInfo);
		break;
		case "ItemDragBox11":
		DragInsertSrollItem(a_ItemInfo);
		break;
		case "ItemDragBox2":
		DragInserEquiptItem(a_ItemInfo);
		break;
		case "ItemDragBox3":
		DropWeapon(a_ItemInfo);
		break;
		case "ItemDragBox4":
		DropLifeStone(a_ItemInfo);
		break;
		case "ItemDragBox5":
		InsertDragSkill(a_ItemInfo);
		break;
		default:
	}
}

function AlarmWindow ()
{
	if ( IsMinimized )
	{
		Me.NotifyAlarm();
	}
}

function EnchantItemStop ()
{
	EnchantInUse = True;
	Class'UIAPI_WINDOW'.KillUITimer("EnchantAIWnd",10300);
	Class'UIAPI_WINDOW'.KillUITimer("EnchantAIWnd",10301);
	EnableEnchantProcess = False;
}

function EnchantItemStopSucsesfull ()
{
	EnchantInUse = True;
	AlarmWindow();
	EnchantItemStop();
	PlaySound("Interface.complete_enchant");
	m_InstructionText.SetText(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(EnchantInstruction_Result," "),EquipItemInfo.Name)," +"),string(EnchantItem_CurrentEnchantLevel)));
}

function OnClickEnchantStop ()
{
	m_InstructionText.SetText(EnchantInstruction_Stop);
	EnchantItemStop();
}

function OnClickEnchantStart ()
{
	EnchantInUse = False;
	m_InstructionText.SetAnchor("ItemEnchantTab","BottomCenter","BottomCenter",0,-38);
	if ( UnknownFunction155(EquipItemInfo.ClassID,0) )
	{
		if ( UnknownFunction132(UnknownFunction155(ScrollItemInfo.ClassID,0),UnknownFunction155(BlessScrollItemInfo.ClassID,0)) )
		{
			if ( UnknownFunction151(EnchantItem_EnchantTo,0) )
			{
				if ( UnknownFunction153(EnchantItem_CurrentEnchantLevel,EnchantItem_EnchantTo) )
				{
					EnchantItemStopSucsesfull();
				} else {
					EnchantSelectScrollFunction();
				}
			} else {
				m_InstructionText.SetText(EnchantInstruction_CheckOption);
			}
		} else {
			m_InstructionText.SetText(EnchantInstruction_SelectScroll);
		}
	} else {
		m_InstructionText.SetText(EnchantInstruction_SelectItem);
	}
}

function int GetScrollCount (out ItemInfo ScrollInform)
{
	local int Index;
	local ItemInfo ScrInfo;

	Index = Class'UIAPI_ITEMWINDOW'.FindItemWithClassID("InventoryWnd.InventoryItem",ScrollInform.ClassID);
	if ( Class'UIAPI_ITEMWINDOW'.GetItem("InventoryWnd.InventoryItem",Index,ScrInfo) )
	{
		ScrollInform = ScrInfo;
		return ScrInfo.ItemNum;
	} else {
		return 0;
	}
}

function EnchantClearSlot (int Type)
{
	switch (Type)
	{
		case 0:
		m_DragboxItem11.Clear();
		ScrollItemInfo.ItemNum = 0;
		ScrollItemInfo.ServerID = 0;
		ScrollItemInfo.ClassID = 0;
		break;
		case 1:
		m_DragboxItem1.Clear();
		BlessScrollItemInfo.ItemNum = 0;
		BlessScrollItemInfo.ServerID = 0;
		BlessScrollItemInfo.ClassID = 0;
		break;
		case 2:
		m_DragBoxItem2.Clear();
		EquipItemInfo.ItemNum = 0;
		EquipItemInfo.ServerID = 0;
		EquipItemInfo.ClassID = 0;
		break;
		default:
	}
}

function EnchantSelectScrollFunction ()
{
	if ( UnknownFunction130(UnknownFunction150(EnchantItem_CurrentEnchantLevel,EnchantItem_EnchantSaveTo),EnchantItem_UseOldScroll) )
	{
		if ( EnchantItem_IsStack )
		{
			if ( UnknownFunction151(GetScrollCount(ScrollItemInfo),0) )
			{
				RequestUseItem(ScrollItemInfo.ServerID);
				Class'UIAPI_WINDOW'.SetUITimer("EnchantAIWnd",10301,TIMER_ENCHANT2_DELAY);
			} else {
				m_InstructionText.SetText(EnchantInstruction_Error_ScrollEnd);
				EnchantItemStop();
				EnchantClearSlot(0);
			}
		} else {
			if ( UnknownFunction151(ScrollItemInfo.ItemNum,0) )
			{
				RequestUseItem(ScrollItemInfo.ServerID);
				Class'UIAPI_WINDOW'.SetUITimer("EnchantAIWnd",10301,TIMER_ENCHANT2_DELAY);
			} else {
				m_InstructionText.SetText(EnchantInstruction_Error_ScrollEnd);
				EnchantItemStop();
				EnchantClearSlot(0);
			}
		}
	} else {
		if ( EnchantItem_IsStack )
		{
			if ( UnknownFunction151(GetScrollCount(BlessScrollItemInfo),0) )
			{
				RequestUseItem(BlessScrollItemInfo.ServerID);
				Class'UIAPI_WINDOW'.SetUITimer("EnchantAIWnd",10301,TIMER_ENCHANT2_DELAY);
			} else {
				m_InstructionText.SetText(EnchantInstruction_Error_ScrollEnd);
				EnchantItemStop();
				EnchantClearSlot(1);
			}
		} else {
			if ( UnknownFunction151(BlessScrollItemInfo.ItemNum,0) )
			{
				RequestUseItem(BlessScrollItemInfo.ServerID);
				Class'UIAPI_WINDOW'.SetUITimer("EnchantAIWnd",10301,TIMER_ENCHANT2_DELAY);
			} else {
				m_InstructionText.SetText(EnchantInstruction_Error_ScrollEnd);
				EnchantItemStop();
				EnchantClearSlot(1);
			}
		}
	}
}

function EnchantFinishFunction ()
{
	Class'EnchantAPI'.RequestEnchantItem(EquipItemInfo.ServerID);
	m_InstructionText.SetText(EnchantInstruction_Process);
}

function HandleSystemMessage (string a_Param)
{
	local int idx;
	local int Id;

	ParseInt(a_Param,"Index",idx);
	switch (idx)
	{
		case 62:
		EnchantItem_CurrentEnchantLevel = 1;
		HandleEnchantResult("Result=65535");
		break;
		case 63:
		ParseInt(a_Param,"Param1",Id);
		EnchantItem_CurrentEnchantLevel = DoAdd(Id,1);
		HandleEnchantResult("Result=65535");
		break;
		case 64:
		case 65:
		EnchantItem_CurrentEnchantLevel = 0;
		HandleEnchantResult("Result=1");
		break;
		case 614:
		case 1517:
		case 1983:
		EnchantItem_CurrentEnchantLevel = 0;
		HandleEnchantResult("Result=1");
		break;
		case 355:
		HandleEnchantResult("Result=0");
		break;
		case 369:
		ParseInt(a_Param,"Param1",Id);
		EnchantItem_CurrentEnchantLevel = Id;
		HandleEnchantResult("Result=1");
		break;
		case 424:
		HandleEnchantResult("Result=2");
		break;
		default:
	}
}

function HandleEnchantResult (string param)
{
	local int IntResult;

	ParseInt(param,"Result",IntResult);
	switch (IntResult)
	{
		case 0:
		if ( UnknownFunction150(EnchantItem_Record,EnchantItem_CurrentEnchantLevel) )
		{
			EnchantItem_Record = EnchantItem_CurrentEnchantLevel;
			UpdateEnchantItemParam(False);
		}
		if ( UnknownFunction153(EnchantItem_CurrentEnchantLevel,EnchantItem_EnchantTo) )
		{
			EnchantItemStopSucsesfull();
		} else {
			Class'UIAPI_WINDOW'.SetUITimer("EnchantAIWnd",10300,TIMER_ENCHANT_DELAY);
		}
		UpdateEquiptItem(EnchantItem_CurrentEnchantLevel);
		break;
		case 1:
		if ( EnchantItem_UseDestrItem )
		{
			if ( UpdateDestroyedItem() )
			{
				InserEquiptItem(EquipItemInfo);
				UpdateEnchantItemParam(True);
				Class'UIAPI_WINDOW'.SetUITimer("EnchantAIWnd",10300,TIMER_ENCHANT_DELAY);
			} else {
				EnchantClearSlot(2);
				EnchantItemStop();
				m_InstructionText.SetText(EnchantInstruction_Error_Destroy);
			}
		} else {
			if ( EnchantItem_UpdateBless )
			{
				EquipItemInfo.Enchanted = EnchantItem_CurrentEnchantLevel;
				Class'UIAPI_WINDOW'.SetUITimer("EnchantAIWnd",10300,TIMER_ENCHANT_DELAY);
				UpdateEquiptItem(EnchantItem_CurrentEnchantLevel);
			} else {
				EnchantClearSlot(2);
				EnchantItemStop();
				m_InstructionText.SetText(EnchantInstruction_Error_Destroy);
			}
		}
		break;
		case 65535:
		EquipItemInfo.Enchanted = EnchantItem_CurrentEnchantLevel;
		if ( UnknownFunction150(EnchantItem_Record,EnchantItem_CurrentEnchantLevel) )
		{
			EnchantItem_Record = EnchantItem_CurrentEnchantLevel;
			UpdateEnchantItemParam(False);
		}
		if ( UnknownFunction153(EnchantItem_CurrentEnchantLevel,EnchantItem_EnchantTo) )
		{
			EnchantItemStopSucsesfull();
		} else {
			Class'UIAPI_WINDOW'.SetUITimer("EnchantAIWnd",10300,TIMER_ENCHANT_DELAY);
		}
		UpdateEquiptItem(EnchantItem_CurrentEnchantLevel);
		break;
		case 2:
		if ( EnchantItem_UpdateBless )
		{
			EnchantItem_CurrentEnchantLevel = EnchantItem_ResetTo;
			EquipItemInfo.Enchanted = EnchantItem_CurrentEnchantLevel;
			Class'UIAPI_WINDOW'.SetUITimer("EnchantAIWnd",10300,TIMER_ENCHANT_DELAY);
			UpdateEquiptItem(EnchantItem_CurrentEnchantLevel);
		} else {
			EnchantItemStop();
			m_InstructionText.SetText(EnchantInstruction_Stop);
		}
		break;
		case 3:
		EnchantItem_CurrentEnchantLevel = EnchantItem_ResetTo;
		EquipItemInfo.Enchanted = EnchantItem_CurrentEnchantLevel;
		Class'UIAPI_WINDOW'.SetUITimer("EnchantAIWnd",10300,TIMER_ENCHANT_DELAY);
		UpdateEquiptItem(EnchantItem_CurrentEnchantLevel);
		break;
		default:
	}
}

function bool UpdateDestroyedItem ()
{
	local int Index;
	local ItemInfo ScrInfo;

	Index = Class'UIAPI_ITEMWINDOW'.FindItemWithClassID("InventoryWnd.InventoryItem",EquipItemInfo.ClassID);
	if ( Class'UIAPI_ITEMWINDOW'.GetItem("InventoryWnd.InventoryItem",Index,ScrInfo) )
	{
		EquipItemInfo = ScrInfo;
		return True;
	} else {
		return False;
	}
}

function UpdateEnchantItemParam (bool NewItem)
{
	if ( NewItem )
	{
		Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.valRecord",UnknownFunction112("+",string(EquipItemInfo.Enchanted)));
	} else {
		Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.valRecord",UnknownFunction112("+",string(EnchantItem_Record)));
	}
}

function DragInsertSrollItem (ItemInfo a_ItemInfo)
{
	EnchantClearSlot(0);
	EnchantClearSlot(2);
	ScrollItemInfo = a_ItemInfo;
	m_DragBoxItem2.EnableWindow();
	m_DragboxItem11.AddItem(a_ItemInfo);
	m_InstructionText.SetText(EnchantInstruction_SelectItem);
}

function DragInsertBlessSrollItem (ItemInfo a_ItemInfo)
{
	EnchantClearSlot(1);
	EnchantClearSlot(2);
	BlessScrollItemInfo = a_ItemInfo;
	BlessScrollServerID = a_ItemInfo.ServerID;
	m_DragboxItem1.AddItem(a_ItemInfo);
	m_DragBoxItem2.EnableWindow();
	m_InstructionText.SetText(EnchantInstruction_SelectItem);
	GetScrollCount(BlessScrollItemInfo);
}

function DragInserEquiptItem (ItemInfo a_ItemInfo)
{
	if ( m_DragBoxItem2.IsEnableWindow() )
	{
		InserEquiptItem(a_ItemInfo);
		UpdateEnchantItemParam(True);
		EnchantItem_Record = a_ItemInfo.Enchanted;
		m_InstructionText.SetText(EnchantInstruction_CheckOption);
	}
}

function InserEquiptItem (ItemInfo a_ItemInfo)
{
	m_DragBoxItem2.Clear();
	EquipItemInfo = a_ItemInfo;
	EquipItemServerID = a_ItemInfo.ServerID;
	EnchantItem_CurrentEnchantLevel = a_ItemInfo.Enchanted;
	m_DragBoxItem2.AddItem(a_ItemInfo);
}

function UpdateEquiptItem (int Enchant)
{
	EquipItemInfo.Enchanted = Enchant;
	m_DragBoxItem2.Clear();
	m_DragBoxItem2.AddItem(EquipItemInfo);
}

function InsertDragSkill (ItemInfo a_ItemInfo)
{
	local string EnchantString;

	EnchantString = Class'UIDATA_SKILL'.GetEnchantName(a_ItemInfo.ClassID,101);
	if ( UnknownFunction123(EnchantString,"") )
	{
		SkillInfo = a_ItemInfo;
		DragSkill(SkillInfo);
		m_InstructionText3.SetText(SkillInstruction_CheckOption);
	} else {
		m_InstructionText3.SetText(SkillInstruction_Error_NoEnchant);
	}
}

function DragSkill (ItemInfo a_ItemInfo)
{
	m_DragBoxItem5.Clear();
	m_DragBoxItem5.AddItem(a_ItemInfo);
	UpdateCombobox(a_ItemInfo);
}

function UpdateSkill (out ItemInfo Info)
{
	local int Index;
	local ItemInfo Skill;

	RequestSkillList();
	Index = Class'UIAPI_ITEMWINDOW'.FindItemWithClassID("MagicSkillWnd.ASkill.SkillItem",SkillInfo.ClassID);
	if ( Class'UIAPI_ITEMWINDOW'.GetItem("MagicSkillWnd.ASkill.SkillItem",Index,Skill) )
	{
		Info = Skill;
	}
}

function UpdateEnchantSkillParam ()
{
	local UserInfo MyInfo;

	if ( GetPlayerInfo(MyInfo) )
	{
		Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.SkillEnchantTab.txtExp",UnknownFunction112(UnknownFunction112(UnknownFunction112(Int64ToString(MyInfo.nCurExp)," ("),string(GetExpRate(MyInfo.nCurExp,MyInfo.nLevel))),"%)"));
		Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.SkillEnchantTab.txtSP",string(MyInfo.nSP));
	}
	Class'UIAPI_TEXTBOX'.SetText("EnchantAIWnd.SkillEnchantTab.txtBookCount",UnknownFunction168(string(UpdateGiantBookCount()),Quantity));
}

function int UpdateGiantBookCount ()
{
	local int Count;
	local int Index;
	local int InvetoryItems;
	local int i;
	local ItemInfo BookInfo;
	local ItemInfo InventoryItem;

	Count = 0;
	InvetoryItems = Class'UIAPI_ITEMWINDOW'.GetItemNum("InventoryWnd.InventoryItem");
	Index = Class'UIAPI_ITEMWINDOW'.FindItemWithClassID("InventoryWnd.InventoryItem",6622);
	if ( Class'UIAPI_ITEMWINDOW'.GetItem("InventoryWnd.InventoryItem",Index,BookInfo) )
	{
		if ( UnknownFunction154(BookInfo.ItemNum,1) )
		{
			i = 0;
			if ( UnknownFunction152(i,InvetoryItems) )
			{
				if ( Class'UIAPI_ITEMWINDOW'.GetItem("InventoryWnd.InventoryItem",InvetoryItems,InventoryItem) )
				{
					if ( UnknownFunction154(InventoryItem.ClassID,6622) )
					{
						UnknownFunction165(Count);
					}
				}
				UnknownFunction163(i);
				goto JL00BD;
			}
		} else {
			if ( UnknownFunction154(BookInfo.ItemNum,0) )
			{
				Count = 0;
			} else {
				Count = BookInfo.ItemNum;
			}
		}
	}
	return Count;
}

function EnchantSkill ()
{
	Class'UIAPI_WINDOW'.SetUITimer("EnchantAIWnd",10500,TIMER_ENCHANTSKILL_DELAY);
	UpdateSkill(SkillInfo);
	if ( UnknownFunction132(UnknownFunction154(SkillInfo.Level,UnknownFunction146(EnchantSkillLimit,100)),UnknownFunction154(SkillInfo.Level,UnknownFunction146(EnchantSkillLimit,140))) )
	{
		StopEnchantSkill();
		AlarmWindow();
		m_InstructionText3.SetText(UnknownFunction112(UnknownFunction112(UnknownFunction168(SkillInstruction_Result,Class'UIDATA_SKILL'.GetName(SkillInfo.ClassID,SkillInfo.Level))," "),Class'UIDATA_SKILL'.GetEnchantName(SkillInfo.ClassID,SkillInfo.Level)));
		PlaySound("Interface.complete_refinery");
	} else {
		if ( UnknownFunction130(UnknownFunction150(SkillInfo.Level,100),UnknownFunction154(ComboEnchantSelect,0)) )
		{
			RequestExEnchantSkill(SkillInfo.ClassID,101);
			m_InstructionText3.SetText(SkillInstruction_Process);
		} else {
			if ( UnknownFunction130(UnknownFunction150(SkillInfo.Level,100),UnknownFunction154(ComboEnchantSelect,1)) )
			{
				RequestExEnchantSkill(SkillInfo.ClassID,141);
				m_InstructionText3.SetText(SkillInstruction_Process);
			} else {
				RequestExEnchantSkill(SkillInfo.ClassID,UnknownFunction146(SkillInfo.Level,1));
				m_InstructionText3.SetText(SkillInstruction_Process);
			}
		}
	}
	UpdateSkill(SkillInfo);
	DragSkill(SkillInfo);
	UpdateEnchantSkillParam();
}

function StopEnchantSkill ()
{
	Class'UIAPI_WINDOW'.KillUITimer("EnchantAIWnd",10500);
	EnableSkillProcess = False;
}

function UpdateCombobox (ItemInfo Skill)
{
	local string Enchant1Full;
	local string Enchant2Full;
	local array<string> Enchant1Name;
	local array<string> Enchant2Name;
	local int tempInt;
	local int tempInt2;

	Class'UIAPI_COMBOBOX'.Clear("EnchantAIWnd.comboSkillType");
	Class'UIAPI_WINDOW'.EnableWindow("EnchantAIWnd.comboSkillType");
	Class'UIAPI_COMBOBOX'.SetSelectedNum("EnchantAIWnd.comboSkillType",ComboEnchantSelect);
	Enchant1Name.Length = 0;
	Enchant2Name.Length = 0;
	Enchant1Full = Class'UIDATA_SKILL'.GetEnchantName(Skill.ClassID,101);
	Enchant2Full = Class'UIDATA_SKILL'.GetEnchantName(Skill.ClassID,141);
	tempInt = Split(Enchant1Full," ",Enchant1Name);
	tempInt2 = Split(Enchant2Full," ",Enchant2Name);
	if ( UnknownFunction123(Enchant1Name[1],"") )
	{
		Class'UIAPI_COMBOBOX'.AddString("EnchantAIWnd.comboSkillType",Enchant1Name[1]);
	}
	if ( UnknownFunction123(Enchant2Name[1],"") )
	{
		Class'UIAPI_COMBOBOX'.AddString("EnchantAIWnd.comboSkillType",Enchant2Name[1]);
	}
	if ( UnknownFunction130(UnknownFunction151(SkillInfo.Level,100),UnknownFunction150(SkillInfo.Level,131)) )
	{
		Class'UIAPI_COMBOBOX'.SetSelectedNum("EnchantAIWnd.comboSkillType",ComboEnchantSelect);
		Class'UIAPI_WINDOW'.DisableWindow("EnchantAIWnd.comboSkillType");
	}
	if ( UnknownFunction151(SkillInfo.Level,131) )
	{
		Class'UIAPI_COMBOBOX'.SetSelectedNum("EnchantAIWnd.comboSkillType",ComboEnchantSelect);
		Class'UIAPI_WINDOW'.DisableWindow("EnchantAIWnd.comboSkillType");
	}
}

function SetSearchParam ()
{
	SearchAll = Class'UIAPI_CHECKBOX'.IsChecked("EnchantAIWnd.checkTypeAll");
	SearchPassive = Class'UIAPI_CHECKBOX'.IsChecked("EnchantAIWnd.checkTypePassive");
	SearchActive = Class'UIAPI_CHECKBOX'.IsChecked("EnchantAIWnd.checkTypeActive");
	SearchChance = Class'UIAPI_CHECKBOX'.IsChecked("EnchantAIWnd.checkTypeChance");
	SearchStat = Class'UIAPI_CHECKBOX'.IsChecked("EnchantAIWnd.checkTypeStat");
	SearchSelect = Class'UIAPI_CHECKBOX'.IsChecked("EnchantAIWnd.checkTypeSelect");
	SearchCustom = Class'UIAPI_CHECKBOX'.IsChecked("EnchantAIWnd.checkTypeCustom");
}

function OnTimer (int TimerID)
{
	switch (TimerID)
	{
		case 10300:
		Class'UIAPI_WINDOW'.KillUITimer("EnchantAIWnd",10300);
		EnchantSelectScrollFunction();
		break;
		case 10301:
		Class'UIAPI_WINDOW'.KillUITimer("EnchantAIWnd",10301);
		EnchantFinishFunction();
		break;
		case 10500:
		Class'UIAPI_WINDOW'.KillUITimer("EnchantAIWnd",10500);
		EnchantSkill();
		break;
		case 10450:
		Class'UIAPI_WINDOW'.KillUITimer("EnchantAIWnd",10450);
		RefineNpcTalk("UnRefine");
		break;
		case 10451:
		Class'UIAPI_WINDOW'.KillUITimer("EnchantAIWnd",10451);
		RefineNpcTalk("Refine");
		break;
		case 10452:
		Class'UIAPI_WINDOW'.KillUITimer("EnchantAIWnd",10452);
		UnRefineFunction();
		break;
		case 10453:
		Class'UIAPI_WINDOW'.KillUITimer("EnchantAIWnd",10453);
		WeaponRefineFunction();
		break;
		case 10454:
		Class'UIAPI_WINDOW'.KillUITimer("EnchantAIWnd",10454);
		LifeStoneRefineFunction();
		break;
		case 10455:
		Class'UIAPI_WINDOW'.KillUITimer("EnchantAIWnd",10455);
		GameStoneRefineFunction();
		break;
		case 10456:
		Class'UIAPI_WINDOW'.KillUITimer("EnchantAIWnd",10456);
		ConfirmRefineFunction();
		break;
		case 10457:
		Class'UIAPI_WINDOW'.KillUITimer("EnchantAIWnd",10457);
		RefineNpcTalk_SendRefBypass_1();
		break;
		case 10458:
		Class'UIAPI_WINDOW'.KillUITimer("EnchantAIWnd",10458);
		RefineNpcTalk_SendRefBypass_2();
		break;
		case 10459:
		Class'UIAPI_WINDOW'.KillUITimer("EnchantAIWnd",10459);
		RefineNpcTalk_SendRefBypass_3();
		break;
		case 10460:
		Class'UIAPI_WINDOW'.KillUITimer("EnchantAIWnd",10460);
		RefineNpcTalk_SendUnRefBypass_1();
		break;
		case 10461:
		Class'UIAPI_WINDOW'.KillUITimer("EnchantAIWnd",10461);
		RefineNpcTalk_SendUnRefBypass_2();
		break;
		case 10462:
		Class'UIAPI_WINDOW'.KillUITimer("EnchantAIWnd",10462);
		RefineNpcTalk_SendUnRefBypass_3();
		break;
		default:
	}
}

function OnClickStartRefinery ()
{
	if ( UnknownFunction155(WeaponItemInfo.ClassID,0) )
	{
		if ( UnknownFunction155(LifeStoneItemInfo.ClassID,0) )
		{
			SetSearchParam();
			if ( UnknownFunction155(WeaponItemInfo.RefineryOp2,0) )
			{
				if ( UseNpcSimulation )
				{
					Class'UIAPI_WINDOW'.SetUITimer("EnchantAIWnd",10450,TIMER_REFINERY_NPCTALK_DELAY);
				} else {
					Class'UIAPI_WINDOW'.SetUITimer("EnchantAIWnd",10452,TIMER_REFINERY_UNREF_DELAY);
				}
			} else {
				StartRefinery();
			}
			EnableRefineryProcess = True;
		} else {
			m_InstructionText2.SetText(RefineryInstruction_SelectLS);
		}
	} else {
		m_InstructionText2.SetText(RefineryInstruction_SelectWeapon);
	}
	m_InstructionText2.SetAnchor("ItemEnchantTab","BottomCenter","BottomCenter",0,-45);
}

function int UpdateLifeStoneCount ()
{
	local int Count;
	local int Index;
	local int InvetoryItems;
	local int i;
	local ItemInfo LSInfo;
	local ItemInfo InventoryItem;

	Count = 0;
	InvetoryItems = Class'UIAPI_ITEMWINDOW'.GetItemNum("InventoryWnd.InventoryItem");
	Index = Class'UIAPI_ITEMWINDOW'.FindItemWithClassID("InventoryWnd.InventoryItem",LifeStoneItemInfo.ClassID);
	if ( Class'UIAPI_ITEMWINDOW'.GetItem("InventoryWnd.InventoryItem",Index,LSInfo) )
	{
		LifeStoneItemInfo = LSInfo;
		if ( UnknownFunction154(LSInfo.ItemNum,1) )
		{
			i = 0;
			if ( UnknownFunction152(i,InvetoryItems) )
			{
				if ( Class'UIAPI_ITEMWINDOW'.GetItem("InventoryWnd.InventoryItem",i,InventoryItem) )
				{
					if ( UnknownFunction154(InventoryItem.ClassID,LifeStoneItemInfo.ClassID) )
					{
						Count = UnknownFunction146(Count,1);
					}
				}
				UnknownFunction163(i);
				goto JL00CD;
			}
		} else {
			if ( UnknownFunction154(LSInfo.ItemNum,0) )
			{
				Count = 0;
			} else {
				Count = LSInfo.ItemNum;
			}
		}
	}
	return Count;
}

function StartRefinery ()
{
	if ( UnknownFunction155(UpdateLifeStoneCount(),0) )
	{
		if ( UseNpcSimulation )
		{
			Class'UIAPI_WINDOW'.SetUITimer("EnchantAIWnd",10451,TIMER_REFINERY_NPCTALK_DELAY);
		} else {
			Class'UIAPI_WINDOW'.SetUITimer("EnchantAIWnd",10453,TIMER_REFINERY_WEAPON_DELAY);
		}
		m_InstructionText2.SetText(RefineryInstruction_Process);
	} else {
		StopRefinery();
		m_InstructionText2.SetText(RefineryInstruction_Error_LS);
		m_DragBoxItem4.Clear();
	}
}

function RefineNpcTalk (string Type)
{
	local UserInfo MyInfo;

	GetPlayerInfo(MyInfo);
	switch (Type)
	{
		case "Refine":
		if ( UnknownFunction130(UseRefinedBypass,UseRefinedBypass_1) )
		{
			Class'UIAPI_WINDOW'.SetUITimer("EnchantAIWnd",10457,TIMER_REFINERY_NPCTALK_DELAY);
		} else {
			Class'UIAPI_WINDOW'.SetUITimer("EnchantAIWnd",10453,TIMER_REFINERY_WEAPON_DELAY);
		}
		break;
		case "UnRefine":
		if ( UnknownFunction130(UseUnRefinedBypass,UseUnRefinedBypass_1) )
		{
			Class'UIAPI_WINDOW'.SetUITimer("EnchantAIWnd",10460,TIMER_REFINERY_NPCTALK_DELAY);
		} else {
			Class'UIAPI_WINDOW'.SetUITimer("EnchantAIWnd",10452,TIMER_REFINERY_UNREF_DELAY);
		}
		break;
		default:
	}
	RequestAction(NPCInfo.nID,MyInfo.loc);
}

function RefineNpcTalk_SendRefBypass_1 ()
{
	if ( UseCryptBypass )
	{
		RequestBypassToServer(CryptRefBypass_1);
	} else {
		RequestBypassToServer(RefBypass_1);
	}
	if ( UseRefinedBypass_2 )
	{
		Class'UIAPI_WINDOW'.SetUITimer("EnchantAIWnd",10458,TIMER_REFINERY_NPCTALK_DELAY);
	} else {
		Class'UIAPI_WINDOW'.SetUITimer("EnchantAIWnd",10453,TIMER_REFINERY_WEAPON_DELAY);
	}
}

function RefineNpcTalk_SendRefBypass_2 ()
{
	if ( UseCryptBypass )
	{
		RequestBypassToServer(CryptRefBypass_2);
	} else {
		RequestBypassToServer(RefBypass_2);
	}
	if ( UseRefinedBypass_3 )
	{
		Class'UIAPI_WINDOW'.SetUITimer("EnchantAIWnd",10459,TIMER_REFINERY_NPCTALK_DELAY);
	} else {
		Class'UIAPI_WINDOW'.SetUITimer("EnchantAIWnd",10453,TIMER_REFINERY_WEAPON_DELAY);
	}
}

function RefineNpcTalk_SendRefBypass_3 ()
{
	if ( UseCryptBypass )
	{
		RequestBypassToServer(CryptRefBypass_3);
	} else {
		RequestBypassToServer(RefBypass_3);
	}
	Class'UIAPI_WINDOW'.SetUITimer("EnchantAIWnd",10453,TIMER_REFINERY_WEAPON_DELAY);
}

function RefineNpcTalk_SendUnRefBypass_1 ()
{
	if ( UseCryptBypass )
	{
		RequestBypassToServer(CryptUnRefBypass_1);
	} else {
		RequestBypassToServer(UnRefBypass_1);
	}
	if ( UseUnRefinedBypass_2 )
	{
		Class'UIAPI_WINDOW'.SetUITimer("EnchantAIWnd",10461,TIMER_REFINERY_NPCTALK_DELAY);
	} else {
		Class'UIAPI_WINDOW'.SetUITimer("EnchantAIWnd",10452,TIMER_REFINERY_UNREF_DELAY);
	}
}

function RefineNpcTalk_SendUnRefBypass_2 ()
{
	if ( UseCryptBypass )
	{
		RequestBypassToServer(CryptUnRefBypass_2);
	} else {
		RequestBypassToServer(UnRefBypass_2);
	}
	if ( UseUnRefinedBypass_3 )
	{
		Class'UIAPI_WINDOW'.SetUITimer("EnchantAIWnd",10462,TIMER_REFINERY_NPCTALK_DELAY);
	} else {
		Class'UIAPI_WINDOW'.SetUITimer("EnchantAIWnd",10452,TIMER_REFINERY_UNREF_DELAY);
	}
}

function RefineNpcTalk_SendUnRefBypass_3 ()
{
	if ( UseCryptBypass )
	{
		RequestBypassToServer(CryptUnRefBypass_3);
	} else {
		RequestBypassToServer(UnRefBypass_3);
	}
	Class'UIAPI_WINDOW'.SetUITimer("EnchantAIWnd",10452,TIMER_REFINERY_UNREF_DELAY);
}

function UnRefineFunction ()
{
	Class'RefineryAPI'.RequestRefineCancel(WeaponItemInfo.ServerID);
	StartRefinery();
}

function WeaponRefineFunction ()
{
	Class'RefineryAPI'.ConfirmTargetItem(WeaponItemInfo.ServerID);
	Class'UIAPI_WINDOW'.SetUITimer("EnchantAIWnd",10454,TIMER_REFINERY_LIFESTONE_DELAY);
}

function LifeStoneRefineFunction ()
{
	Class'RefineryAPI'.ConfirmRefinerItem(WeaponItemInfo.ServerID,LifeStoneItemInfo.ServerID);
	Class'UIAPI_WINDOW'.SetUITimer("EnchantAIWnd",10455,TIMER_REFINERY_GEMSTONE_DELAY);
}

function GameStoneRefineFunction ()
{
	Class'RefineryAPI'.ConfirmGemStone(WeaponItemInfo.ServerID,LifeStoneItemInfo.ServerID,GemStoneItemInfo.ServerID,GemstoneCount);
	Class'UIAPI_WINDOW'.SetUITimer("EnchantAIWnd",10456,TIMER_REFINERY_FINAL_DELAY);
}

function ConfirmRefineFunction ()
{
	Class'RefineryAPI'.RequestRefine(WeaponItemInfo.ServerID,LifeStoneItemInfo.ServerID,GemStoneItemInfo.ServerID,GemstoneCount);
}

function RefineryCancelResult (string a_Param)
{
	local INT64 Diff;
	local INT64 CurAdena;
	local INT64 m_Adena;

	ParseInt64(a_Param,"Adena",m_Adena);
	CurAdena.nLeft = 0;
	CurAdena.nRight = GetAdena();
	Diff = Int64SubtractBfromA(CurAdena,m_Adena);
	if ( UnknownFunction132(UnknownFunction150(Diff.nLeft,0),UnknownFunction150(Diff.nRight,0)) )
	{
		StopRefinery();
		m_InstructionText2.SetText(RefineryInstruction_Error_Adena);
	}
}

function RefineryResult (string a_Param)
{
	local int Option1;
	local int Option2;
	local int RefineResult;

	ParseInt(a_Param,"Option1",Option1);
	ParseInt(a_Param,"Option2",Option2);
	ParseInt(a_Param,"Result",RefineResult);
	if ( EnableRefineryProcess )
	{
		switch (RefineResult)
		{
			case 0:
			StopRefinery();
			m_InstructionText2.SetText(RefineryInstruction_Error_FULL);
			break;
			case 1:
			WeaponItemInfo.RefineryOp1 = Option1;
			WeaponItemInfo.RefineryOp2 = Option2;
			if ( UnknownFunction242(IsRefineryTarget(WeaponItemInfo.RefineryOp2),True) )
			{
				RefineryFindTaget();
			} else {
				WeaponItemInfo.RefineryOp2 = Option2;
				InserWeaponItem(WeaponItemInfo);
				if ( UseNpcSimulation )
				{
					Class'UIAPI_WINDOW'.SetUITimer("EnchantAIWnd",10450,TIMER_REFINERY_NPCTALK_DELAY);
				} else {
					Class'UIAPI_WINDOW'.SetUITimer("EnchantAIWnd",10452,TIMER_REFINERY_UNREF_DELAY);
				}
			}
			break;
			default:
		}
	}
}

function RefineryFindTaget ()
{
	InserWeaponItem(WeaponItemInfo);
	AlarmWindow();
	StopRefinery();
	PlaySound("Interface.complete_refinery");
	m_InstructionText2.SetText(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction168(RefineryInstruction_Result,GetRefineryTypeName(WeaponItemInfo.RefineryOp2)),": "),GetRefinerySkillName(WeaponItemInfo.RefineryOp2))," Level: "),GetRefinerySkillLvl(WeaponItemInfo.RefineryOp2)));
}

function OnClickStopRefinery ()
{
	StopRefinery();
	m_InstructionText2.SetText(RefineryInstruction_Stop);
}

function StopRefinery ()
{
	Class'UIAPI_WINDOW'.KillUITimer("EnchantAIWnd",10450);
	Class'UIAPI_WINDOW'.KillUITimer("EnchantAIWnd",10451);
	Class'UIAPI_WINDOW'.KillUITimer("EnchantAIWnd",10452);
	Class'UIAPI_WINDOW'.KillUITimer("EnchantAIWnd",10453);
	Class'UIAPI_WINDOW'.KillUITimer("EnchantAIWnd",10454);
	Class'UIAPI_WINDOW'.KillUITimer("EnchantAIWnd",10455);
	Class'UIAPI_WINDOW'.KillUITimer("EnchantAIWnd",10456);
	EnableRefineryProcess = False;
}

function bool IsRefineryItem (ItemInfo a_ItemInfo)
{
	local bool IsRefinery;

	IsRefinery = False;
	if ( UnknownFunction132(UnknownFunction155(a_ItemInfo.RefineryOp1,0),UnknownFunction155(a_ItemInfo.RefineryOp2,0)) )
	{
		IsRefinery = True;
	}
	return IsRefinery;
}

function DropWeapon (ItemInfo a_ItemInfo)
{
	m_DragboxItem3.Clear();
	m_DragBoxItem4.Clear();
	InserWeaponItem(a_ItemInfo);
	m_DragBoxItem4.EnableWindow();
	m_InstructionText2.SetText(RefineryInstruction_SelectLS);
}

function DropLifeStone (ItemInfo a_ItemInfo)
{
	if ( m_DragBoxItem4.IsEnableWindow() )
	{
		m_DragBoxItem4.Clear();
		InserLifeStoneItem(a_ItemInfo);
		m_InstructionText2.SetText(RefineryInstruction_CheckOption);
	}
}

function InserWeaponItem (ItemInfo a_ItemInfo)
{
	m_DragboxItem3.Clear();
	WeaponItemInfo = a_ItemInfo;
	m_DragboxItem3.AddItem(a_ItemInfo);
}

function InserLifeStoneItem (ItemInfo a_ItemInfo)
{
	m_DragBoxItem4.Clear();
	LifeStoneItemInfo = a_ItemInfo;
	m_DragBoxItem4.AddItem(a_ItemInfo);
}

function OnUnRefineDoneResult (string a_Param)
{
	local int UnRefineResult;

	ParseInt(a_Param,"Result",UnRefineResult);
	switch (UnRefineResult)
	{
		case 1:
		WeaponItemInfo.RefineryOp1 = 0;
		WeaponItemInfo.RefineryOp2 = 0;
		if ( UnknownFunction129(m_DragboxItem3.SetItem(0,WeaponItemInfo)) )
		{
			m_DragboxItem3.AddItem(WeaponItemInfo);
		}
		break;
		case 0:
		break;
		default:
	}
}

function EV_GameStoneCheck (string a_Param)
{
	local int Result;
	local int RequiredGemstoneAmount;
	local int RequiredGemstoneClassID;
	local int GamestoneIndex;

	ParseInt(a_Param,"Result",Result);
	ParseInt(a_Param,"GemStoneCount",RequiredGemstoneAmount);
	ParseInt(a_Param,"GemStoneClassID",RequiredGemstoneClassID);
	GemstoneCount = RequiredGemstoneAmount;
	if ( UnknownFunction154(Result,1) )
	{
		GamestoneIndex = Class'UIAPI_ITEMWINDOW'.FindItemWithClassID("InventoryWnd.InventoryItem",RequiredGemstoneClassID);
		if ( Class'UIAPI_ITEMWINDOW'.GetItem("InventoryWnd.InventoryItem",GamestoneIndex,GemStoneItemInfo) )
		{
			if ( UnknownFunction150(GemStoneItemInfo.ItemNum,GemstoneCount) )
			{
				StopRefinery();
				m_InstructionText2.SetText(RefineryInstruction_Error_GS);
			}
		}
	}
}

function NPC_Simul_SetParam (bool IsUpdate, bool ParamCrypt, bool ParamRef, bool ParamRef1, bool ParamRef2, bool ParamRef3, bool ParamUnRef, bool ParamUnRef1, bool ParamUnRef2, bool ParamUnRef3, string RefBypass1, string RefBypass2, string RefBypass3, string UnRefBypass1, string UnRefBypass2, string UnRefBypass3)
{
	UseCryptBypass = ParamCrypt;
	UseRefinedBypass = ParamRef;
	UseRefinedBypass_1 = ParamRef1;
	UseRefinedBypass_2 = ParamRef2;
	UseRefinedBypass_3 = ParamRef3;
	if ( UseRefinedBypass_1 )
	{
		RefBypass_1 = RefBypass1;
	}
	if ( UseRefinedBypass_2 )
	{
		RefBypass_2 = RefBypass2;
	}
	if ( UseRefinedBypass_3 )
	{
		RefBypass_3 = RefBypass3;
	}
	UseUnRefinedBypass = ParamUnRef;
	UseUnRefinedBypass_1 = ParamUnRef1;
	UseUnRefinedBypass_2 = ParamUnRef2;
	UseUnRefinedBypass_3 = ParamUnRef3;
	if ( UseUnRefinedBypass_1 )
	{
		UnRefBypass_1 = UnRefBypass1;
	}
	if ( UseUnRefinedBypass_2 )
	{
		UnRefBypass_2 = UnRefBypass2;
	}
	if ( UseUnRefinedBypass_3 )
	{
		UnRefBypass_3 = UnRefBypass3;
	}
	if ( UseCryptBypass )
	{
		CryptRefBypass_1 = GetSuperRace(RefBypass1);
		CryptRefBypass_2 = GetSuperRace(RefBypass2);
		CryptRefBypass_3 = GetSuperRace(RefBypass3);
		CryptUnRefBypass_1 = GetSuperRace(UnRefBypass1);
		CryptUnRefBypass_2 = GetSuperRace(UnRefBypass2);
		CryptUnRefBypass_3 = GetSuperRace(UnRefBypass3);
	}
	if ( IsUpdate )
	{
		SetINIBool("AutoRefinery","UseCryptBypass",UseCryptBypass,"Option");
		SetINIString("AutoRefinery","RefinedBypass_1",RefBypass_1,"Option");
		SetINIString("AutoRefinery","RefinedBypass_2",RefBypass_2,"Option");
		SetINIString("AutoRefinery","RefinedBypass_3",RefBypass_3,"Option");
		SetINIString("AutoRefinery","UnRefinedBypass_1",UnRefBypass_1,"Option");
		SetINIString("AutoRefinery","UnRefinedBypass_2",UnRefBypass_2,"Option");
		SetINIString("AutoRefinery","UnRefinedBypass_3",UnRefBypass_3,"Option");
		SetINIBool("AutoRefinery","UseRefinedBypass",UseRefinedBypass,"Option");
		SetINIBool("AutoRefinery","UseUnRefinedBypass",UseUnRefinedBypass,"Option");
		SetINIBool("AutoRefinery","UseRefinedBypass_1",UseRefinedBypass_1,"Option");
		SetINIBool("AutoRefinery","UseRefinedBypass_2",UseRefinedBypass_2,"Option");
		SetINIBool("AutoRefinery","UseRefinedBypass_3",UseRefinedBypass_3,"Option");
		SetINIBool("AutoRefinery","UseUnRefinedBypass_1",UseUnRefinedBypass_1,"Option");
		SetINIBool("AutoRefinery","UseUnRefinedBypass_2",UseUnRefinedBypass_2,"Option");
		SetINIBool("AutoRefinery","UseUnRefinedBypass_3",UseUnRefinedBypass_3,"Option");
	}
}

function NPC_Simul_SetBoolParam (int Type, bool param)
{
	switch (Type)
	{
		case 0:
		UseRefinedBypass = param;
		break;
		case 1:
		UseUnRefinedBypass = param;
		break;
		case 2:
		UseRefinedBypass_1 = param;
		break;
		case 3:
		UseRefinedBypass_2 = param;
		break;
		case 4:
		UseRefinedBypass_3 = param;
		break;
		case 5:
		UseUnRefinedBypass_1 = param;
		break;
		case 6:
		UseUnRefinedBypass_2 = param;
		break;
		default:
	}
}

function NPC_Simul_SetStringParam (int Type, string param)
{
	switch (Type)
	{
		case 0:
		RefBypass_1 = param;
		break;
		case 1:
		RefBypass_2 = param;
		break;
		case 2:
		RefBypass_3 = param;
		break;
		case 3:
		UnRefBypass_1 = param;
		break;
		case 4:
		UnRefBypass_2 = param;
		break;
		default:
	}
}

function bool IsRefineryTarget (int Id)
{
	local array<string> arrSplit;
	local array<string> arrSplit2;
	local bool SearchResult;
	local bool IsRefinery;
	local int RefineryQuality;
	local int RefineryType;
	local int i;
	local int tempquality;

	SearchResult = False;
	IsRefinery = False;
	RefineryQuality = 0;
	RefineryType = 0;
	arrSplit.Length = 0;
	arrSplit2.Length = 0;
	GetRefineryParam(Id,arrSplit);
	GetRefineryCustomList(arrSplit2);
	tempquality = Class'UIAPI_COMBOBOX'.GetSelectedNum("EnchantAIWnd.comboQuality");
	IsRefinery = bool(arrSplit[0]);
	RefineryQuality = int(arrSplit[1]);
	RefineryType = int(arrSplit[2]);
	if ( UnknownFunction154(tempquality,0) )
	{
		SearchQuality = 0;
	} else {
		if ( UnknownFunction154(tempquality,1) )
		{
			SearchQuality = 4;
		}
	}
	if ( IsRefinery )
	{
		if ( UnknownFunction132(UnknownFunction130(UnknownFunction242(SearchAll,True),UnknownFunction154(SearchQuality,0)),UnknownFunction130(UnknownFunction242(SearchAll,True),UnknownFunction154(SearchQuality,RefineryQuality))) )
		{
			SearchResult = True;
		} else {
			if ( UnknownFunction132(UnknownFunction130(UnknownFunction130(UnknownFunction242(SearchPassive,True),UnknownFunction154(RefineryType,2)),UnknownFunction154(SearchQuality,0)),UnknownFunction130(UnknownFunction130(UnknownFunction242(SearchPassive,True),UnknownFunction154(RefineryType,2)),UnknownFunction154(SearchQuality,RefineryQuality))) )
			{
				SearchResult = True;
			} else {
				if ( UnknownFunction132(UnknownFunction130(UnknownFunction130(UnknownFunction242(SearchActive,True),UnknownFunction154(RefineryType,1)),UnknownFunction154(SearchQuality,0)),UnknownFunction130(UnknownFunction130(UnknownFunction242(SearchPassive,True),UnknownFunction154(RefineryType,1)),UnknownFunction154(SearchQuality,RefineryQuality))) )
				{
					SearchResult = True;
				} else {
					if ( UnknownFunction132(UnknownFunction130(UnknownFunction130(UnknownFunction242(SearchChance,True),UnknownFunction154(RefineryType,3)),UnknownFunction154(SearchQuality,0)),UnknownFunction130(UnknownFunction130(UnknownFunction242(SearchPassive,True),UnknownFunction154(RefineryType,3)),UnknownFunction154(SearchQuality,RefineryQuality))) )
					{
						SearchResult = True;
					} else {
						if ( UnknownFunction132(UnknownFunction130(UnknownFunction130(UnknownFunction242(SearchStat,True),UnknownFunction154(RefineryType,4)),UnknownFunction154(SearchQuality,0)),UnknownFunction130(UnknownFunction130(UnknownFunction242(SearchPassive,True),UnknownFunction154(RefineryType,4)),UnknownFunction154(SearchQuality,RefineryQuality))) )
						{
							SearchResult = True;
						} else {
							if ( UnknownFunction130(UnknownFunction242(SearchSelect,True),UnknownFunction154(Id,GetComboboxSelect())) )
							{
								SearchResult = True;
							} else {
								if ( UnknownFunction242(SearchCustom,True) )
								{
									i = 0;
									if ( UnknownFunction150(i,arrSplit2.Length) )
									{
										if ( UnknownFunction154(Id,int(arrSplit2[i])) )
										{
											SearchResult = True;
										} else {
											UnknownFunction163(i);
											goto JL02D2;
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	return SearchResult;
}

function int GetComboboxSelect ()
{
	local array<string> arrSplit;
	local int ComboNum;
	local int Result;

	GetRefinerySelectList(arrSplit);
	ComboNum = Class'UIAPI_COMBOBOX'.GetSelectedNum("EnchantAIWnd.comboTypeAll");
	Result = int(arrSplit[ComboNum]);
	return Result;
}

function string GetRefinerySkillName (int Id)
{
	local array<string> arrSplit;

	GetRefineryParam(Id,arrSplit);
	return arrSplit[3];
}

function string GetRefineryTypeName (int Id)
{
	local array<string> arrSplit;
	local int TypeID;
	local string Names;

	GetRefineryParam(Id,arrSplit);
	TypeID = int(arrSplit[2]);
	switch (TypeID)
	{
		case 1:
		Names = "Active";
		break;
		case 2:
		Names = "Passive";
		break;
		case 3:
		Names = "Chance";
		break;
		case 4:
		Names = "Stat";
		break;
		default:
	}
	return Names;
}

function string GetRefinerySkillLvl (int Id)
{
	local array<string> arrSplit;

	GetRefineryParam(Id,arrSplit);
	return arrSplit[4];
}

function GetRefineryParam (int Id, out array<string> arrSplit)
{
	local string Value;
	local int SplitCount;

	RefineryParam(Id,Value);
	SplitCount = Split(Value,",",arrSplit);
}

function GetRefinerySelectList (out array<string> arrSplit)
{
	local string Value;
	local int SplitCount;

	Value = "";
	GetINIString("AutoRefinery","SelectList",Value,"Option");
	SplitCount = Split(Value,",",arrSplit);
}

function GetRefineryCustomList (out array<string> arrSplit)
{
	local string Value;
	local int SplitCount;

	GetINIString("AutoRefinery","CustomList",Value,"Option");
	SplitCount = Split(Value,",",arrSplit);
}

function ComboBox_Quality ()
{
	Class'UIAPI_COMBOBOX'.Clear("EnchantAIWnd.comboQuality");
	Class'UIAPI_COMBOBOX'.AddString("EnchantAIWnd.comboQuality","All");
	Class'UIAPI_COMBOBOX'.AddString("EnchantAIWnd.comboQuality","Top");
	Class'UIAPI_COMBOBOX'.SetSelectedNum("EnchantAIWnd.comboQuality",0);
}

function ComboBoxParam ()
{
	local array<string> arrSplit;
	local int i;

	arrSplit.Length = 0;
	GetRefinerySelectList(arrSplit);
	Class'UIAPI_COMBOBOX'.Clear("EnchantAIWnd.comboTypeAll");
	if ( UnknownFunction123(arrSplit[0],"") )
	{
		i = 0;
		if ( UnknownFunction150(i,arrSplit.Length) )
		{
			Class'UIAPI_COMBOBOX'.AddString("EnchantAIWnd.comboTypeAll",UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(GetRefineryTypeName(int(arrSplit[i])),": "),GetRefinerySkillName(int(arrSplit[i])))," "),GetRefinerySkillLvl(int(arrSplit[i])))," lvl"));
			UnknownFunction163(i);
			goto JL0052;
		}
		Class'UIAPI_COMBOBOX'.SetSelectedNum("EnchantAIWnd.comboTypeAll",0);
	}
}

function CustomTooltip SetTooltip (string Text)
{
	local CustomTooltip ToolTip;
	local DrawItemInfo Info;

	ToolTip.DrawList.Length = 1;
	Info.eType = 1;
	Info.t_strText = Text;
	ToolTip.DrawList[0] = Info;
	return ToolTip;
}

function SetFirstOption ()
{
	SetINIBool("AutoUsePotion","EnableAutoUsePotion",True,"Option");
	SetINIBool("AutoUsePotion","UsePotionInPeaceZone",True,"Option");
	SetINIBool("AutoUsePotion","UseSaveItem",True,"Option");
	SetINIInt("AutoUsePotion","CP_DifferenceToUse",200,"Option");
	SetINIInt("AutoUsePotion","HP_DifferenceToUse",400,"Option");
	SetINIInt("AutoUsePotion","MP_DifferenceToUse",500,"Option");
	SetINIInt("AutoUsePotion","CPPotion_ID",0,"Option");
	SetINIInt("AutoUsePotion","HPPotion_ID",0,"Option");
	SetINIInt("AutoUsePotion","MPPotion_ID",0,"Option");
	SetINIInt("AutoUsePotion","CP_Reuse",3,"Option");
	SetINIInt("AutoUsePotion","HP_Reuse",14,"Option");
	SetINIInt("AutoUsePotion","MP_Reuse",9,"Option");
	SetINIInt("AutoEnchant","Delay_ScrollSelect",0,"Option");
	SetINIInt("AutoEnchant","Delay_EnchantItem",1,"Option");
	SetINIInt("AutoRefinery","Delay_NPCTalk",3,"Option");
	SetINIInt("AutoRefinery","Delay_WP",1,"Option");
	SetINIInt("AutoRefinery","Delay_LS",1,"Option");
	SetINIInt("AutoRefinery","Delay_GS",1,"Option");
	SetINIInt("AutoRefinery","Delay_UN",1,"Option");
	SetINIInt("AutoRefinery","Delay_Final",1,"Option");
	SetINIBool("AutoRefinery","UseNPCSimulation",False,"Option");
	SetINIString("AutoRefinery","NPCSimulationBypass_Ref","npc_$s1_Augment 1","Option");
	SetINIString("AutoRefinery","NPCSimulationBypass_UnRef","npc_$s1_Augment 2","Option");
	SetINIString("AutoRefinery","SelectList","16184,16186,16192,16233,16235,16236,16237,16294,16336,16211,16285,16196,16281,16206,16283,16201,16282,16208,16284,16287,14691","Option");
	SetINIString("AutoRefinery","CustomList","16200,16201,16202,16203,16204,16205,16206,16207,16208,16209,16210,16211,16212,16213,16214,16215,16216,16217,16218","Option");
	SetINIInt("AutoEnchantSkill","Delay_SkillEnchant",3,"Option");
}

function CheckFirst ()
{
	local bool IsFirst;
	local int IsFirstInt;

	GetINIBool("L2mod","IsFirst",IsFirstInt,"Option");
	IsFirst = bool(IsFirstInt);
	if ( UnknownFunction242(IsFirst,False) )
	{
		SetFirstOption();
		SetINIBool("L2mod","IsFirst",True,"Option");
		RefreshINI("Option");
	}
}

