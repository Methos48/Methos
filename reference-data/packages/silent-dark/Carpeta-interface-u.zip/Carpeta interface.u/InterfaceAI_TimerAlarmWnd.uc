//================================================================================
// InterfaceAI_TimerAlarmWnd.
//================================================================================

class InterfaceAI_TimerAlarmWnd extends UICommonAPI;

var WindowHandle Me;
const TIMER_DELAY=3000;
const TIMER_ID2=9921;
const TIMER_ID=9920;

function OnLoad ()
{
	RegisterEvent(19002);
	Me = GetHandle("InterfaceAI_TimerAlarmWnd");
}

function OnEvent (int Event_ID, string param)
{
	local string Second;
	local string TimerName;
	local string Text1;
	local string Text2;

	switch (Event_ID)
	{
		case 19002:
		ParseString(param,"Second",Second);
		ParseString(param,"TimerName",TimerName);
		ParseString(param,"String1",Text1);
		ParseString(param,"String2",Text2);
		BeginShowTimerAlarmName(Second,TimerName,Text1,Text2);
		break;
		default:
	}
}

function BeginShowTimerAlarmName (string Second, string TimerName, string Text1, string Text2)
{
	local string TextAlarn;

	TextAlarn = UnknownFunction168(UnknownFunction168(Text1,TimerName),Text2);
	Me.SetAlpha(0);
	ShowWindow("InterfaceAI_TimerAlarmWnd");
	Class'UIAPI_TEXTBOX'.SetText("InterfaceAI_TimerAlarmWnd.valTimerBack",TextAlarn);
	Class'UIAPI_TEXTBOX'.SetText("InterfaceAI_TimerAlarmWnd.valTimer",TextAlarn);
	Class'UIAPI_WINDOW'.SetUITimer("InterfaceAI_TimerAlarmWnd",9920,3000);
	Me.SetAlpha(255,1.0);
}

function OnTimer (int TimerID)
{
	if ( UnknownFunction154(TimerID,9920) )
	{
		Class'UIAPI_WINDOW'.KillUITimer("InterfaceAI_TimerAlarmWnd",9920);
		Me.SetAlpha(0,1.0);
		Class'UIAPI_WINDOW'.SetUITimer("InterfaceAI_TimerAlarmWnd",9921,3000);
	}
	if ( UnknownFunction154(TimerID,9921) )
	{
		Class'UIAPI_WINDOW'.KillUITimer("InterfaceAI_TimerAlarmWnd",9921);
		HideWindow("InterfaceAI_TimerAlarmWnd");
	}
}

