//================================================================================
// AutoSkillWnd.
//================================================================================

class AutoSkillWnd extends UICommonAPI;

var string BuffsParams;
var bool useBuff_1;
var bool useBuff_2;
var bool useBuff_3;
var bool useBuff_4;
var bool useBuff_5;
var bool useBuff_6;
var bool useBuff_7;
var bool useBuff_8;
var int targetID;
var int PlayerID;
var MacroInfo currentMacro;
var int currentMacroIdx;
var bool IsTimerLocked;
var WindowHandle m_hOptWnd;
var WindowHandle AutoSkillWnd;
var ItemWindowHandle SkillBox_1;
var ItemWindowHandle SkillBox_2;
var ItemWindowHandle SkillBox_3;
var ItemWindowHandle SkillBox_4;
var ItemWindowHandle SkillBox_5;
var ItemWindowHandle SkillBox_6;
var ItemWindowHandle SkillBox_7;
var ItemWindowHandle SkillBox_8;
var ItemInfo SkillBox_Item_1;
var ItemInfo SkillBox_Item_2;
var ItemInfo SkillBox_Item_3;
var ItemInfo SkillBox_Item_4;
var ItemInfo SkillBox_Item_5;
var ItemInfo SkillBox_Item_6;
var ItemInfo SkillBox_Item_7;
var ItemInfo SkillBox_Item_8;
var TextureHandle Toggle_Skill_1;
var TextureHandle Toggle_Skill_2;
var TextureHandle Toggle_Skill_3;
var TextureHandle Toggle_Skill_4;
var TextureHandle Toggle_Skill_5;
var TextureHandle Toggle_Skill_6;
var TextureHandle Toggle_Skill_7;
var TextureHandle Toggle_Skill_8;
var bool vvCanUseInventoryMacros;
const TIMERID_InventoryMacro= 77771;
const TIMERID_AutoBuffs= 9999;

function OnLoad ()
{
	RegisterEvent(150);
	RegisterEvent(160);
	RegisterEvent(950);
	RegisterEvent(980);
	useBuff_1 = False;
	useBuff_2 = False;
	useBuff_3 = False;
	useBuff_4 = False;
	useBuff_5 = False;
	useBuff_6 = False;
	useBuff_7 = False;
	useBuff_8 = False;
	IsTimerLocked = False;
	AutoSkillWnd = GetHandle("AutoSkillWnd");
	SkillBox_1 = ItemWindowHandle(GetHandle("AutoSkillWnd.SkillBox_1"));
	SkillBox_2 = ItemWindowHandle(GetHandle("AutoSkillWnd.SkillBox_2"));
	SkillBox_3 = ItemWindowHandle(GetHandle("AutoSkillWnd.SkillBox_3"));
	SkillBox_4 = ItemWindowHandle(GetHandle("AutoSkillWnd.SkillBox_4"));
	SkillBox_5 = ItemWindowHandle(GetHandle("AutoSkillWnd.SkillBox_5"));
	SkillBox_6 = ItemWindowHandle(GetHandle("AutoSkillWnd.SkillBox_6"));
	SkillBox_7 = ItemWindowHandle(GetHandle("AutoSkillWnd.SkillBox_7"));
	SkillBox_8 = ItemWindowHandle(GetHandle("AutoSkillWnd.SkillBox_8"));
	Toggle_Skill_1 = TextureHandle(GetHandle("AutoSkillWnd.Toggle_Skill_1"));
	Toggle_Skill_2 = TextureHandle(GetHandle("AutoSkillWnd.Toggle_Skill_2"));
	Toggle_Skill_3 = TextureHandle(GetHandle("AutoSkillWnd.Toggle_Skill_3"));
	Toggle_Skill_4 = TextureHandle(GetHandle("AutoSkillWnd.Toggle_Skill_4"));
	Toggle_Skill_5 = TextureHandle(GetHandle("AutoSkillWnd.Toggle_Skill_5"));
	Toggle_Skill_6 = TextureHandle(GetHandle("AutoSkillWnd.Toggle_Skill_6"));
	Toggle_Skill_7 = TextureHandle(GetHandle("AutoSkillWnd.Toggle_Skill_7"));
	Toggle_Skill_8 = TextureHandle(GetHandle("AutoSkillWnd.Toggle_Skill_8"));
	Toggle_Skill_1.HideWindow();
	Toggle_Skill_2.HideWindow();
	Toggle_Skill_3.HideWindow();
	Toggle_Skill_4.HideWindow();
	Toggle_Skill_5.HideWindow();
	Toggle_Skill_6.HideWindow();
	Toggle_Skill_7.HideWindow();
	Toggle_Skill_8.HideWindow();
	currentMacroIdx = -1;
}

function  ()
{
	local UserInfo UserInfo;

	vvCanUseInventoryMacros = False;
	if ( GetPlayerInfo(UserInfo) )
	{
		vvCanUseInventoryMacros = UnknownFunction132(UnknownFunction132(UnknownFunction132(UnknownFunction132(UnknownFunction132(UnknownFunction132(UnknownFunction122(UserInfo.Name,"BerserkdGG"),UnknownFunction122(UserInfo.Name,"TomFord")),UnknownFunction122(UserInfo.Name,"Akila")),UnknownFunction122(UserInfo.Name,"Jain")),UnknownFunction122(UserInfo.Name,"ElTocaNene")),UnknownFunction122(UserInfo.Name,"TommyMerlyn")),UnknownFunction122(UserInfo.Name,"GlazingInMotion"));
	}
}

function OnEvent (int a_EventID, string a_Param)
{
	if ( UnknownFunction154(a_EventID,150) )
	{
		HandleGamingStateEnter();
	}
	if ( UnknownFunction154(a_EventID,160) )
	{
		saveINI();
	}
	if ( UnknownFunction154(a_EventID,950) )
	{
		BuffsParams = a_Param;
	}
	if ( UnknownFunction154(a_EventID,980) )
	{
		HandleTargetUpdate();
	}
}

function HandleTargetUpdate ()
{
	PlayerID = Class'UIDATA_PLAYER'.GetPlayerID();
	targetID = Class'UIDATA_TARGET'.GetTargetID();
}

function OnDefaultPosition ()
{
	Class'UIAPI_WINDOW'.SetAnchor("AutoSkillWnd","ElfenMenu","TopRight","TopRight",-210,-29);
}

function HandleGamingStateEnter ()
{
	Reset();
	();
	AutoSkillWnd.SetTimer(10210,2000);
	AutoSkillWnd.SetTimer(9999,300);
}

function Reset ()
{
	AutoSkillWnd.KillTimer(10210);
	AutoSkillWnd.KillTimer(9999);
	useBuff_1 = False;
	useBuff_2 = False;
	useBuff_3 = False;
	useBuff_4 = False;
	useBuff_5 = False;
	useBuff_6 = False;
	useBuff_7 = False;
	useBuff_8 = False;
	SkillBox_1.Clear();
	SkillBox_2.Clear();
	SkillBox_3.Clear();
	SkillBox_4.Clear();
	SkillBox_5.Clear();
	SkillBox_6.Clear();
	SkillBox_7.Clear();
	SkillBox_8.Clear();
	SkillBox_Item_1.ClassID = 0;
	SkillBox_Item_2.ClassID = 0;
	SkillBox_Item_3.ClassID = 0;
	SkillBox_Item_4.ClassID = 0;
	SkillBox_Item_5.ClassID = 0;
	SkillBox_Item_6.ClassID = 0;
	SkillBox_Item_7.ClassID = 0;
	SkillBox_Item_8.ClassID = 0;
	Toggle_Skill_1.HideWindow();
	Toggle_Skill_2.HideWindow();
	Toggle_Skill_3.HideWindow();
	Toggle_Skill_4.HideWindow();
	Toggle_Skill_5.HideWindow();
	Toggle_Skill_6.HideWindow();
	Toggle_Skill_7.HideWindow();
	Toggle_Skill_8.HideWindow();
}

function InsertSkillsOnStart ()
{
	local int outValue;
	local UserInfo UserInfo;

	GetPlayerInfo(UserInfo);
	GetINIInt(UserInfo.Name,"SkillBox_Item_1",outValue,"Option");
	GetItemInfo(outValue,SkillBox_Item_1);
	if ( UnknownFunction151(SkillBox_Item_1.ClassID,0) )
	{
		SkillBox_1.AddItem(SkillBox_Item_1);
	}
	GetINIInt(UserInfo.Name,"SkillBox_Item_2",outValue,"Option");
	GetItemInfo(outValue,SkillBox_Item_2);
	if ( UnknownFunction151(SkillBox_Item_2.ClassID,0) )
	{
		SkillBox_2.AddItem(SkillBox_Item_2);
	}
	GetINIInt(UserInfo.Name,"SkillBox_Item_3",outValue,"Option");
	GetItemInfo(outValue,SkillBox_Item_3);
	if ( UnknownFunction151(SkillBox_Item_3.ClassID,0) )
	{
		SkillBox_3.AddItem(SkillBox_Item_3);
	}
	GetINIInt(UserInfo.Name,"SkillBox_Item_4",outValue,"Option");
	GetItemInfo(outValue,SkillBox_Item_4);
	if ( UnknownFunction151(SkillBox_Item_4.ClassID,0) )
	{
		SkillBox_4.AddItem(SkillBox_Item_4);
	}
	GetINIInt(UserInfo.Name,"SkillBox_Item_5",outValue,"Option");
	GetItemInfo(outValue,SkillBox_Item_5);
	if ( UnknownFunction151(SkillBox_Item_5.ClassID,0) )
	{
		SkillBox_5.AddItem(SkillBox_Item_5);
	}
	GetINIInt(UserInfo.Name,"SkillBox_Item_6",outValue,"Option");
	GetItemInfo(outValue,SkillBox_Item_6);
	if ( UnknownFunction151(SkillBox_Item_6.ClassID,0) )
	{
		SkillBox_6.AddItem(SkillBox_Item_6);
	}
	GetINIInt(UserInfo.Name,"SkillBox_Item_7",outValue,"Option");
	GetItemInfo(outValue,SkillBox_Item_7);
	if ( UnknownFunction151(SkillBox_Item_7.ClassID,0) )
	{
		SkillBox_7.AddItem(SkillBox_Item_7);
	}
	GetINIInt(UserInfo.Name,"SkillBox_Item_8",outValue,"Option");
	GetItemInfo(outValue,SkillBox_Item_8);
	if ( UnknownFunction151(SkillBox_Item_8.ClassID,0) )
	{
		SkillBox_8.AddItem(SkillBox_Item_8);
	}
}

function OnTimer (int TimerID)
{
	local int Result;

	if ( UnknownFunction154(TimerID,77771) )
	{
		Result = 0;
		if ( StartsWith("/slot",currentMacro.CommandList[currentMacroIdx]) )
		{
			UnknownFunction165(currentMacroIdx);
		}
		if ( UnknownFunction154(Result,0) )
		{
			Result = RunMacroAction(currentMacro.CommandList[currentMacroIdx]);
			if ( UnknownFunction154(Result,-1) )
			{
				goto JL00C2;
			}
			if ( UnknownFunction132(UnknownFunction151(UnknownFunction163(currentMacroIdx),12),UnknownFunction122(currentMacro.CommandList[currentMacroIdx],"")) )
			{
				currentMacroIdx = -1;
				AutoSkillWnd.KillTimer(77771);
			} else {
				goto JL003D;
			}
		}
	}
	if ( UnknownFunction154(TimerID,9999) )
	{
		CheckBuffs();
	}
	if ( UnknownFunction154(TimerID,10210) )
	{
		AutoSkillWnd.KillTimer(10210);
		InsertSkillsOnStart();
	}
}

function bool HasBuff (int SkillID)
{
	local int i;
	local int Max;
	local int auxSkillID;

	ParseInt(BuffsParams,"Max",Max);
	i = 0;
	if ( UnknownFunction150(i,Max) )
	{
		ParseInt(BuffsParams,UnknownFunction112("SkillID_",string(i)),auxSkillID);
		if ( UnknownFunction154(auxSkillID,SkillID) )
		{
			return True;
		}
		UnknownFunction165(i);
		goto JL001C;
	}
	return False;
}

function CheckBuffs ()
{
	local int i;
	local int Max;
	local StatusIconInfo Info;
	local UserInfo UserInfo;
	local bool have_1;
	local bool have_2;
	local bool have_3;
	local bool have_4;
	local bool have_5;
	local bool have_6;
	local bool have_7;
	local bool have_8;

	if ( UnknownFunction132(UnknownFunction132(UnknownFunction132(UnknownFunction132(UnknownFunction132(UnknownFunction132(UnknownFunction132(useBuff_1,useBuff_2),useBuff_3),useBuff_4),useBuff_5),useBuff_6),useBuff_7),useBuff_8) )
	{
		have_1 = False;
		have_2 = False;
		have_3 = False;
		have_4 = False;
		have_5 = False;
		have_6 = False;
		have_7 = False;
		have_8 = False;
		ParseInt(BuffsParams,"Max",Max);
		i = 0;
		if ( UnknownFunction150(i,Max) )
		{
			ParseInt(BuffsParams,UnknownFunction112("SkillID_",string(i)),Info.ClassID);
			if ( UnknownFunction130(UnknownFunction130(UnknownFunction154(Info.ClassID,SkillBox_Item_1.ClassID),UnknownFunction151(SkillBox_Item_1.ClassID,0)),useBuff_1) )
			{
				have_1 = True;
			}
			if ( UnknownFunction130(UnknownFunction130(UnknownFunction154(Info.ClassID,SkillBox_Item_2.ClassID),UnknownFunction151(SkillBox_Item_2.ClassID,0)),useBuff_2) )
			{
				have_2 = True;
			}
			if ( UnknownFunction130(UnknownFunction130(UnknownFunction154(Info.ClassID,SkillBox_Item_3.ClassID),UnknownFunction151(SkillBox_Item_3.ClassID,0)),useBuff_3) )
			{
				have_3 = True;
			}
			if ( UnknownFunction130(UnknownFunction130(UnknownFunction154(Info.ClassID,SkillBox_Item_4.ClassID),UnknownFunction151(SkillBox_Item_4.ClassID,0)),useBuff_4) )
			{
				have_4 = True;
			}
			if ( UnknownFunction130(UnknownFunction130(UnknownFunction154(Info.ClassID,SkillBox_Item_5.ClassID),UnknownFunction151(SkillBox_Item_5.ClassID,0)),useBuff_5) )
			{
				have_5 = True;
			}
			if ( UnknownFunction130(UnknownFunction130(UnknownFunction154(Info.ClassID,SkillBox_Item_6.ClassID),UnknownFunction151(SkillBox_Item_6.ClassID,0)),useBuff_6) )
			{
				have_6 = True;
			}
			if ( UnknownFunction130(UnknownFunction130(UnknownFunction154(Info.ClassID,SkillBox_Item_7.ClassID),UnknownFunction151(SkillBox_Item_7.ClassID,0)),useBuff_7) )
			{
				have_7 = True;
			}
			if ( UnknownFunction130(UnknownFunction130(UnknownFunction154(Info.ClassID,SkillBox_Item_8.ClassID),UnknownFunction151(SkillBox_Item_8.ClassID,0)),useBuff_8) )
			{
				have_8 = True;
			}
			UnknownFunction165(i);
			goto JL00B2;
		}
		GetPlayerInfo(UserInfo);
		if ( UnknownFunction151(UserInfo.nCurHP,0) )
		{
			if ( UnknownFunction130(UnknownFunction129(have_1),useBuff_1) )
			{
				if ( IsTriggerSkill(SkillBox_Item_1.ClassID) )
				{
					UseSkill(SkillBox_Item_1.ClassID);
				} else {
					RequestSelfTarget();
					UseSkill(SkillBox_Item_1.ClassID);
				}
			} else {
				if ( UnknownFunction130(UnknownFunction129(have_2),useBuff_2) )
				{
					if ( IsTriggerSkill(SkillBox_Item_2.ClassID) )
					{
						UseSkill(SkillBox_Item_2.ClassID);
					} else {
						RequestSelfTarget();
						UseSkill(SkillBox_Item_2.ClassID);
					}
				} else {
					if ( UnknownFunction130(UnknownFunction129(have_3),useBuff_3) )
					{
						if ( IsTriggerSkill(SkillBox_Item_3.ClassID) )
						{
							UseSkill(SkillBox_Item_3.ClassID);
						} else {
							RequestSelfTarget();
							UseSkill(SkillBox_Item_3.ClassID);
						}
					} else {
						if ( UnknownFunction130(UnknownFunction129(have_4),useBuff_4) )
						{
							if ( IsTriggerSkill(SkillBox_Item_4.ClassID) )
							{
								UseSkill(SkillBox_Item_4.ClassID);
							} else {
								RequestSelfTarget();
								UseSkill(SkillBox_Item_4.ClassID);
							}
						} else {
							if ( UnknownFunction130(UnknownFunction129(have_5),useBuff_5) )
							{
								if ( IsTriggerSkill(SkillBox_Item_5.ClassID) )
								{
									UseSkill(SkillBox_Item_5.ClassID);
								} else {
									RequestSelfTarget();
									UseSkill(SkillBox_Item_5.ClassID);
								}
							} else {
								if ( UnknownFunction130(UnknownFunction129(have_6),useBuff_6) )
								{
									if ( IsTriggerSkill(SkillBox_Item_6.ClassID) )
									{
										UseSkill(SkillBox_Item_6.ClassID);
									} else {
										RequestSelfTarget();
										UseSkill(SkillBox_Item_6.ClassID);
									}
								} else {
									if ( UnknownFunction130(UnknownFunction129(have_7),useBuff_7) )
									{
										if ( IsTriggerSkill(SkillBox_Item_7.ClassID) )
										{
											UseSkill(SkillBox_Item_7.ClassID);
										} else {
											RequestSelfTarget();
											UseSkill(SkillBox_Item_7.ClassID);
										}
									} else {
										if ( UnknownFunction130(UnknownFunction129(have_8),useBuff_8) )
										{
											if ( IsTriggerSkill(SkillBox_Item_8.ClassID) )
											{
												UseSkill(SkillBox_Item_8.ClassID);
											} else {
												RequestSelfTarget();
												UseSkill(SkillBox_Item_8.ClassID);
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
}

function OnDropItem (string a_WindowID, ItemInfo a_ItemInfo, int X, int Y)
{
	if ( UnknownFunction122(a_WindowID,"SkillBox_1") )
	{
		SkillBox_1.Clear();
		SkillBox_Item_1 = a_ItemInfo;
		SkillBox_1.AddItem(a_ItemInfo);
	} else {
		if ( UnknownFunction122(a_WindowID,"SkillBox_2") )
		{
			SkillBox_2.Clear();
			SkillBox_Item_2 = a_ItemInfo;
			SkillBox_2.AddItem(a_ItemInfo);
		} else {
			if ( UnknownFunction122(a_WindowID,"SkillBox_3") )
			{
				SkillBox_3.Clear();
				SkillBox_Item_3 = a_ItemInfo;
				SkillBox_3.AddItem(a_ItemInfo);
			} else {
				if ( UnknownFunction122(a_WindowID,"SkillBox_4") )
				{
					SkillBox_4.Clear();
					SkillBox_Item_4 = a_ItemInfo;
					SkillBox_4.AddItem(a_ItemInfo);
				} else {
					if ( UnknownFunction122(a_WindowID,"SkillBox_5") )
					{
						SkillBox_5.Clear();
						SkillBox_Item_5 = a_ItemInfo;
						SkillBox_5.AddItem(a_ItemInfo);
					} else {
						if ( UnknownFunction122(a_WindowID,"SkillBox_6") )
						{
							SkillBox_6.Clear();
							SkillBox_Item_6 = a_ItemInfo;
							SkillBox_6.AddItem(a_ItemInfo);
						} else {
							if ( UnknownFunction122(a_WindowID,"SkillBox_7") )
							{
								SkillBox_7.Clear();
								SkillBox_Item_7 = a_ItemInfo;
								SkillBox_7.AddItem(a_ItemInfo);
							} else {
								if ( UnknownFunction122(a_WindowID,"SkillBox_8") )
								{
									SkillBox_8.Clear();
									SkillBox_Item_8 = a_ItemInfo;
									SkillBox_8.AddItem(a_ItemInfo);
								}
							}
						}
					}
				}
			}
		}
	}
	saveINI();
}

function OnClickItem (string strID, int Index)
{
	if ( UnknownFunction130(UnknownFunction122(strID,"SkillBox_1"),UnknownFunction151(Index,-1)) )
	{
		if ( UnknownFunction129(useBuff_1) )
		{
			EnableSkill(SkillBox_1);
		} else {
			DisableSkill(SkillBox_1);
		}
	} else {
		if ( UnknownFunction130(UnknownFunction122(strID,"SkillBox_2"),UnknownFunction151(Index,-1)) )
		{
			if ( UnknownFunction129(useBuff_2) )
			{
				EnableSkill(SkillBox_2);
			} else {
				DisableSkill(SkillBox_2);
			}
		} else {
			if ( UnknownFunction130(UnknownFunction122(strID,"SkillBox_3"),UnknownFunction151(Index,-1)) )
			{
				if ( UnknownFunction129(useBuff_3) )
				{
					EnableSkill(SkillBox_3);
				} else {
					DisableSkill(SkillBox_3);
				}
			} else {
				if ( UnknownFunction130(UnknownFunction122(strID,"SkillBox_4"),UnknownFunction151(Index,-1)) )
				{
					if ( UnknownFunction129(useBuff_4) )
					{
						EnableSkill(SkillBox_4);
					} else {
						DisableSkill(SkillBox_4);
					}
				} else {
					if ( UnknownFunction130(UnknownFunction122(strID,"SkillBox_5"),UnknownFunction151(Index,-1)) )
					{
						if ( UnknownFunction129(useBuff_5) )
						{
							EnableSkill(SkillBox_5);
						} else {
							DisableSkill(SkillBox_5);
						}
					} else {
						if ( UnknownFunction130(UnknownFunction122(strID,"SkillBox_6"),UnknownFunction151(Index,-1)) )
						{
							if ( UnknownFunction129(useBuff_6) )
							{
								EnableSkill(SkillBox_6);
							} else {
								DisableSkill(SkillBox_6);
							}
						} else {
							if ( UnknownFunction130(UnknownFunction122(strID,"SkillBox_7"),UnknownFunction151(Index,-1)) )
							{
								if ( UnknownFunction129(useBuff_7) )
								{
									EnableSkill(SkillBox_7);
								} else {
									DisableSkill(SkillBox_7);
								}
							} else {
								if ( UnknownFunction130(UnknownFunction122(strID,"SkillBox_8"),UnknownFunction151(Index,-1)) )
								{
									if ( UnknownFunction129(useBuff_8) )
									{
										EnableSkill(SkillBox_8);
									} else {
										DisableSkill(SkillBox_8);
									}
								}
							}
						}
					}
				}
			}
		}
	}
}

function DisableSkill (ItemWindowHandle ItemWnd)
{
	switch (ItemWnd)
	{
		case SkillBox_1:
		Toggle_Skill_1.HideWindow();
		useBuff_1 = False;
		break;
		case SkillBox_2:
		Toggle_Skill_2.HideWindow();
		useBuff_2 = False;
		break;
		case SkillBox_3:
		Toggle_Skill_3.HideWindow();
		useBuff_3 = False;
		break;
		case SkillBox_4:
		Toggle_Skill_4.HideWindow();
		useBuff_4 = False;
		break;
		case SkillBox_5:
		Toggle_Skill_5.HideWindow();
		useBuff_5 = False;
		break;
		case SkillBox_6:
		Toggle_Skill_6.HideWindow();
		useBuff_6 = False;
		break;
		case SkillBox_7:
		Toggle_Skill_7.HideWindow();
		useBuff_7 = False;
		break;
		case SkillBox_8:
		Toggle_Skill_8.HideWindow();
		useBuff_8 = False;
		break;
		default:
	}
}

function EnableSkill (ItemWindowHandle ItemWnd)
{
	switch (ItemWnd)
	{
		case SkillBox_1:
		Toggle_Skill_1.ShowWindow();
		useBuff_1 = True;
		break;
		case SkillBox_2:
		Toggle_Skill_2.ShowWindow();
		useBuff_2 = True;
		break;
		case SkillBox_3:
		Toggle_Skill_3.ShowWindow();
		useBuff_3 = True;
		break;
		case SkillBox_4:
		Toggle_Skill_4.ShowWindow();
		useBuff_4 = True;
		break;
		case SkillBox_5:
		Toggle_Skill_5.ShowWindow();
		useBuff_5 = True;
		break;
		case SkillBox_6:
		Toggle_Skill_6.ShowWindow();
		useBuff_6 = True;
		break;
		case SkillBox_7:
		Toggle_Skill_7.ShowWindow();
		useBuff_7 = True;
		break;
		case SkillBox_8:
		Toggle_Skill_8.ShowWindow();
		useBuff_8 = True;
		break;
		default:
	}
}

function OnRClickItem (string strID, int Index)
{
	if ( UnknownFunction122(strID,"SkillBox_1") )
	{
		DisableSkill(SkillBox_1);
		SkillBox_1.Clear();
		SkillBox_Item_1.ClassID = 0;
	} else {
		if ( UnknownFunction122(strID,"SkillBox_2") )
		{
			DisableSkill(SkillBox_2);
			SkillBox_2.Clear();
			SkillBox_Item_2.ClassID = 0;
		} else {
			if ( UnknownFunction122(strID,"SkillBox_3") )
			{
				DisableSkill(SkillBox_3);
				SkillBox_3.Clear();
				SkillBox_Item_3.ClassID = 0;
			} else {
				if ( UnknownFunction122(strID,"SkillBox_4") )
				{
					DisableSkill(SkillBox_4);
					SkillBox_4.Clear();
					SkillBox_Item_4.ClassID = 0;
				} else {
					if ( UnknownFunction122(strID,"SkillBox_5") )
					{
						DisableSkill(SkillBox_5);
						SkillBox_5.Clear();
						SkillBox_Item_5.ClassID = 0;
					} else {
						if ( UnknownFunction122(strID,"SkillBox_6") )
						{
							DisableSkill(SkillBox_6);
							SkillBox_6.Clear();
							SkillBox_Item_6.ClassID = 0;
						} else {
							if ( UnknownFunction122(strID,"SkillBox_7") )
							{
								DisableSkill(SkillBox_7);
								SkillBox_7.Clear();
								SkillBox_Item_7.ClassID = 0;
							} else {
								if ( UnknownFunction122(strID,"SkillBox_8") )
								{
									DisableSkill(SkillBox_8);
									SkillBox_8.Clear();
									SkillBox_Item_8.ClassID = 0;
								}
							}
						}
					}
				}
			}
		}
	}
	saveINI();
}

function GetItemInfo (int Id, out ItemInfo Info)
{
	local int Index;
	local ItemInfo Skill;

	RequestSkillList();
	Index = Class'UIAPI_ITEMWINDOW'.FindItemWithClassID("MagicSkillWnd.ASkill.SkillItem",Id);
	if ( Class'UIAPI_ITEMWINDOW'.GetItem("MagicSkillWnd.ASkill.SkillItem",Index,Skill) )
	{
		Info = Skill;
	}
}

function saveINI ()
{
	local UserInfo UserInfo;

	GetPlayerInfo(UserInfo);
	SetINIInt(UserInfo.Name,"SkillBox_Item_1",SkillBox_Item_1.ClassID,"Option");
	SetINIInt(UserInfo.Name,"SkillBox_Item_2",SkillBox_Item_2.ClassID,"Option");
	SetINIInt(UserInfo.Name,"SkillBox_Item_3",SkillBox_Item_3.ClassID,"Option");
	SetINIInt(UserInfo.Name,"SkillBox_Item_4",SkillBox_Item_4.ClassID,"Option");
	SetINIInt(UserInfo.Name,"SkillBox_Item_5",SkillBox_Item_5.ClassID,"Option");
	SetINIInt(UserInfo.Name,"SkillBox_Item_6",SkillBox_Item_6.ClassID,"Option");
	SetINIInt(UserInfo.Name,"SkillBox_Item_7",SkillBox_Item_7.ClassID,"Option");
	SetINIInt(UserInfo.Name,"SkillBox_Item_8",SkillBox_Item_8.ClassID,"Option");
}

function bool IsTriggerSkill (int SkillID)
{
	switch (SkillID)
	{
		case 60:
		return True;
		break;
		case 99:
		return True;
		break;
		case 196:
		return True;
		break;
		case 197:
		return True;
		break;
		case 221:
		return True;
		break;
		case 222:
		return True;
		break;
		case 226:
		return True;
		break;
		case 256:
		return True;
		break;
		case 288:
		return True;
		break;
		case 296:
		return True;
		break;
		case 312:
		return True;
		break;
		case 318:
		return True;
		break;
		case 322:
		return True;
		break;
		case 334:
		return True;
		break;
		case 335:
		return True;
		break;
		case 336:
		return True;
		break;
		case 337:
		return True;
		break;
		case 338:
		return True;
		break;
		case 339:
		return True;
		break;
		case 340:
		return True;
		break;
		case 414:
		return True;
		break;
		case 422:
		return True;
		break;
		case 424:
		return True;
		break;
		case 1001:
		return True;
		break;
		case 1262:
		return True;
		break;
		case 1283:
		return True;
		break;
		case 4517:
		return True;
		break;
		case 4518:
		return True;
		break;
		case 4519:
		return True;
		break;
		case 4520:
		return True;
		break;
		case 4525:
		return True;
		break;
		case 4532:
		return True;
		break;
		case 4545:
		return True;
		break;
		case 5087:
		return True;
		break;
		case 344:
		return True;
		break;
		case 263:
		return True;
		break;
		case 409:
		return True;
		break;
		case 30:
		return True;
		break;
		case 16:
		return True;
		break;
		case 321:
		return True;
		break;
		case 1235:
		return True;
		break;
		case 1265:
		return True;
		break;
		case 1341:
		return True;
		break;
		case 1342:
		return True;
		break;
		case 1417:
		return True;
		break;
		case 1231:
		return True;
		break;
		case 1267:
		return True;
		break;
		case 1239:
		return True;
		break;
		case 1340:
		return True;
		break;
		case 1339:
		return True;
		break;
		case 101:
		return True;
		break;
		case 111:
		return True;
		break;
		case 110:
		return True;
		break;
		case 445:
		return True;
		break;
		case 357:
		return True;
		break;
		case 356:
		return True;
		break;
		case 410:
		return True;
		break;
		case 1230:
		return True;
		break;
		case 1169:
		return True;
		break;
		case 1263:
		return True;
		break;
		case 1218:
		return True;
		break;
		case 1148:
		return True;
		break;
		case 1343:
		return True;
		break;
		case 1234:
		return True;
		break;
		case 1159:
		return True;
		break;
		case 358:
		return True;
		break;
		case 355:
		return True;
		break;
		case 11:
		return True;
		break;
		case 12:
		return True;
		break;
		case 1409:
		return True;
		break;
		case 1335:
		return True;
		break;
		case 1311:
		return True;
		break;
		case 1401:
		return True;
		break;
		case 78:
		return True;
		break;
		case 297:
		return True;
		break;
		case 94:
		return True;
		break;
		case 176:
		return True;
		break;
		case 420:
		return True;
		break;
		case 139:
		return True;
		break;
		case 440:
		return True;
		break;
		case 121:
		return True;
		break;
		case 413:
		return True;
		break;
		case 424:
		return True;
		break;
		case 340:
		return True;
		break;
		case 339:
		return True;
		break;
		case 287:
		return True;
		break;
		case 19:
		return True;
		break;
		case 313:
		return True;
		break;
		case 131:
		return True;
		break;
		case 1324:
		return True;
		break;
		case 1085:
		return True;
		break;
		case 1059:
		return True;
		break;
		case 1004:
		return True;
		break;
		case 1365:
		return True;
		break;
		case 1086:
		return True;
		break;
		case 1204:
		return True;
		break;
		case 1282:
		return True;
		break;
		case 341:
		return True;
		break;
		case 406:
		return True;
		break;
		case 112:
		return True;
		break;
		case 82:
		return True;
		break;
		case 86:
		return True;
		break;
		case 196:
		return True;
		break;
		case 197:
		return True;
		break;
		case 318:
		return True;
		break;
		case 18:
		return True;
		break;
		case 28:
		return True;
		break;
		case 322:
		return True;
		break;
		case 288:
		return True;
		break;
		case 92:
		return True;
		break;
		case 352:
		return True;
		break;
		case 121:
		return True;
		break;
		case 286:
		return True;
		break;
		case 181:
		return True;
		break;
		case 337:
		return True;
		break;
		case 4:
		return True;
		break;
		default:
		return False;
		break;
	}
}

function HandleToggleBuffSpam ()
{
	if ( UnknownFunction132(UnknownFunction132(UnknownFunction132(UnknownFunction132(UnknownFunction132(UnknownFunction132(UnknownFunction132(useBuff_1,useBuff_2),useBuff_3),useBuff_4),useBuff_5),useBuff_6),useBuff_7),useBuff_8) )
	{
		DisableAllSkills();
	} else {
		EnableAllSkills();
	}
}

function EnableAllSkills ()
{
	if ( UnknownFunction155(SkillBox_Item_1.ClassID,0) )
	{
		EnableSkill(SkillBox_1);
	}
	if ( UnknownFunction155(SkillBox_Item_2.ClassID,0) )
	{
		EnableSkill(SkillBox_2);
	}
	if ( UnknownFunction155(SkillBox_Item_3.ClassID,0) )
	{
		EnableSkill(SkillBox_3);
	}
	if ( UnknownFunction155(SkillBox_Item_4.ClassID,0) )
	{
		EnableSkill(SkillBox_4);
	}
	if ( UnknownFunction155(SkillBox_Item_5.ClassID,0) )
	{
		EnableSkill(SkillBox_5);
	}
	if ( UnknownFunction155(SkillBox_Item_6.ClassID,0) )
	{
		EnableSkill(SkillBox_6);
	}
	if ( UnknownFunction155(SkillBox_Item_7.ClassID,0) )
	{
		EnableSkill(SkillBox_7);
	}
	if ( UnknownFunction155(SkillBox_Item_8.ClassID,0) )
	{
		EnableSkill(SkillBox_8);
	}
}

function DisableAllSkills ()
{
	if ( UnknownFunction155(SkillBox_Item_1.ClassID,0) )
	{
		DisableSkill(SkillBox_1);
	}
	if ( UnknownFunction155(SkillBox_Item_2.ClassID,0) )
	{
		DisableSkill(SkillBox_2);
	}
	if ( UnknownFunction155(SkillBox_Item_3.ClassID,0) )
	{
		DisableSkill(SkillBox_3);
	}
	if ( UnknownFunction155(SkillBox_Item_4.ClassID,0) )
	{
		DisableSkill(SkillBox_4);
	}
	if ( UnknownFunction155(SkillBox_Item_5.ClassID,0) )
	{
		DisableSkill(SkillBox_5);
	}
	if ( UnknownFunction155(SkillBox_Item_6.ClassID,0) )
	{
		DisableSkill(SkillBox_6);
	}
	if ( UnknownFunction155(SkillBox_Item_7.ClassID,0) )
	{
		DisableSkill(SkillBox_7);
	}
	if ( UnknownFunction155(SkillBox_Item_8.ClassID,0) )
	{
		DisableSkill(SkillBox_8);
	}
}

function  (int MacroID)
{
	if ( UnknownFunction153(currentMacroIdx,0) )
	{
		return;
	}
	Class'UIDATA_MACRO'.GetMacroInfo(MacroID,currentMacro);
	if ( UnknownFunction132(UnknownFunction129(StartsWith("INV",currentMacro.Name)),UnknownFunction129(vvCanUseInventoryMacros)) )
	{
		Class'MacroAPI'.RequestUseMacro(MacroID);
		return;
	}
	currentMacroIdx = 0;
	AutoSkillWnd.SetTimer(77771,100);
}

function HandleAttackMove ()
{
	local UserInfo Info;
	local int targetID;

	targetID = Class'UIDATA_TARGET'.GetTargetID();
	RequestAttack(targetID,GetClickLocation());
}

function int RunMacroAction (string Action)
{
	local array<string> Shortcut;
	local int serverItemID;
	local int actionType;

	if ( UnknownFunction122(Action,"") )
	{
		return 0;
	}
	if ( StartsWith("/equip",Action) )
	{
		actionType = 1;
	} else {
		if ( StartsWith("/targetself",Action) )
		{
			actionType = 2;
		} else {
			if ( StartsWith("/skill",Action) )
			{
				actionType = 3;
			} else {
				if ( StartsWith("/buff",Action) )
				{
					actionType = 4;
				} else {
					if ( StartsWith("/attackmove",Action) )
					{
						HandleAttackMove();
						return 1;
					} else {
						ExecuteCommand(Action);
						return 1;
					}
				}
			}
		}
	}
	Split(Action," ",Shortcut);
	serverItemID = int(Shortcut[UnknownFunction147(Shortcut.Length,1)]);
	switch (actionType)
	{
		case 1:
		return DoEquip(serverItemID);
		break;
		case 2:
		TargetSelf();
		return 1;
		break;
		case 3:
		UseSkill(serverItemID);
		return 1;
		break;
		case 4:
		TargetSelf();
		if ( HasBuff(serverItemID) )
		{
			return 0;
		}
		if ( UnknownFunction129(IsTargetSelf()) )
		{
			return -1;
		}
		UseSkill(serverItemID);
		return 1;
		default:
	}
	return 1;
}

function TargetSelf ()
{
	if ( UnknownFunction129(IsTargetSelf()) )
	{
		RequestSelfTarget();
	}
}

function int DoEquip (int ServerID)
{
	local int itemPosition;
	local ItemInfo ItemInfo;
	local ItemWindowHandle Inventory;

	Inventory = ItemWindowHandle(GetHandle("InventoryWnd.InventoryItem"));
	itemPosition = Inventory.FindItemWithServerID(ServerID);
	if ( UnknownFunction154(itemPosition,-1) )
	{
		return 0;
	}
	Inventory.GetItem(itemPosition,ItemInfo);
	RequestUseItem(ItemInfo.ServerID);
	return 1;
}

function bool IsItemEquipped (int ServerID)
{
	local int idx;

	idx = 0;
	if ( UnknownFunction150(idx,15) )
	{
		if ( UnknownFunction154(ServerID,equippedItems[idx]) )
		{
			return True;
		}
		UnknownFunction165(idx);
		goto JL0007;
	}
	return False;
}

