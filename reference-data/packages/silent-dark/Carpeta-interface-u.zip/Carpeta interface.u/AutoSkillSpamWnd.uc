//================================================================================
// AutoSkillSpamWnd.
//================================================================================

class AutoSkillSpamWnd extends UICommonAPI;

var bool useSpam_1;
var bool useSpam_2;
var bool useSpam_3;
var bool useSpam_4;
var bool useSpam_5;
var WindowHandle m_hOptWnd;
var WindowHandle AutoSkillSpamWnd;
var ItemWindowHandle SkillBox_Spam_1;
var ItemWindowHandle SkillBox_Spam_2;
var ItemWindowHandle SkillBox_Spam_3;
var ItemWindowHandle SkillBox_Spam_4;
var ItemWindowHandle SkillBox_Spam_5;
var ItemInfo SkillBox_Spam_Spam_Item_1;
var ItemInfo SkillBox_Spam_Spam_Item_2;
var ItemInfo SkillBox_Spam_Spam_Item_3;
var ItemInfo SkillBox_Spam_Spam_Item_4;
var ItemInfo SkillBox_Spam_Spam_Item_5;
var TextureHandle Toggle_Skill_Spam_1;
var TextureHandle Toggle_Skill_Spam_2;
var TextureHandle Toggle_Skill_Spam_3;
var TextureHandle Toggle_Skill_Spam_4;
var TextureHandle Toggle_Skill_Spam_5;
const TIMERID_SPAM_SKILL= 9999;

function OnLoad ()
{
	RegisterEvent(150);
	RegisterEvent(160);
	useSpam_1 = False;
	useSpam_2 = False;
	useSpam_3 = False;
	useSpam_4 = False;
	useSpam_5 = False;
	AutoSkillSpamWnd = GetHandle("AutoSkillSpamWnd");
	SkillBox_Spam_1 = ItemWindowHandle(GetHandle("AutoSkillSpamWnd.SkillBox_Spam_1"));
	SkillBox_Spam_2 = ItemWindowHandle(GetHandle("AutoSkillSpamWnd.SkillBox_Spam_2"));
	SkillBox_Spam_3 = ItemWindowHandle(GetHandle("AutoSkillSpamWnd.SkillBox_Spam_3"));
	SkillBox_Spam_4 = ItemWindowHandle(GetHandle("AutoSkillSpamWnd.SkillBox_Spam_4"));
	SkillBox_Spam_5 = ItemWindowHandle(GetHandle("AutoSkillSpamWnd.SkillBox_Spam_5"));
	Toggle_Skill_Spam_1 = TextureHandle(GetHandle("AutoSkillSpamWnd.Toggle_Skill_Spam_1"));
	Toggle_Skill_Spam_2 = TextureHandle(GetHandle("AutoSkillSpamWnd.Toggle_Skill_Spam_2"));
	Toggle_Skill_Spam_3 = TextureHandle(GetHandle("AutoSkillSpamWnd.Toggle_Skill_Spam_3"));
	Toggle_Skill_Spam_4 = TextureHandle(GetHandle("AutoSkillSpamWnd.Toggle_Skill_Spam_4"));
	Toggle_Skill_Spam_5 = TextureHandle(GetHandle("AutoSkillSpamWnd.Toggle_Skill_Spam_5"));
	Toggle_Skill_Spam_1.HideWindow();
	Toggle_Skill_Spam_2.HideWindow();
	Toggle_Skill_Spam_3.HideWindow();
	Toggle_Skill_Spam_4.HideWindow();
	Toggle_Skill_Spam_5.HideWindow();
}

function HandleToggleSkillSpam ()
{
	if ( UnknownFunction132(UnknownFunction132(UnknownFunction132(useSpam_1,useSpam_2),useSpam_3),useSpam_4) )
	{
		DisableAllSkills();
	} else {
		EnableAllSkills();
	}
}

function OnEvent (int a_EventID, string a_Param)
{
	if ( UnknownFunction154(a_EventID,150) )
	{
		HandleGamingStateEnter();
	}
	if ( UnknownFunction154(a_EventID,160) )
	{
		saveINI();
	}
}

function HandleGamingStateEnter ()
{
	Reset();
	AutoSkillSpamWnd.SetTimer(10210,2000);
	AutoSkillSpamWnd.SetTimer(9999,50);
}

function Reset ()
{
	AutoSkillSpamWnd.KillTimer(10210);
	AutoSkillSpamWnd.KillTimer(9999);
	useSpam_1 = False;
	useSpam_2 = False;
	useSpam_3 = False;
	useSpam_4 = False;
	useSpam_5 = False;
	SkillBox_Spam_1.Clear();
	SkillBox_Spam_2.Clear();
	SkillBox_Spam_3.Clear();
	SkillBox_Spam_4.Clear();
	SkillBox_Spam_5.Clear();
	SkillBox_Spam_Spam_Item_1.ClassID = 0;
	SkillBox_Spam_Spam_Item_2.ClassID = 0;
	SkillBox_Spam_Spam_Item_3.ClassID = 0;
	SkillBox_Spam_Spam_Item_4.ClassID = 0;
	SkillBox_Spam_Spam_Item_5.ClassID = 0;
	Toggle_Skill_Spam_1.HideWindow();
	Toggle_Skill_Spam_2.HideWindow();
	Toggle_Skill_Spam_3.HideWindow();
	Toggle_Skill_Spam_4.HideWindow();
	Toggle_Skill_Spam_5.HideWindow();
}

function InsertSkillsOnStart ()
{
	local int outValue;
	local UserInfo UserInfo;

	GetPlayerInfo(UserInfo);
	GetINIInt(UserInfo.Name,"SkillBox_Spam_Spam_Item_1",outValue,"Option");
	if ( UnknownFunction132(UnknownFunction154(outValue,2),UnknownFunction154(outValue,4)) )
	{
		GetActionInfoFunc(outValue,SkillBox_Spam_Spam_Item_1);
	} else {
		GetSkillInfoFunc(outValue,SkillBox_Spam_Spam_Item_1);
	}
	if ( UnknownFunction151(SkillBox_Spam_Spam_Item_1.ClassID,0) )
	{
		SkillBox_Spam_1.AddItem(SkillBox_Spam_Spam_Item_1);
	}
	GetINIInt(UserInfo.Name,"SkillBox_Spam_Spam_Item_2",outValue,"Option");
	if ( UnknownFunction132(UnknownFunction154(outValue,2),UnknownFunction154(outValue,4)) )
	{
		GetActionInfoFunc(outValue,SkillBox_Spam_Spam_Item_2);
	} else {
		GetSkillInfoFunc(outValue,SkillBox_Spam_Spam_Item_2);
	}
	if ( UnknownFunction151(SkillBox_Spam_Spam_Item_2.ClassID,0) )
	{
		SkillBox_Spam_2.AddItem(SkillBox_Spam_Spam_Item_2);
	}
	GetINIInt(UserInfo.Name,"SkillBox_Spam_Spam_Item_3",outValue,"Option");
	if ( UnknownFunction132(UnknownFunction154(outValue,2),UnknownFunction154(outValue,4)) )
	{
		GetActionInfoFunc(outValue,SkillBox_Spam_Spam_Item_3);
	} else {
		GetSkillInfoFunc(outValue,SkillBox_Spam_Spam_Item_3);
	}
	if ( UnknownFunction151(SkillBox_Spam_Spam_Item_3.ClassID,0) )
	{
		SkillBox_Spam_3.AddItem(SkillBox_Spam_Spam_Item_3);
	}
	GetINIInt(UserInfo.Name,"SkillBox_Spam_Spam_Item_4",outValue,"Option");
	if ( UnknownFunction132(UnknownFunction154(outValue,2),UnknownFunction154(outValue,4)) )
	{
		GetActionInfoFunc(outValue,SkillBox_Spam_Spam_Item_4);
	} else {
		GetSkillInfoFunc(outValue,SkillBox_Spam_Spam_Item_4);
	}
	if ( UnknownFunction151(SkillBox_Spam_Spam_Item_4.ClassID,0) )
	{
		SkillBox_Spam_4.AddItem(SkillBox_Spam_Spam_Item_4);
	}
	GetINIInt(UserInfo.Name,"SkillBox_Spam_Spam_Item_5",outValue,"Option");
	if ( UnknownFunction132(UnknownFunction154(outValue,2),UnknownFunction154(outValue,4)) )
	{
		GetActionInfoFunc(outValue,SkillBox_Spam_Spam_Item_5);
	} else {
		GetSkillInfoFunc(outValue,SkillBox_Spam_Spam_Item_5);
	}
	if ( UnknownFunction151(SkillBox_Spam_Spam_Item_5.ClassID,0) )
	{
		SkillBox_Spam_5.AddItem(SkillBox_Spam_Spam_Item_5);
	}
}

function OnTimer (int a_TimerID)
{
	if ( UnknownFunction154(a_TimerID,9999) )
	{
		SpamSkills();
	}
	if ( UnknownFunction154(a_TimerID,10210) )
	{
		AutoSkillSpamWnd.KillTimer(10210);
		InsertSkillsOnStart();
	}
}

function SpamSkills ()
{
	local UserInfo UserInfo;

	GetPlayerInfo(UserInfo);
	if ( UnknownFunction151(UserInfo.nCurHP,0) )
	{
		if ( useSpam_1 )
		{
			if ( UnknownFunction132(UnknownFunction154(SkillBox_Spam_Spam_Item_1.ClassID,4),UnknownFunction154(SkillBox_Spam_Spam_Item_1.ClassID,2)) )
			{
				DoAction(SkillBox_Spam_Spam_Item_1.ClassID);
			} else {
				UseSkill(SkillBox_Spam_Spam_Item_1.ClassID);
			}
		}
		if ( useSpam_2 )
		{
			if ( UnknownFunction132(UnknownFunction154(SkillBox_Spam_Spam_Item_2.ClassID,4),UnknownFunction154(SkillBox_Spam_Spam_Item_2.ClassID,2)) )
			{
				DoAction(SkillBox_Spam_Spam_Item_2.ClassID);
			} else {
				UseSkill(SkillBox_Spam_Spam_Item_2.ClassID);
			}
		}
		if ( useSpam_3 )
		{
			if ( UnknownFunction132(UnknownFunction154(SkillBox_Spam_Spam_Item_3.ClassID,4),UnknownFunction154(SkillBox_Spam_Spam_Item_3.ClassID,2)) )
			{
				DoAction(SkillBox_Spam_Spam_Item_3.ClassID);
			} else {
				UseSkill(SkillBox_Spam_Spam_Item_3.ClassID);
			}
		}
		if ( useSpam_4 )
		{
			if ( UnknownFunction132(UnknownFunction154(SkillBox_Spam_Spam_Item_4.ClassID,4),UnknownFunction154(SkillBox_Spam_Spam_Item_4.ClassID,2)) )
			{
				DoAction(SkillBox_Spam_Spam_Item_4.ClassID);
			} else {
				UseSkill(SkillBox_Spam_Spam_Item_4.ClassID);
			}
		}
		if ( useSpam_5 )
		{
			if ( UnknownFunction132(UnknownFunction154(SkillBox_Spam_Spam_Item_5.ClassID,4),UnknownFunction154(SkillBox_Spam_Spam_Item_5.ClassID,2)) )
			{
				DoAction(SkillBox_Spam_Spam_Item_5.ClassID);
			} else {
				UseSkill(SkillBox_Spam_Spam_Item_5.ClassID);
			}
		}
	}
}

function OnDropItem (string a_WindowID, ItemInfo a_ItemInfo, int X, int Y)
{
	if ( UnknownFunction122(a_WindowID,"SkillBox_Spam_1") )
	{
		SkillBox_Spam_1.Clear();
		SkillBox_Spam_Spam_Item_1 = a_ItemInfo;
		SkillBox_Spam_1.AddItem(a_ItemInfo);
	} else {
		if ( UnknownFunction122(a_WindowID,"SkillBox_Spam_2") )
		{
			SkillBox_Spam_2.Clear();
			SkillBox_Spam_Spam_Item_2 = a_ItemInfo;
			SkillBox_Spam_2.AddItem(a_ItemInfo);
		} else {
			if ( UnknownFunction122(a_WindowID,"SkillBox_Spam_3") )
			{
				SkillBox_Spam_3.Clear();
				SkillBox_Spam_Spam_Item_3 = a_ItemInfo;
				SkillBox_Spam_3.AddItem(a_ItemInfo);
			} else {
				if ( UnknownFunction122(a_WindowID,"SkillBox_Spam_4") )
				{
					SkillBox_Spam_4.Clear();
					SkillBox_Spam_Spam_Item_4 = a_ItemInfo;
					SkillBox_Spam_4.AddItem(a_ItemInfo);
				} else {
					if ( UnknownFunction122(a_WindowID,"SkillBox_Spam_5") )
					{
						SkillBox_Spam_5.Clear();
						SkillBox_Spam_Spam_Item_5 = a_ItemInfo;
						SkillBox_Spam_5.AddItem(a_ItemInfo);
					}
				}
			}
		}
	}
	saveINI();
}

function EnableAllSkills ()
{
	if ( UnknownFunction155(SkillBox_Spam_Spam_Item_1.ClassID,0) )
	{
		EnableSkill(SkillBox_Spam_1);
	}
	if ( UnknownFunction155(SkillBox_Spam_Spam_Item_2.ClassID,0) )
	{
		EnableSkill(SkillBox_Spam_2);
	}
	if ( UnknownFunction155(SkillBox_Spam_Spam_Item_3.ClassID,0) )
	{
		EnableSkill(SkillBox_Spam_3);
	}
	if ( UnknownFunction155(SkillBox_Spam_Spam_Item_4.ClassID,0) )
	{
		EnableSkill(SkillBox_Spam_4);
	}
	if ( UnknownFunction155(SkillBox_Spam_Spam_Item_5.ClassID,0) )
	{
		EnableSkill(SkillBox_Spam_5);
	}
}

function DisableAllSkills ()
{
	if ( UnknownFunction155(SkillBox_Spam_Spam_Item_1.ClassID,0) )
	{
		DisableSkill(SkillBox_Spam_1);
	}
	if ( UnknownFunction155(SkillBox_Spam_Spam_Item_2.ClassID,0) )
	{
		DisableSkill(SkillBox_Spam_2);
	}
	if ( UnknownFunction155(SkillBox_Spam_Spam_Item_3.ClassID,0) )
	{
		DisableSkill(SkillBox_Spam_3);
	}
	if ( UnknownFunction155(SkillBox_Spam_Spam_Item_4.ClassID,0) )
	{
		DisableSkill(SkillBox_Spam_4);
	}
	if ( UnknownFunction155(SkillBox_Spam_Spam_Item_5.ClassID,0) )
	{
		DisableSkill(SkillBox_Spam_5);
	}
}

function OnClickItem (string strID, int Index)
{
	if ( UnknownFunction130(UnknownFunction122(strID,"SkillBox_Spam_1"),UnknownFunction151(Index,-1)) )
	{
		if ( UnknownFunction129(useSpam_1) )
		{
			EnableSkill(SkillBox_Spam_1);
		} else {
			DisableSkill(SkillBox_Spam_1);
		}
	} else {
		if ( UnknownFunction130(UnknownFunction122(strID,"SkillBox_Spam_2"),UnknownFunction151(Index,-1)) )
		{
			if ( UnknownFunction129(useSpam_2) )
			{
				EnableSkill(SkillBox_Spam_2);
			} else {
				DisableSkill(SkillBox_Spam_2);
			}
		} else {
			if ( UnknownFunction130(UnknownFunction122(strID,"SkillBox_Spam_3"),UnknownFunction151(Index,-1)) )
			{
				if ( UnknownFunction129(useSpam_3) )
				{
					EnableSkill(SkillBox_Spam_3);
				} else {
					DisableSkill(SkillBox_Spam_3);
				}
			} else {
				if ( UnknownFunction130(UnknownFunction122(strID,"SkillBox_Spam_4"),UnknownFunction151(Index,-1)) )
				{
					if ( UnknownFunction129(useSpam_4) )
					{
						EnableSkill(SkillBox_Spam_4);
					} else {
						DisableSkill(SkillBox_Spam_4);
					}
				} else {
					if ( UnknownFunction130(UnknownFunction122(strID,"SkillBox_Spam_5"),UnknownFunction151(Index,-1)) )
					{
						if ( UnknownFunction129(useSpam_5) )
						{
							EnableSkill(SkillBox_Spam_5);
						} else {
							DisableSkill(SkillBox_Spam_5);
						}
					}
				}
			}
		}
	}
}

function DisableSkill (ItemWindowHandle ItemWnd)
{
	switch (ItemWnd)
	{
		case SkillBox_Spam_1:
		Toggle_Skill_Spam_1.HideWindow();
		useSpam_1 = False;
		break;
		case SkillBox_Spam_2:
		Toggle_Skill_Spam_2.HideWindow();
		useSpam_2 = False;
		break;
		case SkillBox_Spam_3:
		Toggle_Skill_Spam_3.HideWindow();
		useSpam_3 = False;
		break;
		case SkillBox_Spam_4:
		Toggle_Skill_Spam_4.HideWindow();
		useSpam_4 = False;
		break;
		case SkillBox_Spam_5:
		Toggle_Skill_Spam_5.HideWindow();
		useSpam_5 = False;
		break;
		default:
	}
}

function EnableSkill (ItemWindowHandle ItemWnd)
{
	switch (ItemWnd)
	{
		case SkillBox_Spam_1:
		Toggle_Skill_Spam_1.ShowWindow();
		useSpam_1 = True;
		break;
		case SkillBox_Spam_2:
		Toggle_Skill_Spam_2.ShowWindow();
		useSpam_2 = True;
		break;
		case SkillBox_Spam_3:
		Toggle_Skill_Spam_3.ShowWindow();
		useSpam_3 = True;
		break;
		case SkillBox_Spam_4:
		Toggle_Skill_Spam_4.ShowWindow();
		useSpam_4 = True;
		break;
		case SkillBox_Spam_5:
		Toggle_Skill_Spam_5.ShowWindow();
		useSpam_5 = True;
		break;
		default:
	}
}

function OnRClickItem (string strID, int Index)
{
	if ( UnknownFunction122(strID,"SkillBox_Spam_1") )
	{
		DisableSkill(SkillBox_Spam_1);
		SkillBox_Spam_1.Clear();
		SkillBox_Spam_Spam_Item_1.ClassID = 0;
	} else {
		if ( UnknownFunction122(strID,"SkillBox_Spam_2") )
		{
			DisableSkill(SkillBox_Spam_2);
			SkillBox_Spam_2.Clear();
			SkillBox_Spam_Spam_Item_2.ClassID = 0;
		} else {
			if ( UnknownFunction122(strID,"SkillBox_Spam_3") )
			{
				DisableSkill(SkillBox_Spam_3);
				SkillBox_Spam_3.Clear();
				SkillBox_Spam_Spam_Item_3.ClassID = 0;
			} else {
				if ( UnknownFunction122(strID,"SkillBox_Spam_4") )
				{
					DisableSkill(SkillBox_Spam_4);
					SkillBox_Spam_4.Clear();
					SkillBox_Spam_Spam_Item_4.ClassID = 0;
				} else {
					if ( UnknownFunction122(strID,"SkillBox_Spam_5") )
					{
						DisableSkill(SkillBox_Spam_5);
						SkillBox_Spam_5.Clear();
						SkillBox_Spam_Spam_Item_5.ClassID = 0;
					}
				}
			}
		}
	}
	saveINI();
}

function GetSkillInfoFunc (int Id, out ItemInfo Info)
{
	local int Index;
	local ItemInfo Skill;

	RequestSkillList();
	Index = Class'UIAPI_ITEMWINDOW'.FindItemWithClassID("MagicSkillWnd.ASkill.SkillItem",Id);
	if ( Class'UIAPI_ITEMWINDOW'.GetItem("MagicSkillWnd.ASkill.SkillItem",Index,Skill) )
	{
		Info = Skill;
	}
}

function GetActionInfoFunc (int Id, out ItemInfo Info)
{
	local int Index;
	local ItemInfo Skill;

	Class'ActionAPI'.RequestActionList();
	Index = Class'UIAPI_ITEMWINDOW'.FindItemWithClassID("ActionWnd.ActionBasicItem",Id);
	if ( Class'UIAPI_ITEMWINDOW'.GetItem("ActionWnd.ActionBasicItem",Index,Skill) )
	{
		Info = Skill;
	}
}

function saveINI ()
{
	local UserInfo UserInfo;

	GetPlayerInfo(UserInfo);
	SetINIInt(UserInfo.Name,"SkillBox_Spam_Spam_Item_1",SkillBox_Spam_Spam_Item_1.ClassID,"Option");
	SetINIInt(UserInfo.Name,"SkillBox_Spam_Spam_Item_2",SkillBox_Spam_Spam_Item_2.ClassID,"Option");
	SetINIInt(UserInfo.Name,"SkillBox_Spam_Spam_Item_3",SkillBox_Spam_Spam_Item_3.ClassID,"Option");
	SetINIInt(UserInfo.Name,"SkillBox_Spam_Spam_Item_4",SkillBox_Spam_Spam_Item_4.ClassID,"Option");
	SetINIInt(UserInfo.Name,"SkillBox_Spam_Spam_Item_5",SkillBox_Spam_Spam_Item_5.ClassID,"Option");
}

