//================================================================================
// OnScreenMessageWnd.
//================================================================================

class OnScreenMessageWnd extends UICommonAPI;

var string currentwnd1;
var bool onshowstat1;
var bool onshowstat2;
var int timerset1;
var int globalAlphavalue1;
var int globalAlphavalue2;
var int globalDuration;
var int droprate;
var int moveval;
var int moveval2;
var string MovedWndName;
var int m_TimerCount;
var bool linedivided;

function OnLoad ()
{
	RegisterEvent(140);
	RegisterEvent(580);
	ResetAllMessage();
	timerset1 = 0;
	moveval = 0;
	moveval2 = 0;
	globalAlphavalue1 = 0;
	globalAlphavalue2 = 255;
	m_TimerCount = 0;
}

function OnTick ()
{
	if ( BoolEquals(onshowstat1,True) )
	{
		FadeIn(currentwnd1);
	}
	if ( BoolEquals(onshowstat2,True) )
	{
		FadeOut(currentwnd1);
	}
}

function OnTimer (int TimerID)
{
	if ( GreaterThan(m_TimerCount,0) )
	{
		Class'UIAPI_WINDOW'.KillUITimer("OnScreenMessageWnd1",m_TimerCount);
		IntDec(m_TimerCount);
		if ( LessThan(m_TimerCount,1) )
		{
			m_TimerCount = 0;
			onshowstat2 = True;
		}
	}
}

function OnHide ()
{
}

function ResetAllMessage ()
{
	local int i;
	local Color DefaultColor;
	local string WndName;

	DefaultColor.R = 255;
	DefaultColor.G = 255;
	DefaultColor.B = 255;
	globalAlphavalue1 = 0;
	globalAlphavalue2 = 255;
	currentwnd1 = "";
	onshowstat1 = False;
	onshowstat2 = False;
	Class'UIAPI_WINDOW'.HideWindow("OnScreenMessageWnd1");
	Class'UIAPI_WINDOW'.HideWindow("OnScreenMessageWnd2");
	Class'UIAPI_WINDOW'.HideWindow("OnScreenMessageWnd3");
	Class'UIAPI_WINDOW'.HideWindow("OnScreenMessageWnd4");
	Class'UIAPI_WINDOW'.HideWindow("OnScreenMessageWnd5");
	Class'UIAPI_WINDOW'.HideWindow("OnScreenMessageWnd6");
	Class'UIAPI_WINDOW'.HideWindow("OnScreenMessageWnd7");
	Class'UIAPI_WINDOW'.HideWindow("OnScreenMessageWnd8");
	i = 1;
	if ( IntLessOrEqual(i,8) )
	{
		WndName = StrCat("OnScreenMessageWnd",string(i));
		Class'UIAPI_TEXTBOX'.SetTextColor(StrCat(StrCat(WndName,".TextBox"),string(i)),DefaultColor);
		IntPreIncrement(i);
		goto JL017B;
	}
}

function ShowMsg (int WndNum, string TextValue, int Duration, int Animation, int FontType, int BackgroundType, int ColorR, int ColorG, int ColorB)
{
	local string WndName;
	local string TextBoxName;
	local string TextValue1;
	local string TextValue2;
	local string CurText;
	local Color FontColor;
	local int i;
	local int j;
	local int LengthTotal;
	local int TotalLength;
	local int TextOffsetTotal1;

	j = 1;
	TotalLength = StrLen(TextValue);
	TextValue1 = "";
	TextValue2 = "";
	linedivided = False;
	FontColor.R = ColorR;
	FontColor.G = ColorG;
	FontColor.B = ColorB;
	i = 1;
	if ( IntLessOrEqual(i,TotalLength) )
	{
		LengthTotal = IntSub(StrLen(TextValue),1);
		CurText = StrLeft(TextValue,1);
		TextValue = StrRight(TextValue,LengthTotal);
		if ( StrEquals(CurText,"`") )
		{
			CurText = "";
		}
		if ( StrEquals(CurText,"#") )
		{
			CurText = "";
			j = 2;
			linedivided = True;
		}
		if ( Equals(j,1) )
		{
			TextValue1 = StrCat(TextValue1,CurText);
		} else {
			TextValue2 = StrCat(TextValue2,CurText);
		}
		IntPreIncrement(i);
		goto JL006D;
	}
	WndName = StrCat("OnScreenMessageWnd",string(WndNum));
	TextBoxName = StrCat(StrCat(WndName,".TextBox"),string(WndNum));
	currentwnd1 = WndName;
	Class'UIAPI_TEXTBOX'.SetTextColor(TextBoxName,FontColor);
	if ( Equals(FontType,0) )
	{
		Class'UIAPI_WINDOW'.ShowWindow(currentwnd1);
		Class'UIAPI_TEXTBOX'.SetText(TextBoxName,TextValue1);
	} else {
		if ( Equals(FontType,1) )
		{
			Class'UIAPI_WINDOW'.ShowWindow(currentwnd1);
			Class'UIAPI_TEXTBOX'.SetText(TextBoxName,"");
		}
	}
	if ( Equals(WndNum,2) )
	{
		if (! UnknownFunction129(IntNotEquals(moveval,0)) ) goto JL025A;
		MovedWndName = WndName;
		moveval2 = IntMul(IntDiv(TextOffsetTotal1,2),29);
		if ( Equals(BackgroundType,1) )
		{
			Class'UIAPI_WINDOW'.ShowWindow(StrCat(MovedWndName,".texturetype1"));
		} else {
			Class'UIAPI_WINDOW'.HideWindow(StrCat(MovedWndName,".texturetype1"));
		}
	} else {
		if ( Equals(WndNum,5) )
		{
			if (! UnknownFunction129(IntNotEquals(moveval,0)) ) goto JL0308;
			MovedWndName = WndName;
		} else {
			if ( Equals(WndNum,7) )
			{
				if (! UnknownFunction129(IntNotEquals(moveval,0)) ) goto JL0337;
				MovedWndName = WndName;
			} else {
				moveval = 0;
			}
		}
	}
	onshowstat1 = True;
	onshowstat2 = False;
	globalDuration = Duration;
	switch (Animation)
	{
		case 0:
		droprate = 255;
		break;
		case 1:
		droprate = 25;
		break;
		case 11:
		droprate = 15;
		break;
		case 12:
		droprate = 25;
		break;
		case 13:
		droprate = 35;
		break;
		default:
	}
}

function FadeIn (string WndName)
{
	globalAlphavalue1 = DoAdd(globalAlphavalue1,droprate);
	if ( LessThan(globalAlphavalue1,255) )
	{
		Class'UIAPI_WINDOW'.SetAlpha(WndName,globalAlphavalue1);
	} else {
		Class'UIAPI_WINDOW'.SetAlpha(WndName,255);
		globalAlphavalue1 = 0;
		onshowstat1 = False;
		IntIncrement(m_TimerCount);
		Class'UIAPI_WINDOW'.SetUITimer("OnScreenMessageWnd1",m_TimerCount,globalDuration);
	}
}

function FadeOut (string WndName)
{
	globalAlphavalue2 = IntSub(globalAlphavalue2,droprate);
	if ( GreaterThan(globalAlphavalue2,1) )
	{
		Class'UIAPI_WINDOW'.SetAlpha(WndName,globalAlphavalue2);
	} else {
		Class'UIAPI_WINDOW'.SetAlpha(WndName,0);
		globalAlphavalue2 = 255;
		onshowstat2 = False;
		ResetAllMessage();
		moveval2 = 0;
		moveval = 0;
	}
}

function OnEvent (int Index, string param)
{
	local int MsgType;
	local int msgNo;
	local int WindowType;
	local int FontSize;
	local int FontType;
	local int MsgColor;
	local int msgcolorR;
	local int msgcolorG;
	local int msgcolorB;
	local int shadowtype;
	local int BackgroundType;
	local int Lifetime;
	local int AnimationType;
	local int SystemMsgIndex;
	local string msgtext;
	local string ParamString1;
	local string ParamString2;

	if ( Equals(Index,140) )
	{
		ParseInt(param,"MsgType",MsgType);
		ParseInt(param,"MsgNo",msgNo);
		ParseInt(param,"WindowType",WindowType);
		ParseInt(param,"FontSize",FontSize);
		ParseInt(param,"FontType",FontType);
		ParseInt(param,"MsgColor",MsgColor);
		if ( NotBool(ParseInt(param,"MsgColorR",msgcolorR)) )
		{
			msgcolorR = 255;
		}
		if ( NotBool(ParseInt(param,"MsgColorG",msgcolorG)) )
		{
			msgcolorG = 255;
		}
		if ( NotBool(ParseInt(param,"MsgColorB",msgcolorB)) )
		{
			msgcolorB = 255;
		}
		ParseInt(param,"ShadowType",shadowtype);
		ParseInt(param,"BackgroundType",BackgroundType);
		ParseInt(param,"LifeTime",Lifetime);
		ParseInt(param,"AnimationType",AnimationType);
		ParseString(param,"Msg",msgtext);
		ResetAllMessage();
		switch (MsgType)
		{
			case 1:
			ShowMsg(WindowType,msgtext,Lifetime,AnimationType,FontType,BackgroundType,msgcolorR,msgcolorG,msgcolorB);
			break;
			case 0:
			msgtext = GetSystemMessage(msgNo);
			ShowMsg(WindowType,msgtext,Lifetime,AnimationType,FontType,BackgroundType,msgcolorR,msgcolorG,msgcolorB);
			break;
			default:
		}
	}
	if ( Equals(Index,580) )
	{
		ParseInt(param,"Index",SystemMsgIndex);
		ParseString(param,"Param1",ParamString1);
		ParseString(param,"Param2",ParamString2);
		if ( LogicalAND(Equals(SystemMsgIndex,35),NotBool(Class'UIAPI_CHECKBOX'.IsChecked("InterfaceOptionWnd.CB_ShowDamage"))) )
		{
			return;
		}
		ValidateSystemMsg(SystemMsgIndex,ParamString1,ParamString2);
	}
}

function ValidateSystemMsg (int Index, string StringTxt1, string StringTxt2)
{
	local SystemMsgData SystemMsgCurrent;
	local int WindowType;
	local int FontType;
	local int BackgroundType;
	local int Lifetime;
	local int AnimationType;
	local string msgtext;
	local Color TextColor;

	GetSystemMsgInfo(Index,SystemMsgCurrent);
	if ( IntNotEquals(SystemMsgCurrent.WindowType,0) )
	{
		WindowType = SystemMsgCurrent.WindowType;
		msgtext = SystemMsgCurrent.OnScrMsg;
		msgtext = MakeFullSystemMsg(msgtext,StringTxt1,StringTxt2);
		Lifetime = IntMul(SystemMsgCurrent.Lifetime,1000);
		AnimationType = SystemMsgCurrent.AnimationType;
		FontType = SystemMsgCurrent.FontType;
		BackgroundType = SystemMsgCurrent.BackgroundType;
		TextColor = SystemMsgCurrent.Color;
		if ( LogicalAND(LogicalAND(Equals(TextColor.R,0),Equals(TextColor.G,0)),Equals(TextColor.B,0)) )
		{
			TextColor.R = 255;
			TextColor.G = 255;
			TextColor.B = 255;
		} else {
			if ( LogicalAND(LogicalAND(Equals(TextColor.R,176),Equals(TextColor.G,155)),Equals(TextColor.B,121)) )
			{
				TextColor.R = 255;
				TextColor.G = 255;
				TextColor.B = 255;
			}
		}
		ShowMsg(WindowType,msgtext,Lifetime,AnimationType,FontType,BackgroundType,TextColor.R,TextColor.G,TextColor.B);
	}
}

