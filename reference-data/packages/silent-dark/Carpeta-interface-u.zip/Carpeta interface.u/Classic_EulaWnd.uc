//================================================================================
// Classic_EulaWnd.
//================================================================================

class Classic_EulaWnd extends UICommonAPI;

var TextureHandle Theme;

function OnLoad ()
{
	RegisterEvent(2900);
	HandleResolutionChanged();
}

function OnShow ()
{
	HandleResolutionChanged();
}

function OnEvent (int Event_ID, string param)
{
	switch (Event_ID)
	{
		case 2900:
		HandleResolutionChanged();
		break;
		default:
	}
}

function HandleResolutionChanged ()
{
	local int ScreenWidth;
	local int ScreenHeight;

	Theme = TextureHandle(GetHandle("Classic_EulaWnd.Theme"));
	GetCurrentResolution(ScreenWidth,ScreenHeight);
	Theme.SetTextureSize(ScreenWidth,ScreenHeight);
	if ( UnknownFunction151(ScreenHeight,1024) )
	{
		Theme.SetTexture("InterfaceTextures.Theme_1080");
	} else {
		if ( UnknownFunction130(UnknownFunction151(ScreenHeight,960),UnknownFunction150(ScreenWidth,1820)) )
		{
			Theme.SetTexture("InterfaceTextures.Theme_1024");
		} else {
			if ( UnknownFunction130(UnknownFunction151(ScreenHeight,900),UnknownFunction150(ScreenWidth,1707)) )
			{
				Theme.SetTexture("InterfaceTextures.Theme_960");
			} else {
				if ( UnknownFunction130(UnknownFunction151(ScreenHeight,864),UnknownFunction150(ScreenWidth,1600)) )
				{
					Theme.SetTexture("InterfaceTextures.Theme_900");
				} else {
					if ( UnknownFunction130(UnknownFunction151(ScreenHeight,800),UnknownFunction150(ScreenWidth,1536)) )
					{
						Theme.SetTexture("InterfaceTextures.Theme_864");
					} else {
						if ( UnknownFunction130(UnknownFunction151(ScreenHeight,768),UnknownFunction150(ScreenWidth,1422)) )
						{
							Theme.SetTexture("InterfaceTextures.Theme_800");
						} else {
							if ( UnknownFunction130(UnknownFunction151(ScreenHeight,720),UnknownFunction150(ScreenWidth,1366)) )
							{
								Theme.SetTexture("InterfaceTextures.Theme_768");
							} else {
								if ( UnknownFunction130(UnknownFunction151(ScreenHeight,600),UnknownFunction150(ScreenWidth,1280)) )
								{
									Theme.SetTexture("InterfaceTextures.Theme_720");
								} else {
									if ( UnknownFunction130(UnknownFunction150(ScreenHeight,600),UnknownFunction150(ScreenWidth,1067)) )
									{
										Theme.SetTexture("InterfaceTextures.Theme_600");
									} else {
										Theme.SetTexture("InterfaceTextures.Theme_1080");
									}
								}
							}
						}
					}
				}
			}
		}
	}
}

