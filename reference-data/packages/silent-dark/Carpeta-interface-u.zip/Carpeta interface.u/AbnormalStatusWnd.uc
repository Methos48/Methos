//================================================================================
// AbnormalStatusWnd.
//================================================================================

class AbnormalStatusWnd extends UICommonAPI;

const ProbablyPotionsTimerID= 4443;
const ProbablyPotionsTimerDelay= 1250;
var int i_UnkInt1;
var int i_UnkInt2;
var int i_UnkInt3;
var int i_UnkInt4;
var int i_UnkInt5;
var int i_UnkInt6;
var bool m_bOnCurState;
var WindowHandle Me;
var StatusIconHandle StatusIcon;
var bool checkAbDebuff;
var bool checkAbSongDance;
var bool checkAbPrior;
var bool checkAbPriorDebuffSameRow;
var array<int> a_UnkArrayInt1;
const NSTATUSICON_MAXCOL= 12;
const NSTATUSICON_FRAMESIZE= 4;

function OnLoad ()
{
	RegisterEvent(950);
	RegisterEvent(960);
	RegisterEvent(970);
	RegisterEvent(4444);
	RegisterEvent(40);
	RegisterEvent(50);
	RegisterEvent(310);
	RegisterEvent(1900);
	i_UnkInt1 = -1;
	i_UnkInt5 = -1;
	i_UnkInt6 = -1;
	i_UnkInt2 = -1;
	i_UnkInt3 = -1;
	i_UnkInt4 = -1;
	m_bOnCurState = False;
	Init();
}

function Init ()
{
	Me = GetHandle("AbnormalStatusWnd");
	StatusIcon = StatusIconHandle(GetHandle("AbnormalStatusWnd.StatusIcon"));
}

function OnEnterState (name a_PreStateName)
{
	m_bOnCurState = True;
	UpdateWindowSize();
}

function OnExitState (name a_NextStateName)
{
	m_bOnCurState = False;
}

function OnEvent (int Event_ID, string param)
{
	if ( UnknownFunction154(Event_ID,950) )
	{
		HandleAddNormalStatus(param);
	} else {
		if ( UnknownFunction154(Event_ID,960) )
		{
			HandleAddEtcStatus(param);
		} else {
			if ( UnknownFunction154(Event_ID,970) )
			{
				HandleAddShortStatus(param);
			} else {
				if ( UnknownFunction154(Event_ID,40) )
				{
					HandleRestart();
				} else {
					if ( UnknownFunction154(Event_ID,50) )
					{
						HandleDie();
					} else {
						if ( UnknownFunction154(Event_ID,310) )
						{
							HandleShowReplayQuitDialogBox();
						} else {
							if ( UnknownFunction154(Event_ID,1900) )
							{
								HandleLanguageChanged();
							} else {
								if ( UnknownFunction154(Event_ID,4444) )
								{
									checkAbDebuff = GetOptionBool("Custom","checkAbDebuff");
									checkAbPrior = GetOptionBool("Custom","checkAbPrior");
									checkAbSongDance = GetOptionBool("Custom","checkAbSongDance");
									checkAbPriorDebuffSameRow = GetOptionBool("Custom","checkAbPriorDebuffSameRow");
									ReHandleAddNormalStatus();
								}
							}
						}
					}
				}
			}
		}
	}
}

function HandleRestart ()
{
	ClearAll();
}

function HandleDie ()
{
	ClearStatus(False,False);
	ClearStatus(False,True);
}

function HandleShowReplayQuitDialogBox ()
{
	Me.HideWindow();
}

function OnShow ()
{
	local int RowCount;

	RowCount = StatusIcon.GetRowCount();
	if ( UnknownFunction150(RowCount,1) )
	{
		Me.HideWindow();
	}
}

function ClearStatus (bool bEtcItem, bool bShortItem)
{
	local int i;
	local int j;
	local int RowCount;
	local int RowCountTmp;
	local int ColCount;
	local StatusIconInfo Info;

	if ( UnknownFunction130(UnknownFunction242(bEtcItem,False),UnknownFunction242(bShortItem,False)) )
	{
		i_UnkInt1 = -1;
		i_UnkInt2 = -1;
		i_UnkInt3 = -1;
		i_UnkInt4 = -1;
	}
	if ( UnknownFunction130(UnknownFunction242(bEtcItem,True),UnknownFunction242(bShortItem,False)) )
	{
		i_UnkInt5 = -1;
	}
	if ( UnknownFunction130(UnknownFunction242(bEtcItem,False),UnknownFunction242(bShortItem,True)) )
	{
		i_UnkInt6 = -1;
	}
	RowCount = StatusIcon.GetRowCount();
	i = 0;
	if ( UnknownFunction150(i,RowCount) )
	{
JL00AC:
		ColCount = StatusIcon.GetColCount(i);
		j = 0;
		if ( UnknownFunction150(j,ColCount) )
		{
			StatusIcon.GetItem(i,j,Info);
			if ( UnknownFunction151(Info.ClassID,0) )
			{
				if ( UnknownFunction130(UnknownFunction242(Info.bEtcItem,bEtcItem),UnknownFunction242(Info.bShortItem,bShortItem)) )
				{
					StatusIcon.DelItem(i,j);
					UnknownFunction166(j);
					UnknownFunction166(ColCount);
					RowCountTmp = StatusIcon.GetRowCount();
					if ( UnknownFunction155(RowCountTmp,RowCount) )
					{
						UnknownFunction166(i);
						UnknownFunction166(RowCount);
					}
				}
			}
			UnknownFunction165(j);
			goto JL00DC;
		}
		UnknownFunction165(i);
		goto JL00AC;
	}
}

function ClearAll ()
{
	ClearStatus(False,False);
	ClearStatus(True,False);
	ClearStatus(False,True);
}

function HandleAddNormalStatus (string param)
{
	local array<StatusIconInfo> a_ArrayStatusIcon1;
	local array<StatusIconInfo> a_ArrayStatusIcon2;
	local array<StatusIconInfo> a_ArrayStatusIcon3;
	local array<StatusIconInfo> a_ArrayStatusIcon4;
	local int i;
	local int Max;
	local int BuffCnt;
	local int i_UnkIntLocal1;
	local StatusIconInfo Info;

	ClearStatus(False,False);
	Info.Size = getBuffSize(GetOptionInt("Custom","AbnormalSize"));
	Info.BackTex = "L2UI.EtcWndBack.AbnormalBack";
	Info.bShow = True;
	Info.bEtcItem = False;
	Info.bShortItem = False;
	BuffCnt = 0;
	i_UnkIntLocal1 = 0;
	ParseInt(param,"Max",Max);
	i = 0;
	if ( UnknownFunction150(i,Max) )
	{
		ParseInt(param,UnknownFunction112("SkillID_",string(i)),Info.ClassID);
		ParseInt(param,UnknownFunction112("SkillLevel_",string(i)),Info.Level);
		ParseInt(param,UnknownFunction112("RemainTime_",string(i)),Info.RemainTime);
		ParseString(param,UnknownFunction112("Name_",string(i)),Info.Name);
		ParseString(param,UnknownFunction112("IconName_",string(i)),Info.IconName);
		ParseString(param,UnknownFunction112("Description_",string(i)),Info.Description);
		Info.BackTex = "L2UI.EtcWndBack.AbnormalBack";
		if ( UnknownFunction151(Info.ClassID,0) )
		{
			if ( UnknownFunction130(isSongDanceCustom(Info.ClassID),checkAbSongDance) )
			{
				a_ArrayStatusIcon1.Length = UnknownFunction146(a_ArrayStatusIcon1.Length,1);
				a_ArrayStatusIcon1[UnknownFunction147(a_ArrayStatusIcon1.Length,1)] = Info;
			} else {
				if ( UnknownFunction130(f_UnkFunc1(Info.ClassID),checkAbPrior) )
				{
					a_ArrayStatusIcon2.Length = UnknownFunction146(a_ArrayStatusIcon2.Length,1);
					a_ArrayStatusIcon2[UnknownFunction147(a_ArrayStatusIcon2.Length,1)] = Info;
				} else {
					if ( UnknownFunction130(isDebuffCustom(Info.ClassID),checkAbDebuff) )
					{
						Info.BackTex = "L2UI_CH3.Debuff";
						if ( UnknownFunction130(checkAbPriorDebuffSameRow,checkAbPrior) )
						{
							a_ArrayStatusIcon2.Length = UnknownFunction146(a_ArrayStatusIcon2.Length,1);
							a_ArrayStatusIcon2[UnknownFunction147(a_ArrayStatusIcon2.Length,1)] = Info;
						} else {
							a_ArrayStatusIcon3.Length = UnknownFunction146(a_ArrayStatusIcon3.Length,1);
							a_ArrayStatusIcon3[UnknownFunction147(a_ArrayStatusIcon3.Length,1)] = Info;
						}
					} else {
						if ( isDebuffCustom(Info.ClassID) )
						{
							Info.BackTex = "L2UI_CH3.Debuff";
						}
						a_ArrayStatusIcon4.Length = UnknownFunction146(a_ArrayStatusIcon4.Length,1);
						a_ArrayStatusIcon4[UnknownFunction147(a_ArrayStatusIcon4.Length,1)] = Info;
					}
				}
			}
		}
		UnknownFunction165(i);
		goto JL00AF;
	}
	i = 0;
	if ( UnknownFunction150(i,a_ArrayStatusIcon4.Length) )
	{
		if ( UnknownFunction180(UnknownFunction173(BuffCnt,12),0) )
		{
			UnknownFunction165(i_UnkInt1);
			StatusIcon.InsertRow(i_UnkInt1);
		}
		StatusIcon.AddCol(i_UnkInt1,a_ArrayStatusIcon4[i]);
		UnknownFunction165(BuffCnt);
		UnknownFunction165(i);
		goto JL037E;
	}
	i = 0;
	if ( UnknownFunction150(i,a_ArrayStatusIcon1.Length) )
	{
		if ( UnknownFunction154(i_UnkInt4,-1) )
		{
			i_UnkInt4 = i_UnkInt1;
		}
		if ( UnknownFunction180(UnknownFunction173(i_UnkIntLocal1,12),0) )
		{
			UnknownFunction165(i_UnkInt4);
			StatusIcon.InsertRow(i_UnkInt4);
		}
		StatusIcon.AddCol(i_UnkInt4,a_ArrayStatusIcon1[i]);
		UnknownFunction165(i_UnkIntLocal1);
		UnknownFunction165(i);
		goto JL03F5;
	}
	i = 0;
	if ( UnknownFunction150(i,a_ArrayStatusIcon2.Length) )
	{
		if ( UnknownFunction130(UnknownFunction154(i_UnkInt3,-1),UnknownFunction154(i_UnkInt4,-1)) )
		{
			i_UnkInt3 = UnknownFunction146(i_UnkInt1,1);
			StatusIcon.InsertRow(i_UnkInt3);
		} else {
			if ( UnknownFunction130(UnknownFunction154(i_UnkInt3,-1),UnknownFunction151(i_UnkInt4,-1)) )
			{
				i_UnkInt3 = UnknownFunction146(i_UnkInt4,1);
				StatusIcon.InsertRow(i_UnkInt3);
			}
		}
		StatusIcon.AddCol(i_UnkInt3,a_ArrayStatusIcon2[i]);
		UnknownFunction165(i);
		goto JL0486;
	}
	i = 0;
	if ( UnknownFunction150(i,a_ArrayStatusIcon3.Length) )
	{
		if ( UnknownFunction130(UnknownFunction130(UnknownFunction154(i_UnkInt2,-1),UnknownFunction154(i_UnkInt3,-1)),UnknownFunction154(i_UnkInt4,-1)) )
		{
			i_UnkInt2 = UnknownFunction146(i_UnkInt1,1);
			StatusIcon.InsertRow(i_UnkInt2);
		} else {
			if ( UnknownFunction130(UnknownFunction130(UnknownFunction154(i_UnkInt2,-1),UnknownFunction154(i_UnkInt3,-1)),UnknownFunction151(i_UnkInt4,-1)) )
			{
				i_UnkInt2 = UnknownFunction146(i_UnkInt4,1);
				StatusIcon.InsertRow(i_UnkInt2);
			} else {
				if ( UnknownFunction130(UnknownFunction154(i_UnkInt2,-1),UnknownFunction151(i_UnkInt3,-1)) )
				{
					i_UnkInt2 = UnknownFunction146(i_UnkInt3,1);
					StatusIcon.InsertRow(i_UnkInt2);
				}
			}
		}
		StatusIcon.AddCol(i_UnkInt2,a_ArrayStatusIcon3[i]);
		UnknownFunction165(i);
		goto JL054D;
	}
	if ( UnknownFunction151(i_UnkInt5,-1) )
	{
		i_UnkInt5 = UnknownFunction146(i_UnkInt1,1);
		if ( UnknownFunction151(i_UnkInt4,-1) )
		{
			i_UnkInt5 = UnknownFunction146(i_UnkInt4,1);
		}
		if ( UnknownFunction151(i_UnkInt3,-1) )
		{
			i_UnkInt5 = UnknownFunction146(i_UnkInt3,1);
		}
		if ( UnknownFunction151(i_UnkInt2,-1) )
		{
			i_UnkInt5 = UnknownFunction146(i_UnkInt2,1);
		}
	}
	if ( UnknownFunction151(i_UnkInt6,-1) )
	{
		i_UnkInt6 = UnknownFunction146(i_UnkInt1,1);
		if ( UnknownFunction151(i_UnkInt4,-1) )
		{
			i_UnkInt6 = UnknownFunction146(i_UnkInt4,1);
		}
		i_UnkInt6 = UnknownFunction146(i_UnkInt1,1);
		if ( UnknownFunction151(i_UnkInt3,-1) )
		{
			i_UnkInt6 = UnknownFunction146(i_UnkInt3,1);
		}
		if ( UnknownFunction151(i_UnkInt2,-1) )
		{
			i_UnkInt6 = UnknownFunction146(i_UnkInt2,1);
		}
	}
	ProbablyAddEmptyBuff();
	UpdateWindowSize();
}

function HandleAddEtcStatus (string param)
{
	local int i;
	local int Max;
	local int BuffCnt;
	local int CurRow;
	local bool bNewRow;
	local StatusIconInfo Info;

	ClearStatus(True,False);
	Info.Size = getBuffSize(GetOptionInt("Custom","AbnormalSize"));
	Info.BackTex = "L2UI.EtcWndBack.AbnormalBack";
	Info.bShow = True;
	Info.bEtcItem = True;
	Info.bShortItem = False;
	if ( UnknownFunction151(i_UnkInt6,-1) )
	{
		bNewRow = False;
		CurRow = i_UnkInt6;
	} else {
		bNewRow = True;
		CurRow = i_UnkInt1;
		if ( UnknownFunction151(i_UnkInt4,-1) )
		{
			CurRow = i_UnkInt4;
		}
		if ( UnknownFunction151(i_UnkInt2,-1) )
		{
			UnknownFunction165(CurRow);
		}
		if ( UnknownFunction151(i_UnkInt3,-1) )
		{
			UnknownFunction165(CurRow);
		}
	}
	BuffCnt = 0;
	ParseInt(param,"Max",Max);
	ProbablyRemoveEmptyBuff();
	i = 0;
	if ( UnknownFunction150(i,Max) )
	{
		ParseInt(param,UnknownFunction112("SkillID_",string(i)),Info.ClassID);
		ParseInt(param,UnknownFunction112("SkillLevel_",string(i)),Info.Level);
		ParseInt(param,UnknownFunction112("RemainTime_",string(i)),Info.RemainTime);
		ParseString(param,UnknownFunction112("Name_",string(i)),Info.Name);
		ParseString(param,UnknownFunction112("IconName_",string(i)),Info.IconName);
		ParseString(param,UnknownFunction112("Description_",string(i)),Info.Description);
		if ( UnknownFunction151(Info.ClassID,0) )
		{
			if ( bNewRow )
			{
				bNewRow = UnknownFunction129(bNewRow);
				UnknownFunction165(CurRow);
				StatusIcon.InsertRow(CurRow);
			}
			StatusIcon.AddCol(CurRow,Info);
			i_UnkInt5 = CurRow;
			UnknownFunction165(BuffCnt);
		}
		UnknownFunction165(i);
		goto JL012C;
	}
	ProbablyAddEmptyBuff();
	UpdateWindowSize();
}

function HandleAddShortStatus (string param)
{
	local int i;
	local int Max;
	local int BuffCnt;
	local int CurRow;
	local bool bNewRow;
	local StatusIconInfo Info;

	ClearStatus(False,True);
	Info.Size = getBuffSize(GetOptionInt("Custom","AbnormalSize"));
	Info.BackTex = "L2UI.EtcWndBack.AbnormalBack";
	Info.bShow = True;
	Info.bEtcItem = False;
	Info.bShortItem = True;
	if ( UnknownFunction151(i_UnkInt5,-1) )
	{
		bNewRow = False;
		CurRow = i_UnkInt5;
	} else {
		bNewRow = True;
		CurRow = i_UnkInt1;
		if ( UnknownFunction151(i_UnkInt4,-1) )
		{
			CurRow = i_UnkInt4;
		}
		if ( UnknownFunction151(i_UnkInt2,-1) )
		{
			UnknownFunction165(CurRow);
		}
		if ( UnknownFunction151(i_UnkInt3,-1) )
		{
			UnknownFunction165(CurRow);
		}
	}
	BuffCnt = 0;
	ParseInt(param,"Max",Max);
	ProbablyRemoveEmptyBuff();
	i = 0;
	if ( UnknownFunction150(i,Max) )
	{
		ParseInt(param,UnknownFunction112("SkillID_",string(i)),Info.ClassID);
		ParseInt(param,UnknownFunction112("SkillLevel_",string(i)),Info.Level);
		ParseInt(param,UnknownFunction112("RemainTime_",string(i)),Info.RemainTime);
		ParseString(param,UnknownFunction112("Name_",string(i)),Info.Name);
		ParseString(param,UnknownFunction112("IconName_",string(i)),Info.IconName);
		ParseString(param,UnknownFunction112("Description_",string(i)),Info.Description);
		if ( UnknownFunction151(Info.ClassID,0) )
		{
			if ( bNewRow )
			{
				bNewRow = UnknownFunction129(bNewRow);
				UnknownFunction165(CurRow);
				StatusIcon.InsertRow(CurRow);
			}
			StatusIcon.AddCol(CurRow,Info);
			i_UnkInt6 = CurRow;
			UnknownFunction165(BuffCnt);
		}
		UnknownFunction165(i);
		goto JL012C;
	}
	ProbablyAddEmptyBuff();
	UpdateWindowSize();
}

function UpdateWindowSize ()
{
	local int RowCount;
	local Rect rectWnd;

	RowCount = StatusIcon.GetRowCount();
	if ( UnknownFunction151(RowCount,1) )
	{
		if ( m_bOnCurState )
		{
			Me.ShowWindow();
		} else {
			Me.HideWindow();
		}
		rectWnd = StatusIcon.GetRect();
		Me.SetWindowSize(UnknownFunction146(rectWnd.nWidth,4),UnknownFunction147(rectWnd.nHeight,getBuffSize(GetOptionInt("Custom","AbnormalSize"))));
		Me.SetFrameSize(4,UnknownFunction147(rectWnd.nHeight,getBuffSize(GetOptionInt("Custom","AbnormalSize"))));
	} else {
		Me.HideWindow();
	}
}

function HandleLanguageChanged ()
{
	local int i;
	local int j;
	local int RowCount;
	local int ColCount;
	local StatusIconInfo Info;

	RowCount = StatusIcon.GetRowCount();
	i = 0;
	if ( UnknownFunction150(i,RowCount) )
	{
		ColCount = StatusIcon.GetColCount(i);
		j = 0;
		if ( UnknownFunction150(j,ColCount) )
		{
			StatusIcon.GetItem(i,j,Info);
			if ( UnknownFunction151(Info.ClassID,0) )
			{
				Info.Name = Class'UIDATA_SKILL'.GetName(Info.ClassID,Info.Level);
				Info.Description = Class'UIDATA_SKILL'.GetDescription(Info.ClassID,Info.Level);
				StatusIcon.SetItem(i,j,Info);
			}
			UnknownFunction165(j);
			goto JL004C;
		}
		UnknownFunction165(i);
		goto JL001C;
	}
}

function ReHandleAddNormalStatus ()
{
	local array<StatusIconInfo> a_ArrayStatusIcon1;
	local array<StatusIconInfo> a_ArrayStatusIcon2;
	local array<StatusIconInfo> a_ArrayStatusIcon3;
	local array<StatusIconInfo> a_ArrayStatusIcon4;
	local array<StatusIconInfo> a_ArrayStatusIcon5;
	local int i;
	local int i_UnkIntLocal2;
	local int BuffCnt;
	local int i_UnkIntLocal1;
	local StatusIconInfo Info;
	local int j;
	local int RowCount;
	local int ColCount;

	RowCount = StatusIcon.GetRowCount();
	i = 0;
	if ( UnknownFunction150(i,RowCount) )
	{
		ColCount = StatusIcon.GetColCount(i);
		j = 0;
		if ( UnknownFunction150(j,ColCount) )
		{
			StatusIcon.GetItem(i,j,Info);
			if ( UnknownFunction130(UnknownFunction130(UnknownFunction130(UnknownFunction151(Info.ClassID,0),UnknownFunction129(Info.bEtcItem)),UnknownFunction129(Info.bShortItem)),UnknownFunction155(Info.ClassID,98944)) )
			{
				a_ArrayStatusIcon5.Length = UnknownFunction146(a_ArrayStatusIcon5.Length,1);
				a_ArrayStatusIcon5[UnknownFunction147(a_ArrayStatusIcon5.Length,1)] = Info;
			}
			UnknownFunction165(j);
			goto JL004C;
		}
		UnknownFunction165(i);
		goto JL001C;
	}
	ClearStatus(False,False);
	BuffCnt = 0;
	i_UnkIntLocal1 = 0;
	i_UnkIntLocal2 = a_ArrayStatusIcon5.Length;
	i = 0;
	if ( UnknownFunction150(i,i_UnkIntLocal2) )
	{
		Info = a_ArrayStatusIcon5[i];
		Info.Size = getBuffSize(GetOptionInt("Custom","AbnormalSize"));
JL0125:
		Info.BackTex = "L2UI.EtcWndBack.AbnormalBack";
		if ( UnknownFunction151(Info.ClassID,0) )
		{
			if ( UnknownFunction130(isSongDanceCustom(Info.ClassID),checkAbSongDance) )
			{
				a_ArrayStatusIcon1.Length = UnknownFunction146(a_ArrayStatusIcon1.Length,1);
				a_ArrayStatusIcon1[UnknownFunction147(a_ArrayStatusIcon1.Length,1)] = Info;
			} else {
				if ( UnknownFunction130(f_UnkFunc1(Info.ClassID),checkAbPrior) )
				{
					a_ArrayStatusIcon2.Length = UnknownFunction146(a_ArrayStatusIcon2.Length,1);
					a_ArrayStatusIcon2[UnknownFunction147(a_ArrayStatusIcon2.Length,1)] = Info;
				} else {
					if ( UnknownFunction130(isDebuffCustom(Info.ClassID),checkAbDebuff) )
					{
						Info.BackTex = "L2UI_CH3.Debuff";
						if ( UnknownFunction130(checkAbPriorDebuffSameRow,checkAbPrior) )
						{
							a_ArrayStatusIcon2.Length = UnknownFunction146(a_ArrayStatusIcon2.Length,1);
							a_ArrayStatusIcon2[UnknownFunction147(a_ArrayStatusIcon2.Length,1)] = Info;
						} else {
							a_ArrayStatusIcon3.Length = UnknownFunction146(a_ArrayStatusIcon3.Length,1);
							a_ArrayStatusIcon3[UnknownFunction147(a_ArrayStatusIcon3.Length,1)] = Info;
						}
					} else {
						if ( isDebuffCustom(Info.ClassID) )
						{
							Info.BackTex = "L2UI_CH3.Debuff";
						}
						a_ArrayStatusIcon4.Length = UnknownFunction146(a_ArrayStatusIcon4.Length,1);
						a_ArrayStatusIcon4[UnknownFunction147(a_ArrayStatusIcon4.Length,1)] = Info;
					}
				}
			}
		}
		UnknownFunction165(i);
		goto JL0125;
	}
	i = 0;
	if ( UnknownFunction150(i,a_ArrayStatusIcon4.Length) )
	{
		if ( UnknownFunction180(UnknownFunction173(BuffCnt,12),0) )
		{
			UnknownFunction165(i_UnkInt1);
			StatusIcon.InsertRow(i_UnkInt1);
		}
		StatusIcon.AddCol(i_UnkInt1,a_ArrayStatusIcon4[i]);
		UnknownFunction165(BuffCnt);
		UnknownFunction165(i);
		goto JL033A;
	}
	i = 0;
	if ( UnknownFunction150(i,a_ArrayStatusIcon1.Length) )
	{
		if ( UnknownFunction154(i_UnkInt4,-1) )
		{
			i_UnkInt4 = i_UnkInt1;
		}
		if ( UnknownFunction180(UnknownFunction173(i_UnkIntLocal1,12),0) )
		{
			UnknownFunction165(i_UnkInt4);
			StatusIcon.InsertRow(i_UnkInt4);
		}
		StatusIcon.AddCol(i_UnkInt4,a_ArrayStatusIcon1[i]);
		UnknownFunction165(i_UnkIntLocal1);
JL033A:
		UnknownFunction165(i);
		goto JL03B1;
	}
	i = 0;
	if ( UnknownFunction150(i,a_ArrayStatusIcon2.Length) )
	{
		if ( UnknownFunction130(UnknownFunction154(i_UnkInt3,-1),UnknownFunction154(i_UnkInt4,-1)) )
		{
			i_UnkInt3 = UnknownFunction146(i_UnkInt1,1);
			StatusIcon.InsertRow(i_UnkInt3);
		} else {
			if ( UnknownFunction130(UnknownFunction154(i_UnkInt3,-1),UnknownFunction151(i_UnkInt4,-1)) )
			{
				i_UnkInt3 = UnknownFunction146(i_UnkInt4,1);
				StatusIcon.InsertRow(i_UnkInt3);
			}
		}
		StatusIcon.AddCol(i_UnkInt3,a_ArrayStatusIcon2[i]);
		UnknownFunction165(i);
		goto JL0442;
	}
	i = 0;
	if ( UnknownFunction150(i,a_ArrayStatusIcon3.Length) )
	{
		if ( UnknownFunction130(UnknownFunction130(UnknownFunction154(i_UnkInt2,-1),UnknownFunction154(i_UnkInt3,-1)),UnknownFunction154(i_UnkInt4,-1)) )
		{
			i_UnkInt2 = UnknownFunction146(i_UnkInt1,1);
			StatusIcon.InsertRow(i_UnkInt2);
		} else {
			if ( UnknownFunction130(UnknownFunction130(UnknownFunction154(i_UnkInt2,-1),UnknownFunction154(i_UnkInt3,-1)),UnknownFunction151(i_UnkInt4,-1)) )
			{
				i_UnkInt2 = UnknownFunction146(i_UnkInt4,1);
				StatusIcon.InsertRow(i_UnkInt2);
			} else {
				if ( UnknownFunction130(UnknownFunction154(i_UnkInt2,-1),UnknownFunction151(i_UnkInt3,-1)) )
				{
					i_UnkInt2 = UnknownFunction146(i_UnkInt3,1);
					StatusIcon.InsertRow(i_UnkInt2);
				}
			}
		}
		StatusIcon.AddCol(i_UnkInt2,a_ArrayStatusIcon3[i]);
		UnknownFunction165(i);
		goto JL0509;
	}
	if ( UnknownFunction151(i_UnkInt5,-1) )
	{
		i_UnkInt5 = UnknownFunction146(i_UnkInt1,1);
		if ( UnknownFunction151(i_UnkInt4,-1) )
		{
			i_UnkInt5 = UnknownFunction146(i_UnkInt4,1);
		}
		if ( UnknownFunction151(i_UnkInt3,-1) )
		{
			i_UnkInt5 = UnknownFunction146(i_UnkInt3,1);
		}
		if ( UnknownFunction151(i_UnkInt2,-1) )
		{
			i_UnkInt5 = UnknownFunction146(i_UnkInt2,1);
		}
	}
	if ( UnknownFunction151(i_UnkInt6,-1) )
	{
		i_UnkInt6 = UnknownFunction146(i_UnkInt1,1);
		if ( UnknownFunction151(i_UnkInt4,-1) )
		{
			i_UnkInt6 = UnknownFunction146(i_UnkInt4,1);
		}
		i_UnkInt6 = UnknownFunction146(i_UnkInt1,1);
		if ( UnknownFunction151(i_UnkInt3,-1) )
		{
			i_UnkInt6 = UnknownFunction146(i_UnkInt3,1);
		}
		if ( UnknownFunction151(i_UnkInt2,-1) )
		{
			i_UnkInt6 = UnknownFunction146(i_UnkInt2,1);
		}
	}
	ProbablyAddEmptyBuff();
	UpdateWindowSize();
}

function bool f_UnkFunc1 (int ClassID)
{
	local int j;

	j = 0;
	if ( UnknownFunction150(j,a_UnkArrayInt1.Length) )
	{
		if ( UnknownFunction154(a_UnkArrayInt1[j],ClassID) )
		{
			return True;
		}
		UnknownFunction165(j);
		goto JL0007;
	}
	return False;
}

function int getBuffSize (int Index)
{
	local int resultIndex;

	switch (Index)
	{
		case 0:
		resultIndex = 24;
		break;
		case 1:
		resultIndex = 20;
		break;
		case 2:
		resultIndex = 16;
		break;
		default:
	}
	return resultIndex;
}

function ProbablyAddEmptyBuff ()
{
	local StatusIconInfo Info;
	local int RowCount;

	Info.Size = getBuffSize(GetOptionInt("Custom","AbnormalSize"));
	Info.BackTex = "L2UI.EtcWndBack.AbnormalBack";
	Info.bShow = False;
	Info.bEtcItem = False;
	Info.bShortItem = False;
	Info.ClassID = 98944;
	Info.Level = 4;
	Info.IconName = "";
	RowCount = StatusIcon.GetRowCount();
	StatusIcon.InsertRow(RowCount);
	StatusIcon.AddCol(RowCount,Info);
}

function ProbablyRemoveEmptyBuff ()
{
	local int i;
	local int j;
	local int RowCount;
	local int ColCount;
	local StatusIconInfo Info;

	RowCount = StatusIcon.GetRowCount();
	i = RowCount;
	if ( UnknownFunction153(i,0) )
	{
		ColCount = StatusIcon.GetColCount(i);
		j = ColCount;
		if ( UnknownFunction153(j,0) )
		{
			StatusIcon.GetItem(i,j,Info);
			if ( UnknownFunction130(UnknownFunction154(Info.ClassID,98944),UnknownFunction154(Info.Level,4)) )
			{
				StatusIcon.DelItem(i,j);
				return;
			}
			UnknownFunction166(j);
			goto JL0050;
		}
		UnknownFunction166(i);
		goto JL0020;
	}
}

function OnClickItem (string strID, int Index)
{
	Debugg("Hola222","Blue");
}

