//================================================================================
// InterfaceAI_StartMainWnd.
//================================================================================

class InterfaceAI_StartMainWnd extends UICommonAPI;

var WindowHandle Me;
var WindowHandle m_hMainWnd;

function OnLoad ()
{
	RegisterEvent(150);
	Me = GetHandle("InterfaceAI_StartMainWnd");
	m_hMainWnd = GetHandle("InterfaceAI_MainWnd");
}

function OnEvent (int a_EventID, string a_Param)
{
	switch (a_EventID)
	{
		case 150:
		Me.ShowWindow();
		break;
		default:
	}
}

function OnClickButton (string strID)
{
	switch (strID)
	{
		case "btnStartInterfaceAI":
		if ( m_hMainWnd.IsShowWindow() )
		{
			m_hMainWnd.HideWindow();
		} else {
			m_hMainWnd.ShowWindow();
		}
		break;
		default:
	}
}

