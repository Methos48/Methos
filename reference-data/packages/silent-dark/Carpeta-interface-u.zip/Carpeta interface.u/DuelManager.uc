//================================================================================
// DuelManager.
//================================================================================

class DuelManager extends UICommonAPI;

var int m_memberInfo[9];
var WindowHandle m_TopWnd;
var WindowHandle m_StatusWnd[9];
var NameCtrlHandle m_PlayerName[9];
var TextureHandle m_ClassIcon[9];
var BarHandle m_BarCP[9];
var BarHandle m_BarHP[9];
var BarHandle m_BarMP[9];
var bool m_bDuelState;
const NDUELSTATUS_HEIGHT= 46;
const MAX_PARTY_NUM= 9;
const DIALOG_ASK_START= 1111;

function OnLoad ()
{
	local int idx;

	RegisterEvent(2700);
	RegisterEvent(2710);
	RegisterEvent(2720);
	RegisterEvent(2730);
	RegisterEvent(2740);
	RegisterEvent(2750);
	RegisterEvent(1710);
	RegisterEvent(1720);
	m_TopWnd = GetHandle("DuelManager");
	idx = 0;
	if ( UnknownFunction150(idx,9) )
	{
JL0078:
		m_StatusWnd[idx] = GetHandle(UnknownFunction112("DuelManager.PartyStatusWnd",string(idx)));
		m_PlayerName[idx] = NameCtrlHandle(GetHandle(UnknownFunction112(UnknownFunction112("DuelManager.PartyStatusWnd",string(idx)),".PlayerName")));
		m_ClassIcon[idx] = TextureHandle(GetHandle(UnknownFunction112(UnknownFunction112("DuelManager.PartyStatusWnd",string(idx)),".ClassIcon")));
		m_BarCP[idx] = BarHandle(GetHandle(UnknownFunction112(UnknownFunction112("DuelManager.PartyStatusWnd",string(idx)),".barCP")));
		m_BarHP[idx] = BarHandle(GetHandle(UnknownFunction112(UnknownFunction112("DuelManager.PartyStatusWnd",string(idx)),".barHP")));
		m_BarMP[idx] = BarHandle(GetHandle(UnknownFunction112(UnknownFunction112("DuelManager.PartyStatusWnd",string(idx)),".barMP")));
		UnknownFunction165(idx);
		goto JL0078;
	}
	Clear();
	m_bDuelState = False;
}

function OnEvent (int EventID, string param)
{
	local Color White;

	White.R = 255;
	White.G = 255;
	White.B = 255;
	switch (EventID)
	{
		case 2700:
		HandleDuelAskStart(param);
		break;
		case 2710:
		m_bDuelState = True;
		break;
		case 2720:
		break;
		case 2730:
		m_bDuelState = False;
		Clear();
		m_TopWnd.HideWindow();
		break;
		case 2740:
		HandleUpdateUserInfo(param);
		break;
		case 2750:
		break;
		case 1710:
		HandleDialogOK();
		break;
		case 1720:
		HandleDialogCancel();
		break;
		default:
		break;
	}
}

function HandleDuelAskStart (string param)
{
	local string sName;
	local int Type;
	local int messageNum;
	local bool bOption;

	bOption = GetOptionBool("Game","IsRejectingDuel");
	ParseString(param,"userName",sName);
	ParseInt(param,"type",Type);
	if ( UnknownFunction242(bOption,True) )
	{
}

function HandleDialogOK ()
{
	local int dialogID;
	local bool bOption;

	if ( DialogIsMine() )
	{
		dialogID = DialogGetID();
		if ( UnknownFunction154(dialogID,1111) )
		{
			bOption = GetOptionBool("Game","IsRejectingDuel");
}

function HandleDialogCancel ()
{
	local int dialogID;
	local bool bOption;

	if ( DialogIsMine() )
	{
		dialogID = DialogGetID();
		if ( UnknownFunction154(dialogID,1111) )
		{
			bOption = GetOptionBool("Game","IsRejectingDuel");
}

function HandleUpdateUserInfo (string param)
{
	local string sName;
	local int Id;
	local int ClassID;
	local int Level;
	local int currentHP;
	local int maxHP;
	local int currentMP;
	local int maxMP;
	local int currentCP;
	local int maxCP;
	local int i;
	local bool bFound;

	if ( UnknownFunction129(m_bDuelState) )
	{
		return;
	}
	ParseString(param,"userName",sName);
	ParseInt(param,"ID",Id);
	ParseInt(param,"class",ClassID);
	ParseInt(param,"level",Level);
	ParseInt(param,"currentHP",currentHP);
	ParseInt(param,"maxHP",maxHP);
	ParseInt(param,"currentMP",currentMP);
	ParseInt(param,"maxMP",maxMP);
	ParseInt(param,"currentCP",currentCP);
	ParseInt(param,"maxCP",maxCP);
	bFound = False;
	i = 0;
	if ( UnknownFunction150(i,9) )
	{
		if ( UnknownFunction155(m_memberInfo[i],0) )
		{
			if ( UnknownFunction154(Id,m_memberInfo[i]) )
			{
				bFound = True;
			} else {
				goto JL0151;
				goto JL015B;
				UnknownFunction163(i);
				goto JL010E;
			}
		}
	}
	if ( UnknownFunction129(bFound) )
	{
		m_memberInfo[i] = Id;
		m_StatusWnd[i].ShowWindow();
		Resize(UnknownFunction146(i,1));
	}
	m_TopWnd.ShowWindow();
	m_PlayerName[i].SetName(sName,0,2);
	m_ClassIcon[i].SetTexture(GetClassIconName(ClassID));
	m_ClassIcon[i].SetTooltipCustomType(MakeTooltipSimpleText(UnknownFunction112(UnknownFunction112(GetClassStr(ClassID)," - "),GetClassType(ClassID))));
	m_BarCP[i].SetValue(maxCP,currentCP);
	m_BarHP[i].SetValue(maxHP,currentHP);
	m_BarMP[i].SetValue(maxMP,currentMP);
}

function Clear ()
{
	local int i;

	i = 0;
	if ( UnknownFunction150(i,9) )
	{
		m_StatusWnd[i].HideWindow();
		m_memberInfo[i] = 0;
		UnknownFunction163(i);
		goto JL0007;
	}
}

function Resize (int Count)
{
	local Rect entireRect;
	local Rect statusWndRect;

	entireRect = m_TopWnd.GetRect();
	statusWndRect = m_StatusWnd[0].GetRect();
	m_TopWnd.SetWindowSize(entireRect.nWidth,UnknownFunction144(statusWndRect.nHeight,Count));
	m_TopWnd.SetResizeFrameSize(10,UnknownFunction144(statusWndRect.nHeight,Count));
}

function OnLButtonDown (WindowHandle a_WindowHandle, int X, int Y)
{
	local Rect rectWnd;
	local int idx;

	rectWnd = m_TopWnd.GetRect();
	if ( UnknownFunction151(X,UnknownFunction146(rectWnd.nX,13)) )
	{
		idx = UnknownFunction145(UnknownFunction147(Y,rectWnd.nY),46);
		RequestTargetUser(m_memberInfo[idx]);
	}
}

