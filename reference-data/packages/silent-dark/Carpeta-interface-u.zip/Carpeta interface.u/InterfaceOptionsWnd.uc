//================================================================================
// InterfaceOptionsWnd.
//================================================================================

class InterfaceOptionsWnd extends UICommonAPI;

var WindowHandle Me;

function OnLoad ()
{
	Me = GetHandle("InterfaceOptionsWnd");
}

function OnEnterState (name a_PreStateName)
{
	if ( UnknownFunction129(Class'UIAPI_WINDOW'.IsShowWindow("InterfaceOptionsWnd")) )
	{
		RequestExit();
	}
}

function OnShow ()
{
	Me.SetWindowSize(141,50);
	Me.SetAnchor("","BottomRight","BottomRight",-10,-60);
	Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionsWnd.btnOptions");
	Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionsWnd.btnOptionsText");
	Class'UIAPI_WINDOW'.SetFocus("InterfaceOptionsWnd.btnOptions");
	Class'UIAPI_WINDOW'.SetFocus("InterfaceOptionsWnd.btnOptionsText");
	Class'UIAPI_WINDOW'.SetAnchor("InterfaceOptionsWnd.btnOptions","InterfaceOptionsWnd","CenterCenter","CenterCenter",5,0);
	Class'UIAPI_WINDOW'.SetAnchor("InterfaceOptionsWnd.btnOptionsText","btnOptions","CenterCenter","CenterCenter",0,0);
	Class'UIAPI_WINDOW'.SetWindowSize("InterfaceOptionsWnd.btnOptions",120,30);
	Class'UIAPI_WINDOW'.SetWindowSize("InterfaceOptionsWnd.btnOptionsText",115,15);
	Class'UIAPI_TEXTBOX'.SetAlign("InterfaceOptionsWnd.btnOptionsText",2);
	Class'UIAPI_TEXTBOX'.SetText("InterfaceOptionsWnd.btnOptionsText","OKTUBRE      ");
	Class'UIAPI_TEXTBOX'.SetTextColor("InterfaceOptionsWnd.btnOptionsText",SetColor("green"));
}

function OnClickButton (string strID)
{
	switch (strID)
	{
		case "btnOptions":
		OpenHideWindow("InterfaceOptionWnd");
		break;
		default:
	}
}

function OnDefaultPosition ()
{
	Me.SetAnchor("","BottomRight","BottomRight",-10,-60);
}

