//================================================================================
// ManorSeedInfoChangeWnd.
//================================================================================

class ManorSeedInfoChangeWnd extends UICommonAPI;

var int m_MinCropPrice;
var int m_MaxCropPrice;
var int m_TomorrowLimit;

function OnLoad ()
{
	RegisterEvent(2660);
}

function OnEvent (int Event_ID, string a_Param)
{
	switch (Event_ID)
	{
		case 2660:
		HandleShow(a_Param);
		break;
		default:
	}
}

function HandleShow (string a_Param)
{
	local string SeedName;
	local int TomorrowVolumeOfSales;
	local int TomorrowLimit;
	local int TomorrowPrice;
	local int MinCropPrice;
	local int MaxCropPrice;
	local string TomorrowLimitString;

	ParseString(a_Param,"SeedName",SeedName);
	ParseInt(a_Param,"TomorrowVolumeOfSales",TomorrowVolumeOfSales);
	ParseInt(a_Param,"TomorrowLimit",TomorrowLimit);
	ParseInt(a_Param,"TomorrowPrice",TomorrowPrice);
	ParseInt(a_Param,"MinCropPrice",MinCropPrice);
	ParseInt(a_Param,"MaxCropPrice",MaxCropPrice);
	Class'UIAPI_TEXTBOX'.SetText("ManorSeedInfoChangeWnd.txtSeedName",SeedName);
	Class'UIAPI_EDITBOX'.SetString("ManorSeedInfoChangeWnd.ebTomorrowSalesVolume",string(TomorrowVolumeOfSales));
	m_TomorrowLimit = TomorrowLimit;
	TomorrowLimitString = MakeCostString(string(TomorrowLimit));
	Class'UIAPI_TEXTBOX'.SetText("ManorSeedInfoChangeWnd.txtVarTomorrowLimit",TomorrowLimitString);
	Class'UIAPI_EDITBOX'.SetString("ManorSeedInfoChangeWnd.ebTomorrowPrice",string(TomorrowPrice));
	m_MinCropPrice = MinCropPrice;
	m_MaxCropPrice = MaxCropPrice;
	ShowWindowWithFocus("ManorSeedInfoChangeWnd");
	Class'UIAPI_WINDOW'.SetFocus("ManorSeedInfoChangeWnd.ebTomorrowSalesVolume");
}

function OnClickButton (string strID)
{
	Debug(UnknownFunction112(" ",strID));
	switch (strID)
	{
		case "btnOk":
		OnClickBtnOk();
		break;
		case "btnCancel":
		HideWindow("ManorSeedInfoChangeWnd");
		break;
		default:
	}
}

function OnClickBtnOk ()
{
	local int InputTomorrowSalesVolume;
	local int InputTomorrowPrice;
	local string ParamString;

	InputTomorrowSalesVolume = int(Class'UIAPI_EDITBOX'.GetString("ManorSeedInfoChangeWnd.ebTomorrowSalesVolume"));
	InputTomorrowPrice = int(Class'UIAPI_EDITBOX'.GetString("ManorSeedInfoChangeWnd.ebTomorrowPrice"));
	if ( UnknownFunction132(UnknownFunction150(InputTomorrowSalesVolume,0),UnknownFunction151(InputTomorrowSalesVolume,m_TomorrowLimit)) )
	{
		ShowErrorDialog(0,m_TomorrowLimit,1558);
		return;
	}
	if ( UnknownFunction130(UnknownFunction155(InputTomorrowSalesVolume,0),UnknownFunction132(UnknownFunction150(InputTomorrowPrice,m_MinCropPrice),UnknownFunction151(InputTomorrowPrice,m_MaxCropPrice))) )
	{
		ShowErrorDialog(m_MinCropPrice,m_MaxCropPrice,1557);
		return;
	}
	ParamAdd(ParamString,"TomorrowSalesVolume",string(InputTomorrowSalesVolume));
	ParamAdd(ParamString,"TomorrowPrice",string(InputTomorrowPrice));
	ExecuteEvent(2659,ParamString);
	HideWindow("ManorSeedInfoChangeWnd");
}

function ShowErrorDialog (int MinValue, int MaxValue, int SystemStringIdx)
{
	local string ParamString;
	local string Message;

	ParamAdd(ParamString,"Type",string(1));
	ParamAdd(ParamString,"param1",string(MinValue));
	AddSystemMessageParam(ParamString);
	ParamString = "";
	ParamAdd(ParamString,"Type",string(1));
	ParamAdd(ParamString,"param1",string(MaxValue));
	AddSystemMessageParam(ParamString);
	Message = EndSystemMessageParam(SystemStringIdx,True);
	DialogShow(5,Message);
}

