//================================================================================
// UnrefineryWnd.
//================================================================================

class UnrefineryWnd extends UICommonAPI;

var WindowHandle m_UnRefineryWnd_Main;
var WindowHandle m_ItemtoUnRefineWnd;
var WindowHandle m_ItemtoUnRefineAnim;
var WindowHandle m_hSelectedItemHighlight;
var WindowHandle m_ResultAnimation1;
var AnimTextureHandle m_ResultAnim1;
var TextBoxHandle m_InstructionText;
var TextBoxHandle m_AdenaText;
var ButtonHandle m_hUnrefineButton;
var ButtonHandle m_OkBtn;
var ItemWindowHandle m_ItemDragBox;
var ItemInfo CurrentItem;
var bool procedure1stat;
var bool procedureopenstat;
var INT64 m_Adena;

function OnLoad ()
{
	RegisterEvent(2810);
	RegisterEvent(2820);
	RegisterEvent(2830);
	procedure1stat = False;
	procedureopenstat = False;
	m_ResultAnimation1 = GetHandle("UnrefineryWnd.RefineResultAnimation01");
	m_ResultAnim1 = AnimTextureHandle(GetHandle("UnrefineryWnd.RefineResultAnimation01.RefineResult1"));
	m_UnRefineryWnd_Main = GetHandle("UnrefineryWnd");
	m_ItemtoUnRefineWnd = GetHandle("Itemtounrefine");
	m_ItemtoUnRefineAnim = GetHandle("ItemtounrefineAnim");
	m_hSelectedItemHighlight = GetHandle("SelectedItemHighlight");
	m_ItemDragBox = ItemWindowHandle(GetHandle("UnRefineryWnd.Itemtounrefine.ItemUnrefine"));
	m_InstructionText = TextBoxHandle(GetHandle("UnrefineryWnd.txtInstruction"));
	m_AdenaText = TextBoxHandle(GetHandle("UnrefineryWnd.txtAdenaInstruction"));
	m_hUnrefineButton = ButtonHandle(GetHandle("btnUnRefine"));
	m_OkBtn = ButtonHandle(GetHandle("btnClose"));
	Class'UIAPI_PROGRESSCTRL'.SetProgressTime("UnrefineryWnd.UnRefineryProgress",2000);
}

function OnShow ()
{
	ResetReady();
}

function ResetReady ()
{
	procedure1stat = False;
	procedureopenstat = False;
	m_UnRefineryWnd_Main.ShowWindow();
	m_ItemtoUnRefineWnd.ShowWindow();
	m_ItemtoUnRefineAnim.ShowWindow();
	m_hSelectedItemHighlight.HideWindow();
	m_ResultAnimation1.HideWindow();
	m_ResultAnim1.Stop();
	m_hUnrefineButton.DisableWindow();
	m_ItemDragBox.Clear();
	m_InstructionText.SetText(GetSystemMessage(1963));
	SetAdenaText("0");
	m_AdenaText.SetTooltipString("");
	Class'UIAPI_PROGRESSCTRL'.SetProgressTime("UnrefineryWnd.UnRefineryProgress",2000);
	Class'UIAPI_PROGRESSCTRL'.Reset("UnrefineryWnd.UnRefineryProgress");
	PlaySound("ItemSound2.smelting.Smelting_dragin");
	m_OkBtn.EnableWindow();
}

function OnEvent (int a_EventID, string a_Param)
{
	switch (a_EventID)
	{
		case 2810:
		if ( UnknownFunction242(procedureopenstat,False) )
		{
			if ( UnknownFunction132(Class'UIAPI_WINDOW'.IsShowWindow("EnchantAIWnd"),Class'UIAPI_WINDOW'.IsMinimizedWindow("EnchantAIWnd")) )
			{
				goto JL0091;
			}
			PlaySound("ItemSound2.smelting.Smelting_dragin");
			ResetReady();
		}
		break;
		case 2820:
		PlaySound("ItemSound2.smelting.Smelting_dragin");
		OnTargetItemValidationResult(a_Param);
		break;
		case 2830:
		PlaySound("ItemSound2.smelting.smelting_finalA");
		OnUnRefineDoneResult(a_Param);
		break;
		default:
		break;
	}
}

function OnDropItem (string a_WindowID, ItemInfo a_ItemInfo, int X, int Y)
{
	switch (a_WindowID)
	{
		case "ItemUnrefine":
		if ( UnknownFunction242(procedure1stat,False) )
		{
			ValidateItem(a_ItemInfo);
		}
		break;
		default:
	}
}

function ValidateItem (ItemInfo a_ItemInfo)
{
	local int TargetItemServerID;

	CurrentItem = a_ItemInfo;
	TargetItemServerID = a_ItemInfo.ServerID;
	Class'RefineryAPI'.ConfirmCancelItem(TargetItemServerID);
}

function OnTargetItemValidationResult (string a_Param)
{
	local int ItemServerID;
	local int ItemClassID;
	local int Option1;
	local int Option2;
	local int ItemValidationResult;
	local string AdenaText;

	Debug("??? ?? ??");
	ParseInt(a_Param,"CancelItemServerID",ItemServerID);
	ParseInt(a_Param,"CancelItemClassID",ItemClassID);
	ParseInt(a_Param,"Option1",Option1);
	ParseInt(a_Param,"Option2",Option2);
	ParseInt64(a_Param,"Adena",m_Adena);
	ParseInt(a_Param,"Result",ItemValidationResult);
	switch (ItemValidationResult)
	{
		case 1:
		m_hUnrefineButton.EnableWindow();
		if ( UnknownFunction129(m_ItemDragBox.SetItem(0,CurrentItem)) )
		{
			m_ItemDragBox.AddItem(CurrentItem);
		}
		AdenaText = MakeCostStringInt64(m_Adena);
		SetAdenaText(AdenaText);
		m_ItemtoUnRefineAnim.HideWindow();
		m_hSelectedItemHighlight.ShowWindow();
		m_InstructionText.SetText("");
		procedureopenstat = True;
		if ( UnknownFunction242(CheckAdena(),False) )
		{
			m_hUnrefineButton.DisableWindow();
			m_InstructionText.SetText(GetSystemMessage(279));
		}
		break;
		case 0:
		break;
		default:
	}
}

function SetAdenaText (string a_AdenaText)
{
	local string AdenaText;

	AdenaText = ConvertNumToText(a_AdenaText);
	m_AdenaText.SetText(UnknownFunction168(a_AdenaText,GetSystemString(469)));
	m_AdenaText.SetTextColor(GetNumericColor(a_AdenaText));
	if ( UnknownFunction154(int(a_AdenaText),0) )
	{
		m_AdenaText.SetTooltipString("");
	} else {
		m_AdenaText.SetTooltipString(AdenaText);
	}
}

function OnClickButton (string strID)
{
	switch (strID)
	{
		case "btnUnRefine":
		OnClickUnRefineButton();
		break;
		case "btnClose":
		procedure1stat = False;
		procedureopenstat = False;
		PlaySound("Itemsound2.smelting.smelting_dragout");
		m_UnRefineryWnd_Main.HideWindow();
		break;
		default:
	}
}

function OnClickUnRefineButton ()
{
	local INT64 Diff;
	local INT64 CurAdena;

	CurAdena.nLeft = 0;
	CurAdena.nRight = GetAdena();
	Diff = Int64SubtractBfromA(CurAdena,m_Adena);
	if ( UnknownFunction132(UnknownFunction153(Diff.nLeft,0),UnknownFunction153(Diff.nRight,0)) )
	{
		m_hUnrefineButton.DisableWindow();
		m_ResultAnim1.SetLoopCount(1);
		m_ResultAnimation1.ShowWindow();
		PlaySound("ItemSound2.smelting.smelting_loding");
		m_ResultAnim1.Play();
		PlayProgressiveBar();
		m_OkBtn.DisableWindow();
	} else {
		DialogShow(1,GetSystemMessage(279));
	}
}

function bool CheckAdena ()
{
	local INT64 Diff;
	local INT64 CurAdena;

	CurAdena.nLeft = 0;
	CurAdena.nRight = GetAdena();
	Diff = Int64SubtractBfromA(CurAdena,m_Adena);
	if ( UnknownFunction132(UnknownFunction153(Diff.nLeft,0),UnknownFunction153(Diff.nRight,0)) )
	{
		return True;
	} else {
		return False;
	}
}

function PlayProgressiveBar ()
{
	Class'UIAPI_PROGRESSCTRL'.Start("UnrefineryWnd.UnRefineryProgress");
}

function OnProgressTimeUp (string aWindowID)
{
	switch (aWindowID)
	{
		case "UnRefineryProgress":
		OnUnRefineRequest();
		break;
		default:
	}
}

function OnTextureAnimEnd (AnimTextureHandle a_WindowHandle)
{
	switch (a_WindowHandle)
	{
		case m_ResultAnim1:
		m_ResultAnimation1.HideWindow();
		break;
		default:
	}
}

function OnUnRefineRequest ()
{
	Class'RefineryAPI'.RequestRefineCancel(CurrentItem.ServerID);
}

function OnUnRefineDoneResult (string a_Param)
{
	local int UnRefineResult;

	ParseInt(a_Param,"Result",UnRefineResult);
	m_OkBtn.EnableWindow();
	Debug("??? ?? ?? ??");
	switch (UnRefineResult)
	{
		case 1:
		CurrentItem.RefineryOp1 = 0;
		CurrentItem.RefineryOp2 = 0;
		if ( UnknownFunction129(m_ItemDragBox.SetItem(0,CurrentItem)) )
		{
			m_ItemDragBox.AddItem(CurrentItem);
		}
		m_InstructionText.SetText(MakeFullSystemMsg(GetSystemMessage(1965),CurrentItem.Name,""));
		m_hUnrefineButton.DisableWindow();
		procedure1stat = True;
		break;
		case 0:
		m_hUnrefineButton.EnableWindow();
		procedure1stat = False;
		m_UnRefineryWnd_Main.HideWindow();
		break;
		default:
	}
}

