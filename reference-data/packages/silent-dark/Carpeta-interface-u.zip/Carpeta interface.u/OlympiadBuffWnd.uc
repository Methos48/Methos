//================================================================================
// OlympiadBuffWnd.
//================================================================================

class OlympiadBuffWnd extends UIScript;

var int m_PlayerNum;
var int m_PlayerID;
var string m_WindowName;
const NSTATUSICON_MAXCOL= 12;
const NSTATUSICON_FRAMESIZE= 12;

function SetPlayerNum (int PlayerNum)
{
	m_PlayerNum = PlayerNum;
	m_WindowName = UnknownFunction112(UnknownFunction112("OlympiadBuff",string(PlayerNum)),"Wnd");
}

function OnLoad ()
{
	RegisterEvent(930);
	RegisterEvent(940);
	RegisterEvent(910);
}

function OnEnterState (name a_PreStateName)
{
	Clear();
	m_PlayerID = 0;
}

function OnEvent (int Event_ID, string param)
{
	if ( UnknownFunction154(Event_ID,930) )
	{
		HandleBuffShow(param);
	} else {
		if ( UnknownFunction154(Event_ID,940) )
		{
			HandleBuffInfo(param);
		} else {
			if ( UnknownFunction154(Event_ID,910) )
			{
				Clear();
				m_PlayerID = 0;
			}
		}
	}
}

function Clear ()
{
	Class'UIAPI_STATUSICONCTRL'.Clear(UnknownFunction112(m_WindowName,".StatusIcon"));
	Class'UIAPI_WINDOW'.HideWindow(m_WindowName);
}

function HandleBuffShow (string param)
{
	local int PlayerNum;

	ParseInt(param,"PlayerNum",PlayerNum);
	if ( UnknownFunction132(UnknownFunction155(m_PlayerNum,PlayerNum),UnknownFunction150(PlayerNum,1)) )
	{
		return;
	}
	ParseInt(param,"PlayerID",m_PlayerID);
}

function HandleBuffInfo (string param)
{
	local int PlayerID;
	local int i;
	local int Max;
	local int CurRow;
	local StatusIconInfo Info;
	local Rect rectWnd;

	ParseInt(param,"PlayerID",PlayerID);
	if ( UnknownFunction132(UnknownFunction155(m_PlayerID,PlayerID),UnknownFunction150(PlayerID,1)) )
	{
		return;
	}
	Clear();
	CurRow = -1;
	ParseInt(param,"Max",Max);
	i = 0;
	if ( UnknownFunction150(i,Max) )
	{
		if ( UnknownFunction180(UnknownFunction173(i,12),0) )
		{
			Class'UIAPI_STATUSICONCTRL'.AddRow(UnknownFunction112(m_WindowName,".StatusIcon"));
			UnknownFunction165(CurRow);
		}
		ParseInt(param,UnknownFunction112("SkillID_",string(i)),Info.ClassID);
		ParseInt(param,UnknownFunction112("SkillLevel_",string(i)),Info.Level);
		ParseInt(param,UnknownFunction112("RemainTime_",string(i)),Info.RemainTime);
		ParseString(param,UnknownFunction112("Name_",string(i)),Info.Name);
		ParseString(param,UnknownFunction112("IconName_",string(i)),Info.IconName);
		ParseString(param,UnknownFunction112("Description_",string(i)),Info.Description);
		Info.Size = 24;
		Info.BackTex = "L2UI.EtcWndBack.AbnormalBack";
		Info.bShow = True;
		Class'UIAPI_STATUSICONCTRL'.AddCol(UnknownFunction112(m_WindowName,".StatusIcon"),CurRow,Info);
		UnknownFunction165(i);
		goto JL0065;
	}
	if ( UnknownFunction151(Max,0) )
	{
		Class'UIAPI_WINDOW'.ShowWindow(m_WindowName);
		rectWnd = Class'UIAPI_WINDOW'.GetRect(UnknownFunction112(m_WindowName,".StatusIcon"));
		Class'UIAPI_WINDOW'.SetWindowSize(m_WindowName,UnknownFunction146(rectWnd.nWidth,12),rectWnd.nHeight);
		Class'UIAPI_WINDOW'.SetFrameSize(m_WindowName,12,rectWnd.nHeight);
	}
}

