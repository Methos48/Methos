//================================================================================
// NPHRN_MiniMapWnd_OLD.
//================================================================================

class NPHRN_MiniMapWnd_OLD extends UICommonAPI;

var WindowHandle unkWndHandle1;
var WindowHandle unkWndHandle2;
var int unkInt2;
var int unkInt1;
var ButtonHandle ButtonHandle;
var ButtonHandle BtnResize;
var bool unkBool;
var bool Large;

function OnLoad ()
{
	BtnResize.SetTooltipCustomType(MakeTooltipSimpleText("Resize"));
	RegisterEvent(2900);
	RegisterEvent(110);
	RegisterEvent(2420);
	RegisterEvent(520);
	RegisterEvent(1790);
	RegisterEvent(1800);
	RegisterEvent(1810);
	RegisterEvent(1820);
	RegisterEvent(1830);
	RegisterEvent(11223344);
	unkWndHandle1 = GetHandle("NPHRN_MiniMapWnd_OLD");
	unkWndHandle2 = GetHandle("NPHRN_MiniMapHandler_OLD");
	ButtonHandle = ButtonHandle(GetHandle("NPHRN_MiniMapWnd_OLD.Curtain.BtnFixLoc"));
	BtnResize = ButtonHandle(GetHandle("NPHRN_MiniMapWnd_OLD.Curtain.BtnResize"));
	unkBool = True;
	unkFunc2();
}

function OnShow ()
{
	AdjustMapToPlayerPosition(True);
	unkWndHandle1.SetTimer(1,1000);
	unkFunc1();
	unkFunc2();
}

function OnTimer (int Id)
{
	unkWndHandle1.KillTimer(Id);
	unkFunc1();
}

function OnTick ()
{
	if ( unkBool )
	{
		AdjustMapToPlayerPosition(True);
	}
}

function OnClickButton (string param)
{
	switch (param)
	{
		case "BtnFixLoc":
		unkFunc3();
		break;
		case "BtnTrans":
		HandleRadarButtonClick();
		break;
		case "BtnTargetLoc":
		unkFunc4();
		break;
		case "BtnPartyLoc":
		unkFunc5();
		break;
		case "BtnResize":
		if ( Large )
		{
			Large = False;
		} else {
			Large = True;
		}
		ResizeWnd();
		break;
		default:
	}
}

function OnEvent (int Index, string param)
{
	local int idx;

	switch (Index)
	{
		case 2900:
		unkWndHandle2.SetAnchor("","TopRight","TopRight",-1,1);
		unkWndHandle2.ClearAnchor();
		break;
		case 110:
		ParseInt(param,"ZoneCode",idx);
		unkFunc6(idx);
		break;
		case 2420:
		unkFunc1();
		break;
		case 520:
		unkFunc7(param);
		break;
		case 1790:
		unkFunc8(param);
		break;
		case 1800:
		unkFunc9(param);
		break;
		case 1810:
		Class'UIAPI_MINIMAPCTRL'.DeleteAllTarget("NPHRN_MiniMapWnd_OLD.Minimap");
		break;
		case 1820:
		Class'UIAPI_MINIMAPCTRL'.SetShowQuest("NPHRN_MiniMapWnd_OLD.Minimap",True);
		break;
		case 1830:
		Class'UIAPI_MINIMAPCTRL'.SetShowQuest("NPHRN_MiniMapWnd_OLD.Minimap",False);
		break;
		case 11223344:
		HandleRadarShowHide();
		break;
		default:
	}
}

function HandleRadarShowHide ()
{
	local int idx;

	idx = GetOptionInt("Custom","Minimap");
	switch (idx)
	{
		case 0:
		Class'UIAPI_WINDOW'.HideWindow("NPHRN_MiniMapWnd_OLD");
		Class'UIAPI_WINDOW'.HideWindow("NPHRN_MiniMapHandler_OLD");
		break;
		case 1:
		Class'UIAPI_WINDOW'.HideWindow("NPHRN_MiniMapWnd_OLD");
		Class'UIAPI_WINDOW'.HideWindow("NPHRN_MiniMapHandler_OLD");
		break;
		case 2:
		Class'UIAPI_WINDOW'.ShowWindow("NPHRN_MiniMapWnd_OLD");
		Class'UIAPI_WINDOW'.ShowWindow("NPHRN_MiniMapHandler_OLD");
		break;
		case 3:
		Class'UIAPI_WINDOW'.HideWindow("NPHRN_MiniMapWnd_OLD");
		Class'UIAPI_WINDOW'.HideWindow("NPHRN_MiniMapHandler_OLD");
		break;
		default:
	}
}

function unkFunc6 (int idx)
{
	switch (idx)
	{
		case 15:
		Class'UIAPI_TEXTURECTRL'.SetTexture("NPHRN_MiniMapWnd_OLD.TexZone","InterfaceTextures.NPHRN_Radar_ZGray");
		break;
		case 12:
		Class'UIAPI_TEXTURECTRL'.SetTexture("NPHRN_MiniMapWnd_OLD.TexZone","InterfaceTextures.NPHRN_Radar_ZBlue");
		break;
		case 11:
		Class'UIAPI_TEXTURECTRL'.SetTexture("NPHRN_MiniMapWnd_OLD.TexZone","InterfaceTextures.NPHRN_Radar_ZOrange");
		break;
		case 9:
		Class'UIAPI_TEXTURECTRL'.SetTexture("NPHRN_MiniMapWnd_OLD.TexZone","InterfaceTextures.NPHRN_Radar_ZRed");
		break;
		case 8:
		Class'UIAPI_TEXTURECTRL'.SetTexture("NPHRN_MiniMapWnd_OLD.TexZone","InterfaceTextures.NPHRN_Radar_ZRed");
		break;
		case 13:
		Class'UIAPI_TEXTURECTRL'.SetTexture("NPHRN_MiniMapWnd_OLD.TexZone","InterfaceTextures.NPHRN_Radar_ZGray");
		break;
		case 14:
		Class'UIAPI_TEXTURECTRL'.SetTexture("NPHRN_MiniMapWnd_OLD.TexZone","InterfaceTextures.NPHRN_Radar_ZGreen");
		break;
		default:
	}
}

function AdjustMapToPlayerPosition (bool a_ZoomToTownMap)
{
	local Vector unkVar;

	unkVar = GetPlayerPosition();
	Class'UIAPI_MINIMAPCTRL'.AdjustMapView("NPHRN_MiniMapWnd_OLD.Minimap",unkVar,a_ZoomToTownMap);
}

function unkFunc1 ()
{
	local string unkVar;

	unkVar = GetCurrentZoneName();
	Class'UIAPI_TEXTBOX'.SetText("NPHRN_MiniMapWnd_OLD.HeadZone",unkVar);
}

function unkFunc7 (string param)
{
	ParseInt(param,"PartyMemberCount",unkInt2);
}

function unkFunc8 (string param)
{
	local Vector unkVar;

	if ( LogicalAND(LogicalAND(ParseFloat(param,"X",unkVar.X),ParseFloat(param,"Y",unkVar.Y)),ParseFloat(param,"Z",unkVar.Z)) )
	{
		Class'UIAPI_MINIMAPCTRL'.AddTarget("NPHRN_MiniMapWnd_OLD.Minimap",unkVar);
		Class'UIAPI_MINIMAPCTRL'.AdjustMapView("NPHRN_MiniMapWnd_OLD.Minimap",unkVar,False,False);
	}
}

function unkFunc9 (string param)
{
	local Vector unkVar;
	local int LocX;
	local int LocY;
	local int LocZ;

	if ( LogicalAND(LogicalAND(ParseInt(param,"X",LocX),ParseInt(param,"Y",LocY)),ParseInt(param,"Z",LocZ)) )
	{
		unkVar.X = LocX;
		unkVar.Y = LocY;
		unkVar.Z = LocZ;
		Class'UIAPI_MINIMAPCTRL'.DeleteTarget("NPHRN_MiniMapWnd_OLD.Minimap",unkVar);
	}
}

function unkFunc4 ()
{
	local Vector QuestLocation;

	if ( GetQuestLocation(QuestLocation) )
	{
		unkFunc10();
		Class'UIAPI_MINIMAPCTRL'.AdjustMapView("NPHRN_MiniMapWnd_OLD.Minimap",QuestLocation);
	}
}

function unkFunc5 ()
{
	local Vector PartyMemberLocation;

	unkInt2 = GetPartyMemberCount();
	if ( Equals(0,unkInt2) )
	{
		return;
	}
	unkFunc10();
	unkInt1 = IntMod(DoAdd(unkInt1,1),unkInt2);
	if ( GetPartyMemberLocation(unkInt1,PartyMemberLocation) )
	{
		Class'UIAPI_MINIMAPCTRL'.AdjustMapView("NPHRN_MiniMapWnd_OLD.Minimap",PartyMemberLocation,False);
	}
}

function HandleRadarButtonClick ()
{
	SetOptionBool("Custom","RadarTransparency",UnknownFunction129(GetOptionBool("Custom","RadarTransparency")));
	unkFunc2();
}

function unkFunc2 ()
{
	local ButtonHandle btnHandle;

	btnHandle = ButtonHandle(GetHandle("NPHRN_MiniMapWnd_OLD.BtnTrans"));
	if ( UnknownFunction129(GetOptionBool("Custom","RadarTransparency")) )
	{
		Class'UIAPI_WINDOW'.SetAlpha("NPHRN_MiniMapWnd_OLD.Minimap",255,0.5);
		Class'UIAPI_WINDOW'.SetAlpha("NPHRN_MiniMapWnd_OLD.Circle",255,0.5);
		btnHandle.SetTexture("InterfaceTextures.NPHRN_Radar_BtnTrans","InterfaceTextures.NPHRN_Radar_BtnTrans_Down","InterfaceTextures.NPHRN_Radar_BtnTrans_Over");
	} else {
		Class'UIAPI_WINDOW'.SetAlpha("NPHRN_MiniMapWnd_OLD.Minimap",130,0.5);
		Class'UIAPI_WINDOW'.SetAlpha("NPHRN_MiniMapWnd_OLD.Circle",130,0.5);
		btnHandle.SetTexture("InterfaceTextures.NPHRN_Radar_BtnSolid","InterfaceTextures.NPHRN_Radar_BtnSolid_Down","InterfaceTextures.NPHRN_Radar_BtnSolid_Over");
	}
}

function unkFunc3 ()
{
	if ( unkBool )
	{
		unkFunc10();
	} else {
		unkFunc11();
	}
}

function unkFunc11 ()
{
	ButtonHandle.SetTexture("InterfaceTextures.NPHRN_Radar_Fix_Enabled","InterfaceTextures.NPHRN_Radar_Fix_Down","InterfaceTextures.NPHRN_Radar_Fix_Over");
	unkBool = True;
}

function unkFunc10 ()
{
	ButtonHandle.SetTexture("InterfaceTextures.NPHRN_Radar_Fix","InterfaceTextures.NPHRN_Radar_Fix_Down","InterfaceTextures.NPHRN_Radar_Fix_Over");
	unkBool = False;
}

function ResizeWnd ()
{
	local TextureHandle Tex;
	local TextureHandle Circle;
	local TextureHandle TexZone;
	local TextureHandle CurtainBg;
	local WindowHandle Minimap;
	local WindowHandle Curtain;

	Tex = TextureHandle(GetHandle("NPHRN_MiniMapWnd_OLD.Tex"));
	Circle = TextureHandle(GetHandle("NPHRN_MiniMapWnd_OLD.Circle"));
	TexZone = TextureHandle(GetHandle("NPHRN_MiniMapWnd_OLD.TexZone"));
	CurtainBg = TextureHandle(GetHandle("NPHRN_MiniMapWnd_OLD.Curtain.Curtain_BG"));
	Curtain = GetHandle("NPHRN_MiniMapWnd_OLD.Curtain");
	Minimap = GetHandle("NPHRN_MiniMapWnd_OLD.Minimap");
	if ( NotBool(Large) )
	{
		unkWndHandle1.SetWindowSize(209,207);
		Tex.SetWindowSize(209,207);
		Tex.SetTexture("InterfaceTextures.NPHRN_Radar_CaseSolid");
		Circle.SetTexture("InterfaceTextures.NPHRN_Radar_Circle");
		CurtainBg.SetTexture("InterfaceTextures.NPHRN_Radar_Curtain");
		CurtainBg.SetWindowSize(40,175);
		TexZone.SetWindowSize(202,24);
		unkWndHandle2.SetWindowSize(202,24);
		Curtain.SetWindowSize(40,175);
		Minimap.SetWindowSize(197,175);
		unkWndHandle2.Move(97,0);
	} else {
		unkWndHandle1.SetWindowSize(312,309);
		Tex.SetWindowSize(312,309);
		Tex.SetTexture("InterfaceTextures.NPHRN_Radar_CaseSolid_Big");
		Circle.SetTexture("InterfaceTextures.Null");
		CurtainBg.SetTexture("InterfaceTextures.NPHRN_Radar_Curtain_Big");
		CurtainBg.SetWindowSize(40,277);
		TexZone.SetWindowSize(300,24);
		unkWndHandle2.SetWindowSize(300,24);
		Curtain.SetWindowSize(40,277);
		Minimap.SetWindowSize(298,276);
		unkWndHandle2.Move(-97,0);
	}
}

