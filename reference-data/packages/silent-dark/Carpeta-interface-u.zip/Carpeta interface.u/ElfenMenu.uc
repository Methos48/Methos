//================================================================================
// ElfenMenu.
//================================================================================

class ElfenMenu extends UICommonAPI;

var string m_WindowName;
var int m_UserID;
var bool m_bReceivedUserInfo;
var bool m_bShow;
var TextBoxHandle UserNameH;

function OnLoad ()
{
	RegisterEvent(70);
	RegisterEvent(180);
	RegisterEvent(1710);
	RegisterEvent(1900);
	UserNameH = TextBoxHandle(GetHandle("ElfenMenu.Username"));
}

function OnEnterState (name a_PreStateName)
{
	local UserInfo UserInfo;

	GetPlayerInfo(UserInfo);
	UserNameH.SetText(UnknownFunction168(UserInfo.Name,":"));
	m_bReceivedUserInfo = False;
	UpdateUserInfo();
}

function OnShow ()
{
	HandleUpdateUserInfo();
	m_bShow = True;
}

function UpdateUserInfo ()
{
	local UserInfo UserInfo;

	if ( GetPlayerInfo(UserInfo) )
	{
		m_bReceivedUserInfo = True;
		m_UserID = UserInfo.nID;
		Class'UIAPI_STATUSBARCTRL'.SetPointExp("ElfenMenu.EXPBars",UserInfo.nCurExp,UserInfo.nLevel);
	}
}

function OnClickButton (string strID)
{
	switch (strID)
	{
		case "BtnCharInfo":
		ToggleOpenCharInfoWnd();
		break;
		case "BtnAction":
		ToggleOpenActionWnd();
		break;
		case "BtnSkills":
		ToggleOpenSkillWnd();
		break;
		case "btnClan":
		ToggleOpenClanWnd();
		break;
		case "BtnInventory":
		ToggleOpenInventoryWnd();
		break;
		case "BtnMacro":
		HandleShowMacroListWnd();
		break;
		case "BtnMap":
		RequestOpenMinimap();
		break;
		case "btnQuest":
		ToggleOpenQuestWnd();
		break;
		case "btnOption":
		HandleShowOptionWnd();
		break;
		case "btnAutoBuff":
		ToggleOpenAutoBuffWnd();
		break;
		case "btnRestart":
		DialogHide();
		DialogShow(4,GetSystemMessage(126));
		DialogSetID(0);
		break;
		case "btnQuit":
		DialogHide();
		DialogShow(4,GetSystemMessage(125));
		DialogSetID(1);
		break;
		default:
	}
}

function HandleShowMacroListWnd ()
{
	ExecuteEvent(1230);
}

function bool GetMyUserInfo (out UserInfo a_MyUserInfo)
{
	return GetPlayerInfo(a_MyUserInfo);
}

function HandleUpdateUserInfo ()
{
	local int DualCount;
	local int PKCount;
	local UserInfo Info;

	if ( GetMyUserInfo(Info) )
	{
		m_UserID = Info.nID;
		DualCount = Info.nDualCount;
		PKCount = Info.nPKCount;
	}
	Class'UIAPI_TEXTBOX'.SetText(UnknownFunction112(m_WindowName,".txtPVP2"),UnknownFunction112(UnknownFunction112(string(DualCount)," / "),string(PKCount)));
}

function OnEvent (int a_EventID, string a_Param)
{
	if ( UnknownFunction154(a_EventID,1710) )
	{
		if ( DialogIsMine() )
		{
			if ( UnknownFunction154(DialogGetID(),0) )
			{
				ExecRestart();
			} else {
				ExecQuit();
			}
		}
	}
	if ( UnknownFunction154(a_EventID,180) )
	{
		HandleUpdateUserInfo();
	}
	switch (a_EventID)
	{
		case 180:
		UpdateUserInfo();
		break;
		default:
		break;
	}
}

function ToggleOpenAutoBuffWnd ()
{
	if ( IsShowWindow("AutoBuffWnd") )
	{
		HideWindow("AutoBuffWnd");
		PlayConsoleSound(6);
	} else {
		ShowWindowWithFocus("AutoBuffWnd");
		PlayConsoleSound(5);
	}
}

function ToggleOpenCharInfoWnd ()
{
	if ( IsShowWindow("DetailStatusWnd") )
	{
		Class'UIAPI_WINDOW'.HideWindow("DetailStatusWnd");
	} else {
		Class'UIAPI_WINDOW'.ShowWindow("DetailStatusWnd");
	}
}

function ToggleOpenSkillWnd ()
{
	if ( IsShowWindow("MagicSkillWnd") )
	{
		HideWindow("MagicSkillWnd");
	} else {
		ShowWindowWithFocus("MagicSkillWnd");
	}
}

function ToggleOpenActionWnd ()
{
	if ( IsShowWindow("ActionWnd") )
	{
		HideWindow("ActionWnd");
	} else {
		ShowWindowWithFocus("ActionWnd");
		ExecuteEvent(1300);
		ExecuteEvent(1310);
		ExecuteEvent(1900);
	}
}

function ToggleOpenClanWnd ()
{
	if ( IsShowWindow("ClanWnd") )
	{
		HideWindow("ClanWnd");
	} else {
		ShowWindowWithFocus("ClanWnd");
	}
}

function ToggleOpenQuestWnd ()
{
	if ( IsShowWindow("QuestTreeWnd") )
	{
		HideWindow("QuestTreeWnd");
	} else {
		ShowWindowWithFocus("QuestTreeWnd");
	}
}

function ToggleOpenInventoryWnd ()
{
	if ( IsShowWindow("InventoryWnd") )
	{
		HideWindow("InventoryWnd");
		PlayConsoleSound(6);
	} else {
		ShowWindowWithFocus("InventoryWnd");
		PlayConsoleSound(5);
	}
}

function HandleShowOptionWnd ()
{
	if ( Class'UIAPI_WINDOW'.IsShowWindow("OptionWnd") )
	{
		PlayConsoleSound(6);
		Class'UIAPI_WINDOW'.HideWindow("OptionWnd");
	} else {
		PlayConsoleSound(5);
		Class'UIAPI_WINDOW'.ShowWindow("OptionWnd");
		Class'UIAPI_WINDOW'.SetFocus("OptionWnd");
	}
}

defaultproperties
{
    m_WindowName="ElfenMenu"

}
