//================================================================================
// ChatFilterWnd.
//================================================================================

class ChatFilterWnd extends UIScript;

function OnClickButton (string strID)
{
	if ( UnknownFunction122(strID,"ChatFilterOK") )
	{
		SaveChatFilterOption();
		Class'UIAPI_WINDOW'.HideWindow("ChatFilterWnd");
	} else {
		if ( UnknownFunction122(strID,"ChatFilterCancel") )
		{
			Class'UIAPI_WINDOW'.HideWindow("ChatFilterWnd");
		}
	}
}

function OnClickCheckBox (string strID)
{
	local ChatWnd script;
	local int chatType;

	script = ChatWnd(GetScript("ChatWnd"));
	chatType = script.m_chatType;
	if ( UnknownFunction122(strID,"CheckBoxSystem") )
	{
		if ( UnknownFunction129(Class'UIAPI_CHECKBOX'.IsChecked("ChatFilterWnd.CheckBoxSystem")) )
		{
			Class'UIAPI_CHECKBOX'.SetDisable("ChatFilterWnd.CheckBoxDamage",True);
			Class'UIAPI_CHECKBOX'.SetDisable("ChatFilterWnd.CheckBoxItem",True);
		} else {
			Class'UIAPI_CHECKBOX'.SetDisable("ChatFilterWnd.CheckBoxDamage",False);
			Class'UIAPI_CHECKBOX'.SetDisable("ChatFilterWnd.CheckBoxItem",False);
		}
	} else {
		if ( UnknownFunction122(strID,"SystemMsgBox") )
		{
			if ( Class'UIAPI_CHECKBOX'.IsChecked("ChatFilterWnd.SystemMsgBox") )
			{
				Class'UIAPI_CHECKBOX'.EnableWindow("ChatFilterWnd.DamageBox");
				Class'UIAPI_CHECKBOX'.EnableWindow("ChatFilterWnd.ItemBox");
			} else {
				Class'UIAPI_CHECKBOX'.DisableWindow("ChatFilterWnd.DamageBox");
				Class'UIAPI_CHECKBOX'.DisableWindow("ChatFilterWnd.ItemBox");
			}
		}
	}
	Class'UIAPI_CHECKBOX'.SetDisable("ChatFilterWnd.CheckBoxNormal",False);
	Class'UIAPI_CHECKBOX'.SetDisable("ChatFilterWnd.CheckBoxShout",False);
	Class'UIAPI_CHECKBOX'.SetDisable("ChatFilterWnd.CheckBoxPledge",False);
	Class'UIAPI_CHECKBOX'.SetDisable("ChatFilterWnd.CheckBoxParty",False);
	Class'UIAPI_CHECKBOX'.SetDisable("ChatFilterWnd.CheckBoxTrade",False);
	Class'UIAPI_CHECKBOX'.SetDisable("ChatFilterWnd.CheckBoxWhisper",False);
	Class'UIAPI_CHECKBOX'.SetDisable("ChatFilterWnd.CheckBoxAlly",False);
	Class'UIAPI_CHECKBOX'.SetDisable("ChatFilterWnd.CheckBoxHero",False);
	Class'UIAPI_CHECKBOX'.SetDisable("ChatFilterWnd.CheckBoxUnion",False);
	switch (chatType)
	{
		case script.1:
		Class'UIAPI_CHECKBOX'.SetDisable("ChatFilterWnd.CheckBoxTrade",True);
		break;
		case script.2:
		Class'UIAPI_CHECKBOX'.SetDisable("ChatFilterWnd.CheckBoxParty",True);
		break;
		case script.3:
		Class'UIAPI_CHECKBOX'.SetDisable("ChatFilterWnd.CheckBoxPledge",True);
		break;
		case script.4:
		Class'UIAPI_CHECKBOX'.SetDisable("ChatFilterWnd.CheckBoxAlly",True);
		break;
		default:
		break;
	}
}

function SaveChatFilterOption ()
{
	local ChatWnd script;
	local int chatType;
	local bool bChecked;

	script = ChatWnd(GetScript("ChatWnd"));
	chatType = script.m_chatType;
	script.m_filterInfo[chatType].bSystem = Class'UIAPI_CHECKBOX'.IsChecked("ChatFilterWnd.CheckBoxSystem").Remove (script.m_filterInfo[chatType].bUseitem = Class'UIAPI_CHECKBOX'.IsChecked("ChatFilterWnd.CheckBoxItem").Remove (script.m_filterInfo[chatType].bDamage = Class'UIAPI_CHECKBOX'.IsChecked("ChatFilterWnd.CheckBoxDamage").Remove (script.m_filterInfo[chatType].bChat = Class'UIAPI_CHECKBOX'.IsChecked("ChatFilterWnd.CheckBoxChat").Remove (script.m_filterInfo[chatType].bNormal = Class'UIAPI_CHECKBOX'.IsChecked("ChatFilterWnd.CheckBoxNormal").Remove (script.m_filterInfo[chatType].bParty = Class'UIAPI_CHECKBOX'.IsChecked("ChatFilterWnd.CheckBoxParty").Remove (script.m_filterInfo[chatType].bShout = Class'UIAPI_CHECKBOX'.IsChecked("ChatFilterWnd.CheckBoxShout").Remove (script.m_filterInfo[chatType].bTrade = Class'UIAPI_CHECKBOX'.IsChecked("ChatFilterWnd.CheckBoxTrade").Remove (script.m_filterInfo[chatType].bClan = Class'UIAPI_CHECKBOX'.IsChecked("ChatFilterWnd.CheckBoxPledge").Remove (script.m_filterInfo[chatType].bWhisper = Class'UIAPI_CHECKBOX'.IsChecked("ChatFilterWnd.CheckBoxWhisper").Remove (script.m_filterInfo[chatType].bAlly = Class'UIAPI_CHECKBOX'.IsChecked("ChatFilterWnd.CheckBoxAlly").Remove (script.m_filterInfo[chatType].bHero = Class'UIAPI_CHECKBOX'.IsChecked("ChatFilterWnd.CheckBoxHero").Remove (script.m_filterInfo[chatType].bUnion = Class'UIAPI_CHECKBOX'.IsChecked("ChatFilterWnd.CheckBoxUnion").Remove (script.m_NoUnionCommanderMessage = Class'UIAPI_CHECKBOX'.IsChecked("ChatFilterWnd.CheckBoxCommand").Remove (bChecked = Class'UIAPI_CHECKBOX'.IsChecked("ChatFilterWnd.SystemMsgBox"),SetOptionBool("Game","SystemMsgWnd",bChecked));,bChecked = Class'UIAPI_CHECKBOX'.IsChecked("ChatFilterWnd.DamageBox"));,SetOptionBool("Game","SystemMsgWndDamage",bChecked));,bChecked = Class'UIAPI_CHECKBOX'.IsChecked("ChatFilterWnd.ItemBox"));,SetOptionBool("Game","SystemMsgWndExpendableItem",bChecked));,bChecked = Class'UIAPI_CHECKBOX'.IsChecked("ChatFilterWnd.OlympiadMessageBox"));,SetOptionBool("Game","OlympiadMsgWnd",bChecked));,if ( GetOptionBool("Game","SystemMsgWnd") ));,Class'UIAPI_WINDOW'.ShowWindow("SystemMsgWnd"));,} else {);,Class'UIAPI_WINDOW'.HideWindow("SystemMsgWnd"));,if ( GetOptionBool("Game","OlympiadMsgWnd") ));,Class'UIAPI_WINDOW'.ShowWindow("OlympiadMsgWnd"));,} else {);;
	// There are 1 jump destination(s) inside the last statement!
	{
		{
			Class'UIAPI_WINDOW'.HideWindow("OlympiadMsgWnd");
		}
	}
	SetINIBool(script.m_sectionName[chatType],"system",bool(script.m_filterInfo[chatType].bSystem),"chatfilter.ini");
	SetINIBool(script.m_sectionName[chatType],"damage",bool(script.m_filterInfo[chatType].bDamage),"chatfilter.ini");
	SetINIBool(script.m_sectionName[chatType],"useitems",bool(script.m_filterInfo[chatType].bUseitem),"chatfilter.ini");
	SetINIBool(script.m_sectionName[chatType],"chat",bool(script.m_filterInfo[chatType].bChat),"chatfilter.ini");
	SetINIBool(script.m_sectionName[chatType],"normal",bool(script.m_filterInfo[chatType].bNormal),"chatfilter.ini");
	SetINIBool(script.m_sectionName[chatType],"party",bool(script.m_filterInfo[chatType].bParty),"chatfilter.ini");
	SetINIBool(script.m_sectionName[chatType],"shout",bool(script.m_filterInfo[chatType].bShout),"chatfilter.ini");
	SetINIBool(script.m_sectionName[chatType],"market",bool(script.m_filterInfo[chatType].bTrade),"chatfilter.ini");
	SetINIBool(script.m_sectionName[chatType],"pledge",bool(script.m_filterInfo[chatType].bClan),"chatfilter.ini");
	SetINIBool(script.m_sectionName[chatType],"tell",bool(script.m_filterInfo[chatType].bWhisper),"chatfilter.ini");
	SetINIBool(script.m_sectionName[chatType],"ally",bool(script.m_filterInfo[chatType].bAlly),"chatfilter.ini");
	SetINIBool(script.m_sectionName[chatType],"hero",bool(script.m_filterInfo[chatType].bHero),"chatfilter.ini");
	SetINIBool(script.m_sectionName[chatType],"union",bool(script.m_filterInfo[chatType].bUnion),"chatfilter.ini");
	SetINIBool("global","command",bool(script.m_NoUnionCommanderMessage),"chatfilter.ini");
}

