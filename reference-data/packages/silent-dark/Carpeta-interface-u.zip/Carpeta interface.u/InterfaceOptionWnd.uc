//================================================================================
// InterfaceOptionWnd.
//================================================================================

class InterfaceOptionWnd extends UICommonAPI;

var array<int> AbnormalPriorityArray;
var AbnormalStatusWnd AbnormalStatusWnd;
var array<int> PartyPriorityArray;
var PartyWnd PartyWnd;

function OnLoad ()
{
	RegisterEvent(150);
	AbnormalStatusWnd = AbnormalStatusWnd(GetScript("AbnormalStatusWnd"));
	PartyWnd = PartyWnd(GetScript("PartyWnd"));
	Class'UIAPI_COMBOBOX'.Clear("InterfaceOptionWnd.MinimapCB");
	Class'UIAPI_COMBOBOX'.AddString("InterfaceOptionWnd.MinimapCB","None");
	Class'UIAPI_COMBOBOX'.AddString("InterfaceOptionWnd.MinimapCB","Retail");
	Class'UIAPI_COMBOBOX'.AddString("InterfaceOptionWnd.MinimapCB","Old");
	Class'UIAPI_COMBOBOX'.AddString("InterfaceOptionWnd.MinimapCB","New");
	InitInterfaceOption();
	HandleAbnormalPriorityBuffsWindows();
	HandleAbnormalPriorityBuffsList();
	HandlePartyPriorityBuffsWindows();
	HandlePartyPriorityBuffsList();
	ExecuteEvent(4444);
	ExecuteEvent(4445);
}

function OnEvent (int Index, string param)
{
	if ( UnknownFunction154(Index,150) )
	{
		ExecuteEvent(11223344);
	}
}

function InitInterfaceOption ()
{
	local int nOption;
	local bool bOption;

	nOption = GetOptionInt("Custom","AbnormalSize");
	Class'UIAPI_COMBOBOX'.SetSelectedNum("InterfaceOptionWnd.AbnormalSizeBox",nOption);
	nOption = GetOptionInt("Custom","Minimap");
	Class'UIAPI_COMBOBOX'.SetSelectedNum("InterfaceOptionWnd.MinimapCB",nOption);
	bOption = GetOptionBool("Custom","ShowDamage");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.Cb_ShowDamage",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.CB_ShowDamage"," OnScreen Damage");
	bOption = GetOptionBool("Custom","HideAssist");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.Cb_HideAssist",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.Cb_HideAssist"," Hide Assist Window");
	bOption = GetOptionBool("Custom","SkillCastingBox");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.CB_SkillCastingBox",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.CB_SkillCastingBox"," Display Skill Casting Box");
	bOption = GetOptionBool("Custom","HideSpamSkills");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.Cb_HideSkillSpam",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.Cb_HideSkillSpam"," Hide Skills Spam");
	bOption = GetOptionBool("Custom","HideAutoBuff");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.Cb_HideAutoBuff",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.Cb_HideAutoBuff"," Hide Auto Buff");
	bOption = GetOptionBool("Custom","HideSpamSkillsBox");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.Cb_HideSkillSpamBox",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.Cb_HideSkillSpamBox"," Skills Spam: Hide Box");
	bOption = GetOptionBool("Custom","HideAutoBuffBox");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.Cb_HideAutoBuffBox",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.Cb_HideAutoBuffBox"," Auto Buff: Hide Box");
	bOption = GetOptionBool("Custom","NoblesseAssist");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.assistIfNoblesse",bOption);
	bOption = GetOptionBool("Custom","BuffPotions");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.BuffPotions",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.BuffPotions"," Use Buff Potions Automatically");
	bOption = GetOptionBool("Custom","ShowEvent");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.CB_ShowEvent",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.Cb_ShowEvent"," Display OnScreen Event");
	bOption = GetOptionBool("Custom","HoldTarget");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.Cb_HoldTarget",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.Cb_HoldTarget"," Hold Target");
	bOption = GetOptionBool("Custom","IgnoreAggr");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.Cb_IgnoreAggr",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.Cb_IgnoreAggr"," Ignore Aggression");
	bOption = GetOptionBool("Custom","ShortcutTransparencyNum");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.Cb_ShotcutTransparencyNum",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.Cb_ShotcutTransparencyNum"," Shortcut: Hide numbers");
	SetShortcutTransparencyNum();
	bOption = GetOptionBool("Custom","ShortcutTransparencyBox");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.Cb_ShotcutTransparencyBox",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.Cb_ShotcutTransparencyBox"," Shortcut: Hide box");
	SetShortcutTransparencyBox();
	bOption = GetOptionBool("Custom","ChatTransparency");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.Cb_ChatTransparency",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.Cb_ChatTransparency"," Chat Transparency");
	HandleChatTransparency();
	bOption = GetOptionBool("Custom","checkAbDebuff");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkAbDebuff",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkAbDebuff"," Show debuffs on seperate row");
	bOption = GetOptionBool("Custom","checkAbSongDance");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkAbSongDance",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkAbSongDance"," Show songs/dances on seperate row");
	bOption = GetOptionBool("Custom","checkAbPrior");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkAbPrior",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkAbPrior"," Show important buffs on seperate row");
	bOption = GetOptionBool("Custom","checkAbPriorNobless");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkAbPriorNobless",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkAbPriorNobless"," Nobless/Salva/Phoenix");
	bOption = GetOptionBool("Custom","checkAbPriorAcumen");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkAbPriorAcumen",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkAbPriorAcumen"," Acumen");
	bOption = GetOptionBool("Custom","checkAbPriorEmpower");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkAbPriorEmpower",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkAbPriorEmpower"," Empower");
	bOption = GetOptionBool("Custom","checkAbPriorWindWalk");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkAbPriorWindWalk",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkAbPriorWindWalk"," Wind Walk");
	bOption = GetOptionBool("Custom","checkAbPriorMight");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkAbPriorMight",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkAbPriorMight"," Might");
	bOption = GetOptionBool("Custom","checkAbPriorHaste");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkAbPriorHaste",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkAbPriorHaste"," Haste");
	bOption = GetOptionBool("Custom","checkAbPriorPrayer");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkAbPriorPrayer",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkAbPriorPrayer"," Prayer");
	bOption = GetOptionBool("Custom","checkAbPriorArcana");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkAbPriorArcana",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkAbPriorArcana"," Arcane Skills");
	bOption = GetOptionBool("Custom","checkAbPriorHotSpring");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkAbPriorHotSpring",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkAbPriorHotSpring"," Hot Spring's Buffs");
	bOption = GetOptionBool("Custom","checkAbPriorViciousStance");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkAbPriorViciousStance",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkAbPriorViciousStance"," Vicious Stance");
	bOption = GetOptionBool("Custom","checkAbPriorHeroicValor");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkAbPriorHeroicValor",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkAbPriorHeroicValor"," Hero Skills");
	bOption = GetOptionBool("Custom","checkAbPriorSummoner");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkAbPriorSummoner",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkAbPriorSummoner"," Summoner");
	bOption = GetOptionBool("Custom","checkAbPriorForce");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkAbPriorForce",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkAbPriorForce"," Force");
	bOption = GetOptionBool("Custom","checkAbPriorTitan");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkAbPriorTitan",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkAbPriorTitan"," Titan");
	bOption = GetOptionBool("Custom","checkAbPriorHawkeye");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkAbPriorHawkeye",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkAbPriorHawkeye"," Hawkeye");
	bOption = GetOptionBool("Custom","checkAbPriorRanger");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkAbPriorRanger",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkAbPriorRanger"," Ranger");
	bOption = GetOptionBool("Custom","checkAbPriorKnight");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkAbPriorKnight",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkAbPriorKnight"," Knight");
	bOption = GetOptionBool("Custom","checkAbPriorMystic");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkAbPriorMystic",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkAbPriorMystic"," Mystic");
	bOption = GetOptionBool("Custom","checkAbPriorMagePoV");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkAbPriorMagePoV",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkAbPriorMagePoV"," MagePoV");
	bOption = GetOptionBool("Custom","checkAbPriorFighterPoV");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkAbPriorFighterPoV",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkAbPriorFighterPoV"," FighterPoV");
	bOption = GetOptionBool("Custom","checkAbPriorTankPoV");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkAbPriorTankPoV",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkAbPriorTankPoV"," TankPoV");
	bOption = GetOptionBool("Custom","checkAbPriorDebuffSameRow");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkAbPriorDebuffSameRow",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkAbPriorDebuffSameRow"," Show important buffs on debuff row");
	bOption = GetOptionBool("Custom","checkPrior");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkPrior",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkPrior"," Show important buffs on seperate row");
	bOption = GetOptionBool("Custom","checkPriorNobless");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkPriorNobless",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkPriorNobless"," Nobless/Salva/Phoenix");
	bOption = GetOptionBool("Custom","checkPriorAcumen");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkPriorAcumen",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkPriorAcumen"," Acumen");
	bOption = GetOptionBool("Custom","checkPriorEmpower");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkPriorEmpower",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkPriorEmpower"," Empower");
	bOption = GetOptionBool("Custom","checkPriorWindWalk");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkPriorWindWalk",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkPriorWindWalk"," Wind Walk");
	bOption = GetOptionBool("Custom","checkPriorMight");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkPriorMight",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkPriorMight"," Might");
	bOption = GetOptionBool("Custom","checkPriorHaste");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkPriorHaste",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkPriorHaste"," Haste");
	bOption = GetOptionBool("Custom","checkPriorPrayer");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkPriorPrayer",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkPriorPrayer"," Prayer");
	bOption = GetOptionBool("Custom","checkPriorArcana");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkPriorArcana",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkPriorArcana"," Arcane Skills");
	bOption = GetOptionBool("Custom","checkPriorHotSpring");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkPriorHotSpring",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkPriorHotSpring"," Hot Spring's Buffs");
	bOption = GetOptionBool("Custom","checkPriorViciousStance");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkPriorViciousStance",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkPriorViciousStance"," Vicious Stance");
	bOption = GetOptionBool("Custom","checkPriorHeroicValor");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkPriorHeroicValor",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkPriorHeroicValor"," Hero Skills");
	bOption = GetOptionBool("Custom","checkPriorSummoner");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkPriorSummoner",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkPriorSummoner"," Summoner");
	bOption = GetOptionBool("Custom","checkPriorForce");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkPriorForce",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkPriorForce"," Force");
	bOption = GetOptionBool("Custom","checkPriorTitan");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkPriorTitan",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkPriorTitan"," Titan");
	bOption = GetOptionBool("Custom","checkPriorHawkeye");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkPriorHawkeye",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkPriorHawkeye"," Hawkeye");
	bOption = GetOptionBool("Custom","checkPriorRanger");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkPriorRanger",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkPriorRanger"," Ranger");
	bOption = GetOptionBool("Custom","checkPriorKnight");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkPriorKnight",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkPriorKnight"," Knight");
	bOption = GetOptionBool("Custom","checkPriorMystic");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkPriorMystic",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkPriorMystic"," Mystic");
	bOption = GetOptionBool("Custom","checkPriorMagePoV");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkPriorMagePoV",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkPriorMagePoV"," MagePoV");
	bOption = GetOptionBool("Custom","checkPriorFighterPoV");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkPriorFighterPoV",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkPriorFighterPoV"," FighterPoV");
	bOption = GetOptionBool("Custom","checkPriorTankPoV");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkPriorTankPoV",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkPriorTankPoV"," TankPoV");
	bOption = GetOptionBool("Custom","checkPriorDebuffSameRow");
	Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.checkPriorDebuffSameRow",bOption);
	Class'UIAPI_CHECKBOX'.SetTitle("InterfaceOptionWnd.checkPriorDebuffSameRow"," Show important buffs on seperate row");
	HandleHideSkillSpamBox();
	HandleHideAutoBuffBox();
}

function OnClickCheckBox (string strID)
{
	switch (strID)
	{
		case "Cb_HideSkillSpam":
		if ( Class'UIAPI_CHECKBOX'.IsChecked("AutoSkillSpamWnd.Cb_HideSkillSpam") )
		{
			SetOptionBool("Custom","HideSpamSkills",True);
		} else {
			SetOptionBool("Custom","HideSpamSkills",False);
		}
		HandleHideAutoBuffAndSpamSkill();
		break;
		case "Cb_HideAutoBuff":
		if ( Class'UIAPI_CHECKBOX'.IsChecked("AutoSkillSpamWnd.Cb_HideAutoBuff") )
		{
			SetOptionBool("Custom","HideAutoBuff",True);
		} else {
			SetOptionBool("Custom","HideAutoBuff",False);
		}
		HandleHideAutoBuffAndSpamSkill();
		break;
		case "Cb_HideSkillSpamBox":
		if ( Class'UIAPI_CHECKBOX'.IsChecked("AutoSkillSpamWnd.Cb_HideSkillSpamBox") )
		{
			SetOptionBool("Custom","HideSpamSkillsBox",True);
		} else {
			SetOptionBool("Custom","HideSpamSkillsBox",False);
		}
		HandleHideSkillSpamBox();
		break;
		case "Cb_HideAutoBuffBox":
		if ( Class'UIAPI_CHECKBOX'.IsChecked("AutoSkillSpamWnd.Cb_HideAutoBuffBox") )
		{
			SetOptionBool("Custom","HideAutoBuffBox",True);
		} else {
			SetOptionBool("Custom","HideAutoBuffBox",False);
		}
		HandleHideAutoBuffBox();
		break;
		case "Cb_ShowDamage":
		if ( Class'UIAPI_CHECKBOX'.IsChecked("InterfaceOptionWnd.Cb_ShowDamage") )
		{
			SetOptionBool("Custom","ShowDamage",True);
		} else {
			SetOptionBool("Custom","ShowDamage",False);
		}
		break;
		case "Cb_HideAssist":
		if ( Class'UIAPI_CHECKBOX'.IsChecked("InterfaceOptionWnd.Cb_HideAssist") )
		{
			SetOptionBool("Custom","HideAssist",True);
			HideWindow("PartyWnd.AssistWnd");
		} else {
			SetOptionBool("Custom","HideAssist",False);
			ShowWindow("PartyWnd.AssistWnd");
		}
		break;
		case "CB_SkillCastingBox":
		if ( Class'UIAPI_CHECKBOX'.IsChecked("InterfaceOptionWnd.Cb_SkillCastingBox") )
		{
			SetOptionBool("Custom","SkillCastingBox",True);
		} else {
			SetOptionBool("Custom","SkillCastingBox",False);
		}
		break;
		case "Cb_ShotcutTransparencyNum":
		if ( Class'UIAPI_CHECKBOX'.IsChecked("InterfaceOptionWnd.Cb_ShotcutTransparencyNum") )
		{
			SetOptionBool("Custom","ShortcutTransparencyNum",True);
		} else {
			SetOptionBool("Custom","ShortcutTransparencyNum",False);
		}
		SetShortcutTransparencyNum();
		break;
		case "assistIfNoblesse":
		if ( Class'UIAPI_CHECKBOX'.IsChecked("InterfaceOptionWnd.assistIfNoblesse") )
		{
			SetOptionBool("Custom","NoblesseAssist",True);
		} else {
			SetOptionBool("Custom","NoblesseAssist",False);
		}
		break;
		case "Cb_ShotcutTransparencyBox":
		if ( Class'UIAPI_CHECKBOX'.IsChecked("InterfaceOptionWnd.Cb_ShotcutTransparencyBox") )
		{
			SetOptionBool("Custom","ShortcutTransparencyBox",True);
		} else {
			SetOptionBool("Custom","ShortcutTransparencyBox",False);
		}
		SetShortcutTransparencyBox();
		break;
		case "Cb_ChatTransparency":
		if ( Class'UIAPI_CHECKBOX'.IsChecked("InterfaceOptionWnd.Cb_ChatTransparency") )
		{
			SetOptionBool("Custom","ChatTransparency",True);
		} else {
			SetOptionBool("Custom","ChatTransparency",False);
		}
		HandleChatTransparency();
		break;
		case "Cb_ShowEvent":
		if ( Class'UIAPI_CHECKBOX'.IsChecked("InterfaceOptionWnd.Cb_ShowEvent") )
		{
			SetOptionBool("Custom","ShowEvent",True);
			ExecuteEvent(2990);
		} else {
			SetOptionBool("Custom","ShowEvent",False);
			ExecuteEvent(2990);
		}
		break;
		case "Cb_HoldTarget":
		if ( Class'UIAPI_CHECKBOX'.IsChecked("InterfaceOptionWnd.Cb_HoldTarget") )
		{
			SetOptionBool("Custom","HoldTarget",True);
		} else {
			SetOptionBool("Custom","HoldTarget",False);
		}
		break;
		case "Cb_IgnoreAggr":
		if ( Class'UIAPI_CHECKBOX'.IsChecked("InterfaceOptionWnd.Cb_IgnoreAggr") )
		{
			SetOptionBool("Custom","IgnoreAggr",True);
		} else {
			SetOptionBool("Custom","IgnoreAggr",False);
		}
		break;
		case "BuffPotions":
		if ( Class'UIAPI_CHECKBOX'.IsChecked("InterfaceOptionWnd.BuffPotions") )
		{
			SetOptionBool("Custom","BuffPotions",True);
		} else {
			SetOptionBool("Custom","BuffPotions",False);
		}
		break;
		case "checkAbDebuff":
		case "checkAbSongDance":
		case "checkAbPriorDebuffSameRow":
		SetOptionBool("Custom",strID,Class'UIAPI_CHECKBOX'.IsChecked(UnknownFunction112("InterfaceOptionWnd.",strID)));
		ExecuteEvent(4444);
		break;
		case "checkAbPrior":
		SetOptionBool("Custom",strID,Class'UIAPI_CHECKBOX'.IsChecked(UnknownFunction112("InterfaceOptionWnd.",strID)));
		HandleAbnormalPriorityBuffsWindows();
		ExecuteEvent(4444);
		break;
		case "checkAbPriorNobless":
		case "checkAbPriorPrayer":
		case "checkAbPriorWindWalk":
		case "checkAbPriorArcana":
		case "checkAbPriorAcumen":
		case "checkAbPriorEmpower":
		case "checkAbPriorHaste":
		case "checkAbPriorMight":
		case "checkAbPriorHotSpring":
		case "checkAbPriorViciousStance":
		case "checkAbPriorHeroicValor":
		case "checkAbPriorSummoner":
		case "checkAbPriorForce":
		case "checkAbPriorTitan":
		case "checkAbPriorHawkeye":
		case "checkAbPriorRanger":
		case "checkAbPriorKnight":
		case "checkAbPriorMystic":
		case "checkAbPriorMagePoV":
		case "checkAbPriorFighterPoV":
		case "checkAbPriorTankPoV":
		SetOptionBool("Custom",strID,Class'UIAPI_CHECKBOX'.IsChecked(UnknownFunction112("InterfaceOptionWnd.",strID)));
		HandleAbnormalPriorityBuffsList();
		ExecuteEvent(4444);
		break;
		case "checkPrior":
		SetOptionBool("Custom",strID,Class'UIAPI_CHECKBOX'.IsChecked(UnknownFunction112("InterfaceOptionWnd.",strID)));
		HandlePartyPriorityBuffsWindows();
		HandlePartyPriorityBuffsList();
		ExecuteEvent(4445);
		break;
		case "checkPriorNobless":
		case "checkPriorPrayer":
		case "checkPriorWindWalk":
		case "checkPriorArcana":
		case "checkPriorAcumen":
		case "checkPriorEmpower":
		case "checkPriorHaste":
		case "checkPriorMight":
		case "checkPriorHotSpring":
		case "checkPriorViciousStance":
		case "checkPriorHeroicValor":
		case "checkPriorDebuffSameRow":
		case "checkPriorSummoner":
		case "checkPriorForce":
		case "checkPriorTitan":
		case "checkPriorHawkeye":
		case "checkPriorRanger":
		case "checkPriorKnight":
		case "checkPriorMystic":
		case "checkPriorMagePoV":
		case "checkPriorFighterPoV":
		case "checkPriorTankPoV":
		SetOptionBool("Custom",strID,Class'UIAPI_CHECKBOX'.IsChecked(UnknownFunction112("InterfaceOptionWnd.",strID)));
		HandlePartyPriorityBuffsList();
		ExecuteEvent(4445);
		break;
		default:
	}
}

function OnShow ()
{
	InitInterfaceOption();
}

function OnClickButton (string strID)
{
	switch (strID)
	{
		case "OtherTab1OKBtn":
		case "OtherTab2OKBtn":
		case "OtherTab3OKBtn":
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd");
		break;
		default:
	}
}

function OnComboBoxItemSelected (string sName, int Index)
{
	local int nSelectedNum;

	switch (sName)
	{
		case "AbnormalSizeBox":
		nSelectedNum = Class'UIAPI_COMBOBOX'.GetSelectedNum("InterfaceOptionWnd.AbnormalSizeBox");
		SetOptionInt("Custom","AbnormalSize",nSelectedNum);
		ExecuteEvent(4444);
		break;
		case "MinimapCB":
		nSelectedNum = Class'UIAPI_COMBOBOX'.GetSelectedNum("InterfaceOptionWnd.MinimapCB");
		SetOptionInt("Custom","Minimap",nSelectedNum);
		ExecuteEvent(11223344);
		break;
		default:
	}
}

function SetShortcutTransparencyNum ()
{
	if ( BoolEquals(GetOptionBool("Custom","ShortcutTransparencyNum"),True) )
	{
		Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.Cb_ShotcutTransparencyNum",True);
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.F1Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.F2Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.F3Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.F4Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.F5Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.F6Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.F7Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.F8Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.F9Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.F10Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.F11Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.F12Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.F1Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.F2Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.F3Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.F4Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.F5Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.F6Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.F7Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.F8Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.F9Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.F10Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.F11Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.F12Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.F1Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.F2Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.F3Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.F4Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.F5Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.F6Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.F7Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.F8Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.F9Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.F10Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.F11Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.F12Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.F1Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.F2Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.F3Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.F4Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.F5Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.F6Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.F7Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.F8Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.F9Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.F10Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.F11Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.F12Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.F1Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.F2Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.F3Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.F4Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.F5Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.F6Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.F7Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.F8Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.F9Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.F10Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.F11Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.F12Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.F1Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.F2Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.F3Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.F4Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.F5Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.F6Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.F7Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.F8Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.F9Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.F10Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.F11Tex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.F12Tex","InterfaceTextures.Null");
	} else {
		Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.Cb_ShotcutTransparencyNum",False);
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.F1Tex","InterfaceTextures.InterfaceTextures.NPHRN_Signa_Key_1");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.F2Tex","InterfaceTextures.InterfaceTextures.NPHRN_Signa_Key_2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.F3Tex","InterfaceTextures.InterfaceTextures.NPHRN_Signa_Key_3");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.F4Tex","InterfaceTextures.InterfaceTextures.NPHRN_Signa_Key_4");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.F5Tex","InterfaceTextures.InterfaceTextures.NPHRN_Signa_Key_5");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.F6Tex","InterfaceTextures.InterfaceTextures.NPHRN_Signa_Key_6");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.F7Tex","InterfaceTextures.InterfaceTextures.NPHRN_Signa_Key_7");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.F8Tex","InterfaceTextures.InterfaceTextures.NPHRN_Signa_Key_8");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.F9Tex","InterfaceTextures.InterfaceTextures.NPHRN_Signa_Key_9");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.F10Tex","InterfaceTextures.InterfaceTextures.NPHRN_Signa_Key_10");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.F11Tex","InterfaceTextures.InterfaceTextures.NPHRN_Signa_Key_11");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.F12Tex","InterfaceTextures.InterfaceTextures.NPHRN_Signa_Key_12");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.F1Tex","InterfaceTextures.NPHRN_Signa_Key_1");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.F2Tex","InterfaceTextures.NPHRN_Signa_Key_2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.F3Tex","InterfaceTextures.NPHRN_Signa_Key_3");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.F4Tex","InterfaceTextures.NPHRN_Signa_Key_4");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.F5Tex","InterfaceTextures.NPHRN_Signa_Key_5");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.F6Tex","InterfaceTextures.NPHRN_Signa_Key_6");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.F7Tex","InterfaceTextures.NPHRN_Signa_Key_7");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.F8Tex","InterfaceTextures.NPHRN_Signa_Key_8");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.F9Tex","InterfaceTextures.NPHRN_Signa_Key_9");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.F10Tex","InterfaceTextures.NPHRN_Signa_Key_10");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.F11Tex","InterfaceTextures.NPHRN_Signa_Key_11");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.F12Tex","InterfaceTextures.NPHRN_Signa_Key_12");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.F1Tex","InterfaceTextures.NPHRN_Signa_Key_1");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.F2Tex","InterfaceTextures.NPHRN_Signa_Key_2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.F3Tex","InterfaceTextures.NPHRN_Signa_Key_3");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.F4Tex","InterfaceTextures.NPHRN_Signa_Key_4");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.F5Tex","InterfaceTextures.NPHRN_Signa_Key_5");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.F6Tex","InterfaceTextures.NPHRN_Signa_Key_6");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.F7Tex","InterfaceTextures.NPHRN_Signa_Key_7");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.F8Tex","InterfaceTextures.NPHRN_Signa_Key_8");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.F9Tex","InterfaceTextures.NPHRN_Signa_Key_9");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.F10Tex","InterfaceTextures.NPHRN_Signa_Key_10");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.F11Tex","InterfaceTextures.NPHRN_Signa_Key_11");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.F12Tex","InterfaceTextures.NPHRN_Signa_Key_12");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.F1Tex","InterfaceTextures.NPHRN_Signa_Key_1");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.F2Tex","InterfaceTextures.NPHRN_Signa_Key_2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.F3Tex","InterfaceTextures.NPHRN_Signa_Key_3");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.F4Tex","InterfaceTextures.NPHRN_Signa_Key_4");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.F5Tex","InterfaceTextures.NPHRN_Signa_Key_5");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.F6Tex","InterfaceTextures.NPHRN_Signa_Key_6");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.F7Tex","InterfaceTextures.NPHRN_Signa_Key_7");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.F8Tex","InterfaceTextures.NPHRN_Signa_Key_8");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.F9Tex","InterfaceTextures.NPHRN_Signa_Key_9");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.F10Tex","InterfaceTextures.NPHRN_Signa_Key_10");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.F11Tex","InterfaceTextures.NPHRN_Signa_Key_11");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.F12Tex","InterfaceTextures.NPHRN_Signa_Key_12");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.F1Tex","InterfaceTextures.NPHRN_Signa_Key_1");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.F2Tex","InterfaceTextures.NPHRN_Signa_Key_2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.F3Tex","InterfaceTextures.NPHRN_Signa_Key_3");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.F4Tex","InterfaceTextures.NPHRN_Signa_Key_4");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.F5Tex","InterfaceTextures.NPHRN_Signa_Key_5");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.F6Tex","InterfaceTextures.NPHRN_Signa_Key_6");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.F7Tex","InterfaceTextures.NPHRN_Signa_Key_7");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.F8Tex","InterfaceTextures.NPHRN_Signa_Key_8");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.F9Tex","InterfaceTextures.NPHRN_Signa_Key_9");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.F10Tex","InterfaceTextures.NPHRN_Signa_Key_10");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.F11Tex","InterfaceTextures.NPHRN_Signa_Key_11");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.F12Tex","InterfaceTextures.NPHRN_Signa_Key_12");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.F1Tex","InterfaceTextures.NPHRN_Signa_Key_1");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.F2Tex","InterfaceTextures.NPHRN_Signa_Key_2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.F3Tex","InterfaceTextures.NPHRN_Signa_Key_3");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.F4Tex","InterfaceTextures.NPHRN_Signa_Key_4");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.F5Tex","InterfaceTextures.NPHRN_Signa_Key_5");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.F6Tex","InterfaceTextures.NPHRN_Signa_Key_6");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.F7Tex","InterfaceTextures.NPHRN_Signa_Key_7");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.F8Tex","InterfaceTextures.NPHRN_Signa_Key_8");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.F9Tex","InterfaceTextures.NPHRN_Signa_Key_9");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.F10Tex","InterfaceTextures.NPHRN_Signa_Key_10");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.F11Tex","InterfaceTextures.NPHRN_Signa_Key_11");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.F12Tex","InterfaceTextures.NPHRN_Signa_Key_12");
	}
}

function SetShortcutTransparencyBox ()
{
	if ( BoolEquals(GetOptionBool("Custom","ShortcutTransparencyBox"),True) )
	{
		Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.Cb_ShotcutTransparencyBox",True);
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.BackDropTex_1","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.BackDropTex_2","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.BackDropTex_3","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.BackDropTex_4","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.BackDropTex_5","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.BackDropTex_6","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.BackDropTex_7","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.BackDropTex_8","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.BackDropTex_9","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.BackDropTex_10","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.BackDropTex_11","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.BackDropTex_12","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.BackDropTex_1","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.BackDropTex_2","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.BackDropTex_3","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.BackDropTex_4","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.BackDropTex_5","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.BackDropTex_6","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.BackDropTex_7","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.BackDropTex_8","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.BackDropTex_9","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.BackDropTex_10","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.BackDropTex_11","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.BackDropTex_12","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.BackDropTex_1","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.BackDropTex_2","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.BackDropTex_3","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.BackDropTex_4","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.BackDropTex_5","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.BackDropTex_6","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.BackDropTex_7","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.BackDropTex_8","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.BackDropTex_9","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.BackDropTex_10","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.BackDropTex_11","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.BackDropTex_12","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.BackDropTex_1","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.BackDropTex_2","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.BackDropTex_3","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.BackDropTex_4","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.BackDropTex_5","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.BackDropTex_6","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.BackDropTex_7","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.BackDropTex_8","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.BackDropTex_9","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.BackDropTex_10","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.BackDropTex_11","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.BackDropTex_12","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.BackDropTex_1","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.BackDropTex_2","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.BackDropTex_3","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.BackDropTex_4","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.BackDropTex_5","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.BackDropTex_6","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.BackDropTex_7","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.BackDropTex_8","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.BackDropTex_9","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.BackDropTex_10","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.BackDropTex_11","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.BackDropTex_12","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.BackDropTex_1","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.BackDropTex_2","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.BackDropTex_3","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.BackDropTex_4","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.BackDropTex_5","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.BackDropTex_6","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.BackDropTex_7","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.BackDropTex_8","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.BackDropTex_9","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.BackDropTex_10","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.BackDropTex_11","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.BackDropTex_12","InterfaceTextures.Null");
	} else {
		Class'UIAPI_CHECKBOX'.SetCheck("InterfaceOptionWnd.Cb_ShotcutTransparencyBox",False);
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.BackDropTex_1","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.BackDropTex_2","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.BackDropTex_3","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.BackDropTex_4","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.BackDropTex_5","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.BackDropTex_6","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.BackDropTex_7","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.BackDropTex_8","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.BackDropTex_9","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.BackDropTex_10","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.BackDropTex_11","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal.BackDropTex_12","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.BackDropTex_1","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.BackDropTex_2","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.BackDropTex_3","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.BackDropTex_4","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.BackDropTex_5","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.BackDropTex_6","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.BackDropTex_7","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.BackDropTex_8","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.BackDropTex_9","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.BackDropTex_10","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.BackDropTex_11","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.BackDropTex_12","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.BackDropTex_1","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.BackDropTex_2","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.BackDropTex_3","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.BackDropTex_4","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.BackDropTex_5","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.BackDropTex_6","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.BackDropTex_7","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.BackDropTex_8","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.BackDropTex_9","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.BackDropTex_10","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.BackDropTex_11","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.BackDropTex_12","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.BackDropTex_1","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.BackDropTex_2","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.BackDropTex_3","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.BackDropTex_4","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.BackDropTex_5","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.BackDropTex_6","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.BackDropTex_7","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.BackDropTex_8","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.BackDropTex_9","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.BackDropTex_10","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.BackDropTex_11","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_3.BackDropTex_12","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.BackDropTex_1","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.BackDropTex_2","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.BackDropTex_3","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.BackDropTex_4","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.BackDropTex_5","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.BackDropTex_6","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.BackDropTex_7","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.BackDropTex_8","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.BackDropTex_9","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.BackDropTex_10","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.BackDropTex_11","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_4.BackDropTex_12","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.BackDropTex_1","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.BackDropTex_2","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.BackDropTex_3","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.BackDropTex_4","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.BackDropTex_5","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.BackDropTex_6","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.BackDropTex_7","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.BackDropTex_8","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.BackDropTex_9","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.BackDropTex_10","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.BackDropTex_11","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndHorizontal_5.BackDropTex_12","InterfaceTextures.ItemWindow_DF_SlotBox_2x2");
	}
}

function HandleAbnormalPriorityBuffsWindows ()
{
	if ( Class'UIAPI_CHECKBOX'.IsChecked("checkAbPrior") )
	{
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkAbPriorNobless");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkAbPriorAcumen");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkAbPriorEmpower");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkAbPriorMight");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkAbPriorHaste");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkAbPriorPrayer");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkAbPriorArcana");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkAbPriorWindWalk");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkAbPriorHotSpring");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkAbPriorDebuffSameRow");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkAbPriorViciousStance");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkAbPriorHeroicValor");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkAbPriorSummoner");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkAbPriorForce");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkAbPriorTitan");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkAbPriorHawkeye");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkAbPriorRanger");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkAbPriorKnight");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkAbPriorMystic");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkAbPriorMagePoV");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkAbPriorFighterPoV");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkAbPriorTankPoV");
	} else {
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkAbPriorNobless");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkAbPriorAcumen");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkAbPriorEmpower");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkAbPriorMight");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkAbPriorHaste");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkAbPriorPrayer");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkAbPriorArcana");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkAbPriorWindWalk");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkAbPriorHotSpring");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkAbPriorDebuffSameRow");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkAbPriorViciousStance");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkAbPriorHeroicValor");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkAbPriorSummoner");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkAbPriorForce");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkAbPriorTitan");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkAbPriorHawkeye");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkAbPriorRanger");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkAbPriorKnight");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkAbPriorMystic");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkAbPriorMagePoV");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkAbPriorFighterPoV");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkAbPriorTankPoV");
	}
}

function HandlePartyPriorityBuffsWindows ()
{
	if ( Class'UIAPI_CHECKBOX'.IsChecked("checkPrior") )
	{
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkPriorNobless");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkPriorAcumen");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkPriorEmpower");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkPriorMight");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkPriorHaste");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkPriorPrayer");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkPriorArcana");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkPriorWindWalk");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkPriorHotSpring");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkPriorDebuffSameRow");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkPriorViciousStance");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkPriorHeroicValor");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkPriorDebuffSameRow");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkPriorSummoner");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkPriorForce");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkPriorTitan");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkPriorHawkeye");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkPriorRanger");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkPriorKnight");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkPriorMystic");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkPriorMagePoV");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkPriorFighterPoV");
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceOptionWnd.checkPriorTankPoV");
	} else {
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkPriorNobless");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkPriorAcumen");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkPriorEmpower");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkPriorMight");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkPriorHaste");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkPriorPrayer");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkPriorArcana");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkPriorWindWalk");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkPriorHotSpring");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkPriorDebuffSameRow");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkPriorViciousStance");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkPriorHeroicValor");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkPriorDebuffSameRow");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkPriorSummoner");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkPriorForce");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkPriorTitan");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkPriorHawkeye");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkPriorRanger");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkPriorKnight");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkPriorMystic");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkPriorMagePoV");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkPriorFighterPoV");
		Class'UIAPI_WINDOW'.HideWindow("InterfaceOptionWnd.checkPriorTankPoV");
	}
}

function AddAbnormalPriorityBuffs (int i_Param)
{
	AbnormalPriorityArray.Length = DoAdd(AbnormalPriorityArray.Length,1);
	AbnormalPriorityArray[IntSub(AbnormalPriorityArray.Length,1)] = i_Param;
}

function HandleAbnormalPriorityBuffsList ()
{
	AbnormalPriorityArray.Length = 0;
	if ( Class'UIAPI_CHECKBOX'.IsChecked("checkAbPrior") )
	{
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkAbPriorNobless") )
		{
			AddAbnormalPriorityBuffs(1323);
			AddAbnormalPriorityBuffs(1410);
			AddAbnormalPriorityBuffs(438);
			AddAbnormalPriorityBuffs(1418);
		}
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkAbPriorPrayer") )
		{
			AddAbnormalPriorityBuffs(1307);
		}
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkAbPriorWindWalk") )
		{
			AddAbnormalPriorityBuffs(1204);
			AddAbnormalPriorityBuffs(2034);
			AddAbnormalPriorityBuffs(1282);
		}
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkAbPriorArcana") )
		{
			AddAbnormalPriorityBuffs(336);
			AddAbnormalPriorityBuffs(337);
			AddAbnormalPriorityBuffs(338);
		}
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkAbPriorAcumen") )
		{
			AddAbnormalPriorityBuffs(1085);
			AddAbnormalPriorityBuffs(1004);
			AddAbnormalPriorityBuffs(1002);
			AddAbnormalPriorityBuffs(2169);
		}
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkAbPriorEmpower") )
		{
			AddAbnormalPriorityBuffs(1059);
			AddAbnormalPriorityBuffs(1365);
		}
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkAbPriorHaste") )
		{
			AddAbnormalPriorityBuffs(1086);
			AddAbnormalPriorityBuffs(1251);
			AddAbnormalPriorityBuffs(2035);
		}
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkAbPriorMight") )
		{
			AddAbnormalPriorityBuffs(1388);
			AddAbnormalPriorityBuffs(3132);
			AddAbnormalPriorityBuffs(3134);
			AddAbnormalPriorityBuffs(3215);
			AddAbnormalPriorityBuffs(3217);
			AddAbnormalPriorityBuffs(3240);
			AddAbnormalPriorityBuffs(3243);
			AddAbnormalPriorityBuffs(4345);
			AddAbnormalPriorityBuffs(4393);
			AddAbnormalPriorityBuffs(5154);
			AddAbnormalPriorityBuffs(5157);
			AddAbnormalPriorityBuffs(1068);
			AddAbnormalPriorityBuffs(1003);
			AddAbnormalPriorityBuffs(1251);
		}
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkAbPriorHotSpring") )
		{
			AddAbnormalPriorityBuffs(4554);
			AddAbnormalPriorityBuffs(4553);
			AddAbnormalPriorityBuffs(4552);
			AddAbnormalPriorityBuffs(4551);
		}
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkAbPriorViciousStance") )
		{
			AddAbnormalPriorityBuffs(312);
		}
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkAbPriorHeroicValor") )
		{
			AddAbnormalPriorityBuffs(395);
			AddAbnormalPriorityBuffs(396);
			AddAbnormalPriorityBuffs(1374);
			AddAbnormalPriorityBuffs(1375);
			AddAbnormalPriorityBuffs(1376);
		}
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkAbPriorSummoner") )
		{
			AddAbnormalPriorityBuffs(1262);
			AddAbnormalPriorityBuffs(4702);
			AddAbnormalPriorityBuffs(4703);
			AddAbnormalPriorityBuffs(4699);
			AddAbnormalPriorityBuffs(4700);
		}
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkAbPriorForce") )
		{
			AddAbnormalPriorityBuffs(5104);
			AddAbnormalPriorityBuffs(5105);
		}
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkAbPriorTitan") )
		{
			AddAbnormalPriorityBuffs(176);
			AddAbnormalPriorityBuffs(420);
			AddAbnormalPriorityBuffs(94);
		}
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkAbPriorHawkeye") )
		{
			AddAbnormalPriorityBuffs(131);
			AddAbnormalPriorityBuffs(313);
			AddAbnormalPriorityBuffs(4);
			AddAbnormalPriorityBuffs(111);
		}
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkAbPriorRanger") )
		{
			AddAbnormalPriorityBuffs(414);
			AddAbnormalPriorityBuffs(413);
			AddAbnormalPriorityBuffs(369);
			AddAbnormalPriorityBuffs(111);
		}
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkAbPriorKnight") )
		{
			AddAbnormalPriorityBuffs(406);
			AddAbnormalPriorityBuffs(341);
			AddAbnormalPriorityBuffs(342);
		}
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkAbPriorMystic") )
		{
			AddAbnormalPriorityBuffs(1189);
			AddAbnormalPriorityBuffs(1191);
			AddAbnormalPriorityBuffs(1182);
			AddAbnormalPriorityBuffs(1287);
			AddAbnormalPriorityBuffs(1285);
			AddAbnormalPriorityBuffs(1286);
		}
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkAbPriorMagePoV") )
		{
			AddAbnormalPriorityBuffs(1413);
			AddAbnormalPriorityBuffs(1355);
		}
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkAbPriorFighterPoV") )
		{
			AddAbnormalPriorityBuffs(1356);
			AddAbnormalPriorityBuffs(1357);
		}
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkAbPriorTankPoV") )
		{
			AddAbnormalPriorityBuffs(1363);
			AddAbnormalPriorityBuffs(1414);
		}
	}
	AbnormalStatusWnd.a_UnkArrayInt1 = AbnormalPriorityArray;
}

function AddPartyPriorityBuffs (int i_Param)
{
	PartyPriorityArray.Length = DoAdd(PartyPriorityArray.Length,1);
	PartyPriorityArray[IntSub(PartyPriorityArray.Length,1)] = i_Param;
}

function HandlePartyPriorityBuffsList ()
{
	PartyPriorityArray.Length = 0;
	if ( Class'UIAPI_CHECKBOX'.IsChecked("checkPrior") )
	{
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkPriorNobless") )
		{
			AddPartyPriorityBuffs(1323);
			AddPartyPriorityBuffs(1410);
			AddPartyPriorityBuffs(438);
			AddPartyPriorityBuffs(1418);
		}
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkPriorPrayer") )
		{
			AddPartyPriorityBuffs(1307);
		}
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkPriorWindWalk") )
		{
			AddPartyPriorityBuffs(1204);
			AddPartyPriorityBuffs(2034);
			AddPartyPriorityBuffs(1282);
		}
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkPriorArcana") )
		{
			AddPartyPriorityBuffs(336);
			AddPartyPriorityBuffs(337);
			AddPartyPriorityBuffs(338);
		}
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkPriorAcumen") )
		{
			AddPartyPriorityBuffs(1085);
			AddPartyPriorityBuffs(1004);
			AddPartyPriorityBuffs(1002);
			AddPartyPriorityBuffs(2169);
		}
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkPriorEmpower") )
		{
			AddPartyPriorityBuffs(1059);
			AddPartyPriorityBuffs(1365);
		}
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkPriorHaste") )
		{
			AddPartyPriorityBuffs(1086);
			AddPartyPriorityBuffs(1251);
			AddPartyPriorityBuffs(2035);
		}
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkPriorMight") )
		{
			AddPartyPriorityBuffs(1388);
			AddPartyPriorityBuffs(3132);
			AddPartyPriorityBuffs(3134);
			AddPartyPriorityBuffs(3215);
			AddPartyPriorityBuffs(3217);
			AddPartyPriorityBuffs(3240);
			AddPartyPriorityBuffs(3243);
			AddPartyPriorityBuffs(4345);
			AddPartyPriorityBuffs(4393);
			AddPartyPriorityBuffs(5154);
			AddPartyPriorityBuffs(5157);
			AddPartyPriorityBuffs(1068);
			AddPartyPriorityBuffs(1003);
			AddPartyPriorityBuffs(1251);
		}
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkPriorHotSpring") )
		{
			AddPartyPriorityBuffs(4554);
			AddPartyPriorityBuffs(4553);
			AddPartyPriorityBuffs(4552);
			AddPartyPriorityBuffs(4551);
		}
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkPriorViciousStance") )
		{
			AddPartyPriorityBuffs(312);
		}
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkPriorHeroicValor") )
		{
			AddPartyPriorityBuffs(395);
			AddPartyPriorityBuffs(396);
			AddPartyPriorityBuffs(1374);
			AddPartyPriorityBuffs(1375);
			AddPartyPriorityBuffs(1376);
		}
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkPriorSummoner") )
		{
			AddPartyPriorityBuffs(1262);
			AddPartyPriorityBuffs(4702);
			AddPartyPriorityBuffs(4703);
			AddPartyPriorityBuffs(4699);
			AddPartyPriorityBuffs(4700);
		}
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkPriorForce") )
		{
			AddPartyPriorityBuffs(5104);
			AddPartyPriorityBuffs(5105);
		}
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkPriorTitan") )
		{
			AddPartyPriorityBuffs(176);
			AddPartyPriorityBuffs(420);
			AddPartyPriorityBuffs(94);
		}
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkPriorHawkeye") )
		{
			AddPartyPriorityBuffs(131);
			AddPartyPriorityBuffs(313);
			AddPartyPriorityBuffs(4);
			AddPartyPriorityBuffs(111);
		}
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkPriorRanger") )
		{
			AddPartyPriorityBuffs(414);
			AddPartyPriorityBuffs(413);
			AddPartyPriorityBuffs(369);
			AddPartyPriorityBuffs(111);
		}
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkPriorKnight") )
		{
			AddPartyPriorityBuffs(406);
			AddPartyPriorityBuffs(341);
			AddPartyPriorityBuffs(342);
		}
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkPriorMystic") )
		{
			AddPartyPriorityBuffs(1189);
			AddPartyPriorityBuffs(1191);
			AddPartyPriorityBuffs(1182);
			AddPartyPriorityBuffs(1287);
			AddPartyPriorityBuffs(1285);
			AddPartyPriorityBuffs(1286);
		}
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkPriorMagePoV") )
		{
			AddPartyPriorityBuffs(1413);
			AddPartyPriorityBuffs(1355);
		}
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkPriorFighterPoV") )
		{
			AddPartyPriorityBuffs(1356);
			AddPartyPriorityBuffs(1357);
		}
		if ( Class'UIAPI_CHECKBOX'.IsChecked("checkPriorTankPoV") )
		{
			AddPartyPriorityBuffs(1363);
			AddPartyPriorityBuffs(1414);
		}
	}
	PartyWnd.a_UnkArrayInt1 = PartyPriorityArray;
}

function HandleHideSpamSkill ()
{
	local ShortcutWnd script;

	script = ShortcutWnd(GetScript("ShortcutWnd"));
	if ( Class'UIAPI_CHECKBOX'.IsChecked("AutoSkillSpamWnd.Cb_HideSkillSpam") )
	{
		Class'UIAPI_WINDOW'.HideWindow("AutoSkillSpamWnd");
	} else {
		Class'UIAPI_WINDOW'.ShowWindow("AutoSkillSpamWnd");
	}
	script.AutoPotionsWndPosition();
}

function HandleHideSkillSpamBox ()
{
	if ( BoolEquals(GetOptionBool("Custom","HideSpamSkillsBox"),True) )
	{
		Class'UIAPI_TEXTURECTRL'.SetTexture("AutoSkillSpamWnd.SpamBackTex_1","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("AutoSkillSpamWnd.SpamBackTex_2","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("AutoSkillSpamWnd.SpamBackTex_3","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("AutoSkillSpamWnd.SpamBackTex_4","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("AutoSkillSpamWnd.SpamBackTex_5","InterfaceTextures.Null");
	} else {
		Class'UIAPI_TEXTURECTRL'.SetTexture("AutoSkillSpamWnd.SpamBackTex_1","InterfaceTextures.SkillBox");
		Class'UIAPI_TEXTURECTRL'.SetTexture("AutoSkillSpamWnd.SpamBackTex_2","InterfaceTextures.SkillBox");
		Class'UIAPI_TEXTURECTRL'.SetTexture("AutoSkillSpamWnd.SpamBackTex_3","InterfaceTextures.SkillBox");
		Class'UIAPI_TEXTURECTRL'.SetTexture("AutoSkillSpamWnd.SpamBackTex_4","InterfaceTextures.SkillBox");
		Class'UIAPI_TEXTURECTRL'.SetTexture("AutoSkillSpamWnd.SpamBackTex_5","InterfaceTextures.SkillBox");
	}
}

function HandleHideAutoBuffBox ()
{
	if ( BoolEquals(GetOptionBool("Custom","HideAutoBuffBox"),True) )
	{
		Class'UIAPI_TEXTURECTRL'.SetTexture("AutoSkillWnd.BackTex_1","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("AutoSkillWnd.BackTex_2","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("AutoSkillWnd.BackTex_3","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("AutoSkillWnd.BackTex_4","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("AutoSkillWnd.BackTex_5","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("AutoSkillWnd.BackTex_6","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("AutoSkillWnd.BackTex_7","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("AutoSkillWnd.BackTex_8","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("AutoSkillWnd.BackTex_9","InterfaceTextures.Null");
	} else {
		Class'UIAPI_TEXTURECTRL'.SetTexture("AutoSkillWnd.BackTex_1","InterfaceTextures.SkillBox");
		Class'UIAPI_TEXTURECTRL'.SetTexture("AutoSkillWnd.BackTex_2","InterfaceTextures.SkillBox");
		Class'UIAPI_TEXTURECTRL'.SetTexture("AutoSkillWnd.BackTex_3","InterfaceTextures.SkillBox");
		Class'UIAPI_TEXTURECTRL'.SetTexture("AutoSkillWnd.BackTex_4","InterfaceTextures.SkillBox");
		Class'UIAPI_TEXTURECTRL'.SetTexture("AutoSkillWnd.BackTex_5","InterfaceTextures.SkillBox");
		Class'UIAPI_TEXTURECTRL'.SetTexture("AutoSkillWnd.BackTex_6","InterfaceTextures.SkillBox");
		Class'UIAPI_TEXTURECTRL'.SetTexture("AutoSkillWnd.BackTex_7","InterfaceTextures.SkillBox");
		Class'UIAPI_TEXTURECTRL'.SetTexture("AutoSkillWnd.BackTex_8","InterfaceTextures.SkillBox");
		Class'UIAPI_TEXTURECTRL'.SetTexture("AutoSkillWnd.BackTex_9","InterfaceTextures.SkillBox");
	}
}

function HandleHideAutoBuffAndSpamSkill ()
{
	local ShortcutWnd script;

	script = ShortcutWnd(GetScript("ShortcutWnd"));
	if ( Class'UIAPI_CHECKBOX'.IsChecked("AutoSkillSpamWnd.Cb_HideAutoBuff") )
	{
		Class'UIAPI_WINDOW'.HideWindow("AutoSkillWnd");
	} else {
		Class'UIAPI_WINDOW'.ShowWindow("AutoSkillWnd");
	}
	if ( Class'UIAPI_CHECKBOX'.IsChecked("AutoSkillSpamWnd.Cb_HideSkillSpam") )
	{
		Class'UIAPI_WINDOW'.HideWindow("AutoSkillSpamWnd");
	} else {
		Class'UIAPI_WINDOW'.ShowWindow("AutoSkillSpamWnd");
	}
	script.AutoPotionsWndPosition();
}

function HandleChatTransparency ()
{
	if ( GetOptionBool("Custom","ChatTransparency") )
	{
		Class'UIAPI_TEXTURECTRL'.SetTexture("ChatWnd.ChatWndHeadTex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ChatWnd.ChatWndBodyTex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ChatWnd.ChatWndBottomTex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("SystemMsgWnd.top","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("SystemMsgWnd.niz","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("SystemMsgWnd.BackTexture","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("SystemMsgWnd.ChatWndHeadTex","InterfaceTextures.Null");
		Class'UIAPI_TEXTURECTRL'.SetTexture("SystemMsgWnd.ChatWndBottomTex2","InterfaceTextures.Null");
	} else {
		Class'UIAPI_TEXTURECTRL'.SetTexture("ChatWnd.ChatWndHeadTex","L2UI_CH3.ChatWnd.Chatting_Back2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ChatWnd.ChatWndBodyTex","L2UI_CH3.ChatWnd.Chatting_Back3");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ChatWnd.ChatWndBottomTex","L2UI_CH3.ChatWnd.Chatting_Back4");
		Class'UIAPI_TEXTURECTRL'.SetTexture("SystemMsgWnd.top","SavoInterfaceTextures.SavoChatBg");
		Class'UIAPI_TEXTURECTRL'.SetTexture("SystemMsgWnd.niz","L2UI_CH3.Minimap.MapWnd_back_max");
		Class'UIAPI_TEXTURECTRL'.SetTexture("SystemMsgWnd.BackTexture","L2UI_CH3.ChatWnd.Chatting_Back3");
		Class'UIAPI_TEXTURECTRL'.SetTexture("SystemMsgWnd.ChatWndHeadTex","L2UI_CH3.ChatWnd.Chatting_Back2");
		Class'UIAPI_TEXTURECTRL'.SetTexture("SystemMsgWnd.ChatWndBottomTex2","L2UI_CH3.ChatWnd.Chatting_Back2");
	}
}

