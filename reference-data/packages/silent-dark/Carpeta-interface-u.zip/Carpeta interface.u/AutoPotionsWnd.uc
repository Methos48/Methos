//================================================================================
// AutoPotionsWnd.
//================================================================================

class AutoPotionsWnd extends UICommonAPI;

const POTION_CP_DELAY= 1;
const POTION_SMALL_CP_DELAY= 1;
const POTION_HP_DELAY= 30;
const POTION_MP_DELAY= 8;
const POTION_BUFF_DELAY= 15;
const POTION_BUFF_TIMER= 4443;
var WindowHandle m_hOptWnd;
var WindowHandle AutoPotionsWnd;
var ItemWindowHandle InventoryItem;
var ItemWindowHandle ElixirBoxCP;
var ItemWindowHandle ElixirBoxHP;
var ItemWindowHandle BoxSmallCP;
var ItemWindowHandle BoxCP;
var ItemWindowHandle BoxHP;
var ItemWindowHandle BoxQHP;
var ItemWindowHandle BoxMP;
var ItemInfo Elixir_CP_Item;
var ItemInfo Elixir_HP_Item;
var ItemInfo CP_SmallItem;
var ItemInfo CP_Item;
var ItemInfo HP_Item;
var ItemInfo QHP_Item;
var ItemInfo MP_Item;
var int timerHP;
var int timerMP;
var int timerSmallCP;
var int timerCP;
var bool ElixirUseCPPot;
var bool ElixirUseHPPot;
var bool UseSmallCPPot;
var bool UseCPPot;
var bool UseHPPot;
var bool UseQHPPot;
var bool UseMPPot;
var TextureHandle ElixirToggleCP;
var TextureHandle ElixirToggleHP;
var TextureHandle ToggleSmallCP;
var TextureHandle ToggleCP;
var TextureHandle ToggleHP;
var TextureHandle ToggleQHP;
var TextureHandle ToggleMP;
var TextBoxHandle ElixirCountCP;
var TextBoxHandle ElixirCountHP;
var TextBoxHandle CountSmallCP;
var TextBoxHandle CountCP;
var TextBoxHandle CountHP;
var TextBoxHandle CountQHP;
var TextBoxHandle CountMP;
var bool PotionsEnabled;
var bool hasAcumen;
var bool hasHaste;
var bool hasWW;
var bool hasBlockBuffEffect;
var bool HPPotInUse;
var bool MPPotInUse;
var bool CPPotInUse;
var bool SmallCPPotInUse;
var bool timerSet;
var int Count;
var ItemInfo AcumenPot;
var ItemInfo HastePot;
var ItemInfo WindWalkPot;
const TIMER_INSERT_ON_START=10210;
const TIMER_AUTOPOTS=10777;

function OnLoad ()
{
	OnRegisterEvent();
	Init();
	ElixirToggleCP.HideWindow();
	ElixirToggleHP.HideWindow();
	ToggleSmallCP.HideWindow();
	ToggleCP.HideWindow();
	ToggleHP.HideWindow();
	ToggleQHP.HideWindow();
	ToggleMP.HideWindow();
}

function OnDefaultPosition ()
{
	Class'UIAPI_WINDOW'.SetAnchor("AutoPotionsWnd","ElfenMenu","TopRight","TopRight",-5,-29);
}

function OnRegisterEvent ()
{
	RegisterEvent(150);
	RegisterEvent(950);
}

function Init ()
{
	AutoPotionsWnd = GetHandle("AutoPotionsWnd");
	InventoryItem = ItemWindowHandle(GetHandle("InventoryWnd.InventoryItem"));
	ElixirBoxCP = ItemWindowHandle(GetHandle("AutoPotionsWnd.ElixirBoxCP"));
	ElixirBoxHP = ItemWindowHandle(GetHandle("AutoPotionsWnd.ElixirBoxHP"));
	BoxSmallCP = ItemWindowHandle(GetHandle("AutoPotionsWnd.BoxSmallCP"));
	BoxCP = ItemWindowHandle(GetHandle("AutoPotionsWnd.BoxCP"));
	BoxHP = ItemWindowHandle(GetHandle("AutoPotionsWnd.BoxHP"));
	BoxQHP = ItemWindowHandle(GetHandle("AutoPotionsWnd.BoxQHP"));
	BoxMP = ItemWindowHandle(GetHandle("AutoPotionsWnd.BoxMP"));
	ElixirToggleCP = TextureHandle(GetHandle("AutoPotionsWnd.ElixirToggleCP"));
	ElixirToggleHP = TextureHandle(GetHandle("AutoPotionsWnd.ElixirToggleHP"));
	ToggleSmallCP = TextureHandle(GetHandle("AutoPotionsWnd.ToggleSmallCP"));
	ToggleCP = TextureHandle(GetHandle("AutoPotionsWnd.ToggleCP"));
	ToggleHP = TextureHandle(GetHandle("AutoPotionsWnd.ToggleHP"));
	ToggleQHP = TextureHandle(GetHandle("AutoPotionsWnd.ToggleQHP"));
	ToggleMP = TextureHandle(GetHandle("AutoPotionsWnd.ToggleMP"));
	ElixirCountCP = TextBoxHandle(GetHandle("AutoPotionsWnd.ElixirCountCP"));
	ElixirCountHP = TextBoxHandle(GetHandle("AutoPotionsWnd.ElixirCountHP"));
	CountSmallCP = TextBoxHandle(GetHandle("AutoPotionsWnd.CountSmallCP"));
	CountCP = TextBoxHandle(GetHandle("AutoPotionsWnd.CountCP"));
	CountHP = TextBoxHandle(GetHandle("AutoPotionsWnd.CountHP"));
	CountQHP = TextBoxHandle(GetHandle("AutoPotionsWnd.CountQHP"));
	CountMP = TextBoxHandle(GetHandle("AutoPotionsWnd.CountMP"));
	timerHP = 0;
	timerMP = 0;
	timerSmallCP = 0;
	Count = 0;
	HPPotInUse = False;
	MPPotInUse = False;
	CPPotInUse = False;
	SmallCPPotInUse = False;
	PotionsEnabled = False;
	timerSet = False;
}

function InsertPotionsOnStart ()
{
	GetItemInfo(8639,Elixir_CP_Item);
	if ( UnknownFunction153(Elixir_CP_Item.ItemNum,1) )
	{
		InsertElixirCPPotion(Elixir_CP_Item);
	}
	GetItemInfo(8627,Elixir_HP_Item);
	if ( UnknownFunction153(Elixir_HP_Item.ItemNum,1) )
	{
		InsertElixirHPPotion(Elixir_HP_Item);
	}
	GetItemInfo(5591,CP_SmallItem);
	if ( UnknownFunction153(CP_SmallItem.ItemNum,1) )
	{
		InsertSmallCPPotion(CP_SmallItem);
		EnablePotions(BoxSmallCP);
	}
	GetItemInfo(5592,CP_Item);
	if ( UnknownFunction153(CP_Item.ItemNum,1) )
	{
		InsertCPPotion(CP_Item);
		EnablePotions(BoxCP);
	} else {
		GetItemInfo(6540,CP_Item);
		if ( UnknownFunction153(CP_Item.ItemNum,1) )
		{
			InsertCPPotion(CP_Item);
			EnablePotions(BoxCP);
		}
	}
	GetItemInfo(1539,HP_Item);
	if ( UnknownFunction153(HP_Item.ItemNum,1) )
	{
		InsertHPPotion(HP_Item);
		EnablePotions(BoxHP);
	}
	GetItemInfo(1540,QHP_Item);
	if ( UnknownFunction153(QHP_Item.ItemNum,1) )
	{
		InsertQHPPotion(QHP_Item);
		EnablePotions(BoxQHP);
	}
	GetItemInfo(728,MP_Item);
	if ( UnknownFunction153(MP_Item.ItemNum,1) )
	{
		InsertMPPotion(MP_Item);
		EnablePotions(BoxMP);
	} else {
		GetItemInfo(6539,MP_Item);
		if ( UnknownFunction153(MP_Item.ItemNum,1) )
		{
			InsertMPPotion(MP_Item);
		}
	}
}

function GetItemInfo (int Id, out ItemInfo Info)
{
	local int Index;
	local ItemInfo item;

	Index = InventoryItem.FindItemWithClassID(Id);
	InventoryItem.GetItem(Index,item);
	if ( UnknownFunction151(Index,-1) )
	{
		Info = item;
	} else {
		Info.ItemNum = 0;
	}
}

function OnClickButton (string strID)
{
	switch (strID)
	{
		case "BtnSetting":
		HandleToggleAutoPotions();
		break;
		default:
	}
}

function HandleToggleAutoPotions ()
{
	if ( PotionsEnabled )
	{
		if ( UnknownFunction151(ElixirBoxCP.GetItemNum(),0) )
		{
			DisablePotions(ElixirBoxCP);
		}
		if ( UnknownFunction151(ElixirBoxHP.GetItemNum(),0) )
		{
			DisablePotions(ElixirBoxHP);
		}
		if ( UnknownFunction151(BoxCP.GetItemNum(),0) )
		{
			DisablePotions(BoxCP);
		}
		if ( UnknownFunction151(BoxSmallCP.GetItemNum(),0) )
		{
			DisablePotions(BoxSmallCP);
		}
		if ( UnknownFunction151(BoxHP.GetItemNum(),0) )
		{
			DisablePotions(BoxHP);
		}
		if ( UnknownFunction151(BoxQHP.GetItemNum(),0) )
		{
			DisablePotions(BoxQHP);
		}
		if ( UnknownFunction151(BoxMP.GetItemNum(),0) )
		{
			DisablePotions(BoxMP);
		}
		PotionsEnabled = False;
	} else {
		if ( UnknownFunction129(timerSet) )
		{
			AutoPotionsWnd.SetTimer(10777,500);
			timerSet = True;
		}
		InsertPotionsOnStart();
		PotionsEnabled = True;
	}
}

function OnTimer (int TimerID)
{
	if ( UnknownFunction154(TimerID,10777) )
	{
		HandlePotUsage();
		UnknownFunction161(Count,1);
		if ( UnknownFunction153(Count,60) )
		{
			AutoPotionsWnd.KillTimer(10777);
			AutoPotionsWnd.SetTimer(10777,500);
			Count = 0;
		}
	}
	if ( UnknownFunction154(TimerID,10210) )
	{
		InsertPotionsOnStart();
	}
	if ( UnknownFunction154(TimerID,4443) )
	{
		TryUsePotions();
	}
}

function HandlePotUsage ()
{
	if ( HPPotInUse )
	{
		UnknownFunction161(timerHP,1);
		if ( UnknownFunction153(timerHP,30) )
		{
			HPPotInUse = False;
			timerHP = 0;
		}
	}
	if ( MPPotInUse )
	{
		UnknownFunction161(timerMP,1);
		if ( UnknownFunction153(timerMP,8) )
		{
			MPPotInUse = False;
			timerMP = 0;
		}
	}
	if ( UnknownFunction130(UnknownFunction129(HPPotInUse),UseHPPot) )
	{
		Handle_CP_HP_MP_Update("HP");
	}
	if ( UnknownFunction130(UnknownFunction129(MPPotInUse),UseMPPot) )
	{
		Handle_CP_HP_MP_Update("MP");
	}
	if ( UnknownFunction132(UseCPPot,UseSmallCPPot) )
	{
		Handle_CP_HP_MP_Update("CP");
	}
	if ( UnknownFunction130(UnknownFunction152(ElixirBoxCP.GetItemNum(),0),ElixirUseCPPot) )
	{
		DisablePotions(ElixirBoxCP);
	}
	if ( UnknownFunction130(UnknownFunction152(ElixirBoxHP.GetItemNum(),0),ElixirUseHPPot) )
	{
		DisablePotions(ElixirBoxHP);
	}
	if ( UnknownFunction130(UnknownFunction152(BoxSmallCP.GetItemNum(),0),UseSmallCPPot) )
	{
		DisablePotions(BoxSmallCP);
	}
	if ( UnknownFunction130(UnknownFunction152(BoxCP.GetItemNum(),0),UseCPPot) )
	{
		DisablePotions(BoxCP);
	}
	if ( UnknownFunction130(UnknownFunction152(BoxHP.GetItemNum(),0),UseHPPot) )
	{
		DisablePotions(BoxHP);
	}
	if ( UnknownFunction130(UnknownFunction152(BoxQHP.GetItemNum(),0),UseQHPPot) )
	{
		DisablePotions(BoxQHP);
	}
	if ( UnknownFunction130(UnknownFunction152(BoxMP.GetItemNum(),0),UseMPPot) )
	{
		DisablePotions(BoxMP);
	}
}

function Reset ()
{
	AutoPotionsWnd.KillTimer(10777);
	timerSet = False;
}

function OnEvent (int a_EventID, string a_Param)
{
	switch (a_EventID)
	{
		case 150:
		HandleGamingStateEnter();
		break;
		case 50:
		Reset();
		break;
		case 950:
		HandleBuffs(a_Param);
		break;
		default:
	}
}

function HandleGamingStateEnter ()
{
	Reset();
}

function OnDropItem (string a_WindowID, ItemInfo a_ItemInfo, int X, int Y)
{
	switch (a_WindowID)
	{
		case "ElixirBoxCP":
		InsertElixirCPPotion(a_ItemInfo);
		break;
		case "ElixirBoxHP":
		InsertElixirHPPotion(a_ItemInfo);
		break;
		case "BoxSmallCP":
		InsertSmallCPPotion(a_ItemInfo);
		break;
		case "BoxCP":
		InsertCPPotion(a_ItemInfo);
		break;
		case "BoxHP":
		InsertHPPotion(a_ItemInfo);
		break;
		case "BoxQHP":
		InsertQHPPotion(a_ItemInfo);
		break;
		case "BoxMP":
		InsertMPPotion(a_ItemInfo);
		break;
		default:
	}
}

function RecalculatePotionsCount ()
{
	GetItemInfo(8639,Elixir_CP_Item);
	GetItemInfo(8627,Elixir_HP_Item);
	GetItemInfo(5591,CP_SmallItem);
	GetItemInfo(5592,CP_Item);
	GetItemInfo(6540,CP_Item);
	GetItemInfo(1539,HP_Item);
	GetItemInfo(1540,QHP_Item);
	GetItemInfo(728,MP_Item);
	GetItemInfo(6539,MP_Item);
	SetPotionsCount(ElixirCountCP,ElixirBoxCP,Elixir_CP_Item.ClassID);
	SetPotionsCount(ElixirCountHP,ElixirBoxHP,Elixir_HP_Item.ClassID);
	SetPotionsCount(CountHP,BoxHP,HP_Item.ClassID);
	SetPotionsCount(CountQHP,BoxQHP,QHP_Item.ClassID);
	SetPotionsCount(CountMP,BoxMP,MP_Item.ClassID);
	SetPotionsCount(CountCP,BoxCP,CP_Item.ClassID);
	SetPotionsCount(CountSmallCP,BoxSmallCP,CP_SmallItem.ClassID);
}

function InsertElixirCPPotion (ItemInfo a_ItemInfo)
{
	if ( UnknownFunction155(a_ItemInfo.ClassID,8639) )
	{
		AddSystemMessage(SetText("Remain",Elixir_CP_Item),SetColor("System"));
		return;
	}
	ElixirBoxCP.Clear();
	Elixir_CP_Item = a_ItemInfo;
	ElixirBoxCP.AddItem(a_ItemInfo);
	ElixirCountCP.ShowWindow();
	SetPotionsCount(ElixirCountCP,ElixirBoxCP,8639);
}

function InsertElixirHPPotion (ItemInfo a_ItemInfo)
{
	if ( UnknownFunction155(a_ItemInfo.ClassID,8627) )
	{
		AddSystemMessage(SetText("Remain",Elixir_HP_Item),SetColor("System"));
		return;
	}
	ElixirBoxHP.Clear();
	Elixir_HP_Item = a_ItemInfo;
	ElixirBoxHP.AddItem(a_ItemInfo);
	ElixirCountHP.ShowWindow();
	SetPotionsCount(ElixirCountHP,ElixirBoxHP,8627);
}

function InsertCPPotion (ItemInfo a_ItemInfo)
{
	if ( UnknownFunction130(UnknownFunction155(a_ItemInfo.ClassID,5592),UnknownFunction155(a_ItemInfo.ClassID,6540)) )
	{
		AddSystemMessage(SetText("Remain",CP_Item),SetColor("System"));
		return;
	}
	BoxCP.Clear();
	CP_Item = a_ItemInfo;
	BoxCP.AddItem(a_ItemInfo);
	CountCP.ShowWindow();
	SetPotionsCount(CountCP,BoxCP,a_ItemInfo.ClassID);
}

function InsertSmallCPPotion (ItemInfo a_ItemInfo)
{
	if ( UnknownFunction155(a_ItemInfo.ClassID,5591) )
	{
		AddSystemMessage(SetText("Remain",CP_SmallItem),SetColor("System"));
		return;
	}
	BoxSmallCP.Clear();
	CP_SmallItem = a_ItemInfo;
	BoxSmallCP.AddItem(a_ItemInfo);
	CountSmallCP.ShowWindow();
	SetPotionsCount(CountSmallCP,BoxSmallCP,a_ItemInfo.ClassID);
}

function InsertHPPotion (ItemInfo a_ItemInfo)
{
	if ( UnknownFunction155(a_ItemInfo.ClassID,1539) )
	{
		AddSystemMessage(SetText("Remain",HP_Item),SetColor("System"));
		return;
	}
	BoxHP.Clear();
	HP_Item = a_ItemInfo;
	BoxHP.AddItem(a_ItemInfo);
	CountHP.ShowWindow();
	SetOptionInt("Potions","Type_HP",HP_Item.ClassID);
	SetPotionsCount(CountHP,BoxHP,HP_Item.ClassID);
}

function InsertQHPPotion (ItemInfo a_ItemInfo)
{
	if ( UnknownFunction155(a_ItemInfo.ClassID,1540) )
	{
		AddSystemMessage(SetText("Remain",QHP_Item),SetColor("System"));
		return;
	}
	BoxQHP.Clear();
	QHP_Item = a_ItemInfo;
	BoxQHP.AddItem(a_ItemInfo);
	CountQHP.ShowWindow();
	SetOptionInt("Potions","Type_QHP",QHP_Item.ClassID);
	SetPotionsCount(CountQHP,BoxQHP,QHP_Item.ClassID);
}

function InsertMPPotion (ItemInfo a_ItemInfo)
{
	if ( UnknownFunction130(UnknownFunction155(a_ItemInfo.ClassID,728),UnknownFunction155(a_ItemInfo.ClassID,6539)) )
	{
		AddSystemMessage(SetText("Remain",MP_Item),SetColor("System"));
		return;
	}
	BoxMP.Clear();
	MP_Item = a_ItemInfo;
	BoxMP.AddItem(a_ItemInfo);
	CountMP.ShowWindow();
	SetPotionsCount(CountMP,BoxMP,a_ItemInfo.ClassID);
}

function SetPotionsCount (TextBoxHandle Text, ItemWindowHandle item, int Id)
{
	local int Index;
	local ItemInfo a_ItemInfo;

	Index = InventoryItem.FindItemWithClassID(Id);
	InventoryItem.GetItem(Index,a_ItemInfo);
	if ( UnknownFunction151(Index,-1) )
	{
		if ( UnknownFunction151(a_ItemInfo.ItemNum,99) )
		{
			Text.SetText("99+");
		} else {
			Text.SetText(string(a_ItemInfo.ItemNum));
		}
	} else {
		Text.SetText("");
		item.Clear();
	}
}

function OnClickItem (string strID, int Index)
{
	if ( UnknownFunction130(UnknownFunction122(strID,"ElixirBoxCP"),UnknownFunction151(Index,-1)) )
	{
		if ( UnknownFunction129(ElixirUseCPPot) )
		{
			EnablePotions(ElixirBoxCP);
		} else {
			DisablePotions(ElixirBoxCP);
		}
	}
	if ( UnknownFunction130(UnknownFunction122(strID,"ElixirBoxHP"),UnknownFunction151(Index,-1)) )
	{
		if ( UnknownFunction129(ElixirUseHPPot) )
		{
			EnablePotions(ElixirBoxHP);
		} else {
			DisablePotions(ElixirBoxHP);
		}
	}
	if ( UnknownFunction130(UnknownFunction122(strID,"BoxSmallCP"),UnknownFunction151(Index,-1)) )
	{
		if ( UnknownFunction129(UseSmallCPPot) )
		{
			EnablePotions(BoxSmallCP);
		} else {
			DisablePotions(BoxSmallCP);
		}
	}
	if ( UnknownFunction130(UnknownFunction122(strID,"BoxCP"),UnknownFunction151(Index,-1)) )
	{
		if ( UnknownFunction129(UseCPPot) )
		{
			EnablePotions(BoxCP);
		} else {
			DisablePotions(BoxCP);
		}
	}
	if ( UnknownFunction130(UnknownFunction122(strID,"BoxHP"),UnknownFunction151(Index,-1)) )
	{
		if ( UnknownFunction129(UseHPPot) )
		{
			EnablePotions(BoxHP);
		} else {
			DisablePotions(BoxHP);
		}
	}
	if ( UnknownFunction130(UnknownFunction122(strID,"BoxQHP"),UnknownFunction151(Index,-1)) )
	{
		if ( UnknownFunction129(UseQHPPot) )
		{
			EnablePotions(BoxQHP);
		} else {
			DisablePotions(BoxQHP);
		}
	}
	if ( UnknownFunction130(UnknownFunction122(strID,"BoxMP"),UnknownFunction151(Index,-1)) )
	{
		if ( UnknownFunction129(UseMPPot) )
		{
			EnablePotions(BoxMP);
		} else {
			DisablePotions(BoxMP);
		}
	}
}

function DisablePotions (ItemWindowHandle ItemWnd)
{
	switch (ItemWnd)
	{
		case ElixirBoxCP:
		ElixirToggleCP.HideWindow();
		ElixirUseCPPot = False;
		AddSystemMessage(SetText("Deactivate",Elixir_CP_Item),SetColor("System"));
		break;
		case ElixirBoxHP:
		ElixirToggleHP.HideWindow();
		ElixirUseHPPot = False;
		AddSystemMessage(SetText("Deactivate",Elixir_HP_Item),SetColor("System"));
		break;
		case BoxSmallCP:
		ToggleSmallCP.HideWindow();
		UseSmallCPPot = False;
		AddSystemMessage(SetText("Deactivate",CP_SmallItem),SetColor("System"));
		break;
		case BoxCP:
		ToggleCP.HideWindow();
		UseCPPot = False;
		AddSystemMessage(SetText("Deactivate",CP_Item),SetColor("System"));
		break;
		case BoxHP:
		ToggleHP.HideWindow();
		UseHPPot = False;
		AddSystemMessage(SetText("Deactivate",HP_Item),SetColor("System"));
		break;
		case BoxQHP:
		ToggleQHP.HideWindow();
		UseQHPPot = False;
		AddSystemMessage(SetText("Deactivate",QHP_Item),SetColor("System"));
		break;
		case BoxMP:
		ToggleMP.HideWindow();
		UseMPPot = False;
		AddSystemMessage(SetText("Deactivate",MP_Item),SetColor("System"));
		break;
		default:
	}
}

function EnablePotions (ItemWindowHandle ItemWnd)
{
	switch (ItemWnd)
	{
		case ElixirBoxCP:
		ElixirToggleCP.ShowWindow();
		ElixirUseCPPot = True;
		AddSystemMessage(SetText("Activate",Elixir_CP_Item),SetColor("System"));
		break;
		case ElixirBoxHP:
		ElixirToggleHP.ShowWindow();
		ElixirUseHPPot = True;
		AddSystemMessage(SetText("Activate",Elixir_HP_Item),SetColor("System"));
		break;
		case BoxSmallCP:
		ToggleSmallCP.ShowWindow();
		UseSmallCPPot = True;
		AddSystemMessage(SetText("Activate",CP_Item),SetColor("System"));
		break;
		case BoxCP:
		ToggleCP.ShowWindow();
		UseCPPot = True;
		AddSystemMessage(SetText("Activate",CP_Item),SetColor("System"));
		break;
		case BoxHP:
		ToggleHP.ShowWindow();
		UseHPPot = True;
		AddSystemMessage(SetText("Activate",HP_Item),SetColor("System"));
		break;
		case BoxQHP:
		ToggleQHP.ShowWindow();
		UseQHPPot = True;
		AddSystemMessage(SetText("Activate",QHP_Item),SetColor("System"));
		break;
		case BoxMP:
		ToggleMP.ShowWindow();
		UseMPPot = True;
		AddSystemMessage(SetText("Activate",MP_Item),SetColor("System"));
		break;
		default:
	}
}

function string SetText (string param, ItemInfo a_ItemInfo)
{
	local string Text;

	switch (param)
	{
		case "Remain":
		Text = UnknownFunction168("This slot for ",a_ItemInfo.Name);
		break;
		case "Activate":
		Text = MakeFullSystemMsg(GetSystemMessage(1433),a_ItemInfo.Name);
		break;
		case "Deactivate":
		Text = MakeFullSystemMsg(GetSystemMessage(1434),a_ItemInfo.Name);
		break;
		default:
	}
	return Text;
}

function Color SetColor (string m_Color)
{
	local Color msnColor;

	switch (m_Color)
	{
		case "Yellow":
		msnColor.R = 255;
		msnColor.G = 255;
		msnColor.B = 0;
		break;
		case "System":
		msnColor.R = 176;
		msnColor.G = 155;
		msnColor.B = 121;
		break;
		case "Amber":
		msnColor.R = 218;
		msnColor.G = 165;
		msnColor.B = 32;
		break;
		case "White":
		msnColor.R = 255;
		msnColor.G = 255;
		msnColor.B = 255;
		break;
		case "Dim":
		msnColor.R = 177;
		msnColor.G = 173;
		msnColor.B = 172;
		break;
		case "Magenta":
		msnColor.R = 255;
		msnColor.G = 0;
		msnColor.B = 255;
		break;
		default:
	}
	return msnColor;
}

function Handle_CP_HP_MP_Update (string pot)
{
	local UserInfo UserInfo;

	GetPlayerInfo(UserInfo);
	if ( UnknownFunction152(UserInfo.nCurHP,0) )
	{
		return;
	}
	switch (pot)
	{
		case "CP":
		if ( UnknownFunction150(UserInfo.nCurCP,UserInfo.nMaxCP) )
		{
			if ( UnknownFunction129(CPPotInUse) )
			{
				RequestUseItem(CP_Item.ServerID);
				CPPotInUse = True;
				SmallCPPotInUse = False;
			} else {
				RequestUseItem(CP_SmallItem.ServerID);
				CPPotInUse = False;
				SmallCPPotInUse = True;
			}
		}
		break;
		case "HP":
		if ( UnknownFunction150(UserInfo.nCurHP,UnknownFunction147(UserInfo.nMaxHP,200)) )
		{
			RequestUseItem(HP_Item.ServerID);
			HPPotInUse = True;
		}
		break;
		case "MP":
		if ( UnknownFunction150(UserInfo.nCurMP,UnknownFunction147(UserInfo.nMaxMP,300)) )
		{
			RequestUseItem(MP_Item.ServerID);
			MPPotInUse = True;
		}
		default:
	}
}

function HandleBuffs (string param)
{
	local int i;
	local int Max;
	local StatusIconInfo Info;

	hasAcumen = False;
	hasWW = False;
	hasHaste = False;
	hasBlockBuffEffect = False;
	ParseInt(param,"Max",Max);
JL003C:
	i = 0;
	if ( UnknownFunction150(i,Max) )
	{
		ParseInt(param,UnknownFunction112("SkillID_",string(i)),Info.ClassID);
		if ( AcumenBuff(Info.ClassID) )
		{
			hasAcumen = True;
		}
		if ( WindWalkBuff(Info.ClassID) )
		{
			hasWW = True;
		}
		if ( HasteBuff(Info.ClassID) )
		{
			hasHaste = True;
		}
		if ( IsBlockBuffEffect(Info.ClassID) )
		{
			hasBlockBuffEffect = True;
		}
		UnknownFunction165(i);
		goto JL003C;
	}
	AutoPotionsWnd.KillTimer(4443);
	if ( UnknownFunction242(GetOptionBool("Custom","BuffPotions"),True) )
	{
		if ( UnknownFunction132(UnknownFunction132(UnknownFunction130(UnknownFunction129(hasAcumen),HavePotions("Acumen")),UnknownFunction130(UnknownFunction129(hasHaste),HavePotions("Haste"))),UnknownFunction130(UnknownFunction129(hasWW),HavePotions("WindWalk"))) )
		{
			AutoPotionsWnd.SetTimer(4443,15);
		}
	}
}

function TryUsePotions ()
{
	local UserInfo UserInfo;

	GetPlayerInfo(UserInfo);
	if ( UnknownFunction151(UserInfo.nCurHP,0) )
	{
		if ( UnknownFunction130(UnknownFunction130(ImFighter(),hasWW),hasHaste) )
		{
			AutoPotionsWnd.KillTimer(4443);
		} else {
			if ( UnknownFunction130(UnknownFunction130(ImMage(),hasWW),hasAcumen) )
			{
				AutoPotionsWnd.KillTimer(4443);
			} else {
				if ( UnknownFunction129(hasBlockBuffEffect) )
				{
					if ( ImFighter() )
					{
						if ( UnknownFunction130(HavePotions("WindWalk"),UnknownFunction129(hasWW)) )
						{
							RequestUseItem(WindWalkPot.ServerID);
						}
						if ( UnknownFunction130(HavePotions("Haste"),UnknownFunction129(hasHaste)) )
						{
							RequestUseItem(HastePot.ServerID);
						}
					} else {
						if ( ImMage() )
						{
							if ( UnknownFunction130(HavePotions("WindWalk"),UnknownFunction129(hasWW)) )
							{
								RequestUseItem(WindWalkPot.ServerID);
							}
							if ( UnknownFunction130(HavePotions("Acumen"),UnknownFunction129(hasAcumen)) )
							{
								RequestUseItem(AcumenPot.ServerID);
							}
						}
					}
				}
			}
		}
	}
}

function bool HavePotions (string Type)
{
	local bool ResultBool;

	ResultBool = False;
	if ( UnknownFunction122(Type,"Acumen") )
	{
		GetItemInfo(6036,AcumenPot);
		if ( UnknownFunction153(AcumenPot.ItemNum,1) )
		{
			ResultBool = True;
		}
	} else {
		if ( UnknownFunction122(Type,"Haste") )
		{
			GetItemInfo(1375,HastePot);
			if ( UnknownFunction153(HastePot.ItemNum,1) )
			{
				ResultBool = True;
			}
		} else {
			if ( UnknownFunction122(Type,"WindWalk") )
			{
				GetItemInfo(1374,WindWalkPot);
				if ( UnknownFunction153(WindWalkPot.ItemNum,1) )
				{
					ResultBool = True;
				}
			}
		}
	}
	return ResultBool;
}

function bool WindWalkBuff (int Id)
{
	local bool ResultBool;

	ResultBool = False;
	switch (Id)
	{
		case 1204:
		case 1282:
		case 2034:
		ResultBool = True;
		break;
		default:
	}
	return ResultBool;
}

function bool HasteBuff (int Id)
{
	local bool ResultBool;

	ResultBool = False;
	switch (Id)
	{
		case 1086:
		case 1251:
		case 2035:
		ResultBool = True;
		break;
		default:
	}
	return ResultBool;
}

function bool AcumenBuff (int Id)
{
	local bool ResultBool;

	ResultBool = False;
	switch (Id)
	{
		case 1004:
		case 1085:
		case 2169:
		ResultBool = True;
		break;
		default:
	}
	return ResultBool;
}

function bool IsBlockBuffEffect (int Id)
{
	local bool ResultBool;

	ResultBool = False;
	switch (Id)
	{
		case 1418:
		case 1427:
		ResultBool = True;
		break;
		default:
	}
	return ResultBool;
}

function bool ImFighter ()
{
	local bool ResultBool;
	local UserInfo Info;

	GetPlayerInfo(Info);
	ResultBool = False;
	switch (Info.nSubClass)
	{
		case 0:
		case 1:
		case 2:
		case 88:
		case 3:
		case 89:
		case 4:
		case 5:
		case 90:
		case 6:
		case 91:
		case 7:
		case 8:
		case 93:
		case 9:
		case 92:
		case 18:
		case 19:
		case 20:
		case 99:
		case 21:
		case 100:
		case 22:
		case 23:
		case 101:
		case 24:
		case 102:
		case 31:
		case 32:
		case 33:
		case 106:
		case 34:
		case 107:
		case 35:
		case 108:
		case 36:
		case 37:
		case 109:
		case 44:
		case 45:
		case 46:
		case 113:
		case 47:
		case 48:
		case 114:
		case 53:
		case 54:
		case 55:
		case 117:
		case 56:
		case 57:
		case 118:
		ResultBool = True;
		break;
		default:
	}
	return ResultBool;
}

function bool ImMage ()
{
	return UnknownFunction129(ImFighter());
}

