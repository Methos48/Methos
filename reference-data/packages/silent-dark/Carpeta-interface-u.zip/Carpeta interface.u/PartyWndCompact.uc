//================================================================================
// PartyWndCompact.
//================================================================================

class PartyWndCompact extends UICommonAPI;

var bool m_bCompact;
var bool m_bBuff;
var bool m_partyleader;
var int m_arrID[8];
var int m_CurCount;
var int m_CurBf;
var int m_MasterID;
var WindowHandle m_wndTop;
var WindowHandle m_PartyOption;
var WindowHandle m_PartyStatus[8];
var TextureHandle m_ClassIcon[8];
var StatusIconHandle m_StatusIconBuff[8];
var StatusIconHandle m_StatusIconDeBuff[8];
var BarHandle m_BarCP[8];
var BarHandle m_BarHP[8];
var BarHandle m_BarMP[8];
var ButtonHandle btnBuff;
const NPARTYSTATUS_MAXCOUNT= 8;
const NPARTYSTATUS_HEIGHT= 26;
const NSTATUSICON_MAXCOL= 12;

function OnLoad ()
{
	local int idx;

	RegisterEvent(1000);
	RegisterEvent(1140);
	RegisterEvent(1150);
	RegisterEvent(1160);
	RegisterEvent(1170);
	RegisterEvent(1180);
	RegisterEvent(40);
	m_bCompact = False;
	m_bBuff = False;
	m_CurBf = 0;
	m_MasterID = 0;
	m_wndTop = GetHandle("PartyWndCompact");
	m_PartyOption = GetHandle("PartyWndOption");
	idx = 0;
	if ( UnknownFunction150(idx,8) )
	{
		m_PartyStatus[idx] = GetHandle(UnknownFunction112("PartyWndCompact.PartyStatusWnd",string(idx)));
		m_ClassIcon[idx] = TextureHandle(GetHandle(UnknownFunction112(UnknownFunction112("PartyWndCompact.PartyStatusWnd",string(idx)),".ClassIcon")));
		m_StatusIconBuff[idx] = StatusIconHandle(GetHandle(UnknownFunction112(UnknownFunction112("PartyWndCompact.PartyStatusWnd",string(idx)),".StatusIconBuff")));
		m_StatusIconDeBuff[idx] = StatusIconHandle(GetHandle(UnknownFunction112(UnknownFunction112("PartyWndCompact.PartyStatusWnd",string(idx)),".StatusIconDebuff")));
		m_BarCP[idx] = BarHandle(GetHandle(UnknownFunction112(UnknownFunction112("PartyWndCompact.PartyStatusWnd",string(idx)),".barCP")));
		m_BarHP[idx] = BarHandle(GetHandle(UnknownFunction112(UnknownFunction112("PartyWndCompact.PartyStatusWnd",string(idx)),".barHP")));
		m_BarMP[idx] = BarHandle(GetHandle(UnknownFunction112(UnknownFunction112("PartyWndCompact.PartyStatusWnd",string(idx)),".barMP")));
		UnknownFunction165(idx);
		goto JL00A8;
	}
	btnBuff = ButtonHandle(GetHandle("PartyWndCompact.btnBuff"));
	idx = 0;
	if ( UnknownFunction150(idx,8) )
	{
		m_StatusIconBuff[idx].SetAnchor(UnknownFunction112("PartyWndCompact.PartyStatusWnd",string(idx)),"TopRight","TopLeft",1,3);
		m_StatusIconDeBuff[idx].SetAnchor(UnknownFunction112("PartyWndCompact.PartyStatusWnd",string(idx)),"TopRight","TopLeft",1,3);
		UnknownFunction165(idx);
		goto JL02FE;
	}
	m_ClassIcon[0].Move(0,7);
	m_PartyOption.HideWindow();
}

function OnShow ()
{
	SetBuffButtonTooltip();
}

function OnEnterState (name a_PreStateName)
{
	m_bCompact = False;
	m_bBuff = False;
	m_CurBf = 0;
	ResizeWnd();
}

function OnEvent (int Event_ID, string param)
{
	if ( UnknownFunction154(Event_ID,1140) )
	{
		HandlePartyAddParty(param);
	} else {
		if ( UnknownFunction154(Event_ID,1150) )
		{
			HandlePartyUpdateParty(param);
		} else {
			if ( UnknownFunction154(Event_ID,1160) )
			{
				HandlePartyDeleteParty(param);
			} else {
				if ( UnknownFunction154(Event_ID,1170) )
				{
					HandlePartyDeleteAllParty();
				} else {
					if ( UnknownFunction154(Event_ID,1180) )
					{
						HandlePartySpelledList(param);
					} else {
						if ( UnknownFunction154(Event_ID,1000) )
						{
							HandleShowBuffIcon(param);
						} else {
							if ( UnknownFunction154(Event_ID,40) )
							{
								HandleRestart();
							}
						}
					}
				}
			}
		}
	}
}

function HandleRestart ()
{
	Clear();
}

function Clear ()
{
	local int idx;

	idx = 0;
	if ( UnknownFunction150(idx,8) )
	{
		ClearStatus(idx);
		UnknownFunction165(idx);
		goto JL0007;
	}
	m_CurCount = 0;
	ResizeWnd();
}

function ClearStatus (int idx)
{
	m_StatusIconBuff[idx].Clear();
	m_StatusIconDeBuff[idx].Clear();
	m_ClassIcon[idx].SetTexture("");
	UpdateCPBar(idx,0,0);
	UpdateHPBar(idx,0,0);
	UpdateMPBar(idx,0,0);
	m_arrID[idx] = 0;
}

function CopyStatus (int DesIndex, int SrcIndex)
{
	local int MaxValue;
	local int CurValue;
	local int row;
	local int col;
	local int MaxRow;
	local int MaxCol;
	local StatusIconInfo Info;
	local CustomTooltip TooltipInfo;
	local CustomTooltip TooltipInfo2;

	m_arrID[DesIndex] = m_arrID[SrcIndex];
	m_PartyStatus[SrcIndex].GetTooltipCustomType(TooltipInfo);
	m_PartyStatus[DesIndex].SetTooltipCustomType(TooltipInfo);
	m_ClassIcon[DesIndex].SetTexture(m_ClassIcon[SrcIndex].GetTextureName());
	m_ClassIcon[SrcIndex].GetTooltipCustomType(TooltipInfo2);
	m_ClassIcon[DesIndex].SetTooltipCustomType(TooltipInfo2);
	m_BarCP[SrcIndex].GetValue(MaxValue,CurValue);
	m_BarCP[DesIndex].SetValue(MaxValue,CurValue);
	m_BarHP[SrcIndex].GetValue(MaxValue,CurValue);
	m_BarHP[DesIndex].SetValue(MaxValue,CurValue);
	m_BarMP[SrcIndex].GetValue(MaxValue,CurValue);
	m_BarMP[DesIndex].SetValue(MaxValue,CurValue);
	m_StatusIconBuff[DesIndex].Clear();
	MaxRow = m_StatusIconBuff[SrcIndex].GetRowCount();
	row = 0;
	if ( UnknownFunction150(row,MaxRow) )
	{
		m_StatusIconBuff[DesIndex].AddRow();
		MaxCol = m_StatusIconBuff[SrcIndex].GetColCount(row);
		col = 0;
		if ( UnknownFunction150(col,MaxCol) )
		{
			m_StatusIconBuff[SrcIndex].GetItem(row,col,Info);
			m_StatusIconBuff[DesIndex].AddCol(row,Info);
JL019A:
			UnknownFunction165(col);
			goto JL01E5;
		}
		UnknownFunction165(row);
		goto JL019A;
	}
	m_StatusIconDeBuff[DesIndex].Clear();
	MaxRow = m_StatusIconDeBuff[SrcIndex].GetRowCount();
	row = 0;
	if ( UnknownFunction150(row,MaxRow) )
	{
		m_StatusIconDeBuff[DesIndex].AddRow();
		MaxCol = m_StatusIconDeBuff[SrcIndex].GetColCount(row);
		col = 0;
		if ( UnknownFunction150(col,MaxCol) )
		{
			m_StatusIconDeBuff[SrcIndex].GetItem(row,col,Info);
			m_StatusIconDeBuff[DesIndex].AddCol(row,Info);
			UnknownFunction165(col);
			goto JL02CD;
		}
		UnknownFunction165(row);
		goto JL0282;
	}
}

function ResizeWnd ()
{
	local int idx;
	local Rect rectWnd;
	local bool bOption;

	bOption = GetOptionBool("Game","SmallPartyWnd");
	if ( UnknownFunction151(m_CurCount,0) )
	{
		rectWnd = m_wndTop.GetRect();
		m_wndTop.SetWindowSize(rectWnd.nWidth,UnknownFunction144(26,m_CurCount));
		m_wndTop.SetResizeFrameSize(10,UnknownFunction144(26,m_CurCount));
		if ( bOption )
		{
			m_wndTop.ShowWindow();
		} else {
			m_wndTop.HideWindow();
		}
		idx = 0;
		if ( UnknownFunction150(idx,8) )
		{
			if ( UnknownFunction152(idx,UnknownFunction147(m_CurCount,1)) )
			{
				m_PartyStatus[idx].ShowWindow();
			} else {
				m_PartyStatus[idx].HideWindow();
			}
			UnknownFunction165(idx);
			goto JL00AF;
		}
	} else {
		m_wndTop.HideWindow();
	}
}

function int FindPartyID (int Id)
{
	local int idx;

	idx = 0;
	if ( UnknownFunction150(idx,8) )
	{
		if ( UnknownFunction154(m_arrID[idx],Id) )
		{
			return idx;
		}
		UnknownFunction165(idx);
		goto JL0007;
	}
	return -1;
}

function HandlePartyAddParty (string param)
{
	local int Id;

	ParseInt(param,"ID",Id);
	if ( UnknownFunction151(Id,0) )
	{
		UnknownFunction165(m_CurCount);
		ResizeWnd();
		m_arrID[UnknownFunction147(m_CurCount,1)] = Id;
		UpdateStatus(UnknownFunction147(m_CurCount,1),param);
	}
}

function HandlePartyUpdateParty (string param)
{
	local int Id;
	local int idx;

	ParseInt(param,"ID",Id);
	if ( UnknownFunction151(Id,0) )
	{
		idx = FindPartyID(Id);
		UpdateStatus(idx,param);
	}
}

function HandlePartyDeleteParty (string param)
{
	local int Id;
	local int idx;
	local int i;

	ParseInt(param,"ID",Id);
	if ( UnknownFunction151(Id,0) )
	{
		idx = FindPartyID(Id);
		if ( UnknownFunction151(idx,-1) )
		{
			i = idx;
			if ( UnknownFunction150(i,UnknownFunction147(m_CurCount,1)) )
			{
				CopyStatus(i,UnknownFunction146(i,1));
				UnknownFunction165(i);
				goto JL004A;
			}
			ClearStatus(m_CurCount);
			UnknownFunction166(m_CurCount);
			ResizeWnd();
		}
	}
}

function HandlePartyDeleteAllParty ()
{
	Clear();
}

function UpdateStatus (int idx, string param)
{
	local string Name;
	local int Id;
	local int CP;
	local int maxCP;
	local int HP;
	local int maxHP;
	local int MP;
	local int maxMP;
	local int ClassID;
	local int MasterID;
	local CustomTooltip TooltipInfo;
	local CustomTooltip TooltipInfo2;

	if ( UnknownFunction132(UnknownFunction150(idx,0),UnknownFunction153(idx,8)) )
	{
		return;
	}
	ParseString(param,"Name",Name);
	ParseInt(param,"ID",Id);
	ParseInt(param,"CurCP",CP);
	ParseInt(param,"MaxCP",maxCP);
	ParseInt(param,"CurHP",HP);
	ParseInt(param,"MaxHP",maxHP);
	ParseInt(param,"CurMP",MP);
	ParseInt(param,"MaxMP",maxMP);
	ParseInt(param,"ClassID",ClassID);
	if ( ParseInt(param,"MasterID",MasterID) )
	{
		m_MasterID = MasterID;
	}
	TooltipInfo.DrawList.Length = 1;
	TooltipInfo.DrawList[0].eType = 1;
	TooltipInfo.DrawList[0].t_bDrawOneLine = True;
	if ( UnknownFunction130(UnknownFunction151(m_MasterID,0),UnknownFunction154(m_MasterID,Id)) )
	{
		TooltipInfo.DrawList[0].t_strText = UnknownFunction112(UnknownFunction112(UnknownFunction112(Name,"("),GetSystemString(408)),")");
	} else {
		TooltipInfo.DrawList[0].t_strText = Name;
	}
	m_PartyStatus[idx].SetTooltipCustomType(TooltipInfo);
	m_ClassIcon[idx].SetTexture(GetClassIconName(ClassID));
	TooltipInfo2.DrawList.Length = 2;
	TooltipInfo2.DrawList[0].eType = 1;
	TooltipInfo2.DrawList[0].t_bDrawOneLine = True;
	if ( UnknownFunction130(UnknownFunction151(m_MasterID,0),UnknownFunction154(m_MasterID,Id)) )
	{
		TooltipInfo2.DrawList[0].t_strText = UnknownFunction112(UnknownFunction112(UnknownFunction112(Name,"("),GetSystemString(408)),")");
	} else {
		TooltipInfo2.DrawList[0].t_strText = Name;
	}
	TooltipInfo2.DrawList[1].eType = 1;
	TooltipInfo2.DrawList[1].nOffSetY = 2;
	TooltipInfo2.DrawList[1].t_bDrawOneLine = True;
	TooltipInfo2.DrawList[1].bLineBreak = True;
	TooltipInfo2.DrawList[1].t_strText = UnknownFunction112(UnknownFunction112(GetClassStr(ClassID)," - "),GetClassType(ClassID));
	TooltipInfo2.DrawList[1].t_color.R = 128;
	TooltipInfo2.DrawList[1].t_color.G = 128;
	TooltipInfo2.DrawList[1].t_color.B = 128;
	TooltipInfo2.DrawList[1].t_color.A = 255;
	m_ClassIcon[idx].SetTooltipCustomType(TooltipInfo2);
	UpdateCPBar(idx,CP,maxCP);
	UpdateHPBar(idx,HP,maxHP);
	UpdateMPBar(idx,MP,maxMP);
}

function HandlePartySpelledList (string param)
{
	local int i;
	local int idx;
	local int Id;
	local int Max;
	local int BuffCnt;
	local int BuffCurRow;
	local int DeBuffCnt;
	local int DeBuffCurRow;
	local StatusIconInfo Info;

	DeBuffCurRow = -1;
	BuffCurRow = -1;
	ParseInt(param,"ID",Id);
	if ( UnknownFunction150(Id,1) )
	{
		return;
	}
	idx = FindPartyID(Id);
	if ( UnknownFunction150(idx,0) )
	{
		return;
	}
	m_StatusIconBuff[idx].Clear();
	m_StatusIconDeBuff[idx].Clear();
	Info.Size = 10;
	Info.bShow = True;
	ParseInt(param,"Max",Max);
	i = 0;
	if ( UnknownFunction150(i,Max) )
	{
		ParseInt(param,UnknownFunction112("SkillID_",string(i)),Info.ClassID);
		ParseInt(param,UnknownFunction112("Level_",string(i)),Info.Level);
		if ( UnknownFunction151(Info.ClassID,0) )
		{
			Info.IconName = Class'UIDATA_SKILL'.GetIconName(Info.ClassID,Info.Level);
			if ( UnknownFunction242(IsDebuff(Info.ClassID,Info.Level),True) )
			{
				if ( UnknownFunction180(UnknownFunction173(DeBuffCnt,12),0) )
				{
					UnknownFunction165(DeBuffCurRow);
					m_StatusIconDeBuff[idx].AddRow();
				}
				m_StatusIconDeBuff[idx].AddCol(DeBuffCurRow,Info);
				UnknownFunction165(DeBuffCnt);
			} else {
				if ( UnknownFunction180(UnknownFunction173(BuffCnt,12),0) )
				{
					UnknownFunction165(BuffCurRow);
					m_StatusIconBuff[idx].AddRow();
				}
				m_StatusIconBuff[idx].AddCol(BuffCurRow,Info);
				UnknownFunction165(BuffCnt);
			}
		}
		UnknownFunction165(i);
		goto JL00B5;
	}
	UpdateBuff();
}

function HandleShowBuffIcon (string param)
{
	local int nShow;

	ParseInt(param,"Show",nShow);
	m_CurBf = UnknownFunction146(m_CurBf,1);
	if ( UnknownFunction151(m_CurBf,2) )
	{
		m_CurBf = 0;
	}
	SetBuffButtonTooltip();
	switch (m_CurBf)
	{
		case 1:
		UpdateBuff();
		break;
		case 2:
		UpdateBuff();
		break;
		case 0:
		m_CurBf = 0;
		UpdateBuff();
		default:
	}
}

function OnClickButton (string strID)
{
	local PartyWnd script;

	script = PartyWnd(GetScript("PartyWnd"));
	switch (strID)
	{
		case "btnBuff":
		OnBuffButton();
		script.OnBuffButton();
		break;
		case "btnOption":
		OnOpenPartyWndOption();
		default:
	}
}

function OnOpenPartyWndOption ()
{
	local PartyWndOption script;

	script = PartyWndOption(GetScript("PartyWndOption"));
	script.ShowPartyWndOption();
	m_PartyOption.SetAnchor("PartyWndCompact.PartyStatusWnd0","TopRight","TopLeft",5,5);
}

function OnBuffButton ()
{
	m_CurBf = UnknownFunction146(m_CurBf,1);
	if ( UnknownFunction151(m_CurBf,2) )
	{
		m_CurBf = 0;
	}
	SetBuffButtonTooltip();
	UpdateBuff();
}

function UpdateBuff ()
{
	local int idx;

	if ( UnknownFunction154(m_CurBf,1) )
	{
		idx = 0;
		if ( UnknownFunction150(idx,8) )
		{
			m_StatusIconBuff[idx].ShowWindow();
			m_StatusIconDeBuff[idx].HideWindow();
			UnknownFunction165(idx);
			goto JL0012;
		}
	} else {
		if ( UnknownFunction154(m_CurBf,2) )
		{
			idx = 0;
			if ( UnknownFunction150(idx,8) )
			{
				m_StatusIconBuff[idx].HideWindow();
				m_StatusIconDeBuff[idx].ShowWindow();
				UnknownFunction165(idx);
				goto JL0068;
			}
		} else {
			idx = 0;
			if ( UnknownFunction150(idx,8) )
			{
				m_StatusIconBuff[idx].HideWindow();
JL00B2:
				m_StatusIconDeBuff[idx].HideWindow();
				UnknownFunction165(idx);
				goto JL00B2;
			}
		}
	}
}

function UpdateCPBar (int idx, int Value, int MaxValue)
{
	m_BarCP[idx].SetValue(MaxValue,Value);
}

function UpdateHPBar (int idx, int Value, int MaxValue)
{
	m_BarHP[idx].SetValue(MaxValue,Value);
}

function UpdateMPBar (int idx, int Value, int MaxValue)
{
	m_BarMP[idx].SetValue(MaxValue,Value);
}

function OnLButtonDown (WindowHandle a_WindowHandle, int X, int Y)
{
	local Rect rectWnd;
	local int idx;

	rectWnd = m_wndTop.GetRect();
	if ( UnknownFunction151(X,UnknownFunction146(rectWnd.nX,30)) )
	{
		idx = UnknownFunction145(UnknownFunction147(Y,rectWnd.nY),26);
		RequestTargetUser(m_arrID[idx]);
	}
}

function OnRButtonUp (int X, int Y)
{
	local Rect rectWnd;
	local UserInfo UserInfo;
	local int idx;

	rectWnd = m_wndTop.GetRect();
	if ( UnknownFunction151(X,UnknownFunction146(rectWnd.nX,30)) )
	{
		if ( GetPlayerInfo(UserInfo) )
		{
			idx = UnknownFunction145(UnknownFunction147(Y,rectWnd.nY),26);
			RequestAssist(m_arrID[idx],UserInfo.loc);
		}
	}
}

function SetBuffButtonTooltip ()
{
	local int idx;

	switch (m_CurBf)
	{
		case 0:
		idx = 1496;
		break;
		case 1:
		idx = 1497;
		break;
		case 2:
		idx = 1498;
		break;
		default:
	}
	btnBuff.SetTooltipCustomType(MakeTooltipSimpleText(GetSystemString(idx)));
}

