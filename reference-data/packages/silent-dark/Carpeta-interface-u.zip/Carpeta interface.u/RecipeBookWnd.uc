//================================================================================
// RecipeBookWnd.
//================================================================================

class RecipeBookWnd extends UICommonAPI;

var int m_ItemCount;
var array<int> m_arrItem;
var int m_BookType;
var int m_ItemMaxCount_Dwarf;
var int m_ItemMaxCount_Normal;
var int m_DeleteItemID;

function OnLoad ()
{
	RegisterEvent(820);
	RegisterEvent(830);
	RegisterEvent(2070);
	RegisterEvent(1710);
}

function OnEvent (int Event_ID, string param)
{
	local Rect rectWnd;
	local int RecipeAddBookItem;

	if ( UnknownFunction154(Event_ID,820) )
	{
		Clear();
		rectWnd = Class'UIAPI_WINDOW'.GetRect("RecipeManufactureWnd");
		Class'UIAPI_WINDOW'.MoveTo("RecipeBookWnd",rectWnd.nX,rectWnd.nY);
		Class'UIAPI_WINDOW'.ShowWindow("RecipeBookWnd");
		Class'UIAPI_WINDOW'.SetFocus("RecipeBookWnd");
		ParseInt(param,"Type",m_BookType);
		if ( UnknownFunction154(m_BookType,1) )
		{
			Class'UIAPI_WINDOW'.SetWindowTitle("RecipeBookWnd",1214);
		} else {
			Class'UIAPI_WINDOW'.SetWindowTitle("RecipeBookWnd",1215);
		}
	} else {
		if ( UnknownFunction154(Event_ID,830) )
		{
			ParseInt(param,"RecipeID",RecipeAddBookItem);
			AddRecipeBookItem(RecipeAddBookItem);
		} else {
			if ( UnknownFunction154(Event_ID,2070) )
			{
				ParseInt(param,"recipe",m_ItemMaxCount_Normal);
				ParseInt(param,"dwarvenRecipe",m_ItemMaxCount_Dwarf);
				SetItemCount(m_ItemCount);
			} else {
				if ( UnknownFunction154(Event_ID,1710) )
				{
					if ( DialogIsMine() )
					{
						Class'RecipeAPI'.RequestRecipeItemDelete(m_DeleteItemID);
					}
				}
			}
		}
	}
}

function OnDBClickItem (string strID, int Index)
{
	if ( UnknownFunction130(UnknownFunction122(strID,"RecipeItem"),UnknownFunction151(m_ItemCount,Index)) )
	{
		Class'RecipeAPI'.RequestRecipeItemMakeInfo(m_arrItem[Index]);
	}
}

function OnDropItem (string strID, ItemInfo infItem, int X, int Y)
{
	if ( UnknownFunction122(strID,"btnTrash") )
	{
		DeleteItem(infItem);
	}
}

function OnClickButton (string strID)
{
	local ItemInfo infItem;

	switch (strID)
	{
		case "btnTrash":
		if ( Class'UIAPI_ITEMWINDOW'.GetSelectedItem("RecipeBookWnd.RecipeItem",infItem) )
		{
			DeleteItem(infItem);
		}
		break;
		default:
	}
}

function Clear ()
{
	SetItemCount(0);
	m_arrItem.Remove (0,m_arrItem.Length);
	Class'UIAPI_ITEMWINDOW'.Clear("RecipeBookWnd.RecipeItem");
}

function AddRecipeBookItem (int RecipeID)
{
	local ItemInfo infItem;
	local int ProductID;
	local int Index;

	ProductID = Class'UIDATA_RECIPE'.GetRecipeProductID(RecipeID);
	Index = Class'UIDATA_RECIPE'.GetRecipeIndex(RecipeID);
	infItem.ClassID = Class'UIDATA_RECIPE'.GetRecipeClassID(RecipeID);
	infItem.Level = Class'UIDATA_RECIPE'.GetRecipeLevel(RecipeID);
	infItem.ServerID = Class'UIDATA_RECIPE'.GetRecipeIndex(RecipeID);
	infItem.ItemSubType = 5;
	infItem.Name = Class'UIDATA_ITEM'.GetItemName(infItem.ClassID);
	infItem.Description = Class'UIDATA_ITEM'.GetItemDescription(infItem.ClassID);
	infItem.Weight = Class'UIDATA_ITEM'.GetItemWeight(infItem.ClassID);
	infItem.IconName = Class'UIDATA_ITEM'.GetItemTextureName(ProductID);
	infItem.CrystalType = Class'UIDATA_RECIPE'.GetRecipeCrystalType(RecipeID);
	Class'UIAPI_ITEMWINDOW'.AddItem("RecipeBookWnd.RecipeItem",infItem);
	byte(m_arrItem)
	m_arrItem.Length
	1
	m_arrItem[UnknownFunction147(m_arrItem.Length,1)] = Index;
	UnknownFunction165(m_ItemCount);
	SetItemCount(m_ItemCount);
}

function SetItemCount (int MaxCount)
{
	local int nTmp;

	m_ItemCount = MaxCount;
	if ( UnknownFunction154(m_BookType,1) )
	{
		nTmp = m_ItemMaxCount_Normal;
	} else {
		nTmp = m_ItemMaxCount_Dwarf;
	}
	Class'UIAPI_TEXTBOX'.SetText("RecipeBookWnd.txtCount",UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112("(",string(m_ItemCount)),"/"),string(nTmp)),")"));
}

function DeleteItem (ItemInfo infItem)
{
	local string strMsg;

	strMsg = MakeFullSystemMsg(GetSystemMessage(74),infItem.Name,"");
	m_DeleteItemID = infItem.ServerID;
	DialogShow(4,strMsg);
}

