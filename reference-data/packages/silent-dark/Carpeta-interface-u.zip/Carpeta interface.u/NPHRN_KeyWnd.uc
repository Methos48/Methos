//================================================================================
// NPHRN_KeyWnd.
//================================================================================

class NPHRN_KeyWnd extends UICommonAPI;

var WindowHandle Me;
var Shortcut script;
var CheckBoxHandle Cb_UseNumpad;
var CheckBoxHandle Cb_UseFPad;
var CheckBoxHandle Cb_UseQwerty;
var CheckBoxHandle Cb_ChatEnter;
var ComboBoxHandle ComboPanel1;
var ComboBoxHandle ComboPanel2;
var ComboBoxHandle ComboPanel3;
var TextBoxHandle Tooltip_ChatEnter;
var TextBoxHandle Tooltip_UseNumpad;
var TextBoxHandle Tooltip_UseFPad;
var TextBoxHandle Tooltip_UseQwerty;

function OnLoad ()
{
	InitHandle();
	InitWindows();
}

function InitHandle ()
{
	Me = GetHandle("NPHRN_KeyWnd");
	script = Shortcut(GetScript("Shortcut"));
	Cb_UseNumpad = CheckBoxHandle(GetHandle("NPHRN_KeyWnd.Cb_UseNumpad"));
	Cb_UseFPad = CheckBoxHandle(GetHandle("NPHRN_KeyWnd.Cb_UseFPad"));
	Cb_UseQwerty = CheckBoxHandle(GetHandle("NPHRN_KeyWnd.Cb_UseQwerty"));
	Cb_ChatEnter = CheckBoxHandle(GetHandle("NPHRN_KeyWnd.Cb_ChatEnter"));
	ComboPanel1 = ComboBoxHandle(GetHandle("NPHRN_KeyWnd.ComboPanel1"));
	ComboPanel2 = ComboBoxHandle(GetHandle("NPHRN_KeyWnd.ComboPanel2"));
	ComboPanel3 = ComboBoxHandle(GetHandle("NPHRN_KeyWnd.ComboPanel3"));
	Tooltip_ChatEnter = TextBoxHandle(GetHandle("NPHRN_BeltWnd.Tooltip_ChatEnter"));
	Tooltip_UseNumpad = TextBoxHandle(GetHandle("NPHRN_BeltWnd.Tooltip_UseNumpad"));
	Tooltip_UseFPad = TextBoxHandle(GetHandle("NPHRN_BeltWnd.Tooltip_UseFPad"));
	Tooltip_UseQwerty = TextBoxHandle(GetHandle("NPHRN_BeltWnd.Tooltip_UseQwerty"));
}

function InitWindows ()
{
	if ( IntLessOrEqual(GetOptionInt("Key","Panel1"),0) )
	{
		SetOptionInt("Key","Panel1",1);
	}
	if ( IntLessOrEqual(GetOptionInt("Key","Panel2"),0) )
	{
		SetOptionInt("Key","Panel2",1);
	}
	if ( IntLessOrEqual(GetOptionInt("Key","Panel3"),0) )
	{
		SetOptionInt("Key","Panel3",1);
	}
	Cb_ChatEnter.SetTitle("Enter Chat");
	Cb_UseNumpad.SetTitle("Numpad");
	Cb_UseQwerty.SetTitle("Qwerty");
	Cb_UseFPad.SetTitle("F-Pad");
	Tooltip_ChatEnter.SetTooltipString("Enable Enter Chat to use binded shortcuts.");
	Tooltip_UseNumpad.SetTooltipString("Keys: 1, 2, 3 Etc");
	Tooltip_UseFPad.SetTooltipString("Keys: F1, F2, F3 Etc");
	Tooltip_UseQwerty.SetTooltipString("Keys: Q, W, E, Etc");
	Cb_ChatEnter.SetCheck(GetOptionBool("Game","EnterChatting"));
	Cb_UseNumpad.SetCheck(GetOptionBool("Key","UseNumpad"));
	Cb_UseFPad.SetCheck(GetOptionBool("Key","UseFPad"));
	Cb_UseQwerty.SetCheck(GetOptionBool("Key","UseQwerty"));
	ComboPanel1.SetSelectedNum(IntSub(GetOptionInt("Key","Panel1"),1));
	ComboPanel2.SetSelectedNum(IntSub(GetOptionInt("Key","Panel2"),1));
	ComboPanel3.SetSelectedNum(IntSub(GetOptionInt("Key","Panel3"),1));
}

function OnClickButton (string strID)
{
	switch (strID)
	{
		case "BtnApply":
		OnClickApply();
		break;
		case "BtnClose":
		Me.HideWindow();
		break;
		default:
	}
}

function OnClickApply ()
{
	SetOptionInt("Key","Panel1",DoAdd(ComboPanel1.GetSelectedNum(),1));
	SetOptionInt("Key","Panel2",DoAdd(ComboPanel2.GetSelectedNum(),1));
	SetOptionInt("Key","Panel3",DoAdd(ComboPanel3.GetSelectedNum(),1));
	script.LoadData();
}

function OnClickCheckBox (string strID)
{
	switch (strID)
	{
		case "Cb_ChatEnter":
		if ( Cb_ChatEnter.IsChecked() )
		{
			SetOptionBool("Game","EnterChatting",True);
		} else {
			SetOptionBool("Game","EnterChatting",False);
		}
		break;
		case "Cb_UseNumpad":
		if ( Cb_UseNumpad.IsChecked() )
		{
			SetOptionBool("Key","UseNumpad",True);
		} else {
			SetOptionBool("Key","UseNumpad",False);
		}
		break;
		case "Cb_UseFPad":
		if ( Cb_UseFPad.IsChecked() )
		{
			SetOptionBool("Key","UseFPad",True);
		} else {
			SetOptionBool("Key","UseFPad",False);
		}
		break;
		case "Cb_UseQwerty":
		if ( Cb_UseQwerty.IsChecked() )
		{
			SetOptionBool("Key","UseQwerty",True);
		} else {
			SetOptionBool("Key","UseQwerty",False);
		}
		break;
		default:
	}
}

