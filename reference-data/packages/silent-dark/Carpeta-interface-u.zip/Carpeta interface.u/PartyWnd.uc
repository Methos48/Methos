//================================================================================
// PartyWnd.
//================================================================================

class PartyWnd extends UICommonAPI;

var bool m_bCompact;
var bool m_bBuff;
var int m_arrID[9];
var int m_CurCount;
var int m_CurBf;
var bool is_Nobless;
var WindowHandle m_wndTop;
var WindowHandle m_PartyStatus[9];
var WindowHandle m_PartyOption;
var NameCtrlHandle m_PlayerName[9];
var TextureHandle m_ClassIcon[9];
var TextureHandle m_ClassIconCustom[9];
var TextureHandle m_LeaderIcon[9];
var StatusIconHandle m_StatusIconBuff[9];
var StatusIconHandle m_StatusIconDeBuff[9];
var StatusIconHandle m_StatusNoblessBuff[9];
var BarHandle m_BarCP[9];
var BarHandle m_BarHP[9];
var BarHandle m_BarMP[9];
var ButtonHandle btnBuff;
var Color LeaderNameColor;
var Color AssistNameColor_1;
var Color AssistNameColor_2;
var int isLeader[10];
var string RoutingTypeString;
var bool b_AutoAssistEnabled;
var string s_AssistName_1;
var string s_AssistName_2;
var int i_AssistIndex_1;
var int i_AssistIndex_2;
var ComboBoxHandle m_cb1stAssist;
var ComboBoxHandle m_cb2ndAssist;
var ButtonHandle btnAssist;
var string ParamSpelledList[9];
var int checkPriorDebuffSameRow;
var bool checkPrior;
var array<int> a_UnkArrayInt1;
var int i_UnkInt_1;
const NPARTYSTATUS_MAXCOUNT= 8;
const NPARTYSTATUS_HEIGHT= 46;
const NSTATUSICON_MAXCOL= 18;

function OnLoad ()
{
	local int idx;

	RegisterEvent(950);
	RegisterEvent(1000);
	RegisterEvent(4445);
	RegisterEvent(1140);
	RegisterEvent(1150);
	RegisterEvent(1160);
	RegisterEvent(1170);
	RegisterEvent(1180);
	RegisterEvent(90);
	RegisterEvent(40);
	is_Nobless = False;
	m_bCompact = False;
	m_bBuff = False;
	m_CurBf = 0;
	m_wndTop = GetHandle("PartyWnd");
	m_PartyOption = GetHandle("PartyWndOption");
	idx = 0;
	if ( UnknownFunction150(idx,9) )
	{
		m_PartyStatus[idx] = GetHandle(UnknownFunction112("PartyWnd.PartyStatusWnd",string(idx)));
		m_PlayerName[idx] = NameCtrlHandle(GetHandle(UnknownFunction112(UnknownFunction112("PartyWnd.PartyStatusWnd",string(idx)),".PlayerName")));
		m_ClassIcon[idx] = TextureHandle(GetHandle(UnknownFunction112(UnknownFunction112("PartyWnd.PartyStatusWnd",string(idx)),".ClassIcon")));
		m_ClassIconCustom[idx] = TextureHandle(GetHandle(UnknownFunction112(UnknownFunction112("PartyWnd.PartyStatusWnd",string(idx)),".ClassIconCustom")));
		m_LeaderIcon[idx] = TextureHandle(GetHandle(UnknownFunction112(UnknownFunction112("PartyWnd.PartyStatusWnd",string(idx)),".LeaderIcon")));
		m_StatusIconBuff[idx] = StatusIconHandle(GetHandle(UnknownFunction112(UnknownFunction112("PartyWnd.PartyStatusWnd",string(idx)),".StatusIconBuff")));
		m_StatusIconDeBuff[idx] = StatusIconHandle(GetHandle(UnknownFunction112(UnknownFunction112("PartyWnd.PartyStatusWnd",string(idx)),".StatusIconDebuff")));
		m_StatusNoblessBuff[idx] = StatusIconHandle(GetHandle(UnknownFunction112(UnknownFunction112("PartyWnd.PartyStatusWnd",string(idx)),".StatusNoblessBuff")));
		m_BarCP[idx] = BarHandle(GetHandle(UnknownFunction112(UnknownFunction112("PartyWnd.PartyStatusWnd",string(idx)),".barCP")));
		m_BarHP[idx] = BarHandle(GetHandle(UnknownFunction112(UnknownFunction112("PartyWnd.PartyStatusWnd",string(idx)),".barHP")));
		m_BarMP[idx] = BarHandle(GetHandle(UnknownFunction112(UnknownFunction112("PartyWnd.PartyStatusWnd",string(idx)),".barMP")));
		UnknownFunction165(idx);
		goto JL00C0;
	}
	btnBuff = ButtonHandle(GetHandle("PartyWnd.btnBuff"));
	idx = 0;
	if ( UnknownFunction150(idx,8) )
	{
		m_StatusIconBuff[idx].SetAnchor(UnknownFunction112("PartyWnd.PartyStatusWnd",string(idx)),"TopRight","TopLeft",-3,1);
		m_StatusIconDeBuff[idx].SetAnchor(UnknownFunction112("PartyWnd.PartyStatusWnd",string(idx)),"TopRight","TopLeft",-3,3);
		m_StatusNoblessBuff[idx].SetAnchor(UnknownFunction112("PartyWnd.PartyStatusWnd",string(idx)),"TopRight","TopRight",-11,2);
		m_PlayerName[idx].SetAnchor(UnknownFunction112(UnknownFunction112("PartyWnd.PartyStatusWnd",string(idx)),".ClassIcon"),"TopLeft","TopLeft",16,1);
		m_ClassIconCustom[idx].SetAnchor(UnknownFunction112("PartyWnd.PartyStatusWnd",string(idx)),"TopRight","TopRight",-11,1);
		UnknownFunction165(idx);
		goto JL040A;
	}
	m_PartyOption.HideWindow();
	LeaderNameColor.R = 0;
	LeaderNameColor.G = 153;
	LeaderNameColor.B = 255;
	LeaderNameColor.A = 255;
	AssistNameColor_1.R = 255;
	AssistNameColor_1.G = 51;
	AssistNameColor_1.B = 51;
	AssistNameColor_1.A = 255;
	AssistNameColor_2.R = 0;
	AssistNameColor_2.G = 255;
	AssistNameColor_2.B = 0;
	AssistNameColor_2.A = 255;
	m_cb1stAssist = ComboBoxHandle(GetHandle("PartyWnd.AssistWnd.cb1stAssist"));
	m_cb2ndAssist = ComboBoxHandle(GetHandle("PartyWnd.AssistWnd.cb2ndAssist"));
	btnAssist = ButtonHandle(GetHandle("PartyWnd.AssistWnd.btnAssist"));
	s_AssistName_1 = "";
	s_AssistName_2 = "";
	DisableAutoAssist();
	btnAssist.SetTooltipCustomType(SetTooltip("Auto Assist (Space)"));
	checkPrior = GetOptionBool("Custom","checkPrior");
}

function OnShow ()
{
	ResizeWnd();
	UpdateAndSetAssistIndex();
	SetBuffButtonTooltip();
	if ( GetOptionBool("Custom","HideAssist") )
	{
		HideWindow("PartyWnd.AssistWnd");
	} else {
		ShowWindow("PartyWnd.AssistWnd");
	}
}

function OnHide ()
{
	HideWindow("PartyWnd.AssistWnd");
}

function OnEnterState (name a_PreStateName)
{
	m_bCompact = False;
	m_bBuff = False;
	m_CurBf = 0;
	ResizeWnd();
}

function OnEvent (int Event_ID, string param)
{
	local int idx;

	if ( UnknownFunction154(Event_ID,950) )
	{
		HandleAddNormalStatus(param);
	} else {
		if ( UnknownFunction154(Event_ID,1140) )
		{
			HandlePartyAddParty(param);
		} else {
			if ( UnknownFunction154(Event_ID,1150) )
			{
				HandlePartyUpdateParty(param);
			} else {
				if ( UnknownFunction154(Event_ID,1160) )
				{
					HandlePartyDeleteParty(param);
				} else {
					if ( UnknownFunction154(Event_ID,1170) )
					{
						HandlePartyDeleteAllParty();
					} else {
						if ( UnknownFunction154(Event_ID,1180) )
						{
							idx = HandlePartySpelledList(param);
							if ( UnknownFunction151(idx,-1) )
							{
								ParamSpelledList[idx] = param;
							}
						} else {
							if ( UnknownFunction154(Event_ID,1000) )
							{
								HandleShowBuffIcon(param);
							} else {
								if ( UnknownFunction154(Event_ID,40) )
								{
									HandleRestart();
									DisableAutoAssist();
								} else {
									if ( UnknownFunction154(Event_ID,90) )
									{
										HandleShortcutCommand(param);
									} else {
										if ( UnknownFunction154(Event_ID,4445) )
										{
											checkPrior = GetOptionBool("Custom","checkPrior");
											checkPriorDebuffSameRow = GetOptionBool("Custom","checkPriorDebuffSameRow").Remove (UpdateAndSetAssistIndex(),ReHandlePartySpelledList());;
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
}

function HandleAddNormalStatus (string param)
{
	local int i;
	local int Max;
	local StatusIconInfo Info;

	is_Nobless = False;
	ParseInt(param,"Max",Max);
	i = 0;
	if ( UnknownFunction150(i,Max) )
	{
		ParseInt(param,UnknownFunction112("SkillID_",string(i)),Info.ClassID);
		if ( UnknownFunction154(Info.ClassID,1323) )
		{
			is_Nobless = True;
		} else {
			UnknownFunction165(i);
			goto JL0024;
		}
	}
}

function OnTimer (int TimerID)
{
	local UserInfo StatusInfo;
	local bool inTimerBool;

	if ( UnknownFunction154(TimerID,4440) )
	{
		if ( b_AutoAssistEnabled )
		{
			SetAssistIndex();
			SetPartyMembersColors();
			if ( UnknownFunction130(UnknownFunction154(i_AssistIndex_1,-1),UnknownFunction154(i_AssistIndex_2,-1)) )
			{
				DisableAutoAssist();
			} else {
				inTimerBool = True;
				if ( UnknownFunction151(i_AssistIndex_1,-1) )
				{
					GetUserInfo(m_arrID[i_AssistIndex_1],StatusInfo);
					if ( UnknownFunction130(isNotMemberDead(i_AssistIndex_1),InRange(StatusInfo.loc,2000)) )
					{
						RequestAssistFunction(i_AssistIndex_1);
						inTimerBool = False;
					}
				}
				if ( UnknownFunction130(inTimerBool,UnknownFunction151(i_AssistIndex_2,-1)) )
				{
					GetUserInfo(m_arrID[i_AssistIndex_2],StatusInfo);
					RequestAssistFunction(i_AssistIndex_2);
				}
			}
		}
	}
}

function ReHandlePartySpelledList ()
{
	local int A;

	A = 0;
	if ( UnknownFunction150(A,8) )
	{
		HandlePartySpelledList(ParamSpelledList[A]);
		UnknownFunction165(A);
		goto JL0007;
	}
}

function HandleShortcutCommand (string param)
{
	local string Command;

	if ( ParseString(param,"Command",Command) )
	{
		switch (Command)
		{
			case "ChangeAssistStatus":
			HandleChangeAssistStatus();
			break;
			default:
		}
	}
}

function RequestAssistFunction (int Index)
{
	local UserInfo UserInfo;
	local bool if_Nobless;

	if_Nobless = GetOptionBool("Custom","NoblesseAssist");
	GetPlayerInfo(UserInfo);
	if ( UnknownFunction130(UnknownFunction132(UnknownFunction130(is_Nobless,if_Nobless),UnknownFunction129(if_Nobless)),UnknownFunction151(UserInfo.nCurHP,0)) )
	{
		RequestAssist(m_arrID[Index],UserInfo.loc);
	}
}

function HandleUpdateComboBox ()
{
	local int A;

	m_cb1stAssist.Clear();
	m_cb1stAssist.AddString("MA1");
	m_cb2ndAssist.Clear();
	m_cb2ndAssist.AddString("MA2");
	m_cb1stAssist.SetSelectedNum(0);
	m_cb2ndAssist.SetSelectedNum(0);
	A = 0;
	if ( UnknownFunction150(A,m_CurCount) )
	{
		m_cb1stAssist.AddString(GetMemberName(A));
		m_cb2ndAssist.AddString(GetMemberName(A));
		if ( UnknownFunction122(GetMemberName(A),s_AssistName_1) )
		{
			m_cb1stAssist.SetSelectedNum(A);
		}
		if ( UnknownFunction122(GetMemberName(A),s_AssistName_2) )
		{
			m_cb2ndAssist.SetSelectedNum(A);
		}
		UnknownFunction165(A);
		goto JL006D;
	}
}

function OnComboBoxItemSelected (string strID, int Index)
{
	if ( UnknownFunction122(strID,"cb1stAssist") )
	{
		s_AssistName_1 = GetMainAssistName(1);
	} else {
		if ( UnknownFunction122(strID,"cb2ndAssist") )
		{
			s_AssistName_2 = GetMainAssistName(2);
		}
	}
	SetAssistIndex();
	SetPartyMembersColors();
}

function UpdateAndSetAssistIndex ()
{
	HandleUpdateComboBox();
	SetAssistIndex();
	SetPartyMembersColors();
}

function string GetMainAssistName (int Index)
{
	switch (Index)
	{
		case 1:
		return m_cb1stAssist.GetString(GetSelectedNumAssist(1));
		break;
		case 2:
		return m_cb2ndAssist.GetString(GetSelectedNumAssist(2));
		break;
		default:
	}
}

function int GetSelectedNumAssist (int Index)
{
	if ( UnknownFunction154(Index,1) )
	{
		return m_cb1stAssist.GetSelectedNum();
	} else {
		if ( UnknownFunction154(Index,2) )
		{
			return m_cb2ndAssist.GetSelectedNum();
		} else {
			return 0;
		}
	}
}

function SetAssistIndex ()
{
	local int A;

	i_AssistIndex_1 = -1;
	i_AssistIndex_2 = -1;
	if ( UnknownFunction151(GetSelectedNumAssist(1),0) )
	{
		A = 0;
		if ( UnknownFunction150(A,m_CurCount) )
		{
			if ( UnknownFunction122(GetMemberName(A),s_AssistName_1) )
			{
				i_AssistIndex_1 = A;
			} else {
				UnknownFunction165(A);
				goto JL002A;
			}
		}
	}
	if ( UnknownFunction151(GetSelectedNumAssist(2),0) )
	{
		i_AssistIndex_2 = -1;
		A = 0;
		if ( UnknownFunction150(A,m_CurCount) )
		{
			if ( UnknownFunction122(GetMemberName(A),s_AssistName_2) )
			{
				i_AssistIndex_2 = A;
			} else {
				UnknownFunction165(A);
				goto JL0086;
			}
		}
	}
}

function bool isNotMemberDead (int Index)
{
	local int MaxValue;
	local int CurValue;

	if ( UnknownFunction150(Index,0) )
	{
		return False;
	}
	m_BarHP[Index].GetValue(MaxValue,CurValue);
	if ( UnknownFunction151(CurValue,0) )
	{
		return True;
	} else {
		return False;
	}
}

function string GetMemberName (int Index)
{
	return m_PlayerName[Index].GetName();
}

function DisableAutoAssist ()
{
	btnAssist.SetTexture("InterfaceTextures.Assist_On_Off","InterfaceTextures.Assist_On_Off","InterfaceTextures.Assist_On_Off");
	Class'UIAPI_WINDOW'.KillUITimer("PartyWnd",4440);
	b_AutoAssistEnabled = False;
	i_AssistIndex_1 = -1;
	i_AssistIndex_2 = -1;
}

function EnableAutoAssist ()
{
	btnAssist.SetTexture("InterfaceTextures.Potions_Btn_Down","InterfaceTextures.Potions_Btn_Down","InterfaceTextures.Potions_Btn_Down");
	Class'UIAPI_WINDOW'.SetUITimer("PartyWnd",4440,1000);
	b_AutoAssistEnabled = True;
}

function HandleRestart ()
{
	Clear(True);
}

function Clear (bool b_Value)
{
	local int idx;

	idx = 0;
	if ( UnknownFunction150(idx,9) )
	{
		ClearStatus(idx,b_Value);
		UnknownFunction165(idx);
		goto JL0007;
	}
	m_CurCount = 0;
	ResizeWnd();
	UpdateAndSetAssistIndex();
}

function ClearStatus (int idx, bool b_Value)
{
	m_StatusIconBuff[idx].Clear();
	m_StatusIconDeBuff[idx].Clear();
	m_StatusNoblessBuff[idx].Clear();
	m_PlayerName[idx].SetName("",0,1);
	isLeader[idx] = 0;
	m_LeaderIcon[idx].SetTexture("");
	m_PlayerName[idx].SetAnchor(UnknownFunction112(UnknownFunction112("PartyWnd.PartyStatusWnd",string(idx)),".ClassIcon"),"TopLeft","TopLeft",16,1);
	m_ClassIcon[idx].SetTexture("");
	m_ClassIconCustom[idx].SetTexture("");
	UpdateCPBar(idx,0,0);
	UpdateHPBar(idx,0,0);
	UpdateMPBar(idx,0,0);
	m_arrID[idx] = 0;
	if ( b_Value )
	{
		ParamSpelledList[idx] = "";
	}
}

function f_UnkFunc_1 (int DesIndex, int SrcIndex)
{
	local int MaxValue;
	local int CurValue;
	local CustomTooltip TooltipInfo;

	m_arrID[DesIndex] = m_arrID[SrcIndex];
	ParamSpelledList[DesIndex] = ParamSpelledList[SrcIndex];
	m_PlayerName[DesIndex].SetName(m_PlayerName[SrcIndex].GetName(),0,1);
	m_ClassIcon[DesIndex].SetTexture(m_ClassIcon[SrcIndex].GetTextureName());
	m_ClassIconCustom[DesIndex].SetTexture(m_ClassIconCustom[SrcIndex].GetTextureName());
	m_LeaderIcon[DesIndex].SetTexture(m_LeaderIcon[SrcIndex].GetTextureName());
	m_PlayerName[SrcIndex].SetAnchor(UnknownFunction112(UnknownFunction112("PartyWnd.PartyStatusWnd",string(SrcIndex)),".ClassIcon"),"TopLeft","TopLeft",16,1);
	m_PlayerName[DesIndex].SetAnchor(UnknownFunction112(UnknownFunction112("PartyWnd.PartyStatusWnd",string(DesIndex)),".ClassIcon"),"TopLeft","TopLeft",16,1);
	if ( UnknownFunction154(isLeader[SrcIndex],1) )
	{
		m_PlayerName[DesIndex].SetNameWithColor(m_PlayerName[SrcIndex].GetName(),0,1,LeaderNameColor);
		m_PlayerName[DesIndex].SetAnchor(UnknownFunction112(UnknownFunction112("PartyWnd.PartyStatusWnd",string(DesIndex)),".ClassIcon"),"TopLeft","TopLeft",32,1);
		isLeader[DesIndex] = 1;
		isLeader[SrcIndex] = 0;
	}
	m_PartyStatus[SrcIndex].GetTooltipCustomType(TooltipInfo);
	m_PartyStatus[DesIndex].SetTooltipCustomType(TooltipInfo);
	m_ClassIconCustom[SrcIndex].GetTooltipCustomType(TooltipInfo);
	m_ClassIconCustom[DesIndex].SetTooltipCustomType(TooltipInfo);
	m_BarCP[SrcIndex].GetValue(MaxValue,CurValue);
	m_BarCP[DesIndex].SetValue(MaxValue,CurValue);
	m_BarHP[SrcIndex].GetValue(MaxValue,CurValue);
	m_BarHP[DesIndex].SetValue(MaxValue,CurValue);
	m_BarMP[SrcIndex].GetValue(MaxValue,CurValue);
	m_BarMP[DesIndex].SetValue(MaxValue,CurValue);
}

function ResizeWnd ()
{
	local int idx;
	local Rect rectWnd;
	local bool bOption;

	bOption = GetOptionBool("Game","SmallPartyWnd");
	if ( UnknownFunction151(m_CurCount,0) )
	{
		rectWnd = m_wndTop.GetRect();
		m_wndTop.SetWindowSize(rectWnd.nWidth,UnknownFunction144(46,m_CurCount));
		m_wndTop.SetResizeFrameSize(10,UnknownFunction144(46,m_CurCount));
		if ( UnknownFunction129(bOption) )
		{
			m_wndTop.ShowWindow();
		} else {
			m_wndTop.HideWindow();
		}
		idx = 0;
		if ( UnknownFunction150(idx,8) )
		{
			if ( UnknownFunction152(idx,UnknownFunction147(m_CurCount,1)) )
			{
				m_PartyStatus[idx].ShowWindow();
			} else {
				m_PartyStatus[idx].HideWindow();
			}
			UnknownFunction165(idx);
			goto JL00B1;
		}
	} else {
		m_wndTop.HideWindow();
	}
}

function int GetMemberIndex (int Id)
{
	local int idx;

	idx = 0;
	if ( UnknownFunction150(idx,8) )
	{
		if ( UnknownFunction154(m_arrID[idx],Id) )
		{
			return idx;
		}
		UnknownFunction165(idx);
		goto JL0007;
	}
	return -1;
}

function HandlePartyAddParty (string param)
{
	local int Id;

	ParseInt(param,"ID",Id);
	if ( UnknownFunction151(Id,0) )
	{
		UnknownFunction165(m_CurCount);
		ResizeWnd();
		m_arrID[UnknownFunction147(m_CurCount,1)] = Id;
		UpdateStatus(UnknownFunction147(m_CurCount,1),param);
	}
	UpdateAndSetAssistIndex();
	ReHandlePartySpelledList();
}

function HandlePartyUpdateParty (string param)
{
	local int Id;
	local int idx;

	ParseInt(param,"ID",Id);
	if ( UnknownFunction151(Id,0) )
	{
		idx = GetMemberIndex(Id);
		UpdateStatus(idx,param);
	}
}

function HandlePartyDeleteParty (string param)
{
	local int Id;
	local int idx;
	local int A;

	ParseInt(param,"ID",Id);
	if ( UnknownFunction151(Id,0) )
	{
		idx = GetMemberIndex(Id);
		if ( UnknownFunction151(idx,-1) )
		{
			A = idx;
			if ( UnknownFunction150(A,UnknownFunction147(m_CurCount,1)) )
			{
				f_UnkFunc_1(A,UnknownFunction146(A,1));
				UnknownFunction165(A);
				goto JL004A;
			}
			ClearStatus(UnknownFunction147(m_CurCount,1),True);
			UnknownFunction166(m_CurCount);
			ResizeWnd();
		}
	}
	UpdateAndSetAssistIndex();
	ReHandlePartySpelledList();
}

function HandlePartyDeleteAllParty ()
{
	Clear(False);
	UpdateAndSetAssistIndex();
}

function UpdateStatus (int idx, string param)
{
	local string Name;
	local int MasterID;
	local int RoutingType;
	local int Id;
	local int CP;
	local int maxCP;
	local int HP;
	local int maxHP;
	local int MP;
	local int maxMP;
	local int ClassID;
	local int Level;

	if ( UnknownFunction132(UnknownFunction150(idx,0),UnknownFunction153(idx,8)) )
	{
		return;
	}
	ParseString(param,"Name",Name);
	ParseInt(param,"ID",Id);
	ParseInt(param,"CurCP",CP);
	ParseInt(param,"MaxCP",maxCP);
	ParseInt(param,"CurHP",HP);
	ParseInt(param,"MaxHP",maxHP);
	ParseInt(param,"CurMP",MP);
	ParseInt(param,"MaxMP",maxMP);
	ParseInt(param,"ClassID",ClassID);
	ParseInt(param,"Level",Level);
	if ( ParseInt(param,"MasterID",MasterID) )
	{
		if ( UnknownFunction130(UnknownFunction151(MasterID,0),UnknownFunction154(MasterID,Id)) )
		{
			ParseInt(param,"RoutingType",RoutingType);
			RoutingTypeString = GetRoutingString(RoutingType);
			m_PartyStatus[idx].SetTooltipCustomType(MakeTooltipSimpleText(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112("Lv",string(Level))," - "),GetClassType(ClassID))," ["),RoutingTypeString),"]")));
			m_PlayerName[idx].SetNameWithColor(Name,0,1,LeaderNameColor);
			m_LeaderIcon[idx].SetTexture("InterfaceTextures.party_leadericon");
			isLeader[idx] = 1;
		} else {
			m_PlayerName[idx].SetName(Name,0,1);
			m_PartyStatus[idx].SetTooltipCustomType(MakeTooltipSimpleText(UnknownFunction112(UnknownFunction112(UnknownFunction112("Lv",string(Level))," - "),GetClassType(ClassID))));
			m_LeaderIcon[idx].SetTexture("");
			isLeader[idx] = 0;
		}
		UpdateAndSetAssistIndex();
		ReHandlePartySpelledList();
	}
	if ( UnknownFunction154(isLeader[idx],1) )
	{
		m_PartyStatus[idx].SetTooltipCustomType(MakeTooltipSimpleText(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112("Lv",string(Level))," - "),GetClassType(ClassID))," ["),RoutingTypeString),"]")));
		m_PlayerName[idx].SetAnchor(UnknownFunction112(UnknownFunction112("PartyWnd.PartyStatusWnd",string(idx)),".ClassIcon"),"TopLeft","TopLeft",32,1);
	} else {
		m_PartyStatus[idx].SetTooltipCustomType(MakeTooltipSimpleText(UnknownFunction112(UnknownFunction112(UnknownFunction112("Lv",string(Level))," - "),GetClassType(ClassID))));
		m_PlayerName[idx].SetAnchor(UnknownFunction112(UnknownFunction112("PartyWnd.PartyStatusWnd",string(idx)),".ClassIcon"),"TopLeft","TopLeft",16,1);
	}
	m_ClassIcon[idx].SetTexture(GetClassIconCustom(ClassID));
	m_ClassIcon[idx].SetTextureSize(32,32);
	m_ClassIcon[idx].SetWindowSize(14,14);
	m_ClassIcon[idx].SetTextureCtrlType(0);
	m_ClassIconCustom[idx].SetTexture(s_GetCustomClassIcon(ClassID,1));
	m_ClassIconCustom[idx].SetTooltipCustomType(MakeTooltipSimpleText(s_GetCustomClassIconTooltipText(ClassID,1)));
	UpdateCPBar(idx,CP,maxCP);
	UpdateHPBar(idx,HP,maxHP);
	UpdateMPBar(idx,MP,maxMP);
}

function SetPartyMembersColors ()
{
	local int idx;

	idx = 0;
	if ( UnknownFunction150(idx,m_CurCount) )
	{
		if ( UnknownFunction154(isLeader[idx],1) )
		{
			m_PlayerName[idx].SetNameWithColor(m_PlayerName[idx].GetName(),0,1,LeaderNameColor);
		} else {
			if ( UnknownFunction154(idx,i_AssistIndex_1) )
			{
				m_PlayerName[idx].SetNameWithColor(m_PlayerName[idx].GetName(),0,1,AssistNameColor_1);
			} else {
				if ( UnknownFunction154(idx,i_AssistIndex_2) )
				{
					m_PlayerName[idx].SetNameWithColor(m_PlayerName[idx].GetName(),0,1,AssistNameColor_2);
				} else {
					m_PlayerName[idx].SetName(m_PlayerName[idx].GetName(),0,1);
				}
			}
		}
		UnknownFunction165(idx);
		goto JL0007;
	}
}

function int HandlePartySpelledList (string param)
{
	local int A;
	local int idx;
	local int Id;
	local int Max;
	local int BuffCnt;
	local int BuffCurRow;
	local StatusIconInfo StatusInfo;

	BuffCurRow = -1;
	ParseInt(param,"ID",Id);
	if ( UnknownFunction150(Id,1) )
	{
		return -1;
	}
	idx = GetMemberIndex(Id);
	if ( UnknownFunction150(idx,0) )
	{
		return -1;
	}
	m_StatusIconBuff[idx].Clear();
	m_StatusNoblessBuff[idx].Clear();
	m_StatusIconDeBuff[idx].Clear();
	A = 0;
	if ( UnknownFunction150(A,9) )
	{
		m_StatusIconDeBuff[A].AddRow();
		m_StatusIconDeBuff[A].AddRow();
		UnknownFunction165(A);
		goto JL0098;
	}
	StatusInfo.Size = 14;
	StatusInfo.bShow = True;
	ParseInt(param,"Max",Max);
	m_ClassIconCustom[idx].SetAnchor(UnknownFunction112("PartyWnd.PartyStatusWnd",string(idx)),"TopRight","TopRight",-11,1);
	A = 0;
	if ( UnknownFunction150(A,Max) )
	{
		ParseInt(param,UnknownFunction112("SkillID_",string(A)),StatusInfo.ClassID);
		ParseInt(param,UnknownFunction112("Level_",string(A)),StatusInfo.Level);
		if ( UnknownFunction151(StatusInfo.ClassID,0) )
		{
			if ( UnknownFunction154(StatusInfo.ClassID,1323) )
			{
				m_ClassIconCustom[idx].SetAnchor(UnknownFunction112("PartyWnd.PartyStatusWnd",string(idx)),"TopRight","TopRight",-28,1);
			}
			StatusInfo.IconName = Class'UIDATA_SKILL'.GetIconName(StatusInfo.ClassID,StatusInfo.Level);
			StatusInfo.BackTex = "";
			if ( isDebuffCustom(StatusInfo.ClassID) )
			{
				StatusInfo.BackTex = "L2UI_CH3.Debuff";
				m_StatusIconDeBuff[idx].AddCol(checkPriorDebuffSameRow,StatusInfo);
			} else {
				if ( UnknownFunction180(UnknownFunction173(BuffCnt,18),0) )
				{
					UnknownFunction165(BuffCurRow);
					m_StatusIconBuff[idx].AddRow();
				}
				m_StatusIconBuff[idx].AddCol(BuffCurRow,StatusInfo);
				UnknownFunction165(BuffCnt);
			}
			if ( UnknownFunction130(f_UnkFunc1(StatusInfo.ClassID),checkPrior) )
			{
				m_StatusIconDeBuff[idx].AddCol(0,StatusInfo);
			}
			HandleOnPartyBuff(idx,StatusInfo);
		}
		UnknownFunction165(A);
		goto JL015F;
	}
	UpdateBuff();
	return idx;
}

function bool f_UnkFunc1 (int ClassID)
{
	local int j;

	j = 0;
	if ( UnknownFunction150(j,a_UnkArrayInt1.Length) )
	{
		if ( UnknownFunction154(a_UnkArrayInt1[j],ClassID) )
		{
			return True;
		}
		UnknownFunction165(j);
		goto JL0007;
	}
	return False;
}

function HandleShowBuffIcon (string param)
{
	local int nShow;

	ParseInt(param,"Show",nShow);
	m_CurBf = UnknownFunction146(m_CurBf,1);
	if ( UnknownFunction151(m_CurBf,2) )
	{
		m_CurBf = 0;
	}
	SetBuffButtonTooltip();
	switch (m_CurBf)
	{
		case 1:
		UpdateBuff();
		break;
		case 2:
		UpdateBuff();
		break;
		case 0:
		m_CurBf = 0;
		UpdateBuff();
		default:
	}
}

function OnClickButton (string strID)
{
	local PartyWndCompact script;

	script = PartyWndCompact(GetScript("PartyWndCompact"));
	switch (strID)
	{
		case "btnBuff":
		OnBuffButton();
		script.OnBuffButton();
		break;
		case "btnCompact":
		OnOpenPartyWndOption();
		break;
		case "btnAssist":
		HandleChangeAssistStatus();
		break;
		default:
	}
}

function HandleChangeAssistStatus ()
{
	if ( b_AutoAssistEnabled )
	{
		DisableAutoAssist();
	} else {
		if ( UnknownFunction132(UnknownFunction151(GetSelectedNumAssist(1),0),UnknownFunction151(GetSelectedNumAssist(2),0)) )
		{
			EnableAutoAssist();
		}
	}
}

function OnOpenPartyWndOption ()
{
	local PartyWndOption script;

	script = PartyWndOption(GetScript("PartyWndOption"));
	script.ShowPartyWndOption();
	m_PartyOption.SetAnchor("PartyWnd.PartyStatusWnd0","TopRight","TopLeft",5,5);
}

function OnBuffButton ()
{
	m_CurBf = UnknownFunction146(m_CurBf,1);
	if ( UnknownFunction151(m_CurBf,2) )
	{
		m_CurBf = 0;
	}
	SetBuffButtonTooltip();
	UpdateBuff();
}

function UpdateBuff ()
{
	local int idx;

	if ( UnknownFunction154(m_CurBf,1) )
	{
		idx = 0;
		if ( UnknownFunction150(idx,8) )
		{
			m_StatusIconBuff[idx].ShowWindow();
			m_StatusIconDeBuff[idx].HideWindow();
			UnknownFunction165(idx);
			goto JL0012;
		}
	} else {
		if ( UnknownFunction154(m_CurBf,2) )
		{
			idx = 0;
			if ( UnknownFunction150(idx,8) )
			{
				m_StatusIconBuff[idx].HideWindow();
				m_StatusIconDeBuff[idx].ShowWindow();
				UnknownFunction165(idx);
				goto JL0068;
			}
		} else {
			idx = 0;
			if ( UnknownFunction150(idx,8) )
			{
				m_StatusIconBuff[idx].HideWindow();
JL00B2:
				m_StatusIconDeBuff[idx].HideWindow();
				UnknownFunction165(idx);
				goto JL00B2;
			}
		}
	}
}

function UpdateCPBar (int idx, int Value, int MaxValue)
{
	m_BarCP[idx].SetValue(MaxValue,Value);
}

function UpdateHPBar (int idx, int Value, int MaxValue)
{
	m_BarHP[idx].SetValue(MaxValue,Value);
}

function UpdateMPBar (int idx, int Value, int MaxValue)
{
	m_BarMP[idx].SetValue(MaxValue,Value);
}

function OnLButtonDown (WindowHandle a_WindowHandle, int X, int Y)
{
	local Rect rectWnd;
	local UserInfo StatusInfo;
	local int idx;

	rectWnd = m_wndTop.GetRect();
	if ( UnknownFunction130(UnknownFunction130(UnknownFunction151(X,UnknownFunction146(rectWnd.nX,13)),UnknownFunction150(X,UnknownFunction147(UnknownFunction146(rectWnd.nX,rectWnd.nWidth),10))),UnknownFunction151(Y,rectWnd.nY)) )
	{
		idx = UnknownFunction145(UnknownFunction147(Y,rectWnd.nY),46);
		if ( IsKeyDown(18) )
		{
			i_UnkInt_1 = idx;
		} else {
			if ( GetPlayerInfo(StatusInfo) )
			{
				if ( IsPKMode() )
				{
					RequestAttack(m_arrID[idx],StatusInfo.loc);
				} else {
					RequestAction(m_arrID[idx],StatusInfo.loc);
				}
			}
		}
	}
}

function OnLButtonUp (WindowHandle a_WindowHandle, int X, int Y)
{
	local Rect rectWnd;
	local int idx;

	rectWnd = m_wndTop.GetRect();
	if ( UnknownFunction130(UnknownFunction130(UnknownFunction151(X,UnknownFunction146(rectWnd.nX,13)),UnknownFunction150(X,UnknownFunction147(UnknownFunction146(rectWnd.nX,rectWnd.nWidth),10))),UnknownFunction151(Y,rectWnd.nY)) )
	{
		idx = UnknownFunction145(UnknownFunction147(Y,rectWnd.nY),46);
		if ( IsKeyDown(18) )
		{
			if ( UnknownFunction130(UnknownFunction151(i_UnkInt_1,-1),UnknownFunction155(i_UnkInt_1,idx)) )
			{
				ProbablyMove(i_UnkInt_1,idx);
			}
		}
	}
	i_UnkInt_1 = -1;
}

function OnRButtonUp (int X, int Y)
{
	local Rect rectWnd;
	local UserInfo Info;
	local int idx;

	rectWnd = m_wndTop.GetRect();
	if ( UnknownFunction130(UnknownFunction130(UnknownFunction151(X,UnknownFunction146(rectWnd.nX,13)),UnknownFunction150(X,UnknownFunction147(UnknownFunction146(rectWnd.nX,rectWnd.nWidth),10))),UnknownFunction151(Y,rectWnd.nY)) )
	{
		if ( GetPlayerInfo(Info) )
		{
			idx = UnknownFunction145(UnknownFunction147(Y,rectWnd.nY),46);
			RequestAssist(m_arrID[idx],Info.loc);
		}
	}
}

function SetBuffButtonTooltip ()
{
	local int idx;

	switch (m_CurBf)
	{
		case 0:
		idx = 1496;
		break;
		case 1:
		idx = 1497;
		break;
		case 2:
		idx = 1498;
		break;
		default:
	}
	btnBuff.SetTooltipCustomType(MakeTooltipSimpleText(GetSystemString(idx)));
}

function HandleOnPartyBuff (int idx, StatusIconInfo StatusInfo)
{
	local StatusIconInfo Info;

	if ( UnknownFunction132(UnknownFunction132(UnknownFunction132(UnknownFunction154(StatusInfo.ClassID,1410),UnknownFunction154(StatusInfo.ClassID,438)),UnknownFunction154(StatusInfo.ClassID,1418)),UnknownFunction154(StatusInfo.ClassID,1427)) )
	{
		m_StatusNoblessBuff[idx].DelItem(0,0);
		if ( UnknownFunction150(m_StatusNoblessBuff[idx].GetRowCount(),1) )
		{
			m_StatusNoblessBuff[idx].AddRow();
		}
		m_StatusNoblessBuff[idx].AddCol(0,StatusInfo);
	} else {
		if ( UnknownFunction154(StatusInfo.ClassID,1323) )
		{
			m_StatusNoblessBuff[idx].GetItem(0,0,Info);
			if ( UnknownFunction130(UnknownFunction130(UnknownFunction130(UnknownFunction155(Info.ClassID,1410),UnknownFunction155(Info.ClassID,438)),UnknownFunction155(Info.ClassID,1418)),UnknownFunction155(Info.ClassID,1427)) )
			{
				if ( UnknownFunction150(m_StatusNoblessBuff[idx].GetRowCount(),1) )
				{
					m_StatusNoblessBuff[idx].AddRow();
				}
				m_StatusNoblessBuff[idx].AddCol(0,StatusInfo);
			}
		}
	}
}

function ProbablyMove (int UnkInt_ProbablyMemberPos, int idx)
{
	local int A;

	if ( UnknownFunction132(UnknownFunction151(UnkInt_ProbablyMemberPos,UnknownFunction147(m_CurCount,1)),UnknownFunction151(idx,UnknownFunction147(m_CurCount,1))) )
	{
		return;
	}
	if ( UnknownFunction154(UnkInt_ProbablyMemberPos,idx) )
	{
		return;
	}
	if ( UnknownFunction132(UnknownFunction154(UnkInt_ProbablyMemberPos,-1),UnknownFunction154(idx,-1)) )
	{
		return;
	} else {
		if ( UnknownFunction150(UnkInt_ProbablyMemberPos,idx) )
		{
			f_UnkFunc_1(UnknownFunction147(9,1),UnkInt_ProbablyMemberPos);
			A = UnkInt_ProbablyMemberPos;
			if ( UnknownFunction150(A,idx) )
			{
				f_UnkFunc_1(A,UnknownFunction146(A,1));
				UnknownFunction165(A);
				goto JL0088;
			}
			f_UnkFunc_1(idx,UnknownFunction147(9,1));
		} else {
			f_UnkFunc_1(UnknownFunction147(9,1),UnkInt_ProbablyMemberPos);
			A = UnkInt_ProbablyMemberPos;
			if ( UnknownFunction151(A,idx) )
			{
				f_UnkFunc_1(A,UnknownFunction147(A,1));
				UnknownFunction166(A);
				goto JL00E2;
			}
			f_UnkFunc_1(idx,UnknownFunction147(9,1));
		}
	}
	ClearStatus(UnknownFunction147(9,1),True);
	ResizeWnd();
	UpdateAndSetAssistIndex();
	ReHandlePartySpelledList();
}

function CustomTooltip SetTooltip (string Text)
{
	local CustomTooltip ToolTip;
	local DrawItemInfo Info;

	ToolTip.DrawList.Length = 1;
	Info.eType = 1;
	Info.t_strText = Text;
	ToolTip.DrawList[0] = Info;
	return ToolTip;
}

function bool InRange (Vector v_Vector, int Range)
{
	local int X;
	local int Y;
	local int Z;
	local UserInfo Info;

	GetPlayerInfo(Info);
	X = int(UnknownFunction175(v_Vector.X,Info.loc.X));
	Y = int(UnknownFunction175(v_Vector.Y,Info.loc.Y));
	Z = int(UnknownFunction175(v_Vector.Z,Info.loc.Z));
	return UnknownFunction150(UnknownFunction146(UnknownFunction146(UnknownFunction144(X,X),UnknownFunction144(Y,Y)),UnknownFunction144(Z,Z)),UnknownFunction144(Range,Range));
}

