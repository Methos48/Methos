//================================================================================
// UnionDetailWnd.
//================================================================================

class UnionDetailWnd extends UICommonAPI;

var int m_MasterID;
var WindowHandle Me;
var TextBoxHandle txtMasterName;
var ListCtrlHandle lstPartyMember;

function OnLoad ()
{
	RegisterEvent(1420);
	Me = GetHandle("UnionDetailWnd");
	txtMasterName = TextBoxHandle(GetHandle("UnionDetailWnd.txtMasterName"));
	lstPartyMember = ListCtrlHandle(GetHandle("UnionDetailWnd.lstPartyMember"));
}

function OnEvent (int Event_ID, string param)
{
	if ( UnknownFunction154(Event_ID,1420) )
	{
		HandleCommandChannelPartyMember(param);
	}
}

function SetMasterInfo (string MasterName, int MasterID)
{
	txtMasterName.SetText(MasterName);
	m_MasterID = MasterID;
}

function int GetMasterID ()
{
	return m_MasterID;
}

function Clear ()
{
	lstPartyMember.DeleteAllItem();
	txtMasterName.SetText("");
}

function OnClickButton (string strID)
{
	switch (strID)
	{
		case "btnClose":
		OnCloseClick();
		break;
		default:
	}
}

function OnCloseClick ()
{
	Me.HideWindow();
}

function OnDBClickListCtrlRecord (string strID)
{
	local UserInfo UserInfo;
	local LVDataRecord Record;
	local int ServerID;

	if ( UnknownFunction122(strID,"lstPartyMember") )
	{
		Record = lstPartyMember.GetSelectedRecord();
		ServerID = Record.nReserved1;
		if ( UnknownFunction151(ServerID,0) )
		{
			if ( GetPlayerInfo(UserInfo) )
			{
				if ( IsPKMode() )
				{
					RequestAttack(ServerID,UserInfo.loc);
				} else {
					RequestAction(ServerID,UserInfo.loc);
				}
			}
		}
	}
}

function HandleCommandChannelPartyMember (string param)
{
	local LVDataRecord Record;
	local int idx;
	local int MemberCount;
	local string Name;
	local int ClassID;
	local int ServerID;
	local UnionWnd script;

	lstPartyMember.DeleteAllItem();
	ParseInt(param,"MemberCount",MemberCount);
	idx = 0;
	if ( UnknownFunction150(idx,MemberCount) )
	{
		ParseString(param,UnknownFunction112("Name_",string(idx)),Name);
		ParseInt(param,UnknownFunction112("ClassID_",string(idx)),ClassID);
		ParseInt(param,UnknownFunction112("ServerID_",string(idx)),ServerID);
		if ( UnknownFunction151(UnknownFunction125(Name),0) )
		{
			Record.LVDataList.Length = 2;
			Record.nReserved1 = ServerID;
			Record.LVDataList[0].szData = Name;
			Record.LVDataList[1].nTextureWidth = 11;
			Record.LVDataList[1].nTextureHeight = 11;
			Record.LVDataList[1].szData = string(ClassID);
			Record.LVDataList[1].szTexture = GetClassIconName(ClassID);
			lstPartyMember.InsertRecord(Record);
		}
		UnknownFunction165(idx);
		goto JL0033;
	}
	script = UnionWnd(GetScript("UnionWnd"));
	script.UpdatePartyMemberCount(m_MasterID,MemberCount);
}

