//================================================================================
// MacroEditWnd.
//================================================================================

class MacroEditWnd extends UICommonAPI;

var bool m_bShow;
var int unkInt3;
var int m_CurMacroID;
var int unkInt1;
var int unkInt2;
const MACRO_MAX_COUNT= 24;
const MACROCOMMAND_MAX_COUNT= 12;
const MACROICON_MAX_COUNT= 104;
const MACRO_ICONANME= "L2UI.MacroWnd.Macro_Icon";

function OnLoad ()
{
	RegisterEvent(150);
	RegisterEvent(1710);
	RegisterEvent(1260);
	RegisterEvent(1270);
	m_bShow = False;
	unkInt3 = 1;
	m_CurMacroID = 0;
	unkInt1 = 7;
	InitTabOrder();
	HandleMacroList();
	unkInt2 = 1;
}

function OnShow ()
{
	m_bShow = True;
	SetFocus();
}

function OnHide ()
{
	m_bShow = False;
}

function OnClickButton (string strID)
{
	switch (strID)
	{
		case "BtnInfo":
		unkFunction();
		break;
		case "BtnHelp":
		OnClickHelp();
		break;
		case "BtnCancel":
		OnClickCancel();
		break;
		case "BtnLeft":
		OnClickLeft();
		break;
		case "BtnRight":
		OnClickRight();
		break;
		case "BtnSave":
		OnClickSave();
		break;
		default:
	}
}

function OnEvent (int Event_ID, string param)
{
	if ( Equals(Event_ID,1260) )
	{
		HandleMacroShowEditWnd(param);
	} else {
		if ( Equals(Event_ID,1270) )
		{
			HandleMacroDeleted(param);
		} else {
			if ( Equals(Event_ID,1710) )
			{
				if (! UnknownFunction129(DialogIsMine()) ) goto JL0060;
			}
		}
	}
}

function InitTabOrder ()
{
	local int idx;

	Class'UIAPI_WINDOW'.SetTabOrder("MacroEditWnd","MacroEditWnd.txtName","MacroEditWnd.TxtShortName");
	Class'UIAPI_WINDOW'.SetTabOrder("MacroEditWnd.TxtName","MacroEditWnd.TxtShortName","MacroEditWnd");
	Class'UIAPI_WINDOW'.SetTabOrder("MacroEditWnd.TxtShortName","MacroEditWnd.TxtEdit0","MacroEditWnd.txtName");
	idx = 0;
	if ( LessThan(idx,12) )
	{
		if ( Equals(idx,0) )
		{
			Class'UIAPI_WINDOW'.SetTabOrder("MacroEditWnd.TxtEdit0","MacroEditWnd.txtEdit1","MacroEditWnd.txtShortName");
		} else {
			if ( Equals(idx,IntSub(12,1)) )
			{
				Class'UIAPI_WINDOW'.SetTabOrder("MacroEditWnd.TxtEdit11","MacroEditWnd.txtName","MacroEditWnd.txtEdit10");
			} else {
				Class'UIAPI_WINDOW'.SetTabOrder(StrCat("MacroEditWnd.TxtEdit",string(idx)),StrCat("MacroEditWnd.txtEdit",string(DoAdd(idx,1))),StrCat("MacroEditWnd.txtEdit",string(IntSub(idx,1))));
			}
		}
		IntIncrement(idx);
		goto JL00FA;
	}
}

function unkFunction ()
{
	if ( Class'UIAPI_WINDOW'.IsShowWindow("MacroEditWnd.AreaEdit") )
	{
		Class'UIAPI_TEXTBOX'.SetText("MacroEditWnd.InfoHead","Macro Content");
		Class'UIAPI_WINDOW'.HideWindow("MacroEditWnd.BtnSave");
		Class'UIAPI_WINDOW'.HideWindow("MacroEditWnd.BtnCancel");
		Class'UIAPI_WINDOW'.HideWindow("MacroEditWnd.AreaEdit");
		Class'UIAPI_WINDOW'.ShowWindow("MacroEditWnd.IconEdit");
	} else {
		Class'UIAPI_TEXTBOX'.SetText("MacroEditWnd.InfoHead","Change Icon");
		Class'UIAPI_WINDOW'.HideWindow("MacroEditWnd.IconEdit");
		Class'UIAPI_WINDOW'.ShowWindow("MacroEditWnd.AreaEdit");
		Class'UIAPI_WINDOW'.ShowWindow("MacroEditWnd.BtnCancel");
		Class'UIAPI_WINDOW'.ShowWindow("MacroEditWnd.BtnSave");
	}
}

function HandleMacroList ()
{
	local int idx;
	local ItemInfo ItemInfo;

	ItemInfo.IconName = "L2UI.Macro_Icon105";
	ItemInfo.Name = "105";
	Class'UIAPI_ITEMWINDOW'.AddItem("MacroEditWnd.MacroItem",ItemInfo);
JL0062:
	idx = 1;
	if ( LessThan(idx,8) )
	{
		ItemInfo.IconName = StrCat("L2UI.Macro_Icon",string(idx));
		ItemInfo.Name = StrCat("",string(idx));
		Class'UIAPI_ITEMWINDOW'.AddItem("MacroEditWnd.MacroItem",ItemInfo);
		IntIncrement(idx);
		goto JL0062;
	}
	idx = 104;
	if ( GreaterThan(idx,7) )
	{
		ItemInfo.IconName = StrCat("L2UI.Macro_Icon",string(idx));
		ItemInfo.Name = StrCat("",string(idx));
		Class'UIAPI_ITEMWINDOW'.AddItem("MacroEditWnd.MacroItem",ItemInfo);
		IntDec(idx);
		goto JL00F7;
	}
}

function OnClickItem (string strID, int Index)
{
	local ItemInfo ItemInfo;

	if ( LogicalAND(StrEquals(strID,"MacroItem"),GreaterThan(Index,-1)) )
	{
		if ( Class'UIAPI_ITEMWINDOW'.GetItem("MacroEditWnd.MacroItem",Index,ItemInfo) )
		{
			unkInt3 = int(ItemInfo.Name);
			Class'UIAPI_TEXTURECTRL'.SetTexture("MacroEditWnd.TexMacro",StrCat("L2UI.MacroWnd.Macro_Icon",ItemInfo.Name));
			unkFunction();
		}
	}
}

function OnClickHelp ()
{
	local string strParam;

	ParamAdd(strParam,"FilePath","..L2texthelp_macro.htm");
	ExecuteEvent(1210,strParam);
}

function OnClickCancel ()
{
	Class'UIAPI_WINDOW'.HideWindow("MacroEditWnd");
}

function OnClickSave ()
{
	SaveMacro();
}

function OnDropItem (string strID, ItemInfo ItemInfo, int X, int Y)
{
	if ( LessThan(StrLen(strID),1) )
	{
		return;
	}
	if ( NotEquals(StrLeft(strID,unkInt1),"TxtEdit") )
	{
		return;
	}
	Class'UIAPI_EDITBOX'.SetString(StrCat("MacroEditWnd.",strID),ItemInfo.MacroCommand);
	Class'UIAPI_EDITBOX'.SetHighLight(StrCat("MacroEditWnd.",strID),False);
}

function OnDragItemStart (string strID, ItemInfo ItemInfo)
{
	if ( LessThan(StrLen(strID),1) )
	{
		return;
	}
	if ( NotEquals(StrLeft(strID,unkInt1),"TxtEdit") )
	{
		return;
	}
	Class'UIAPI_EDITBOX'.SetHighLight(StrCat("MacroEditWnd.",strID),True);
}

function OnDragItemEnd (string strID)
{
	if ( LessThan(StrLen(strID),1) )
	{
		return;
	}
	if ( NotEquals(StrLeft(strID,unkInt1),"txtEdit") )
	{
		return;
	}
	Class'UIAPI_EDITBOX'.SetHighLight(StrCat("MacroEditWnd.",strID),False);
}

function OnChangeEditBox (string strID)
{
	switch (strID)
	{
		case "TxtShortName":
		UpdateIconName();
		break;
		default:
	}
}

function OnClickLeft ()
{
	IntDec(unkInt3);
	if ( LessThan(unkInt3,1) )
	{
		unkInt3 = 104;
	}
	UpdateIcon();
}

function OnClickRight ()
{
	IntIncrement(unkInt3);
	if ( GreaterThan(unkInt3,104) )
	{
		unkInt3 = 1;
	}
	UpdateIcon();
}

function UpdateIcon ()
{
	Class'UIAPI_TEXTURECTRL'.SetTexture("MacroEditWnd.TexMacro",StrCat("L2UI.MacroWnd.Macro_Icon",string(unkInt3)));
}

function UpdateIconName ()
{
	local string strShortName;

	strShortName = Class'UIAPI_EDITBOX'.GetString("MacroEditWnd.TxtShortName");
	Class'UIAPI_TEXTBOX'.SetText("MacroEditWnd.TxtMacroName",strShortName);
}

function Clear ()
{
	local int idx;
	local WindowHandle m_MacroEditWnd;

	unkInt3 = 105;
	m_MacroEditWnd = GetHandle("MacroEditWnd.AreaEdit");
	Class'UIAPI_EDITBOX'.SetString("MacroEditWnd.TxtName","");
	Class'UIAPI_EDITBOX'.SetString("MacroEditWnd.TxtShortName","");
	idx = 0;
	if ( LessThan(idx,12) )
	{
		Class'UIAPI_EDITBOX'.SetString(StrCat("MacroEditWnd.txtEdit",string(idx)),"");
		IntIncrement(idx);
		goto JL0085;
	}
	UpdateIcon();
	UpdateIconName();
}

function HandleMacroDeleted (string param)
{
	local int MacroID;

	ParseInt(param,"MacroID",MacroID);
	if ( LogicalAND(m_bShow,Equals(m_CurMacroID,MacroID)) )
	{
		PlayConsoleSound(6);
		Class'UIAPI_WINDOW'.HideWindow("MacroEditWnd");
	}
}

function HandleMacroShowEditWnd (string param)
{
	local int MacroCount;
	local Color TextColor;

	Clear();
	m_CurMacroID = 0;
	if ( ParseInt(param,"MacroID",m_CurMacroID) )
	{
		SetMacroID(m_CurMacroID);
		if ( NotBool(m_bShow) )
		{
			PlayConsoleSound(5);
			Class'UIAPI_WINDOW'.ShowWindow("MacroEditWnd");
		}
		Class'UIAPI_WINDOW'.SetFocus("MacroEditWnd.TxtName");
	} else {
		if ( m_bShow )
		{
			PlayConsoleSound(6);
			Class'UIAPI_WINDOW'.HideWindow("MacroEditWnd");
		} else {
			MacroCount = Class'UIDATA_MACRO'.GetMacroCount();
			if ( IntGreaterOrEqual(MacroCount,24) )
			{
				TextColor.R = 176;
				TextColor.G = 155;
				TextColor.B = 121;
				TextColor.A = 255;
				DialogShow(5,GetSystemMessage(797));
				DialogSetID(0);
				return;
			}
			PlayConsoleSound(5);
			Class'UIAPI_WINDOW'.ShowWindow("MacroEditWnd");
			Class'UIAPI_WINDOW'.SetFocus("MacroEditWnd.TxtName");
		}
	}
}

function SetMacroID (int MacroID)
{
	local int idx;
	local MacroInfo Info;
	local MacroInfoWnd MacroInfoWnd;

	if ( LessThan(MacroID,1) )
	{
		return;
	}
	if ( Class'UIDATA_MACRO'.GetMacroInfo(MacroID,Info) )
	{
		Class'UIAPI_EDITBOX'.SetString("MacroEditWnd.TxtName",Info.Name);
		Class'UIAPI_EDITBOX'.SetString("MacroEditWnd.TxtShortName",Info.IconName);
		unkInt3 = int(StrRight(Info.IconTextureName,1));
		if ( LessThan(unkInt3,1) )
		{
			unkInt3 = GetMacroNum(Info.Name);
		}
		UpdateIcon();
		MacroInfoWnd = MacroInfoWnd(GetScript("MacroInfoWnd"));
		MacroInfoWnd.SetInfoText(Info.Description);
		idx = 0;
		if ( LessThan(idx,12) )
		{
			Class'UIAPI_EDITBOX'.SetString(StrCat("MacroEditWnd.TxtEdit",string(idx)),Info.CommandList[idx]);
			IntIncrement(idx);
			goto JL0113;
		}
	}
}

function SaveMacro ()
{
	local int idx;
	local MacroInfoWnd MacroInfoWnd;
	local string Name;
	local string IconName;
	local string Description;
	local string unkLocStr;
	local array<string> CommandList;

	MacroInfoWnd = MacroInfoWnd(GetScript("MacroInfoWnd"));
	Name = Class'UIAPI_EDITBOX'.GetString("MacroEditWnd.TxtName");
	IconName = Class'UIAPI_EDITBOX'.GetString("MacroEditWnd.TxtShortName");
	Description = MacroInfoWnd.GetInfoText();
	idx = 0;
	if ( LessThan(idx,12) )
	{
		unkLocStr = Class'UIAPI_EDITBOX'.GetString(StrCat("MacroEditWnd.TxtEdit",string(idx)));
		byte(CommandList)
		CommandList.Length
		1
		CommandList[IntSub(CommandList.Length,1)] = unkLocStr;
		IntIncrement(idx);
		goto JL0096;
	}
	if ( GreaterThan(unkInt3,7) )
	{
		SetINIInt("MacroList",Name,unkInt3,"MacroGrp");
	}
	if ( Class'MacroAPI'.RequestMakeMacro(m_CurMacroID,Name,IconName,IntSub(unkInt3,1),Description,CommandList) )
	{
		Class'UIAPI_WINDOW'.HideWindow("MacroEditWnd");
	}
}

function SetFocus ()
{
	Class'UIAPI_WINDOW'.SetFocus("MacroEditWnd.TxtHead");
	Class'UIAPI_WINDOW'.SetFocus("MacroEditWnd.TxtNameHead");
	Class'UIAPI_WINDOW'.SetFocus("MacroEditWnd.TxtName");
	Class'UIAPI_WINDOW'.SetFocus("MacroEditWnd.TxtShortName");
	Class'UIAPI_WINDOW'.SetFocus("MacroEditWnd.TxtShortNameHead");
	Class'UIAPI_WINDOW'.SetFocus("MacroEditWnd.TxtMacroName");
}

