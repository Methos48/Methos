//================================================================================
// OlympiadTargetWnd.
//================================================================================

class OlympiadTargetWnd extends UICommonAPI;

var int m_PlayerNum;
var int m_id;
var string m_Name;
var int m_ClassID;
var int m_MaxHP;
var int m_CurHP;
var int m_MaxCP;
var int m_CurCP;
var int OlyTime;
var bool UnknownBool;
var int DamageDealt;
var int DamageReceived;
var int MPDamageDealt;
var int MPDamageReceived;
var int m_targetID;
var UserInfo uInfo;
var StatusWnd StatusWndHandle;

function OnLoad ()
{
	RegisterEvent(900);
	RegisterEvent(920);
	RegisterEvent(910);
	RegisterEvent(980);
	RegisterEvent(290);
	DamageDealt = 0;
	DamageReceived = 0;
	MPDamageDealt = 0;
	MPDamageReceived = 0;
	RegisterEvent(580);
	OlyTime = 360;
	UnknownBool = False;
	StatusWndHandle = StatusWnd(GetScript("StatusWnd"));
}

function OnEvent (int Event_ID, string param)
{
	if ( UnknownFunction154(Event_ID,900) )
	{
		Clear();
		ParseInt(param,"PlayerNum",m_PlayerNum);
		Class'UIAPI_WINDOW'.ShowWindow("OlympiadTargetWnd");
	} else {
		if ( UnknownFunction154(Event_ID,920) )
		{
			HandleUserInfo(param);
			UpdateStatus();
		} else {
			if ( UnknownFunction154(Event_ID,910) )
			{
				Clear();
			} else {
				if ( UnknownFunction154(Event_ID,580) )
				{
					HandleSystemMessage(param);
				} else {
					if ( UnknownFunction154(Event_ID,980) )
					{
						m_targetID = Class'UIDATA_TARGET'.GetTargetID();
					} else {
						if ( UnknownFunction154(Event_ID,290) )
						{
							HandleMagicSkillUse(param);
						}
					}
				}
			}
		}
	}
}

function HandleMagicSkillUse (string param)
{
	local int SkillID;
	local int AttackerID;
	local string SkillName;

	ParseInt(param,"SkillID",SkillID);
	ParseInt(param,"AttackerID",AttackerID);
	if ( UnknownFunction154(AttackerID,StatusWndHandle.m_UserID) )
	{
		return;
	}
	if ( UnknownFunction129(IsShowWindow("OlympiadTargetWnd")) )
	{
		return;
	}
	if ( UnknownFunction155(uInfo.nID,AttackerID) )
	{
		GetUserInfo(AttackerID,uInfo);
	}
	SkillName = Class'UIDATA_SKILL'.GetName(SkillID,1);
	if ( UnknownFunction129(IsConsumable(SkillID)) )
	{
		ChatOlyMsg(UnknownFunction112(UnknownFunction112(uInfo.Name," used "),SkillName),SetColor("DamageRed"));
	}
}

function HandleSystemMessage (string param)
{
	local int Index;
	local int DamageDealtParam;
	local string msgParam;
	local string PetParam;

	ParseInt(param,"Index",Index);
	if ( UnknownFunction129(IsShowWindow("OlympiadTargetWnd")) )
	{
		return;
	}
	switch (Index)
	{
		case 35:
		case 1026:
		if ( UnknownFunction130(UnknownFunction153(m_id,1),UnknownFunction132(UnknownFunction154(m_targetID,m_id),UnknownFunction150(m_targetID,1))) )
		{
			ParseInt(param,"Param1",DamageDealtParam);
			DamageDealt = UnknownFunction146(DamageDealt,DamageDealtParam);
		}
		break;
		case 36:
		case 37:
		ParseInt(param,"Param2",DamageDealtParam);
		ParseString(param,"Param1",PetParam);
		if ( UnknownFunction130(UnknownFunction130(UnknownFunction130(UnknownFunction130(UnknownFunction130(UnknownFunction130(UnknownFunction130(UnknownFunction130(UnknownFunction130(UnknownFunction123(PetParam,"Imperial Phoenix"),UnknownFunction123(PetParam,"kat the cat")),UnknownFunction123(PetParam,"mew the cat")),UnknownFunction123(PetParam,"feline queen")),UnknownFunction123(PetParam,"feline king")),UnknownFunction123(PetParam,"kai the cat")),UnknownFunction123(PetParam,"nightshade")),UnknownFunction123(PetParam,"spectral lord")),UnknownFunction123(PetParam,"magnus the unicorn")),UnknownFunction123(PetParam,"Dark Panther")) )
		{
			DamageReceived = UnknownFunction146(DamageReceived,DamageDealtParam);
			ChatOlyMsg(UnknownFunction112(UnknownFunction112(uInfo.Name," hit "),string(DamageDealtParam)),SetColor("DamageRed"));
		}
		break;
		case 970:
		ParseInt(param,"Param2",DamageDealtParam);
		UnknownFunction161(MPDamageReceived,DamageDealtParam);
		ChatOlyMsg(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(uInfo.Name," drained "),string(DamageDealtParam))," MP. Total: "),string(MPDamageReceived)),SetColor("DamageRed"));
		break;
		case 1867:
		ParseInt(param,"Param1",DamageDealtParam);
		UnknownFunction161(MPDamageDealt,DamageDealtParam);
		break;
		case 46:
		ParseString(param,"Param1",msgParam);
		break;
		case 44:
		case 1280:
		ChatOlyMsg("Critical Hit!",SetColor("Green"));
		break;
		case 139:
		case 43:
		case 158:
		ChatOlyMsg("Failed",SetColor("Red"));
		default:
	}
	SetDealtReceivedDamage();
}

function OnEnterState (name a_PreStateName)
{
	Clear();
}

function Clear ()
{
	m_PlayerNum = 0;
	m_id = 0;
	m_Name = "";
	m_ClassID = 0;
	m_MaxHP = 0;
	m_CurHP = 0;
	m_MaxCP = 0;
	m_CurCP = 0;
	DamageDealt = 0;
	DamageReceived = 0;
	MPDamageDealt = 0;
	MPDamageReceived = 0;
	OlyTime = 360;
	UnknownBool = False;
	SetDealtReceivedDamage();
	UpdateStatus();
	uInfo.nID = -1;
}

function SetDealtReceivedDamage ()
{
	Class'UIAPI_TEXTBOX'.SetText("OlympiadTargetWnd.txtDamageDealt",UnknownFunction112("Dealt :           ",string(DamageDealt)));
	Class'UIAPI_TEXTBOX'.SetText("OlympiadTargetWnd.txtDamageReceived",UnknownFunction112("Received :     ",string(DamageReceived)));
	Class'UIAPI_TEXTBOX'.SetText("OlympiadTargetWnd.txtMPDamageDealt",string(MPDamageDealt));
	Class'UIAPI_TEXTBOX'.SetText("OlympiadTargetWnd.txtMPDamageReceived",string(MPDamageReceived));
}

function HandleUserInfo (string param)
{
	local int IsPlayer;
	local int PlayerNum;

	ParseInt(param,"IsPlayer",IsPlayer);
	if ( UnknownFunction155(IsPlayer,0) )
	{
		return;
	}
	ParseInt(param,"PlayerNum",PlayerNum);
	if ( UnknownFunction132(UnknownFunction155(m_PlayerNum,PlayerNum),UnknownFunction150(PlayerNum,1)) )
	{
		return;
	}
	if ( UnknownFunction129(UnknownBool) )
	{
		UnknownBool = True;
		OlyTime = 360;
		Class'UIAPI_WINDOW'.KillUITimer("OlympiadTargetWnd",4412);
		Class'UIAPI_WINDOW'.SetUITimer("OlympiadTargetWnd",4412,1000);
	}
	ParseInt(param,"ID",m_id);
	ParseString(param,"Name",m_Name);
	ParseInt(param,"ClassID",m_ClassID);
	ParseInt(param,"MaxHP",m_MaxHP);
	ParseInt(param,"CurHP",m_CurHP);
	ParseInt(param,"MaxCP",m_MaxCP);
	ParseInt(param,"CurCP",m_CurCP);
}

function UpdateStatus ()
{
	Class'UIAPI_TEXTBOX'.SetText("OlympiadTargetWnd.txtName",UnknownFunction112(UnknownFunction112(UnknownFunction112(m_Name," ["),GetClassType(m_ClassID)),"]"));
	if ( UnknownFunction151(m_MaxCP,0) )
	{
		Class'UIAPI_BARCTRL'.SetValue("OlympiadTargetWnd.barCP",m_MaxCP,m_CurCP);
		Class'UIAPI_TEXTBOX'.SetText("OlympiadTargetWnd.txtCP",UnknownFunction112(UnknownFunction112(string(m_CurCP)," / "),string(m_MaxCP)));
	} else {
		Class'UIAPI_BARCTRL'.SetValue("OlympiadTargetWnd.barCP",m_MaxCP,0);
		Class'UIAPI_TEXTBOX'.SetText("OlympiadTargetWnd.txtCP","");
	}
	if ( UnknownFunction151(m_MaxHP,0) )
	{
		Class'UIAPI_BARCTRL'.SetValue("OlympiadTargetWnd.barHP",m_MaxHP,m_CurHP);
		Class'UIAPI_TEXTBOX'.SetText("OlympiadTargetWnd.txtHP",UnknownFunction112(UnknownFunction112(string(m_CurHP)," / "),string(m_MaxHP)));
	} else {
		Class'UIAPI_BARCTRL'.SetValue("OlympiadTargetWnd.barHP",m_MaxHP,0);
		Class'UIAPI_TEXTBOX'.SetText("OlympiadTargetWnd.txtHP","");
	}
}

function OnLButtonDown (WindowHandle a_WindowHandle, int X, int Y)
{
	local UserInfo Info;

	if ( GetUserInfo(m_id,Info) )
	{
		RequestAttack(m_id,Info.loc);
	}
}

function OnTimer (int TimerID)
{
	if ( UnknownFunction154(TimerID,4412) )
	{
		UnknownFunction166(OlyTime);
		if ( UnknownFunction152(OlyTime,0) )
		{
			Class'UIAPI_WINDOW'.KillUITimer("OlympiadTargetWnd",4412);
		}
		Class'UIAPI_TEXTBOX'.SetText("OlympiadTargetWnd.txtTime",UnknownFunction112(UnknownFunction112(string(UnknownFunction145(OlyTime,60)),":"),string(int(UnknownFunction173(OlyTime,60)))));
	}
}

