//================================================================================
// MainWnd.
//================================================================================

class MainWnd extends UIScript;

var ClanWnd ClanWndScript;

function OnLoad ()
{
	Class'UIAPI_WINDOW'.SetWindowTitle("MainWnd",433);
	ClanWndScript = ClanWnd(GetScript("ClanWnd"));
}

function OnHide ()
{
}

function OnMinimize ()
{
	local int Index;

	Index = Class'UIAPI_TABCTRL'.GetTopIndex("MainWnd.MainTabCtrl");
	if ( UnknownFunction154(Index,0) )
	{
		Class'UIAPI_WINDOW'.Iconize("MainWnd","L2UI_CH3.TABBUTTON.MainWndTabIcon1",194);
	} else {
		if ( UnknownFunction154(Index,1) )
		{
			Class'UIAPI_WINDOW'.Iconize("MainWnd","L2UI_CH3.TABBUTTON.MainWndTabIcon2",196);
		} else {
			if ( UnknownFunction154(Index,2) )
			{
				Class'UIAPI_WINDOW'.Iconize("MainWnd","L2UI_CH3.TABBUTTON.MainWndTabIcon3",197);
			} else {
				if ( UnknownFunction154(Index,3) )
				{
					Class'UIAPI_WINDOW'.Iconize("MainWnd","L2UI_CH3.TABBUTTON.MainWndTabIcon4",895);
				} else {
					if ( UnknownFunction154(Index,4) )
					{
						Class'UIAPI_WINDOW'.Iconize("MainWnd","L2UI_CH3.TABBUTTON.MainWndTabIcon5",198);
					}
				}
			}
		}
	}
	ClanWndScript.ResetOpeningVariables();
}

function OnClickButton (string strID)
{
	if ( UnknownFunction122(strID,"MainTabCtrl0") )
	{
		Class'UIAPI_WINDOW'.SetWindowTitle("MainWnd",433);
		Class'UIAPI_WINDOW'.HideWindow("ClanDrawerWnd");
		ClanWndScript.ResetOpeningVariables();
	} else {
		if ( UnknownFunction122(strID,"MainTabCtrl1") )
		{
			Class'UIAPI_WINDOW'.SetWindowTitle("MainWnd",119);
			Class'UIAPI_WINDOW'.HideWindow("ClanDrawerWnd");
			ClanWndScript.ResetOpeningVariables();
		} else {
			if ( UnknownFunction122(strID,"MainTabCtrl2") )
			{
				Class'UIAPI_WINDOW'.SetWindowTitle("MainWnd",127);
				Class'UIAPI_WINDOW'.HideWindow("ClanDrawerWnd");
				ClanWndScript.ResetOpeningVariables();
			} else {
				if ( UnknownFunction122(strID,"MainTabCtrl3") )
				{
					Class'UIAPI_WINDOW'.SetWindowTitle("MainWnd",439);
					ClanWndScript.getmyClanInfo();
					ClanWndScript.NoblessMenuValidate();
					ClanWndScript.ResetOpeningVariables();
				} else {
					if ( UnknownFunction122(strID,"MainTabCtrl4") )
					{
						Class'UIAPI_WINDOW'.HideWindow("ClanDrawerWnd");
						Class'UIAPI_WINDOW'.SetWindowTitle("MainWnd",118);
						ClanWndScript.ResetOpeningVariables();
					}
				}
			}
		}
	}
}

