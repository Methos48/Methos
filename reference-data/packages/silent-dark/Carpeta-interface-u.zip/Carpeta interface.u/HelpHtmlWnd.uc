//================================================================================
// HelpHtmlWnd.
//================================================================================

class HelpHtmlWnd extends UIScript;

var bool m_bShow;

function OnLoad ()
{
	RegisterState("HelpHtmlWnd","GamingState");
	RegisterState("HelpHtmlWnd","LoginState");
	RegisterEvent(1210);
	RegisterEvent(1220);
	m_bShow = False;
}

function OnShow ()
{
	m_bShow = True;
}

function OnHide ()
{
	m_bShow = False;
}

function OnEvent (int Event_ID, string param)
{
	if ( UnknownFunction154(Event_ID,1210) )
	{
		HandleShowHelp(param);
	} else {
		if ( UnknownFunction154(Event_ID,1220) )
		{
			HandleLoadHelpHtml(param);
		}
	}
}

function HandleShowHelp (string param)
{
	local string strPath;

	if ( m_bShow )
	{
		PlayConsoleSound(6);
		Class'UIAPI_WINDOW'.HideWindow("HelpHtmlWnd");
	} else {
		ParseString(param,"FilePath",strPath);
		if ( UnknownFunction151(UnknownFunction125(strPath),0) )
		{
			Class'UIAPI_HTMLCTRL'.LoadHtml("HelpHtmlWnd.HtmlViewer",strPath);
			PlayConsoleSound(5);
			Class'UIAPI_WINDOW'.ShowWindow("HelpHtmlWnd");
			Class'UIAPI_WINDOW'.SetFocus("HelpHtmlWnd");
		}
	}
}

function HandleLoadHelpHtml (string param)
{
	local string strHtml;

	ParseString(param,"HtmlString",strHtml);
	if ( UnknownFunction151(UnknownFunction125(strHtml),0) )
	{
		Class'UIAPI_HTMLCTRL'.LoadHtmlFromString("HelpHtmlWnd.HtmlViewer",strHtml);
	}
}

