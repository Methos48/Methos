//================================================================================
// UICommonAPI.
//================================================================================

class UICommonAPI extends UIScript;

var int Time;
var bool SuperRaceShop;
var int equippedItems[15];
struct MacroShortcut
{
	var int MacroID;
	var string MacroName;
	var int wnd;
	var int Shortcut;
};

struct BuffInfo
{
	var int Id;
	var string Name;
	var bool BuffInfo_Bool;
	var int BuffInfo_Int;
};

enum DialogDefaultAction {
	EDefaultNone,
	EDefaultOK,
	EDefaultCancel
};

enum EDialogType {
	DIALOG_OKCancel,
	DIALOG_OK,
	DIALOG_OKCancelInput,
	DIALOG_OKInput,
	DIALOG_Warning,
	DIALOG_Notice,
	DIALOG_NumberPad,
	DIALOG_Progress
};

const EV_HandleRadar_ShowHide= 11223344;
const EV_BeginTimerAlarnWnd= 19002;
const EV_UpdateAssist= 19500;
const EV_UpdateLang= 19000;
const EV_TargetShotdown= 2960;

function bool IsValidItemID (ItemInfo Id)
{
	if ( UnknownFunction130(UnknownFunction150(Id.ClassID,1),UnknownFunction150(Id.ServerID,1)) )
	{
		return False;
	}
	return True;
}

function DialogShow (EDialogType dialogType, string strMessage)
{
	local DialogBox script;

	script = DialogBox(GetScript("DialogBox"));
	script.ShowDialog(dialogType,strMessage,string(self));
}

function DialogHide ()
{
	local DialogBox script;

	script = DialogBox(GetScript("DialogBox"));
	script.HideDialog();
}

function DialogSetDefaultOK ()
{
	local DialogBox script;

	script = DialogBox(GetScript("DialogBox"));
	script.SetDefaultAction(1);
}

function bool DialogIsMine ()
{
	local DialogBox script;

	script = DialogBox(GetScript("DialogBox"));
	if ( UnknownFunction122(script.GetTarget(),string(self)) )
	{
		return True;
	}
	return False;
}

function DialogSetID (int Id)
{
	local DialogBox script;

	script = DialogBox(GetScript("DialogBox"));
	script.SetID(Id);
}

function DialogSetEditType (string strType)
{
	local DialogBox script;

	script = DialogBox(GetScript("DialogBox"));
	script.SetEditType(strType);
}

function string DialogGetString ()
{
	local DialogBox script;

	script = DialogBox(GetScript("DialogBox"));
	return script.GetEditMessage();
}

function DialogSetString (string strInput)
{
	local DialogBox script;

	script = DialogBox(GetScript("DialogBox"));
	script.SetEditMessage(strInput);
}

function int DialogGetID ()
{
	local DialogBox script;

	script = DialogBox(GetScript("DialogBox"));
	return script.GetID();
}

function DialogSetParamInt (int param)
{
	local DialogBox script;

	script = DialogBox(GetScript("DialogBox"));
	script.SetParamInt(param);
}

function DialogSetReservedInt (int Value)
{
	local DialogBox script;

	script = DialogBox(GetScript("DialogBox"));
	script.SetReservedInt(Value);
}

function DialogSetReservedInt2 (int Value)
{
	local DialogBox script;

	script = DialogBox(GetScript("DialogBox"));
	script.SetReservedInt2(Value);
}

function DialogSetReservedInt3 (int Value)
{
	local DialogBox script;

	script = DialogBox(GetScript("DialogBox"));
	script.SetReservedInt3(Value);
}

function int DialogGetReservedInt ()
{
	local DialogBox script;

	script = DialogBox(GetScript("DialogBox"));
	return script.GetReservedInt();
}

function int DialogGetReservedInt2 ()
{
	local DialogBox script;

	script = DialogBox(GetScript("DialogBox"));
	return script.GetReservedInt2();
}

function int DialogGetReservedInt3 ()
{
	local DialogBox script;

	script = DialogBox(GetScript("DialogBox"));
	return script.GetReservedInt3();
}

function DialogSetEditBoxMaxLength (int maxLength)
{
	local DialogBox script;

	script = DialogBox(GetScript("DialogBox"));
	script.SetEditBoxMaxLength(maxLength);
}

function int Split (string strInput, string delim, out array<string> arrToken)
{
	local int arrSize;

	if ( UnknownFunction151(UnknownFunction126(strInput,delim),0) )
	{
		byte(arrToken)
		arrToken.Length
		1
		arrToken[UnknownFunction147(arrToken.Length,1)] = UnknownFunction128(strInput,UnknownFunction126(strInput,delim));
		strInput = UnknownFunction127(strInput,UnknownFunction146(UnknownFunction126(strInput,delim),1));
		arrSize = UnknownFunction146(arrSize,1);
		goto JL0000;
	}
	byte(arrToken)
	arrToken.Length
	1
	arrToken[UnknownFunction147(arrToken.Length,1)] = strInput;
	arrSize = UnknownFunction146(arrSize,1);
	return arrSize;
}

function JoinArray (array<string> StringArray, out string out_Result, string delim, bool bIgnoreBlanks)
{
	local int i;
	local string S;

	i = 0;
	if ( UnknownFunction150(i,StringArray.Length) )
	{
		if ( UnknownFunction132(UnknownFunction123(StringArray[i],""),UnknownFunction129(bIgnoreBlanks)) )
		{
			if ( UnknownFunction123(S,"") )
			{
				S = UnknownFunction112(S,delim);
			}
			S = UnknownFunction112(S,StringArray[i]);
		}
		UnknownFunction165(i);
		goto JL0007;
	}
	out_Result = S;
}

function ShowWindow (string a_ControlID)
{
	Class'UIAPI_WINDOW'.ShowWindow(a_ControlID);
}

function ShowWindowWithFocus (string a_ControlID)
{
	Class'UIAPI_WINDOW'.ShowWindow(a_ControlID);
	Class'UIAPI_WINDOW'.SetFocus(a_ControlID);
}

function HideWindow (string a_ControlID)
{
	Class'UIAPI_WINDOW'.HideWindow(a_ControlID);
}

function bool IsShowWindow (string a_ControlID)
{
	return Class'UIAPI_WINDOW'.IsShowWindow(a_ControlID);
}

function ParamToItemInfo (string param, out ItemInfo Info)
{
	local int tmpInt;

	ParseInt(param,"classID",Info.ClassID);
	ParseInt(param,"level",Info.Level);
	ParseString(param,"name",Info.Name);
	ParseString(param,"additionalName",Info.AdditionalName);
	ParseString(param,"iconName",Info.IconName);
	ParseString(param,"description",Info.Description);
	ParseInt(param,"itemType",Info.ItemType);
	ParseInt(param,"serverID",Info.ServerID);
	ParseInt(param,"itemNum",Info.ItemNum);
	ParseInt(param,"slotBitType",Info.SlotBitType);
	ParseInt(param,"enchanted",Info.Enchanted);
	ParseInt(param,"blessed",Info.Blessed);
	ParseInt(param,"damaged",Info.Damaged);
	if ( ParseInt(param,"equipped",tmpInt) )
	{
		Info.bEquipped = bool(tmpInt);
	}
	ParseInt(param,"price",Info.Price);
	ParseInt(param,"reserved",Info.Reserved);
	ParseInt(param,"defaultPrice",Info.DefaultPrice);
	ParseInt(param,"refineryOp1",Info.RefineryOp1);
	ParseInt(param,"refineryOp2",Info.RefineryOp2);
	ParseInt(param,"currentDurability",Info.CurrentDurability);
	ParseInt(param,"weight",Info.Weight);
	ParseInt(param,"materialType",Info.MaterialType);
	ParseInt(param,"weaponType",Info.WeaponType);
	ParseInt(param,"physicalDamage",Info.PhysicalDamage);
	ParseInt(param,"magicalDamage",Info.MagicalDamage);
	ParseInt(param,"shieldDefense",Info.ShieldDefense);
	ParseInt(param,"shieldDefenseRate",Info.ShieldDefenseRate);
	ParseInt(param,"durability",Info.Durability);
	ParseInt(param,"crystalType",Info.CrystalType);
	ParseInt(param,"randomDamage",Info.RandomDamage);
	ParseInt(param,"critical",Info.Critical);
	ParseInt(param,"hitModify",Info.HitModify);
	ParseInt(param,"attackSpeed",Info.AttackSpeed);
	ParseInt(param,"mpConsume",Info.MpConsume);
	ParseInt(param,"avoidModify",Info.AvoidModify);
	ParseInt(param,"soulshotCount",Info.SoulshotCount);
	ParseInt(param,"spiritshotCount",Info.SpiritshotCount);
	ParseInt(param,"armorType",Info.ArmorType);
	ParseInt(param,"physicalDefense",Info.PhysicalDefense);
	ParseInt(param,"magicalDefense",Info.MagicalDefense);
	ParseInt(param,"mpBonus",Info.MpBonus);
	ParseInt(param,"consumeType",Info.ConsumeType);
	ParseInt(param,"ItemSubType",Info.ItemSubType);
	ParseString(param,"iconNameEx1",Info.IconNameEx1);
	ParseString(param,"iconNameEx2",Info.IconNameEx2);
	ParseString(param,"iconNameEx3",Info.IconNameEx3);
	ParseString(param,"iconNameEx4",Info.IconNameEx4);
	if ( ParseInt(param,"arrow",tmpInt) )
	{
		Info.bArrow = bool(tmpInt);
	}
	if ( ParseInt(param,"recipe",tmpInt) )
	{
		Info.bRecipe = bool(tmpInt);
	}
}

function ParamToRecord (string param, out LVDataRecord Record)
{
	local int idx;
	local int MaxColumn;

	ParseString(param,"szReserved",Record.szReserved);
	ParseInt(param,"nReserved1",Record.nReserved1);
	ParseInt(param,"nReserved2",Record.nReserved2);
	ParseInt(param,"nReserved3",Record.nReserved3);
	ParseInt(param,"MaxColumn",MaxColumn);
	Record.LVDataList.Length = MaxColumn;
	idx = 0;
	if ( UnknownFunction150(idx,MaxColumn) )
	{
		ParseString(param,UnknownFunction112("szData_",string(idx)),Record.LVDataList[idx].szData);
		ParseString(param,UnknownFunction112("szReserved_",string(idx)),Record.LVDataList[idx].szReserved);
		ParseInt(param,UnknownFunction112("nReserved1_",string(idx)),Record.LVDataList[idx].nReserved1);
		ParseInt(param,UnknownFunction112("nReserved2_",string(idx)),Record.LVDataList[idx].nReserved2);
		ParseInt(param,UnknownFunction112("nReserved3_",string(idx)),Record.LVDataList[idx].nReserved3);
		UnknownFunction165(idx);
		goto JL00B7;
	}
}

function CustomTooltip MakeTooltipSimpleText (string Text)
{
	local CustomTooltip ToolTip;
	local DrawItemInfo Info;

	ToolTip.DrawList.Length = 1;
	Info.eType = 1;
	Info.t_bDrawOneLine = True;
	Info.t_strText = Text;
	ToolTip.DrawList[0] = Info;
	return ToolTip;
}

function Debugg (string Msn, string Colors)
{
	local Color msnColor;

	switch (Colors)
	{
		case "Red":
		msnColor.R = 255;
		msnColor.G = 0;
		msnColor.B = 0;
		break;
		case "Green":
		msnColor.R = 0;
		msnColor.G = 255;
		msnColor.B = 0;
		break;
		case "Blue":
		msnColor.R = 0;
		msnColor.G = 0;
		msnColor.B = 255;
		break;
		case "Default":
		msnColor.R = 176;
		msnColor.G = 153;
		msnColor.B = 121;
		break;
		default:
	}
	AddSystemMessage(UnknownFunction112("Interface: ",Msn),msnColor);
}

function int GetSecond ()
{
	local array<string> arrSplit;
	local int SplitCount;
	local string strNodeName;
	local int strCount;

	strNodeName = GetTimeString();
	SplitCount = Split(strNodeName,":",arrSplit);
	if ( UnknownFunction151(SplitCount,0) )
	{
		strNodeName = arrSplit[2];
		strCount = int(strNodeName);
	}
	return strCount;
}

function SetSuperRaceShop (bool param)
{
	SuperRaceShop = param;
}

function bool GetSuperRaceShop ()
{
	return SuperRaceShop;
}

function string GetSuperRace (string Text)
{
	local string Result;
	local int SplitCount;
	local int i;
	local array<string> temp;
	local array<string> texttemp;

	temp.Length = 0;
	texttemp.Length = 0;
	SplitCount = Split(Text,",",texttemp);
	i = 0;
	if ( UnknownFunction152(i,texttemp.Length) )
	{
		temp[i] = UnknownFunction236(int(texttemp[i]));
		Result = UnknownFunction112(Result,temp[i]);
		UnknownFunction163(i);
		goto JL0030;
	}
	return Result;
}

function RefineryParam (int Id, out string ResultParam)
{
	local string param;

	switch (Id)
	{
		case 14578:
		param = "1,3,1,Winter,1";
		break;
		case 14579:
		param = "1,3,1,Agility,1";
		break;
		case 14580:
		param = "1,3,1,Bleed,1";
		break;
		case 14581:
		param = "1,3,1,Ritual,1";
		break;
		case 14582:
		param = "1,3,1,Stone,1";
		break;
		case 14583:
		param = "1,3,1,Fear,1";
		break;
		case 14584:
		param = "1,3,1,Prominence,1";
		break;
		case 14585:
		param = "1,3,1,Peace,1";
		break;
		case 14586:
		param = "1,3,3,Charm,1";
		break;
		case 14587:
		param = "1,3,1,Aggression,1";
		break;
		case 14588:
		param = "1,3,1,Guidance,1";
		break;
		case 14589:
		param = "1,3,1,Hold,1";
		break;
		case 14590:
		param = "1,3,1,Solar Flare,1";
		break;
		case 14591:
		param = "1,3,1,Heal Empower,1";
		break;
		case 14592:
		param = "1,3,1,Prayer,1";
		break;
		case 14593:
		param = "1,3,1,Heal,1";
		break;
		case 14594:
		param = "1,3,1,Empower,1";
		break;
		case 14595:
		param = "1,3,1,Cheer,1";
		break;
		case 14596:
		param = "1,3,1,Battle Roar,1";
		break;
		case 14597:
		param = "1,3,1,Blessed Body,1";
		break;
		case 14598:
		param = "1,3,1,Blessed Soul,1";
		break;
		case 14599:
		param = "1,3,1,Magic Barrier,1";
		break;
		case 14600:
		param = "1,3,1,Mana Burn,1";
		break;
		case 14601:
		param = "1,3,1,Mana Gain,1";
		break;
		case 14602:
		param = "1,3,1,Recharge,1";
		break;
		case 14603:
		param = "1,3,1,Aura Flare,1";
		break;
		case 14604:
		param = "1,3,1,Might,1";
		break;
		case 14605:
		param = "1,3,1,Paralyze,1";
		break;
		case 14606:
		param = "1,3,1,Shield,1";
		break;
		case 14607:
		param = "1,3,1,Poison,1";
		break;
		case 14608:
		param = "1,3,1,Duel Weakness,1";
		break;
		case 14609:
		param = "1,3,1,Duel Might,1";
		break;
		case 14610:
		param = "1,3,1,Recall,1";
		break;
		case 14611:
		param = "1,3,1,Resurrection,1";
		break;
		case 14612:
		param = "1,3,1,Self Stone,1";
		break;
		case 14613:
		param = "1,3,1,Self Prominence,1";
		break;
		case 14614:
		param = "1,3,1,Self Solar Flare,1";
		break;
		case 14615:
		param = "1,3,1,Self Aura Flare,1";
		break;
		case 14616:
		param = "1,3,1,Self Shadow Flare,1";
		break;
		case 14617:
		param = "1,3,1,Self Hydro Blast,1";
		break;
		case 14618:
		param = "1,3,1,Self Hurricane,1";
		break;
		case 14619:
		param = "1,3,1,Sleep,1";
		break;
		case 14620:
		param = "1,3,1,Slow,1";
		break;
		case 14621:
		param = "1,3,1,Stun,1";
		break;
		case 14622:
		param = "1,3,1,Ae Stone,1";
		break;
		case 14623:
		param = "1,3,1,Ae Prominence,1";
		break;
		case 14624:
		param = "1,3,1,Ae Solar Flare,1";
		break;
		case 14625:
		param = "1,3,1,Ae Aura Flare,1";
		break;
		case 14626:
		param = "1,3,1,Ae Shadow Flare,1";
		break;
		case 14627:
		param = "1,3,1,Ae Hydro Blast,1";
		break;
		case 14628:
		param = "1,3,1,Ae Hurricane,1";
		break;
		case 14629:
		param = "1,3,1,Trick,1";
		break;
		case 14630:
		param = "1,3,1,Medusa,1";
		break;
		case 14631:
		param = "1,3,1,Shadow Flare,1";
		break;
		case 14632:
		param = "1,3,1,Unlock,1";
		break;
		case 14633:
		param = "1,3,1,Vampiric Touch,1";
		break;
		case 14634:
		param = "1,3,1,Hydro Blast,1";
		break;
		case 14635:
		param = "1,3,1,Hurricane,1";
		break;
		case 14636:
		param = "1,3,3,Physical Winter,1";
		break;
		case 14637:
		param = "1,3,3,Physical Bleed,1";
		break;
		case 14638:
		param = "1,3,3,Physical Fear,1";
		break;
		case 14639:
		param = "1,3,3,Physical Hold,1";
		break;
		case 14640:
		param = "1,3,3,Physical Poison,1";
		break;
		case 14641:
		param = "1,3,3,Physical Medusa,1";
		break;
		case 14642:
		param = "1,3,3,Critical Winter,1";
		break;
		case 14643:
		param = "1,3,3,Critical Bleed,1";
		break;
		case 14644:
		param = "1,3,3,Critical Fear,1";
		break;
		case 14645:
		param = "1,3,3,Critical Hold,1";
		break;
		case 14646:
		param = "1,3,3,Critical Poison,1";
		break;
		case 14647:
		param = "1,3,3,Critical Medusa,1";
		break;
		case 14648:
		param = "1,3,3,Winter,1";
		break;
		case 14649:
		param = "1,3,3,Agility,1";
		break;
		case 14650:
		param = "1,3,3,Bleed,1";
		break;
		case 14651:
		param = "1,3,3,Ritual,1";
		break;
		case 14652:
		param = "1,3,3,Focus,1";
		break;
		case 14653:
		param = "1,3,3,Charm,1";
		break;
		case 14654:
		param = "1,3,3,Guidance,1";
		break;
		case 14655:
		param = "1,3,3,Hold,1";
		break;
		case 14656:
		param = "1,3,3,Prayer,1";
		break;
		case 14657:
		param = "1,3,3,Heal,1";
		break;
		case 14658:
		param = "1,3,3,Empower,1";
		break;
		case 14659:
		param = "1,3,3,Wild Magic,1";
		break;
		case 14660:
		param = "1,3,3,Cheer,1";
		break;
		case 14661:
		param = "1,3,3,Blessed Body,1";
		break;
		case 14662:
		param = "1,3,3,Blessed Soul,1";
		break;
		case 14663:
		param = "1,3,3,Magic Barrier,1";
		break;
		case 14664:
		param = "1,3,3,Might,1";
		break;
		case 14665:
		param = "1,3,3,Shield,1";
		break;
		case 14666:
		param = "1,3,3,Poison,1";
		break;
		case 14667:
		param = "1,3,3,Duel Weakness,1";
		break;
		case 14668:
		param = "1,3,3,Duel Might,1";
		break;
		case 14669:
		param = "1,3,3,Sleep,1";
		break;
		case 14670:
		param = "1,3,3,Slow,1";
		break;
		case 14671:
		param = "1,3,3,Magical Winter,1";
		break;
		case 14672:
		param = "1,3,3,Magical Bleed,1";
		break;
		case 14673:
		param = "1,3,3,Magical Fear,1";
		break;
		case 14674:
		param = "1,3,3,Magical Hold,1";
		break;
		case 14675:
		param = "1,3,3,Magical Poison,1";
		break;
		case 14676:
		param = "1,3,3,Magical Medusa,1";
		break;
		case 14677:
		param = "1,3,2,Heal Empower,1";
		break;
		case 14678:
		param = "1,3,2,Prayer,1";
		break;
		case 14679:
		param = "1,3,2,Empower,1";
		break;
		case 14680:
		param = "1,3,2,Magic Barrier,1";
		break;
		case 14681:
		param = "1,3,2,Might,1";
		break;
		case 14682:
		param = "1,3,2,Shield,1";
		break;
		case 14683:
		param = "1,3,2,Duel Might,1";
		break;
		case 14684:
		param = "1,3,2,Weight Limit,1";
		break;
		case 14685:
		param = "1,4,1,Focus,1";
		break;
		case 14686:
		param = "1,4,1,Focus,1";
		break;
		case 14687:
		param = "1,4,1,Focus,1";
		break;
		case 14688:
		param = "1,4,1,Focus,1";
		break;
		case 14689:
		param = "1,4,1,Doom,1";
		break;
		case 14690:
		param = "1,4,1,Recall,2";
		break;
		case 14691:
		param = "1,4,1,Celestial Shield,1";
		break;
		case 14692:
		param = "1,4,1,Wild Magic,1";
		break;
		case 14693:
		param = "1,4,1,Wild Magic,1";
		break;
		case 14694:
		param = "1,4,1,Silence,1";
		break;
		case 14695:
		param = "1,4,1,Wild Magic,1";
		break;
		case 14696:
		param = "1,4,1,Wild Magic,1";
		break;
		case 14697:
		param = "1,4,1,Silence,1";
		break;
		case 14698:
		param = "1,4,1,Silence,1";
		break;
		case 14699:
		param = "1,4,1,Silence,1";
		break;
		case 14700:
		param = "1,4,1,Silence,1";
		break;
		case 14701:
		param = "1,4,1,Silence,1";
		break;
		case 14702:
		param = "1,4,1,Vampiric Rage,1";
		break;
		case 14703:
		param = "1,4,3,Physical Doom,1";
		break;
		case 14704:
		param = "1,4,3,Physical Mana Burn,1";
		break;
		case 14705:
		param = "1,4,3,Physical Paralyze,1";
		break;
		case 14706:
		param = "1,4,3,Physical Silence,1";
		break;
		case 14707:
		param = "1,4,3,Physical Sleep,1";
		break;
		case 14708:
		param = "1,4,3,Physical Stun,1";
		break;
		case 14709:
		param = "1,4,3,Critical Doom,1";
		break;
		case 14710:
		param = "1,4,3,Critical Mana Burn,1";
		break;
		case 14711:
		param = "1,4,3,Critical Paralyze,1";
		break;
		case 14712:
		param = "1,4,3,Critical Silence,1";
		break;
		case 14713:
		param = "1,4,3,Critical Sleep,1";
		break;
		case 14714:
		param = "1,4,3,Critical Stun,1";
		break;
		case 14715:
		param = "1,4,3,Doom,1";
		break;
		case 14716:
		param = "1,4,3,Fear,1";
		break;
		case 14717:
		param = "1,4,3,Mana Gain,1";
		break;
		case 14718:
		param = "1,4,3,Recharge,1";
		break;
		case 14719:
		param = "1,4,3,Paralyze,1";
		break;
		case 14720:
		param = "1,4,3,Silence,1";
		break;
		case 14721:
		param = "1,4,3,Stun,1";
		break;
		case 14722:
		param = "1,4,3,Medusa,1";
		break;
		case 14723:
		param = "1,4,3,Magical Doom,1";
		break;
		case 14724:
		param = "1,4,3,Magical Mana Burn,1";
		break;
		case 14725:
		param = "1,4,3,Magical Paralyze,1";
		break;
		case 14726:
		param = "1,4,3,Magical Silence,1";
		break;
		case 14727:
		param = "1,4,3,Magical Sleep,1";
		break;
		case 14728:
		param = "1,4,3,Magical Stun,1";
		break;
		case 14729:
		param = "1,4,2,Agility,1";
		break;
		case 14730:
		param = "1,4,2,Agility,1";
		break;
		case 14731:
		param = "1,4,2,Focus,1";
		break;
		case 14732:
		param = "1,4,2,Focus,1";
		break;
		case 14733:
		param = "1,4,2,Guidance,1";
		break;
		case 14734:
		param = "1,4,2,Wild Magic,1";
		break;
		case 14735:
		param = "1,4,2,Mana Gain,1";
		break;
		case 14736:
		param = "1,4,2,Mana Gain,1";
		break;
		case 14737:
		param = "1,4,2,Mana Gain,1";
		break;
		case 14738:
		param = "1,4,2,Mana Gain,1";
		break;
		case 14756:
		param = "1,3,1,Winter,2";
		break;
		case 14757:
		param = "1,3,1,Agility,2";
		break;
		case 14758:
		param = "1,3,1,Bleed,2";
		break;
		case 14759:
		param = "1,3,1,Ritual,2";
		break;
		case 14760:
		param = "1,3,1,Stone,2";
		break;
		case 14761:
		param = "1,3,1,Fear,2";
		break;
		case 14762:
		param = "1,3,1,Prominence,2";
		break;
		case 14763:
		param = "1,3,1,Peace,2";
		break;
		case 14764:
		param = "1,3,1,Charm,2";
		break;
		case 14765:
		param = "1,3,1,Aggression,2";
		break;
		case 14766:
		param = "1,3,1,Guidance,2";
		break;
		case 14767:
		param = "1,3,1,Hold,2";
		break;
		case 14768:
		param = "1,3,1,Solar Flare,2";
		break;
		case 14769:
		param = "1,3,1,Heal Empower,2";
		break;
		case 14770:
		param = "1,3,1,Prayer,2";
		break;
		case 14771:
		param = "1,3,1,Heal,2";
		break;
		case 14772:
		param = "1,3,1,Empower,2";
		break;
		case 14773:
		param = "1,3,1,Cheer,2";
		break;
		case 14774:
		param = "1,3,1,Battle Roar,2";
		break;
		case 14775:
		param = "1,3,1,Blessed Body,2";
		break;
		case 14776:
		param = "1,3,1,Blessed Soul,2";
		break;
		case 14777:
		param = "1,3,1,Magic Barrier,2";
		break;
		case 14778:
		param = "1,3,1,Mana Burn,2";
		break;
		case 14779:
		param = "1,3,1,Mana Gain,2";
		break;
		case 14780:
		param = "1,3,1,Recharge,2";
		break;
		case 14781:
		param = "1,3,1,Aura Flare,2";
		break;
		case 14782:
		param = "1,3,1,Might,2";
		break;
		case 14783:
		param = "1,3,1,Paralyze,2";
		break;
		case 14784:
		param = "1,3,1,Shield,2";
		break;
		case 14785:
		param = "1,3,1,Poison,2";
		break;
		case 14786:
		param = "1,3,1,Duel Weakness,2";
		break;
		case 14787:
		param = "1,3,1,Duel Might,2";
		break;
		case 14788:
		param = "1,3,1,Recall,1";
		break;
		case 14789:
		param = "1,3,1,Resurrection,2";
		break;
		case 14790:
		param = "1,3,1,Self Stone,2";
		break;
		case 14791:
		param = "1,3,1,Self Prominence,2";
		break;
		case 14792:
		param = "1,3,1,Self Solar Flare,2";
		break;
		case 14793:
		param = "1,3,1,Self Aura Flare,2";
		break;
		case 14794:
		param = "1,3,1,Self Shadow Flare,2";
		break;
		case 14795:
		param = "1,3,1,Self Hydro Blast,2";
		break;
		case 14796:
		param = "1,3,1,Self Hurricane,2";
		break;
		case 14797:
		param = "1,3,1,Sleep,2";
		break;
		case 14798:
		param = "1,3,1,Slow,2";
		break;
		case 14799:
		param = "1,3,1,Stun,2";
		break;
		case 14800:
		param = "1,3,1,Ae Stone,2";
		break;
		case 14801:
		param = "1,3,1,Ae Prominence,2";
		break;
		case 14802:
		param = "1,3,1,Ae Solar Flare,2";
		break;
		case 14803:
		param = "1,3,1,Ae Aura Flare,2";
		break;
		case 14804:
		param = "1,3,1,Ae Shadow Flare,2";
		break;
		case 14805:
		param = "1,3,1,Ae Hydro Blast,2";
		break;
		case 14806:
		param = "1,3,1,Ae Hurricane,2";
		break;
		case 14807:
		param = "1,3,1,Trick,2";
		break;
		case 14808:
		param = "1,3,1,Medusa,2";
		break;
		case 14809:
		param = "1,3,1,Shadow Flare,2";
		break;
		case 14810:
		param = "1,3,1,Unlock,2";
		break;
		case 14811:
		param = "1,3,1,Vampiric Touch,2";
		break;
		case 14812:
		param = "1,3,1,Hydro Blast,2";
		break;
		case 14813:
		param = "1,3,1,Hurricane,2";
		break;
		case 14814:
		param = "1,3,3,Physical Winter,2";
		break;
		case 14815:
		param = "1,3,3,Physical Bleed,2";
		break;
		case 14816:
		param = "1,3,3,Physical Fear,2";
		break;
		case 14817:
		param = "1,3,3,Physical Hold,2";
		break;
		case 14818:
		param = "1,3,3,Physical Poison,2";
		break;
		case 14819:
		param = "1,3,3,Physical Medusa,2";
		break;
		case 14820:
		param = "1,3,3,Critical Winter,2";
		break;
		case 14821:
		param = "1,3,3,Critical Bleed,2";
		break;
		case 14822:
		param = "1,3,3,Critical Fear,2";
		break;
		case 14823:
		param = "1,3,3,Critical Hold,2";
		break;
		case 14824:
		param = "1,3,3,Critical Poison,2";
		break;
		case 14825:
		param = "1,3,3,Critical Medusa,2";
		break;
		case 14826:
		param = "1,3,3,Winter,2";
		break;
		case 14827:
		param = "1,3,3,Agility,2";
		break;
		case 14828:
		param = "1,3,3,Bleed,2";
		break;
		case 14829:
		param = "1,3,3,Ritual,2";
		break;
		case 14830:
		param = "1,3,3,Focus,2";
		break;
		case 14831:
		param = "1,3,3,Charm,2";
		break;
		case 14832:
		param = "1,3,3,Guidance,2";
		break;
		case 14833:
		param = "1,3,3,Hold,2";
		break;
		case 14834:
		param = "1,3,3,Prayer,2";
		break;
		case 14835:
		param = "1,3,3,Heal,2";
		break;
		case 14836:
		param = "1,3,3,Empower,2";
		break;
		case 14837:
		param = "1,3,3,Wild Magic,2";
		break;
		case 14838:
		param = "1,3,3,Cheer,2";
		break;
		case 14839:
		param = "1,3,3,Blessed Body,2";
		break;
		case 14840:
		param = "1,3,3,Blessed Soul,2";
		break;
		case 14841:
		param = "1,3,3,Magic Barrier,2";
		break;
		case 14842:
		param = "1,3,3,Might,2";
		break;
		case 14843:
		param = "1,3,3,Shield,2";
		break;
		case 14844:
		param = "1,3,3,Poison,2";
		break;
		case 14845:
		param = "1,3,3,Duel Weakness,2";
		break;
		case 14846:
		param = "1,3,3,Duel Might,2";
		break;
		case 14847:
		param = "1,3,3,Sleep,2";
		break;
		case 14848:
		param = "1,3,3,Slow,2";
		break;
		case 14849:
		param = "1,3,3,Magical Winter,2";
		break;
		case 14850:
		param = "1,3,3,Magical Bleed,2";
		break;
		case 14851:
		param = "1,3,3,Magical Fear,2";
		break;
		case 14852:
		param = "1,3,3,Magical Hold,2";
		break;
		case 14853:
		param = "1,3,3,Magical Poison,2";
		break;
		case 14854:
		param = "1,3,3,Magical Medusa,2";
		break;
		case 14855:
		param = "1,3,2,Heal Empower,2";
		break;
		case 14856:
		param = "1,3,2,Prayer,2";
		break;
		case 14857:
		param = "1,3,2,Empower,2";
		break;
		case 14858:
		param = "1,3,2,Magic Barrier,2";
		break;
		case 14859:
		param = "1,3,2,Might,2";
		break;
		case 14860:
		param = "1,3,2,Shield,2";
		break;
		case 14861:
		param = "1,3,2,Duel Might,2";
		break;
		case 14862:
		param = "1,3,2,Weight Limit,2";
		break;
		case 14863:
		param = "1,4,1,Focus,2";
		break;
		case 14864:
		param = "1,4,1,Focus,2";
		break;
		case 14865:
		param = "1,4,1,Focus,2";
		break;
		case 14866:
		param = "1,4,1,Focus,2";
		break;
		case 14867:
		param = "1,4,1,Doom,2";
		break;
		case 14868:
		param = "1,4,1,Recall,2";
		break;
		case 14869:
		param = "1,4,1,Celestial Shield,1";
		break;
		case 14870:
		param = "1,4,1,Wild Magic,2";
		break;
		case 14871:
		param = "1,4,1,Party Recall,1";
		break;
		case 14872:
		param = "1,4,1,Silence,2";
		break;
		case 14873:
		param = "1,4,1,Recall,2";
		break;
		case 14874:
		param = "1,4,1,Recall,2";
		break;
		case 14875:
		param = "1,4,1,Silence,2";
		break;
		case 14876:
		param = "1,4,1,Silence,2";
		break;
		case 14877:
		param = "1,4,1,Silence,2";
		break;
		case 14878:
		param = "1,4,1,Silence,2";
		break;
		case 14879:
		param = "1,4,1,Silence,2";
		break;
		case 14880:
		param = "1,4,1,Vampiric Rage,2";
		break;
		case 14881:
		param = "1,4,3,Physical Doom,2";
		break;
		case 14882:
		param = "1,4,3,Physical Mana Burn,2";
		break;
		case 14883:
		param = "1,4,3,Physical Paralyze,2";
		break;
		case 14884:
		param = "1,4,3,Physical Silence,2";
		break;
		case 14885:
		param = "1,4,3,Physical Sleep,2";
		break;
		case 14886:
		param = "1,4,3,Physical Stun,2";
		break;
		case 14887:
		param = "1,4,3,Critical Doom,2";
		break;
		case 14888:
		param = "1,4,3,Critical Mana Burn,2";
		break;
		case 14889:
		param = "1,4,3,Critical Paralyze,2";
		break;
		case 14890:
		param = "1,4,3,Critical Silence,2";
		break;
		case 14891:
		param = "1,4,3,Critical Sleep,2";
		break;
		case 14892:
		param = "1,4,3,Critical Stun,2";
		break;
		case 14893:
		param = "1,4,3,Doom,2";
		break;
		case 14894:
		param = "1,4,3,Fear,2";
		break;
		case 14895:
		param = "1,4,3,Mana Gain,2";
		break;
		case 14896:
		param = "1,4,3,Recharge,2";
		break;
		case 14897:
		param = "1,4,3,Paralyze,2";
		break;
		case 14898:
		param = "1,4,3,Silence,2";
		break;
		case 14899:
		param = "1,4,3,Stun,2";
		break;
		case 14900:
		param = "1,4,3,Medusa,2";
		break;
		case 14901:
		param = "1,4,3,Magical Doom,2";
		break;
		case 14902:
		param = "1,4,3,Magical Mana Burn,2";
		break;
		case 14903:
		param = "1,4,3,Magical Paralyze,2";
		break;
		case 14904:
		param = "1,4,3,Magical Silence,2";
		break;
		case 14905:
		param = "1,4,3,Magical Sleep,2";
		break;
		case 14906:
		param = "1,4,3,Magical Stun,2";
		break;
		case 14907:
		param = "1,4,2,Agility,2";
		break;
		case 14908:
		param = "1,4,2,Agility,2";
		break;
		case 14909:
		param = "1,4,2,Focus,2";
		break;
		case 14910:
		param = "1,4,2,Focus,2";
		break;
		case 14911:
		param = "1,4,2,Guidance,2";
		break;
		case 14912:
		param = "1,4,2,Wild Magic,2";
		break;
		case 14913:
		param = "1,4,2,Mana Gain,2";
		break;
		case 14914:
		param = "1,4,2,Mana Gain,2";
		break;
		case 14915:
		param = "1,4,2,Mana Gain,2";
		break;
		case 14916:
		param = "1,4,2,Mana Gain,2";
		break;
		case 14934:
		param = "1,3,1,Winter,3";
		break;
		case 14935:
		param = "1,3,1,Agility,3";
		break;
		case 14936:
		param = "1,3,1,Bleed,3";
		break;
		case 14937:
		param = "1,3,1,Ritual,3";
		break;
		case 14938:
		param = "1,3,1,Stone,3";
		break;
		case 14939:
		param = "1,3,1,Fear,3";
		break;
		case 14940:
		param = "1,3,1,Prominence,3";
		break;
		case 14941:
		param = "1,3,1,Peace,3";
		break;
		case 14942:
		param = "1,3,1,Charm,3";
		break;
		case 14943:
		param = "1,3,1,Aggression,3";
		break;
		case 14944:
		param = "1,3,1,Guidance,3";
		break;
		case 14945:
		param = "1,3,1,Hold,3";
		break;
		case 14946:
		param = "1,3,1,Solar Flare,3";
		break;
		case 14947:
		param = "1,3,1,Heal Empower,3";
		break;
		case 14948:
		param = "1,3,1,Prayer,3";
		break;
		case 14949:
		param = "1,3,1,Heal,3";
		break;
		case 14950:
		param = "1,3,1,Empower,3";
		break;
		case 14951:
		param = "1,3,1,Cheer,3";
		break;
		case 14952:
		param = "1,3,1,Battle Roar,3";
		break;
		case 14953:
		param = "1,3,1,Blessed Body,3";
		break;
		case 14954:
		param = "1,3,1,Blessed Soul,3";
		break;
		case 14955:
		param = "1,3,1,Magic Barrier,3";
		break;
		case 14956:
		param = "1,3,1,Mana Burn,3";
		break;
		case 14957:
		param = "1,3,1,Mana Gain,3";
		break;
		case 14958:
		param = "1,3,1,Recharge,3";
		break;
		case 14959:
		param = "1,3,1,Aura Flare,3";
		break;
		case 14960:
		param = "1,3,1,Might,3";
		break;
		case 14961:
		param = "1,3,1,Paralyze,3";
		break;
		case 14962:
		param = "1,3,1,Shield,3";
		break;
		case 14963:
		param = "1,3,1,Poison,3";
		break;
		case 14964:
		param = "1,3,1,Duel Weakness,3";
		break;
		case 14965:
		param = "1,3,1,Duel Might,3";
		break;
		case 14966:
		param = "1,3,1,Recall,1";
		break;
		case 14967:
		param = "1,3,1,Resurrection,3";
		break;
		case 14968:
		param = "1,3,1,Self Stone,3";
		break;
		case 14969:
		param = "1,3,1,Self Prominence,3";
		break;
		case 14970:
		param = "1,3,1,Self Solar Flare,3";
		break;
		case 14971:
		param = "1,3,1,Self Aura Flare,3";
		break;
		case 14972:
		param = "1,3,1,Self Shadow Flare,3";
		break;
		case 14973:
		param = "1,3,1,Self Hydro Blast,3";
		break;
		case 14974:
		param = "1,3,1,Self Hurricane,3";
		break;
		case 14975:
		param = "1,3,1,Sleep,3";
		break;
		case 14976:
		param = "1,3,1,Slow,3";
		break;
		case 14977:
		param = "1,3,1,Stun,3";
		break;
		case 14978:
		param = "1,3,1,Ae Stone,3";
		break;
		case 14979:
		param = "1,3,1,Ae Prominence,3";
		break;
		case 14980:
		param = "1,3,1,Ae Solar Flare,3";
		break;
		case 14981:
		param = "1,3,1,Ae Aura Flare,3";
		break;
		case 14982:
		param = "1,3,1,Ae Shadow Flare,3";
		break;
		case 14983:
		param = "1,3,1,Ae Hydro Blast,3";
		break;
		case 14984:
		param = "1,3,1,Ae Hurricane,3";
		break;
		case 14985:
		param = "1,3,1,Trick,3";
		break;
		case 14986:
		param = "1,3,1,Medusa,3";
		break;
		case 14987:
		param = "1,3,1,Shadow Flare,3";
		break;
		case 14988:
		param = "1,3,1,Unlock,3";
		break;
		case 14989:
		param = "1,3,1,Vampiric Touch,3";
		break;
		case 14990:
		param = "1,3,1,Hydro Blast,3";
		break;
		case 14991:
		param = "1,3,1,Hurricane,3";
		break;
		case 14992:
		param = "1,3,3,Physical Winter,3";
		break;
		case 14993:
		param = "1,3,3,Physical Bleed,3";
		break;
		case 14994:
		param = "1,3,3,Physical Fear,3";
		break;
		case 14995:
		param = "1,3,3,Physical Hold,3";
		break;
		case 14996:
		param = "1,3,3,Physical Poison,3";
		break;
		case 14997:
		param = "1,3,3,Physical Medusa,3";
		break;
		case 14998:
		param = "1,3,3,Critical Winter,3";
		break;
		case 14999:
		param = "1,3,3,Critical Bleed,3";
		break;
		case 15000:
		param = "1,3,3,Critical Fear,3";
		break;
		case 15001:
		param = "1,3,3,Critical Hold,3";
		break;
		case 15002:
		param = "1,3,3,Critical Poison,3";
		break;
		case 15003:
		param = "1,3,3,Critical Medusa,3";
		break;
		case 15004:
		param = "1,3,3,Winter,3";
		break;
		case 15005:
		param = "1,3,3,Agility,3";
		break;
		case 15006:
		param = "1,3,3,Bleed,3";
		break;
		case 15007:
		param = "1,3,3,Ritual,3";
		break;
		case 15008:
		param = "1,3,3,Focus,3";
		break;
		case 15009:
		param = "1,3,3,Charm,3";
		break;
		case 15010:
		param = "1,3,3,Guidance,3";
		break;
		case 15011:
		param = "1,3,3,Hold,3";
		break;
		case 15012:
		param = "1,3,3,Prayer,3";
		break;
		case 15013:
		param = "1,3,3,Heal,3";
		break;
		case 15014:
		param = "1,3,3,Empower,3";
		break;
		case 15015:
		param = "1,3,3,Wild Magic,3";
		break;
		case 15016:
		param = "1,3,3,Cheer,3";
		break;
		case 15017:
		param = "1,3,3,Blessed Body,3";
		break;
		case 15018:
		param = "1,3,3,Blessed Soul,3";
		break;
		case 15019:
		param = "1,3,3,Magic Barrier,3";
		break;
		case 15020:
		param = "1,3,3,Might,3";
		break;
		case 15021:
		param = "1,3,3,Shield,3";
		break;
		case 15022:
		param = "1,3,3,Poison,3";
		break;
		case 15023:
		param = "1,3,3,Duel Weakness,3";
		break;
		case 15024:
		param = "1,3,3,Duel Might,3";
		break;
		case 15025:
		param = "1,3,3,Sleep,3";
		break;
		case 15026:
		param = "1,3,3,Slow,3";
		break;
		case 15027:
		param = "1,3,3,Magical Winter,3";
		break;
		case 15028:
		param = "1,3,3,Magical Bleed,3";
		break;
		case 15029:
		param = "1,3,3,Magical Fear,3";
		break;
		case 15030:
		param = "1,3,3,Magical Hold,3";
		break;
		case 15031:
		param = "1,3,3,Magical Poison,3";
		break;
		case 15032:
		param = "1,3,3,Magical Medusa,3";
		break;
		case 15033:
		param = "1,3,2,Heal Empower,3";
		break;
		case 15034:
		param = "1,3,2,Prayer,3";
		break;
		case 15035:
		param = "1,3,2,Empower,3";
		break;
		case 15036:
		param = "1,3,2,Magic Barrier,3";
		break;
		case 15037:
		param = "1,3,2,Might,3";
		break;
		case 15038:
		param = "1,3,2,Shield,3";
		break;
		case 15039:
		param = "1,3,2,Duel Might,3";
		break;
		case 15040:
		param = "1,3,2,Weight Limit,3";
		break;
		case 15041:
		param = "1,4,1,Focus,3";
		break;
		case 15042:
		param = "1,4,1,Focus,3";
		break;
		case 15043:
		param = "1,4,1,Focus,3";
		break;
		case 15044:
		param = "1,4,1,Focus,3";
		break;
		case 15045:
		param = "1,4,1,Doom,3";
		break;
		case 15046:
		param = "1,4,1,Recall,2";
		break;
		case 15047:
		param = "1,4,1,Celestial Shield,1";
		break;
		case 15048:
		param = "1,4,1,Wild Magic,3";
		break;
		case 15049:
		param = "1,4,1,Party Recall,1";
		break;
		case 15050:
		param = "1,4,1,Silence,3";
		break;
		case 15051:
		param = "1,4,1,Party Recall,1";
		break;
		case 15052:
		param = "1,4,1,Party Recall,1";
		break;
		case 15053:
		param = "1,4,1,Party Recall,1";
		break;
		case 15054:
		param = "1,4,1,Silence,3";
		break;
		case 15055:
		param = "1,4,1,Silence,3";
		break;
		case 15056:
		param = "1,4,1,Silence,3";
		break;
		case 15057:
		param = "1,4,1,Silence,3";
		break;
		case 15058:
		param = "1,4,1,Vampiric Rage,3";
		break;
		case 15059:
		param = "1,4,3,Physical Doom,3";
		break;
		case 15060:
		param = "1,4,3,Physical Mana Burn,3";
		break;
		case 15061:
		param = "1,4,3,Physical Paralyze,3";
		break;
		case 15062:
		param = "1,4,3,Physical Silence,3";
		break;
		case 15063:
		param = "1,4,3,Physical Sleep,3";
		break;
		case 15064:
		param = "1,4,3,Physical Stun,3";
		break;
		case 15065:
		param = "1,4,3,Critical Doom,3";
		break;
		case 15066:
		param = "1,4,3,Critical Mana Burn,3";
		break;
		case 15067:
		param = "1,4,3,Critical Paralyze,3";
		break;
		case 15068:
		param = "1,4,3,Critical Silence,3";
		break;
		case 15069:
		param = "1,4,3,Critical Sleep,3";
		break;
		case 15070:
		param = "1,4,3,Critical Stun,3";
		break;
		case 15071:
		param = "1,4,3,Doom,3";
		break;
		case 15072:
		param = "1,4,3,Fear,3";
		break;
		case 15073:
		param = "1,4,3,Mana Gain,3";
		break;
		case 15074:
		param = "1,4,3,Recharge,3";
		break;
		case 15075:
		param = "1,4,3,Paralyze,3";
		break;
		case 15076:
		param = "1,4,3,Silence,3";
		break;
		case 15077:
		param = "1,4,3,Stun,3";
		break;
		case 15078:
		param = "1,4,3,Medusa,3";
		break;
		case 15079:
		param = "1,4,3,Magical Doom,3";
		break;
		case 15080:
		param = "1,4,3,Magical Mana Burn,3";
		break;
		case 15081:
		param = "1,4,3,Magical Paralyze,3";
		break;
		case 15082:
		param = "1,4,3,Magical Silence,3";
		break;
		case 15083:
		param = "1,4,3,Magical Sleep,3";
		break;
		case 15084:
		param = "1,4,3,Magical Stun,3";
		break;
		case 15085:
		param = "1,4,2,Agility,3";
		break;
		case 15086:
		param = "1,4,2,Agility,3";
		break;
		case 15087:
		param = "1,4,2,Focus,3";
		break;
		case 15088:
		param = "1,4,2,Focus,3";
		break;
		case 15089:
		param = "1,4,2,Guidance,3";
		break;
		case 15090:
		param = "1,4,2,Wild Magic,3";
		break;
		case 15091:
		param = "1,4,2,Mana Gain,3";
		break;
		case 15092:
		param = "1,4,2,Mana Gain,3";
		break;
		case 15093:
		param = "1,4,2,Mana Gain,3";
		break;
		case 15094:
		param = "1,4,2,Mana Gain,3";
		break;
		case 15112:
		param = "1,3,1,Winter,4";
		break;
		case 15113:
		param = "1,3,1,Agility,4";
		break;
		case 15114:
		param = "1,3,1,Bleed,4";
		break;
		case 15115:
		param = "1,3,1,Ritual,4";
		break;
		case 15116:
		param = "1,3,1,Stone,4";
		break;
		case 15117:
		param = "1,3,1,Fear,4";
		break;
		case 15118:
		param = "1,3,1,Prominence,4";
		break;
		case 15119:
		param = "1,3,1,Peace,4";
		break;
		case 15120:
		param = "1,3,1,Charm,4";
		break;
		case 15121:
		param = "1,3,1,Aggression,4";
		break;
		case 15122:
		param = "1,3,1,Guidance,4";
		break;
		case 15123:
		param = "1,3,1,Hold,4";
		break;
		case 15124:
		param = "1,3,1,Solar Flare,4";
		break;
		case 15125:
		param = "1,3,1,Heal Empower,4";
		break;
		case 15126:
		param = "1,3,1,Prayer,4";
		break;
		case 15127:
		param = "1,3,1,Heal,4";
		break;
		case 15128:
		param = "1,3,1,Empower,4";
		break;
		case 15129:
		param = "1,3,1,Cheer,4";
		break;
		case 15130:
		param = "1,3,1,Battle Roar,4";
		break;
		case 15131:
		param = "1,3,1,Blessed Body,4";
		break;
		case 15132:
		param = "1,3,1,Blessed Soul,4";
		break;
		case 15133:
		param = "1,3,1,Magic Barrier,4";
		break;
		case 15134:
		param = "1,3,1,Mana Burn,4";
		break;
		case 15135:
		param = "1,3,1,Mana Gain,4";
		break;
		case 15136:
		param = "1,3,1,Recharge,4";
		break;
		case 15137:
		param = "1,3,1,Aura Flare,4";
		break;
		case 15138:
		param = "1,3,1,Might,4";
		break;
		case 15139:
		param = "1,3,1,Paralyze,4";
		break;
		case 15140:
		param = "1,3,1,Shield,4";
		break;
		case 15141:
		param = "1,3,1,Poison,4";
		break;
		case 15142:
		param = "1,3,1,Duel Weakness,4";
		break;
		case 15143:
		param = "1,3,1,Duel Might,4";
		break;
		case 15144:
		param = "1,3,1,Recall,1";
		break;
		case 15145:
		param = "1,3,1,Resurrection,4";
		break;
		case 15146:
		param = "1,3,1,Self Stone,4";
		break;
		case 15147:
		param = "1,3,1,Self Prominence,4";
		break;
		case 15148:
		param = "1,3,1,Self Solar Flare,4";
		break;
		case 15149:
		param = "1,3,1,Self Aura Flare,4";
		break;
		case 15150:
		param = "1,3,1,Self Shadow Flare,4";
		break;
		case 15151:
		param = "1,3,1,Self Hydro Blast,4";
		break;
		case 15152:
		param = "1,3,1,Self Hurricane,4";
		break;
		case 15153:
		param = "1,3,1,Sleep,4";
		break;
		case 15154:
		param = "1,3,1,Slow,4";
		break;
		case 15155:
		param = "1,3,1,Stun,4";
		break;
		case 15156:
		param = "1,3,1,Ae Stone,4";
		break;
		case 15157:
		param = "1,3,1,Ae Prominence,4";
		break;
		case 15158:
		param = "1,3,1,Ae Solar Flare,4";
		break;
		case 15159:
		param = "1,3,1,Ae Aura Flare,4";
		break;
		case 15160:
		param = "1,3,1,Ae Shadow Flare,4";
		break;
		case 15161:
		param = "1,3,1,Ae Hydro Blast,4";
		break;
		case 15162:
		param = "1,3,1,Ae Hurricane,4";
		break;
		case 15163:
		param = "1,3,1,Trick,4";
		break;
		case 15164:
		param = "1,3,1,Medusa,4";
		break;
		case 15165:
		param = "1,3,1,Shadow Flare,4";
		break;
		case 15166:
		param = "1,3,1,Unlock,4";
		break;
		case 15167:
		param = "1,3,1,Vampiric Touch,4";
		break;
		case 15168:
		param = "1,3,1,Hydro Blast,4";
		break;
		case 15169:
		param = "1,3,1,Hurricane,4";
		break;
		case 15170:
		param = "1,3,3,Physical Winter,4";
		break;
		case 15171:
		param = "1,3,3,Physical Bleed,4";
		break;
		case 15172:
		param = "1,3,3,Physical Fear,4";
		break;
		case 15173:
		param = "1,3,3,Physical Hold,4";
		break;
		case 15174:
		param = "1,3,3,Physical Poison,4";
		break;
		case 15175:
		param = "1,3,3,Physical Medusa,4";
		break;
		case 15176:
		param = "1,3,3,Critical Winter,4";
		break;
		case 15177:
		param = "1,3,3,Critical Bleed,4";
		break;
		case 15178:
		param = "1,3,3,Critical Fear,4";
		break;
		case 15179:
		param = "1,3,3,Critical Hold,4";
		break;
		case 15180:
		param = "1,3,3,Critical Poison,4";
		break;
		case 15181:
		param = "1,3,3,Critical Medusa,4";
		break;
		case 15182:
		param = "1,3,3,Winter,4";
		break;
		case 15183:
		param = "1,3,3,Agility,4";
		break;
		case 15184:
		param = "1,3,3,Bleed,4";
		break;
		case 15185:
		param = "1,3,3,Ritual,4";
		break;
		case 15186:
		param = "1,3,3,Focus,4";
		break;
		case 15187:
		param = "1,3,3,Charm,4";
		break;
		case 15188:
		param = "1,3,3,Guidance,4";
		break;
		case 15189:
		param = "1,3,3,Hold,4";
		break;
		case 15190:
		param = "1,3,3,Prayer,4";
		break;
		case 15191:
		param = "1,3,3,Heal,4";
		break;
		case 15192:
		param = "1,3,3,Empower,4";
		break;
		case 15193:
		param = "1,3,3,Wild Magic,4";
		break;
		case 15194:
		param = "1,3,3,Cheer,4";
		break;
		case 15195:
		param = "1,3,3,Blessed Body,4";
		break;
		case 15196:
		param = "1,3,3,Blessed Soul,4";
		break;
		case 15197:
		param = "1,3,3,Magic Barrier,4";
		break;
		case 15198:
		param = "1,3,3,Might,4";
		break;
		case 15199:
		param = "1,3,3,Shield,4";
		break;
		case 15200:
		param = "1,3,3,Poison,4";
		break;
		case 15201:
		param = "1,3,3,Duel Weakness,4";
		break;
		case 15202:
		param = "1,3,3,Duel Might,4";
		break;
		case 15203:
		param = "1,3,3,Sleep,4";
		break;
		case 15204:
		param = "1,3,3,Slow,4";
		break;
		case 15205:
		param = "1,3,3,Magical Winter,4";
		break;
		case 15206:
		param = "1,3,3,Magical Bleed,4";
		break;
		case 15207:
		param = "1,3,3,Magical Fear,4";
		break;
		case 15208:
		param = "1,3,3,Magical Hold,4";
		break;
		case 15209:
		param = "1,3,3,Magical Poison,4";
		break;
		case 15210:
		param = "1,3,3,Magical Medusa,4";
		break;
		case 15211:
		param = "1,3,2,Heal Empower,4";
		break;
		case 15212:
		param = "1,3,2,Prayer,4";
		break;
		case 15213:
		param = "1,3,2,Empower,4";
		break;
		case 15214:
		param = "1,3,2,Magic Barrier,4";
		break;
		case 15215:
		param = "1,3,2,Might,4";
		break;
		case 15216:
		param = "1,3,2,Shield,4";
		break;
		case 15217:
		param = "1,3,2,Duel Might,4";
		break;
		case 15218:
		param = "1,3,2,Weight Limit,4";
		break;
		case 15219:
		param = "1,4,1,Refresh,1";
		break;
		case 15220:
		param = "1,4,1,Clarity,1";
		break;
		case 15221:
		param = "1,4,1,Focus,4";
		break;
		case 15222:
		param = "1,4,1,Reflect Damage,1";
		break;
		case 15223:
		param = "1,4,1,Doom,4";
		break;
		case 15224:
		param = "1,4,1,Recall,2";
		break;
		case 15225:
		param = "1,4,1,Celestial Shield,1";
		break;
		case 15226:
		param = "1,4,1,Wild Magic,4";
		break;
		case 15227:
		param = "1,4,1,Party Recall,1";
		break;
		case 15228:
		param = "1,4,1,Silence,4";
		break;
		case 15229:
		param = "1,4,1,Skill Refresh,1";
		break;
		case 15230:
		param = "1,4,1,Skill Clarity,1";
		break;
		case 15231:
		param = "1,4,1,Music Refresh,1";
		break;
		case 15232:
		param = "1,4,1,Music Clarity,1";
		break;
		case 15233:
		param = "1,4,1,Spell Refresh,1";
		break;
		case 15234:
		param = "1,4,1,Spell Clarity,1";
		break;
		case 15235:
		param = "1,4,1,Spell Clarity,1";
		break;
		case 15236:
		param = "1,4,1,Vampiric Rage,4";
		break;
		case 15237:
		param = "1,4,3,Physical Doom,4";
		break;
		case 15238:
		param = "1,4,3,Physical Mana Burn,4";
		break;
		case 15239:
		param = "1,4,3,Physical Paralyze,4";
		break;
		case 15240:
		param = "1,4,3,Physical Silence,4";
		break;
		case 15241:
		param = "1,4,3,Physical Sleep,4";
		break;
		case 15242:
		param = "1,4,3,Physical Stun,4";
		break;
		case 15243:
		param = "1,4,3,Critical Doom,4";
		break;
		case 15244:
		param = "1,4,3,Critical Mana Burn,4";
		break;
		case 15245:
		param = "1,4,3,Critical Paralyze,4";
		break;
		case 15246:
		param = "1,4,3,Critical Silence,4";
		break;
		case 15247:
		param = "1,4,3,Critical Sleep,4";
		break;
		case 15248:
		param = "1,4,3,Critical Stun,4";
		break;
		case 15249:
		param = "1,4,3,Doom,4";
		break;
		case 15250:
		param = "1,4,3,Fear,4";
		break;
		case 15251:
		param = "1,4,3,Mana Gain,4";
		break;
		case 15252:
		param = "1,4,3,Recharge,4";
		break;
		case 15253:
		param = "1,4,3,Paralyze,4";
		break;
		case 15254:
		param = "1,4,3,Silence,4";
		break;
		case 15255:
		param = "1,4,3,Stun,4";
		break;
		case 15256:
		param = "1,4,3,Medusa,4";
		break;
		case 15257:
		param = "1,4,3,Magical Doom,4";
		break;
		case 15258:
		param = "1,4,3,Magical Mana Burn,4";
		break;
		case 15259:
		param = "1,4,3,Magical Paralyze,4";
		break;
		case 15260:
		param = "1,4,3,Magical Silence,4";
		break;
		case 15261:
		param = "1,4,3,Magical Sleep,4";
		break;
		case 15262:
		param = "1,4,3,Magical Stun,4";
		break;
		case 15263:
		param = "1,4,2,Clarity,1";
		break;
		case 15264:
		param = "1,4,2,Agility,4";
		break;
		case 15265:
		param = "1,4,2,Focus,4";
		break;
		case 15266:
		param = "1,4,2,Reflect Damage,1";
		break;
		case 15267:
		param = "1,4,2,Guidance,4";
		break;
		case 15268:
		param = "1,4,2,Wild Magic,4";
		break;
		case 15269:
		param = "1,4,2,Mana Gain,4";
		break;
		case 15270:
		param = "1,4,2,Skill Clarity,1";
		break;
		case 15271:
		param = "1,4,2,Music Clarity,1";
		break;
		case 15272:
		param = "1,4,2,Spell Clarity,1";
		break;
		case 15290:
		param = "1,3,1,Winter,5";
		break;
		case 15291:
		param = "1,3,1,Agility,5";
		break;
		case 15292:
		param = "1,3,1,Bleed,5";
		break;
		case 15293:
		param = "1,3,1,Ritual,5";
		break;
		case 15294:
		param = "1,3,1,Stone,5";
		break;
		case 15295:
		param = "1,3,1,Fear,5";
		break;
		case 15296:
		param = "1,3,1,Prominence,5";
		break;
		case 15297:
		param = "1,3,1,Peace,5";
		break;
		case 15298:
		param = "1,3,1,Charm,5";
		break;
		case 15299:
		param = "1,3,1,Aggression,5";
		break;
		case 15300:
		param = "1,3,1,Guidance,5";
		break;
		case 15301:
		param = "1,3,1,Hold,5";
		break;
		case 15302:
		param = "1,3,1,Solar Flare,5";
		break;
		case 15303:
		param = "1,3,1,Heal Empower,5";
		break;
		case 15304:
		param = "1,3,1,Prayer,5";
		break;
		case 15305:
		param = "1,3,1,Heal,5";
		break;
		case 15306:
		param = "1,3,1,Empower,5";
		break;
		case 15307:
		param = "1,3,1,Cheer,5";
		break;
		case 15308:
		param = "1,3,1,Battle Roar,5";
		break;
		case 15309:
		param = "1,3,1,Blessed Body,5";
		break;
		case 15310:
		param = "1,3,1,Blessed Soul,5";
		break;
		case 15311:
		param = "1,3,1,Magic Barrier,5";
		break;
		case 15312:
		param = "1,3,1,Mana Burn,5";
		break;
		case 15313:
		param = "1,3,1,Mana Gain,5";
		break;
		case 15314:
		param = "1,3,1,Recharge,5";
		break;
		case 15315:
		param = "1,3,1,Aura Flare,5";
		break;
		case 15316:
		param = "1,3,1,Might,5";
		break;
		case 15317:
		param = "1,3,1,Paralyze,5";
		break;
		case 15318:
		param = "1,3,1,Shield,5";
		break;
		case 15319:
		param = "1,3,1,Poison,5";
		break;
		case 15320:
		param = "1,3,1,Duel Weakness,5";
		break;
		case 15321:
		param = "1,3,1,Duel Might,5";
		break;
		case 15322:
		param = "1,3,1,Recall,1";
		break;
		case 15323:
		param = "1,3,1,Resurrection,5";
		break;
		case 15324:
		param = "1,3,1,Self Stone,5";
		break;
		case 15325:
		param = "1,3,1,Self Prominence,5";
		break;
		case 15326:
		param = "1,3,1,Self Solar Flare,5";
		break;
		case 15327:
		param = "1,3,1,Self Aura Flare,5";
		break;
		case 15328:
		param = "1,3,1,Self Shadow Flare,5";
		break;
		case 15329:
		param = "1,3,1,Self Hydro Blast,5";
		break;
		case 15330:
		param = "1,3,1,Self Hurricane,5";
		break;
		case 15331:
		param = "1,3,1,Sleep,5";
		break;
		case 15332:
		param = "1,3,1,Slow,5";
		break;
		case 15333:
		param = "1,3,1,Stun,5";
		break;
		case 15334:
		param = "1,3,1,Ae Stone,5";
		break;
		case 15335:
		param = "1,3,1,Ae Prominence,5";
		break;
		case 15336:
		param = "1,3,1,Ae Solar Flare,5";
		break;
		case 15337:
		param = "1,3,1,Ae Aura Flare,5";
		break;
		case 15338:
		param = "1,3,1,Ae Shadow Flare,5";
		break;
		case 15339:
		param = "1,3,1,Ae Hydro Blast,5";
		break;
		case 15340:
		param = "1,3,1,Ae Hurricane,5";
		break;
		case 15341:
		param = "1,3,1,Trick,5";
		break;
		case 15342:
		param = "1,3,1,Medusa,5";
		break;
		case 15343:
		param = "1,3,1,Shadow Flare,5";
		break;
		case 15344:
		param = "1,3,1,Unlock,5";
		break;
		case 15345:
		param = "1,3,1,Vampiric Touch,5";
		break;
		case 15346:
		param = "1,3,1,Hydro Blast,5";
		break;
		case 15347:
		param = "1,3,1,Hurricane,5";
		break;
		case 15348:
		param = "1,3,3,Physical Winter,5";
		break;
		case 15349:
		param = "1,3,3,Physical Bleed,5";
		break;
		case 15350:
		param = "1,3,3,Physical Fear,5";
		break;
		case 15351:
		param = "1,3,3,Physical Hold,5";
		break;
		case 15352:
		param = "1,3,3,Physical Poison,5";
		break;
		case 15353:
		param = "1,3,3,Physical Medusa,5";
		break;
		case 15354:
		param = "1,3,3,Critical Winter,5";
		break;
		case 15355:
		param = "1,3,3,Critical Bleed,5";
		break;
		case 15356:
		param = "1,3,3,Critical Fear,5";
		break;
		case 15357:
		param = "1,3,3,Critical Hold,5";
		break;
		case 15358:
		param = "1,3,3,Critical Poison,5";
		break;
		case 15359:
		param = "1,3,3,Critical Medusa,5";
		break;
		case 15360:
		param = "1,3,3,Winter,5";
		break;
		case 15361:
		param = "1,3,3,Agility,5";
		break;
		case 15362:
		param = "1,3,3,Bleed,5";
		break;
		case 15363:
		param = "1,3,3,Ritual,5";
		break;
		case 15364:
		param = "1,3,3,Focus,5";
		break;
		case 15365:
		param = "1,3,3,Charm,5";
		break;
		case 15366:
		param = "1,3,3,Guidance,5";
		break;
		case 15367:
		param = "1,3,3,Hold,5";
		break;
		case 15368:
		param = "1,3,3,Prayer,5";
		break;
		case 15369:
		param = "1,3,3,Heal,5";
		break;
		case 15370:
		param = "1,3,3,Empower,5";
		break;
		case 15371:
		param = "1,3,3,Wild Magic,5";
		break;
		case 15372:
		param = "1,3,3,Cheer,5";
		break;
		case 15373:
		param = "1,3,3,Blessed Body,5";
		break;
		case 15374:
		param = "1,3,3,Blessed Soul,5";
		break;
		case 15375:
		param = "1,3,3,Magic Barrier,5";
		break;
		case 15376:
		param = "1,3,3,Might,5";
		break;
		case 15377:
		param = "1,3,3,Shield,5";
		break;
		case 15378:
		param = "1,3,3,Poison,5";
		break;
		case 15379:
		param = "1,3,3,Duel Weakness,5";
		break;
		case 15380:
		param = "1,3,3,Duel Might,5";
		break;
		case 15381:
		param = "1,3,3,Sleep,5";
		break;
		case 15382:
		param = "1,3,3,Slow,5";
		break;
		case 15383:
		param = "1,3,3,Magical Winter,5";
		break;
		case 15384:
		param = "1,3,3,Magical Bleed,5";
		break;
		case 15385:
		param = "1,3,3,Magical Fear,5";
		break;
		case 15386:
		param = "1,3,3,Magical Hold,5";
		break;
		case 15387:
		param = "1,3,3,Magical Poison,5";
		break;
		case 15388:
		param = "1,3,3,Magical Medusa,5";
		break;
		case 15389:
		param = "1,3,2,Heal Empower,5";
		break;
		case 15390:
		param = "1,3,2,Prayer,5";
		break;
		case 15391:
		param = "1,3,2,Empower,5";
		break;
		case 15392:
		param = "1,3,2,Magic Barrier,5";
		break;
		case 15393:
		param = "1,3,2,Might,5";
		break;
		case 15394:
		param = "1,3,2,Shield,5";
		break;
		case 15395:
		param = "1,3,2,Duel Might,5";
		break;
		case 15396:
		param = "1,3,2,Weight Limit,5";
		break;
		case 15397:
		param = "1,4,1,Refresh,1";
		break;
		case 15398:
		param = "1,4,1,Clarity,1";
		break;
		case 15399:
		param = "1,4,1,Focus,5";
		break;
		case 15400:
		param = "1,4,1,Reflect Damage,1";
		break;
		case 15401:
		param = "1,4,1,Doom,5";
		break;
		case 15402:
		param = "1,4,1,Recall,2";
		break;
		case 15403:
		param = "1,4,1,Celestial Shield,1";
		break;
		case 15404:
		param = "1,4,1,Wild Magic,5";
		break;
		case 15405:
		param = "1,4,1,Party Recall,2";
		break;
		case 15406:
		param = "1,4,1,Silence,5";
		break;
		case 15407:
		param = "1,4,1,Skill Refresh,1";
		break;
		case 15408:
		param = "1,4,1,Skill Clarity,1";
		break;
		case 15409:
		param = "1,4,1,Music Refresh,1";
		break;
		case 15410:
		param = "1,4,1,Music Clarity,1";
		break;
		case 15411:
		param = "1,4,1,Spell Refresh,1";
		break;
		case 15412:
		param = "1,4,1,Spell Clarity,1";
		break;
		case 15413:
		param = "1,4,1,Stealth,1";
		break;
		case 15414:
		param = "1,4,1,Vampiric Rage,5";
		break;
		case 15415:
		param = "1,4,3,Physical Doom,5";
		break;
		case 15416:
		param = "1,4,3,Physical Mana Burn,5";
		break;
		case 15417:
		param = "1,4,3,Physical Paralyze,5";
		break;
		case 15418:
		param = "1,4,3,Physical Silence,5";
		break;
		case 15419:
		param = "1,4,3,Physical Sleep,5";
		break;
		case 15420:
		param = "1,4,3,Physical Stun,5";
		break;
		case 15421:
		param = "1,4,3,Critical Doom,5";
		break;
		case 15422:
		param = "1,4,3,Critical Mana Burn,5";
		break;
		case 15423:
		param = "1,4,3,Critical Paralyze,5";
		break;
		case 15424:
		param = "1,4,3,Critical Silence,5";
		break;
		case 15425:
		param = "1,4,3,Critical Sleep,5";
		break;
		case 15426:
		param = "1,4,3,Critical Stun,5";
		break;
		case 15427:
		param = "1,4,3,Doom,5";
		break;
		case 15428:
		param = "1,4,3,Fear,5";
		break;
		case 15429:
		param = "1,4,3,Mana Gain,5";
		break;
		case 15430:
		param = "1,4,3,Recharge,5";
		break;
		case 15431:
		param = "1,4,3,Paralyze,5";
		break;
		case 15432:
		param = "1,4,3,Silence,5";
		break;
		case 15433:
		param = "1,4,3,Stun,5";
		break;
		case 15434:
		param = "1,4,3,Medusa,5";
		break;
		case 15435:
		param = "1,4,3,Magical Doom,5";
		break;
		case 15436:
		param = "1,4,3,Magical Mana Burn,5";
		break;
		case 15437:
		param = "1,4,3,Magical Paralyze,5";
		break;
		case 15438:
		param = "1,4,3,Magical Silence,5";
		break;
		case 15439:
		param = "1,4,3,Magical Sleep,5";
		break;
		case 15440:
		param = "1,4,3,Magical Stun,5";
		break;
		case 15441:
		param = "1,4,2,Clarity,1";
		break;
		case 15442:
		param = "1,4,2,Agility,5";
		break;
		case 15443:
		param = "1,4,2,Focus,5";
		break;
		case 15444:
		param = "1,4,2,Reflect Damage,1";
		break;
		case 15445:
		param = "1,4,2,Guidance,5";
		break;
		case 15446:
		param = "1,4,2,Wild Magic,5";
		break;
		case 15447:
		param = "1,4,2,Mana Gain,5";
		break;
		case 15448:
		param = "1,4,2,Skill Clarity,1";
		break;
		case 15449:
		param = "1,4,2,Music Clarity,1";
		break;
		case 15450:
		param = "1,4,2,Spell Clarity,1";
		break;
		case 15468:
		param = "1,3,1,Winter,6";
		break;
		case 15469:
		param = "1,3,1,Agility,6";
		break;
		case 15470:
		param = "1,3,1,Bleed,6";
		break;
		case 15471:
		param = "1,3,1,Ritual,6";
		break;
		case 15472:
		param = "1,3,1,Stone,6";
		break;
		case 15473:
		param = "1,3,1,Fear,6";
		break;
		case 15474:
		param = "1,3,1,Prominence,6";
		break;
		case 15475:
		param = "1,3,1,Peace,6";
		break;
		case 15476:
		param = "1,3,1,Charm,6";
		break;
		case 15477:
		param = "1,3,1,Aggression,6";
		break;
		case 15478:
		param = "1,3,1,Guidance,6";
		break;
		case 15479:
		param = "1,3,1,Hold,6";
		break;
		case 15480:
		param = "1,3,1,Solar Flare,6";
		break;
		case 15481:
		param = "1,3,1,Heal Empower,6";
		break;
		case 15482:
		param = "1,3,1,Prayer,6";
		break;
		case 15483:
		param = "1,3,1,Heal,6";
		break;
		case 15484:
		param = "1,3,1,Empower,6";
		break;
		case 15485:
		param = "1,3,1,Cheer,6";
		break;
		case 15486:
		param = "1,3,1,Battle Roar,6";
		break;
		case 15487:
		param = "1,3,1,Blessed Body,6";
		break;
		case 15488:
		param = "1,3,1,Blessed Soul,6";
		break;
		case 15489:
		param = "1,3,1,Magic Barrier,6";
		break;
		case 15490:
		param = "1,3,1,Mana Burn,6";
		break;
		case 15491:
		param = "1,3,1,Mana Gain,6";
		break;
		case 15492:
		param = "1,3,1,Recharge,6";
		break;
		case 15493:
		param = "1,3,1,Aura Flare,6";
		break;
		case 15494:
		param = "1,3,1,Might,6";
		break;
		case 15495:
		param = "1,3,1,Paralyze,6";
		break;
		case 15496:
		param = "1,3,1,Shield,6";
		break;
		case 15497:
		param = "1,3,1,Poison,6";
		break;
		case 15498:
		param = "1,3,1,Duel Weakness,6";
		break;
		case 15499:
		param = "1,3,1,Duel Might,6";
		break;
		case 15500:
		param = "1,3,1,Recall,1";
		break;
		case 15501:
		param = "1,3,1,Resurrection,6";
		break;
		case 15502:
		param = "1,3,1,Self Stone,6";
		break;
		case 15503:
		param = "1,3,1,Self Prominence,6";
		break;
		case 15504:
		param = "1,3,1,Self Solar Flare,6";
		break;
		case 15505:
		param = "1,3,1,Self Aura Flare,6";
		break;
		case 15506:
		param = "1,3,1,Self Shadow Flare,6";
		break;
		case 15507:
		param = "1,3,1,Self Hydro Blast,6";
		break;
		case 15508:
		param = "1,3,1,Self Hurricane,6";
		break;
		case 15509:
		param = "1,3,1,Sleep,6";
		break;
		case 15510:
		param = "1,3,1,Slow,6";
		break;
		case 15511:
		param = "1,3,1,Stun,6";
		break;
		case 15512:
		param = "1,3,1,Ae Stone,6";
		break;
		case 15513:
		param = "1,3,1,Ae Prominence,6";
		break;
		case 15514:
		param = "1,3,1,Ae Solar Flare,6";
		break;
		case 15515:
		param = "1,3,1,Ae Aura Flare,6";
		break;
		case 15516:
		param = "1,3,1,Ae Shadow Flare,6";
		break;
		case 15517:
		param = "1,3,1,Ae Hydro Blast,6";
		break;
		case 15518:
		param = "1,3,1,Ae Hurricane,6";
		break;
		case 15519:
		param = "1,3,1,Trick,6";
		break;
		case 15520:
		param = "1,3,1,Medusa,6";
		break;
		case 15521:
		param = "1,3,1,Shadow Flare,6";
		break;
		case 15522:
		param = "1,3,1,Unlock,6";
		break;
		case 15523:
		param = "1,3,1,Vampiric Touch,6";
		break;
		case 15524:
		param = "1,3,1,Hydro Blast,6";
		break;
		case 15525:
		param = "1,3,1,Hurricane,6";
		break;
		case 15526:
		param = "1,3,3,Physical Winter,6";
		break;
		case 15527:
		param = "1,3,3,Physical Bleed,6";
		break;
		case 15528:
		param = "1,3,3,Physical Fear,6";
		break;
		case 15529:
		param = "1,3,3,Physical Hold,6";
		break;
		case 15530:
		param = "1,3,3,Physical Poison,6";
		break;
		case 15531:
		param = "1,3,3,Physical Medusa,6";
		break;
		case 15532:
		param = "1,3,3,Critical Winter,6";
		break;
		case 15533:
		param = "1,3,3,Critical Bleed,6";
		break;
		case 15534:
		param = "1,3,3,Critical Fear,6";
		break;
		case 15535:
		param = "1,3,3,Critical Hold,6";
		break;
		case 15536:
		param = "1,3,3,Critical Poison,6";
		break;
		case 15537:
		param = "1,3,3,Critical Medusa,6";
		break;
		case 15538:
		param = "1,3,3,Winter,6";
		break;
		case 15539:
		param = "1,3,3,Agility,6";
		break;
		case 15540:
		param = "1,3,3,Bleed,6";
		break;
		case 15541:
		param = "1,3,3,Ritual,6";
		break;
		case 15542:
		param = "1,3,3,Focus,6";
		break;
		case 15543:
		param = "1,3,3,Charm,6";
		break;
		case 15544:
		param = "1,3,3,Guidance,6";
		break;
		case 15545:
		param = "1,3,3,Hold,6";
		break;
		case 15546:
		param = "1,3,3,Prayer,6";
		break;
		case 15547:
		param = "1,3,3,Heal,6";
		break;
		case 15548:
		param = "1,3,3,Empower,6";
		break;
		case 15549:
		param = "1,3,3,Wild Magic,6";
		break;
		case 15550:
		param = "1,3,3,Cheer,6";
		break;
		case 15551:
		param = "1,3,3,Blessed Body,6";
		break;
		case 15552:
		param = "1,3,3,Blessed Soul,6";
		break;
		case 15553:
		param = "1,3,3,Magic Barrier,6";
		break;
		case 15554:
		param = "1,3,3,Might,6";
		break;
		case 15555:
		param = "1,3,3,Shield,6";
		break;
		case 15556:
		param = "1,3,3,Poison,6";
		break;
		case 15557:
		param = "1,3,3,Duel Weakness,6";
		break;
		case 15558:
		param = "1,3,3,Duel Might,6";
		break;
		case 15559:
		param = "1,3,3,Sleep,6";
		break;
		case 15560:
		param = "1,3,3,Slow,6";
		break;
		case 15561:
		param = "1,3,3,Magical Winter,6";
		break;
		case 15562:
		param = "1,3,3,Magical Bleed,6";
		break;
		case 15563:
		param = "1,3,3,Magical Fear,6";
		break;
		case 15564:
		param = "1,3,3,Magical Hold,6";
		break;
		case 15565:
		param = "1,3,3,Magical Poison,6";
		break;
		case 15566:
		param = "1,3,3,Magical Medusa,6";
		break;
		case 15567:
		param = "1,3,2,Heal Empower,6";
		break;
		case 15568:
		param = "1,3,2,Prayer,6";
		break;
		case 15569:
		param = "1,3,2,Empower,6";
		break;
		case 15570:
		param = "1,3,2,Magic Barrier,6";
		break;
		case 15571:
		param = "1,3,2,Might,6";
		break;
		case 15572:
		param = "1,3,2,Shield,6";
		break;
		case 15573:
		param = "1,3,2,Duel Might,6";
		break;
		case 15574:
		param = "1,3,2,Weight Limit,6";
		break;
		case 15575:
		param = "1,4,1,Refresh,1";
		break;
		case 15576:
		param = "1,4,1,Clarity,1";
		break;
		case 15577:
		param = "1,4,1,Focus,6";
		break;
		case 15578:
		param = "1,4,1,Reflect Damage,1";
		break;
		case 15579:
		param = "1,4,1,Doom,6";
		break;
		case 15580:
		param = "1,4,1,Recall,2";
		break;
		case 15581:
		param = "1,4,1,Celestial Shield,1";
		break;
		case 15582:
		param = "1,4,1,Wild Magic,6";
		break;
		case 15583:
		param = "1,4,1,Party Recall,2";
		break;
		case 15584:
		param = "1,4,1,Silence,6";
		break;
		case 15585:
		param = "1,4,1,Skill Refresh,1";
		break;
		case 15586:
		param = "1,4,1,Skill Clarity,1";
		break;
		case 15587:
		param = "1,4,1,Music Refresh,1";
		break;
		case 15588:
		param = "1,4,1,Music Clarity,1";
		break;
		case 15589:
		param = "1,4,1,Spell Refresh,1";
		break;
		case 15590:
		param = "1,4,1,Spell Clarity,1";
		break;
		case 15591:
		param = "1,4,1,Stealth,1";
		break;
		case 15592:
		param = "1,4,1,Vampiric Rage,6";
		break;
		case 15593:
		param = "1,4,3,Physical Doom,6";
		break;
		case 15594:
		param = "1,4,3,Physical Mana Burn,6";
		break;
		case 15595:
		param = "1,4,3,Physical Paralyze,6";
		break;
		case 15596:
		param = "1,4,3,Physical Silence,6";
		break;
		case 15597:
		param = "1,4,3,Physical Sleep,6";
		break;
		case 15598:
		param = "1,4,3,Physical Stun,6";
		break;
		case 15599:
		param = "1,4,3,Critical Doom,6";
		break;
		case 15600:
		param = "1,4,3,Critical Mana Burn,6";
		break;
		case 15601:
		param = "1,4,3,Critical Paralyze,6";
		break;
		case 15602:
		param = "1,4,3,Critical Silence,6";
		break;
		case 15603:
		param = "1,4,3,Critical Sleep,6";
		break;
		case 15604:
		param = "1,4,3,Critical Stun,6";
		break;
		case 15605:
		param = "1,4,3,Doom,6";
		break;
		case 15606:
		param = "1,4,3,Fear,6";
		break;
		case 15607:
		param = "1,4,3,Mana Gain,6";
		break;
		case 15608:
		param = "1,4,3,Recharge,6";
		break;
		case 15609:
		param = "1,4,3,Paralyze,6";
		break;
		case 15610:
		param = "1,4,3,Silence,6";
		break;
		case 15611:
		param = "1,4,3,Stun,6";
		break;
		case 15612:
		param = "1,4,3,Medusa,6";
		break;
		case 15613:
		param = "1,4,3,Magical Doom,6";
		break;
		case 15614:
		param = "1,4,3,Magical Mana Burn,6";
		break;
		case 15615:
		param = "1,4,3,Magical Paralyze,6";
		break;
		case 15616:
		param = "1,4,3,Magical Silence,6";
		break;
		case 15617:
		param = "1,4,3,Magical Sleep,6";
		break;
		case 15618:
		param = "1,4,3,Magical Stun,6";
		break;
		case 15619:
		param = "1,4,2,Clarity,1";
		break;
		case 15620:
		param = "1,4,2,Agility,6";
		break;
		case 15621:
		param = "1,4,2,Focus,6";
		break;
		case 15622:
		param = "1,4,2,Reflect Damage,1";
		break;
		case 15623:
		param = "1,4,2,Guidance,6";
		break;
		case 15624:
		param = "1,4,2,Wild Magic,6";
		break;
		case 15625:
		param = "1,4,2,Mana Gain,6";
		break;
		case 15626:
		param = "1,4,2,Skill Clarity,1";
		break;
		case 15627:
		param = "1,4,2,Music Clarity,1";
		break;
		case 15628:
		param = "1,4,2,Spell Clarity,1";
		break;
		case 15646:
		param = "1,3,1,Winter,7";
		break;
		case 15647:
		param = "1,3,1,Agility,7";
		break;
		case 15648:
		param = "1,3,1,Bleed,7";
		break;
		case 15649:
		param = "1,3,1,Ritual,7";
		break;
		case 15650:
		param = "1,3,1,Stone,7";
		break;
		case 15651:
		param = "1,3,1,Fear,7";
		break;
		case 15652:
		param = "1,3,1,Prominence,7";
		break;
		case 15653:
		param = "1,3,1,Peace,7";
		break;
		case 15654:
		param = "1,3,1,Charm,7";
		break;
		case 15655:
		param = "1,3,1,Aggression,7";
		break;
		case 15656:
		param = "1,3,1,Guidance,7";
		break;
		case 15657:
		param = "1,3,1,Hold,7";
		break;
		case 15658:
		param = "1,3,1,Solar Flare,7";
		break;
		case 15659:
		param = "1,3,1,Heal Empower,7";
		break;
		case 15660:
		param = "1,3,1,Prayer,7";
		break;
		case 15661:
		param = "1,3,1,Heal,7";
		break;
		case 15662:
		param = "1,3,1,Empower,7";
		break;
		case 15663:
		param = "1,3,1,Cheer,7";
		break;
		case 15664:
		param = "1,3,1,Battle Roar,7";
		break;
		case 15665:
		param = "1,3,1,Blessed Body,7";
		break;
		case 15666:
		param = "1,3,1,Blessed Soul,7";
		break;
		case 15667:
		param = "1,3,1,Magic Barrier,7";
		break;
		case 15668:
		param = "1,3,1,Mana Burn,7";
		break;
		case 15669:
		param = "1,3,1,Mana Gain,7";
		break;
		case 15670:
		param = "1,3,1,Recharge,7";
		break;
		case 15671:
		param = "1,3,1,Aura Flare,7";
		break;
		case 15672:
		param = "1,3,1,Might,7";
		break;
		case 15673:
		param = "1,3,1,Paralyze,7";
		break;
		case 15674:
		param = "1,3,1,Shield,7";
		break;
		case 15675:
		param = "1,3,1,Poison,7";
		break;
		case 15676:
		param = "1,3,1,Duel Weakness,7";
		break;
		case 15677:
		param = "1,3,1,Duel Might,7";
		break;
		case 15678:
		param = "1,3,1,Recall,1";
		break;
		case 15679:
		param = "1,3,1,Resurrection,7";
		break;
		case 15680:
		param = "1,3,1,Self Stone,7";
		break;
		case 15681:
		param = "1,3,1,Self Prominence,7";
		break;
		case 15682:
		param = "1,3,1,Self Solar Flare,7";
		break;
		case 15683:
		param = "1,3,1,Self Aura Flare,7";
		break;
		case 15684:
		param = "1,3,1,Self Shadow Flare,7";
		break;
		case 15685:
		param = "1,3,1,Self Hydro Blast,7";
		break;
		case 15686:
		param = "1,3,1,Self Hurricane,7";
		break;
		case 15687:
		param = "1,3,1,Sleep,7";
		break;
		case 15688:
		param = "1,3,1,Slow,7";
		break;
		case 15689:
		param = "1,3,1,Stun,7";
		break;
		case 15690:
		param = "1,3,1,Ae Stone,7";
		break;
		case 15691:
		param = "1,3,1,Ae Prominence,7";
		break;
		case 15692:
		param = "1,3,1,Ae Solar Flare,7";
		break;
		case 15693:
		param = "1,3,1,Ae Aura Flare,7";
		break;
		case 15694:
		param = "1,3,1,Ae Shadow Flare,7";
		break;
		case 15695:
		param = "1,3,1,Ae Hydro Blast,7";
		break;
		case 15696:
		param = "1,3,1,Ae Hurricane,7";
		break;
		case 15697:
		param = "1,3,1,Trick,7";
		break;
		case 15698:
		param = "1,3,1,Medusa,7";
		break;
		case 15699:
		param = "1,3,1,Shadow Flare,7";
		break;
		case 15700:
		param = "1,3,1,Unlock,7";
		break;
		case 15701:
		param = "1,3,1,Vampiric Touch,7";
		break;
		case 15702:
		param = "1,3,1,Hydro Blast,7";
		break;
		case 15703:
		param = "1,3,1,Hurricane,7";
		break;
		case 15704:
		param = "1,3,3,Physical Winter,7";
		break;
		case 15705:
		param = "1,3,3,Physical Bleed,7";
		break;
		case 15706:
		param = "1,3,3,Physical Fear,7";
		break;
		case 15707:
		param = "1,3,3,Physical Hold,7";
		break;
		case 15708:
		param = "1,3,3,Physical Poison,7";
		break;
		case 15709:
		param = "1,3,3,Physical Medusa,7";
		break;
		case 15710:
		param = "1,3,3,Critical Winter,7";
		break;
		case 15711:
		param = "1,3,3,Critical Bleed,7";
		break;
		case 15712:
		param = "1,3,3,Critical Fear,7";
		break;
		case 15713:
		param = "1,3,3,Critical Hold,7";
		break;
		case 15714:
		param = "1,3,3,Critical Poison,7";
		break;
		case 15715:
		param = "1,3,3,Critical Medusa,7";
		break;
		case 15716:
		param = "1,3,3,Winter,7";
		break;
		case 15717:
		param = "1,3,3,Agility,7";
		break;
		case 15718:
		param = "1,3,3,Bleed,7";
		break;
		case 15719:
		param = "1,3,3,Ritual,7";
		break;
		case 15720:
		param = "1,3,3,Focus,7";
		break;
		case 15721:
		param = "1,3,3,Charm,7";
		break;
		case 15722:
		param = "1,3,3,Guidance,7";
		break;
		case 15723:
		param = "1,3,3,Hold,7";
		break;
		case 15724:
		param = "1,3,3,Prayer,7";
		break;
		case 15725:
		param = "1,3,3,Heal,7";
		break;
		case 15726:
		param = "1,3,3,Empower,7";
		break;
		case 15727:
		param = "1,3,3,Wild Magic,7";
		break;
		case 15728:
		param = "1,3,3,Cheer,7";
		break;
		case 15729:
		param = "1,3,3,Blessed Body,7";
		break;
		case 15730:
		param = "1,3,3,Blessed Soul,7";
		break;
		case 15731:
		param = "1,3,3,Magic Barrier,7";
		break;
		case 15732:
		param = "1,3,3,Might,7";
		break;
		case 15733:
		param = "1,3,3,Shield,7";
		break;
		case 15734:
		param = "1,3,3,Poison,7";
		break;
		case 15735:
		param = "1,3,3,Duel Weakness,7";
		break;
		case 15736:
		param = "1,3,3,Duel Might,7";
		break;
		case 15737:
		param = "1,3,3,Sleep,7";
		break;
		case 15738:
		param = "1,3,3,Slow,7";
		break;
		case 15739:
		param = "1,3,3,Magical Winter,7";
		break;
		case 15740:
		param = "1,3,3,Magical Bleed,7";
		break;
		case 15741:
		param = "1,3,3,Magical Fear,7";
		break;
		case 15742:
		param = "1,3,3,Magical Hold,7";
		break;
		case 15743:
		param = "1,3,3,Magical Poison,7";
		break;
		case 15744:
		param = "1,3,3,Magical Medusa,7";
		break;
		case 15745:
		param = "1,3,2,Heal Empower,7";
		break;
		case 15746:
		param = "1,3,2,Prayer,7";
		break;
		case 15747:
		param = "1,3,2,Empower,7";
		break;
		case 15748:
		param = "1,3,2,Magic Barrier,7";
		break;
		case 15749:
		param = "1,3,2,Might,7";
		break;
		case 15750:
		param = "1,3,2,Shield,7";
		break;
		case 15751:
		param = "1,3,2,Duel Might,7";
		break;
		case 15752:
		param = "1,3,2,Weight Limit,7";
		break;
		case 15753:
		param = "1,4,1,Refresh,2";
		break;
		case 15754:
		param = "1,4,1,Clarity,2";
		break;
		case 15755:
		param = "1,4,1,Focus,7";
		break;
		case 15756:
		param = "1,4,1,Reflect Damage,2";
		break;
		case 15757:
		param = "1,4,1,Doom,7";
		break;
		case 15758:
		param = "1,4,1,Recall,2";
		break;
		case 15759:
		param = "1,4,1,Celestial Shield,1";
		break;
		case 15760:
		param = "1,4,1,Wild Magic,7";
		break;
		case 15761:
		param = "1,4,1,Party Recall,2";
		break;
		case 15762:
		param = "1,4,1,Silence,7";
		break;
		case 15763:
		param = "1,4,1,Skill Refresh,2";
		break;
		case 15764:
		param = "1,4,1,Skill Clarity,2";
		break;
		case 15765:
		param = "1,4,1,Music Refresh,2";
		break;
		case 15766:
		param = "1,4,1,Music Clarity,2";
		break;
		case 15767:
		param = "1,4,1,Spell Refresh,2";
		break;
		case 15768:
		param = "1,4,1,Spell Clarity,2";
		break;
		case 15769:
		param = "1,4,1,Stealth,1";
		break;
		case 15770:
		param = "1,4,1,Vampiric Rage,7";
		break;
		case 15771:
		param = "1,4,3,Physical Doom,7";
		break;
		case 15772:
		param = "1,4,3,Physical Mana Burn,7";
		break;
		case 15773:
		param = "1,4,3,Physical Paralyze,7";
		break;
		case 15774:
		param = "1,4,3,Physical Silence,7";
		break;
		case 15775:
		param = "1,4,3,Physical Sleep,7";
		break;
		case 15776:
		param = "1,4,3,Physical Stun,7";
		break;
		case 15777:
		param = "1,4,3,Critical Doom,7";
		break;
		case 15778:
		param = "1,4,3,Critical Mana Burn,7";
		break;
		case 15779:
		param = "1,4,3,Critical Paralyze,7";
		break;
		case 15780:
		param = "1,4,3,Critical Silence,7";
		break;
		case 15781:
		param = "1,4,3,Critical Sleep,7";
		break;
		case 15782:
		param = "1,4,3,Critical Stun,7";
		break;
		case 15783:
		param = "1,4,3,Doom,7";
		break;
		case 15784:
		param = "1,4,3,Fear,7";
		break;
		case 15785:
		param = "1,4,3,Mana Gain,7";
		break;
		case 15786:
		param = "1,4,3,Recharge,7";
		break;
		case 15787:
		param = "1,4,3,Paralyze,7";
		break;
		case 15788:
		param = "1,4,3,Silence,7";
		break;
		case 15789:
		param = "1,4,3,Stun,7";
		break;
		case 15790:
		param = "1,4,3,Medusa,7";
		break;
		case 15791:
		param = "1,4,3,Magical Doom,7";
		break;
		case 15792:
		param = "1,4,3,Magical Mana Burn,7";
		break;
		case 15793:
		param = "1,4,3,Magical Paralyze,7";
		break;
		case 15794:
		param = "1,4,3,Magical Silence,7";
		break;
		case 15795:
		param = "1,4,3,Magical Sleep,7";
		break;
		case 15796:
		param = "1,4,3,Magical Stun,7";
		break;
		case 15797:
		param = "1,4,2,Clarity,2";
		break;
		case 15798:
		param = "1,4,2,Agility,7";
		break;
		case 15799:
		param = "1,4,2,Focus,7";
		break;
		case 15800:
		param = "1,4,2,Reflect Damage,2";
		break;
		case 15801:
		param = "1,4,2,Guidance,7";
		break;
		case 15802:
		param = "1,4,2,Wild Magic,7";
		break;
		case 15803:
		param = "1,4,2,Mana Gain,7";
		break;
		case 15804:
		param = "1,4,2,Skill Clarity,2";
		break;
		case 15805:
		param = "1,4,2,Music Clarity,2";
		break;
		case 15806:
		param = "1,4,2,Spell Clarity,2";
		break;
		case 15824:
		param = "1,3,1,Winter,8";
		break;
		case 15825:
		param = "1,3,1,Agility,8";
		break;
		case 15826:
		param = "1,3,1,Bleed,8";
		break;
		case 15827:
		param = "1,3,1,Ritual,8";
		break;
		case 15828:
		param = "1,3,1,Stone,8";
		break;
		case 15829:
		param = "1,3,1,Fear,8";
		break;
		case 15830:
		param = "1,3,1,Prominence,8";
		break;
		case 15831:
		param = "1,3,1,Peace,8";
		break;
		case 15832:
		param = "1,3,1,Charm,8";
		break;
		case 15833:
		param = "1,3,1,Aggression,8";
		break;
		case 15834:
		param = "1,3,1,Guidance,8";
		break;
		case 15835:
		param = "1,3,1,Hold,8";
		break;
		case 15836:
		param = "1,3,1,Solar Flare,8";
		break;
		case 15837:
		param = "1,3,1,Heal Empower,8";
		break;
		case 15838:
		param = "1,3,1,Prayer,8";
		break;
		case 15839:
		param = "1,3,1,Heal,8";
		break;
		case 15840:
		param = "1,3,1,Empower,8";
		break;
		case 15841:
		param = "1,3,1,Cheer,8";
		break;
		case 15842:
		param = "1,3,1,Battle Roar,8";
		break;
		case 15843:
		param = "1,3,1,Blessed Body,8";
		break;
		case 15844:
		param = "1,3,1,Blessed Soul,8";
		break;
		case 15845:
		param = "1,3,1,Magic Barrier,8";
		break;
		case 15846:
		param = "1,3,1,Mana Burn,8";
		break;
		case 15847:
		param = "1,3,1,Mana Gain,8";
		break;
		case 15848:
		param = "1,3,1,Recharge,8";
		break;
		case 15849:
		param = "1,3,1,Aura Flare,8";
		break;
		case 15850:
		param = "1,3,1,Might,8";
		break;
		case 15851:
		param = "1,3,1,Paralyze,8";
		break;
		case 15852:
		param = "1,3,1,Shield,8";
		break;
		case 15853:
		param = "1,3,1,Poison,8";
		break;
		case 15854:
		param = "1,3,1,Duel Weakness,8";
		break;
		case 15855:
		param = "1,3,1,Duel Might,8";
		break;
		case 15856:
		param = "1,3,1,Recall,1";
		break;
		case 15857:
		param = "1,3,1,Resurrection,8";
		break;
		case 15858:
		param = "1,3,1,Self Stone,8";
		break;
		case 15859:
		param = "1,3,1,Self Prominence,8";
		break;
		case 15860:
		param = "1,3,1,Self Solar Flare,8";
		break;
		case 15861:
		param = "1,3,1,Self Aura Flare,8";
		break;
		case 15862:
		param = "1,3,1,Self Shadow Flare,8";
		break;
		case 15863:
		param = "1,3,1,Self Hydro Blast,8";
		break;
		case 15864:
		param = "1,3,1,Self Hurricane,8";
		break;
		case 15865:
		param = "1,3,1,Sleep,8";
		break;
		case 15866:
		param = "1,3,1,Slow,8";
		break;
		case 15867:
		param = "1,3,1,Stun,8";
		break;
		case 15868:
		param = "1,3,1,Ae Stone,8";
		break;
		case 15869:
		param = "1,3,1,Ae Prominence,8";
		break;
		case 15870:
		param = "1,3,1,Ae Solar Flare,8";
		break;
		case 15871:
		param = "1,3,1,Ae Aura Flare,8";
		break;
		case 15872:
		param = "1,3,1,Ae Shadow Flare,8";
		break;
		case 15873:
		param = "1,3,1,Ae Hydro Blast,8";
		break;
		case 15874:
		param = "1,3,1,Ae Hurricane,8";
		break;
		case 15875:
		param = "1,3,1,Trick,8";
		break;
		case 15876:
		param = "1,3,1,Medusa,8";
		break;
		case 15877:
		param = "1,3,1,Shadow Flare,8";
		break;
		case 15878:
		param = "1,3,1,Unlock,8";
		break;
		case 15879:
		param = "1,3,1,Vampiric Touch,8";
		break;
		case 15880:
		param = "1,3,1,Hydro Blast,8";
		break;
		case 15881:
		param = "1,3,1,Hurricane,8";
		break;
		case 15882:
		param = "1,3,3,Physical Winter,8";
		break;
		case 15883:
		param = "1,3,3,Physical Bleed,8";
		break;
		case 15884:
		param = "1,3,3,Physical Fear,8";
		break;
		case 15885:
		param = "1,3,3,Physical Hold,8";
		break;
		case 15886:
		param = "1,3,3,Physical Poison,8";
		break;
		case 15887:
		param = "1,3,3,Physical Medusa,8";
		break;
		case 15888:
		param = "1,3,3,Critical Winter,8";
		break;
		case 15889:
		param = "1,3,3,Critical Bleed,8";
		break;
		case 15890:
		param = "1,3,3,Critical Fear,8";
		break;
		case 15891:
		param = "1,3,3,Critical Hold,8";
		break;
		case 15892:
		param = "1,3,3,Critical Poison,8";
		break;
		case 15893:
		param = "1,3,3,Critical Medusa,8";
		break;
		case 15894:
		param = "1,3,3,Winter,8";
		break;
		case 15895:
		param = "1,3,3,Agility,8";
		break;
		case 15896:
		param = "1,3,3,Bleed,8";
		break;
		case 15897:
		param = "1,3,3,Ritual,8";
		break;
		case 15898:
		param = "1,3,3,Focus,8";
		break;
		case 15899:
		param = "1,3,3,Charm,8";
		break;
		case 15900:
		param = "1,3,3,Guidance,8";
		break;
		case 15901:
		param = "1,3,3,Hold,8";
		break;
		case 15902:
		param = "1,3,3,Prayer,8";
		break;
		case 15903:
		param = "1,3,3,Heal,8";
		break;
		case 15904:
		param = "1,3,3,Empower,8";
		break;
		case 15905:
		param = "1,3,3,Wild Magic,8";
		break;
		case 15906:
		param = "1,3,3,Cheer,8";
		break;
		case 15907:
		param = "1,3,3,Blessed Body,8";
		break;
		case 15908:
		param = "1,3,3,Blessed Soul,8";
		break;
		case 15909:
		param = "1,3,3,Magic Barrier,8";
		break;
		case 15910:
		param = "1,3,3,Might,8";
		break;
		case 15911:
		param = "1,3,3,Shield,8";
		break;
		case 15912:
		param = "1,3,3,Poison,8";
		break;
		case 15913:
		param = "1,3,3,Duel Weakness,8";
		break;
		case 15914:
		param = "1,3,3,Duel Might,8";
		break;
		case 15915:
		param = "1,3,3,Sleep,8";
		break;
		case 15916:
		param = "1,3,3,Slow,8";
		break;
		case 15917:
		param = "1,3,3,Magical Winter,8";
		break;
		case 15918:
		param = "1,3,3,Magical Bleed,8";
		break;
		case 15919:
		param = "1,3,3,Magical Fear,8";
		break;
		case 15920:
		param = "1,3,3,Magical Hold,8";
		break;
		case 15921:
		param = "1,3,3,Magical Poison,8";
		break;
		case 15922:
		param = "1,3,3,Magical Medusa,8";
		break;
		case 15923:
		param = "1,3,2,Heal Empower,8";
		break;
		case 15924:
		param = "1,3,2,Prayer,8";
		break;
		case 15925:
		param = "1,3,2,Empower,8";
		break;
		case 15926:
		param = "1,3,2,Magic Barrier,8";
		break;
		case 15927:
		param = "1,3,2,Might,8";
		break;
		case 15928:
		param = "1,3,2,Shield,8";
		break;
		case 15929:
		param = "1,3,2,Duel Might,8";
		break;
		case 15930:
		param = "1,3,2,Weight Limit,8";
		break;
		case 15931:
		param = "1,4,1,Refresh,2";
		break;
		case 15932:
		param = "1,4,1,Clarity,2";
		break;
		case 15933:
		param = "1,4,1,Focus,8";
		break;
		case 15934:
		param = "1,4,1,Reflect Damage,2";
		break;
		case 15935:
		param = "1,4,1,Doom,8";
		break;
		case 15936:
		param = "1,4,1,Recall,2";
		break;
		case 15937:
		param = "1,4,1,Celestial Shield,1";
		break;
		case 15938:
		param = "1,4,1,Wild Magic,8";
		break;
		case 15939:
		param = "1,4,1,Party Recall,2";
		break;
		case 15940:
		param = "1,4,1,Silence,8";
		break;
		case 15941:
		param = "1,4,1,Skill Refresh,2";
		break;
		case 15942:
		param = "1,4,1,Skill Clarity,2";
		break;
		case 15943:
		param = "1,4,1,Music Refresh,2";
		break;
		case 15944:
		param = "1,4,1,Music Clarity,2";
		break;
		case 15945:
		param = "1,4,1,Spell Refresh,2";
		break;
		case 15946:
		param = "1,4,1,Spell Clarity,2";
		break;
		case 15947:
		param = "1,4,1,Stealth,2";
		break;
		case 15948:
		param = "1,4,1,Vampiric Rage,8";
		break;
		case 15949:
		param = "1,4,3,Physical Doom,8";
		break;
		case 15950:
		param = "1,4,3,Physical Mana Burn,8";
		break;
		case 15951:
		param = "1,4,3,Physical Paralyze,8";
		break;
		case 15952:
		param = "1,4,3,Physical Silence,8";
		break;
		case 15953:
		param = "1,4,3,Physical Sleep,8";
		break;
		case 15954:
		param = "1,4,3,Physical Stun,8";
		break;
		case 15955:
		param = "1,4,3,Critical Doom,8";
		break;
		case 15956:
		param = "1,4,3,Critical Mana Burn,8";
		break;
		case 15957:
		param = "1,4,3,Critical Paralyze,8";
		break;
		case 15958:
		param = "1,4,3,Critical Silence,8";
		break;
		case 15959:
		param = "1,4,3,Critical Sleep,8";
		break;
		case 15960:
		param = "1,4,3,Critical Stun,8";
		break;
		case 15961:
		param = "1,4,3,Doom,8";
		break;
		case 15962:
		param = "1,4,3,Fear,8";
		break;
		case 15963:
		param = "1,4,3,Mana Gain,8";
		break;
		case 15964:
		param = "1,4,3,Recharge,8";
		break;
		case 15965:
		param = "1,4,3,Paralyze,8";
		break;
		case 15966:
		param = "1,4,3,Silence,8";
		break;
		case 15967:
		param = "1,4,3,Stun,8";
		break;
		case 15968:
		param = "1,4,3,Medusa,8";
		break;
		case 15969:
		param = "1,4,3,Magical Doom,8";
		break;
		case 15970:
		param = "1,4,3,Magical Mana Burn,8";
		break;
		case 15971:
		param = "1,4,3,Magical Paralyze,8";
		break;
		case 15972:
		param = "1,4,3,Magical Silence,8";
		break;
		case 15973:
		param = "1,4,3,Magical Sleep,8";
		break;
		case 15974:
		param = "1,4,3,Magical Stun,8";
		break;
		case 15975:
		param = "1,4,2,Clarity,2";
		break;
		case 15976:
		param = "1,4,2,Agility,8";
		break;
		case 15977:
		param = "1,4,2,Focus,8";
		break;
		case 15978:
		param = "1,4,2,Reflect Damage,2";
		break;
		case 15979:
		param = "1,4,2,Guidance,8";
		break;
		case 15980:
		param = "1,4,2,Wild Magic,8";
		break;
		case 15981:
		param = "1,4,2,Mana Gain,8";
		break;
		case 15982:
		param = "1,4,2,Skill Clarity,2";
		break;
		case 15983:
		param = "1,4,2,Music Clarity,2";
		break;
		case 15984:
		param = "1,4,2,Spell Clarity,2";
		break;
		case 16002:
		param = "1,3,1,Winter,9";
		break;
		case 16003:
		param = "1,3,1,Agility,9";
		break;
		case 16004:
		param = "1,3,1,Bleed,9";
		break;
		case 16005:
		param = "1,3,1,Ritual,9";
		break;
		case 16006:
		param = "1,3,1,Stone,9";
		break;
		case 16007:
		param = "1,3,1,Fear,9";
		break;
		case 16008:
		param = "1,3,1,Prominence,9";
		break;
		case 16009:
		param = "1,3,1,Peace,9";
		break;
		case 16010:
		param = "1,3,1,Charm,9";
		break;
		case 16011:
		param = "1,3,1,Aggression,9";
		break;
		case 16012:
		param = "1,3,1,Guidance,9";
		break;
		case 16013:
		param = "1,3,1,Hold,9";
		break;
		case 16014:
		param = "1,3,1,Solar Flare,9";
		break;
		case 16015:
		param = "1,3,1,Heal Empower,9";
		break;
		case 16016:
		param = "1,3,1,Prayer,9";
		break;
		case 16017:
		param = "1,3,1,Heal,9";
		break;
		case 16018:
		param = "1,3,1,Empower,9";
		break;
		case 16019:
		param = "1,3,1,Cheer,9";
		break;
		case 16020:
		param = "1,3,1,Battle Roar,9";
		break;
		case 16021:
		param = "1,3,1,Blessed Body,9";
		break;
		case 16022:
		param = "1,3,1,Blessed Soul,9";
		break;
		case 16023:
		param = "1,3,1,Magic Barrier,9";
		break;
		case 16024:
		param = "1,3,1,Mana Burn,9";
		break;
		case 16025:
		param = "1,3,1,Mana Gain,9";
		break;
		case 16026:
		param = "1,3,1,Recharge,9";
		break;
		case 16027:
		param = "1,3,1,Aura Flare,9";
		break;
		case 16028:
		param = "1,3,1,Might,9";
		break;
		case 16029:
		param = "1,3,1,Paralyze,9";
		break;
		case 16030:
		param = "1,3,1,Shield,9";
		break;
		case 16031:
		param = "1,3,1,Poison,9";
		break;
		case 16032:
		param = "1,3,1,Duel Weakness,9";
		break;
		case 16033:
		param = "1,3,1,Duel Might,9";
		break;
		case 16034:
		param = "1,3,1,Recall,1";
		break;
		case 16035:
		param = "1,3,1,Resurrection,9";
		break;
		case 16036:
		param = "1,3,1,Self Stone,9";
		break;
		case 16037:
		param = "1,3,1,Self Prominence,9";
		break;
		case 16038:
		param = "1,3,1,Self Solar Flare,9";
		break;
		case 16039:
		param = "1,3,1,Self Aura Flare,9";
		break;
		case 16040:
		param = "1,3,1,Self Shadow Flare,9";
		break;
		case 16041:
		param = "1,3,1,Self Hydro Blast,9";
		break;
		case 16042:
		param = "1,3,1,Self Hurricane,9";
		break;
		case 16043:
		param = "1,3,1,Sleep,9";
		break;
		case 16044:
		param = "1,3,1,Slow,9";
		break;
		case 16045:
		param = "1,3,1,Stun,9";
		break;
		case 16046:
		param = "1,3,1,Ae Stone,9";
		break;
		case 16047:
		param = "1,3,1,Ae Prominence,9";
		break;
		case 16048:
		param = "1,3,1,Ae Solar Flare,9";
		break;
		case 16049:
		param = "1,3,1,Ae Aura Flare,9";
		break;
		case 16050:
		param = "1,3,1,Ae Shadow Flare,9";
		break;
		case 16051:
		param = "1,3,1,Ae Hydro Blast,9";
		break;
		case 16052:
		param = "1,3,1,Ae Hurricane,9";
		break;
		case 16053:
		param = "1,3,1,Trick,9";
		break;
		case 16054:
		param = "1,3,1,Medusa,9";
		break;
		case 16055:
		param = "1,3,1,Shadow Flare,9";
		break;
		case 16056:
		param = "1,3,1,Unlock,9";
		break;
		case 16057:
		param = "1,3,1,Vampiric Touch,9";
		break;
		case 16058:
		param = "1,3,1,Hydro Blast,9";
		break;
		case 16059:
		param = "1,3,1,Hurricane,9";
		break;
		case 16060:
		param = "1,3,3,Physical Winter,9";
		break;
		case 16061:
		param = "1,3,3,Physical Bleed,9";
		break;
		case 16062:
		param = "1,3,3,Physical Fear,9";
		break;
		case 16063:
		param = "1,3,3,Physical Hold,9";
		break;
		case 16064:
		param = "1,3,3,Physical Poison,9";
		break;
		case 16065:
		param = "1,3,3,Physical Medusa,9";
		break;
		case 16066:
		param = "1,3,3,Critical Winter,9";
		break;
		case 16067:
		param = "1,3,3,Critical Bleed,9";
		break;
		case 16068:
		param = "1,3,3,Critical Fear,9";
		break;
		case 16069:
		param = "1,3,3,Critical Hold,9";
		break;
		case 16070:
		param = "1,3,3,Critical Poison,9";
		break;
		case 16071:
		param = "1,3,3,Critical Medusa,9";
		break;
		case 16072:
		param = "1,3,3,Winter,9";
		break;
		case 16073:
		param = "1,3,3,Agility,9";
		break;
		case 16074:
		param = "1,3,3,Bleed,9";
		break;
		case 16075:
		param = "1,3,3,Ritual,9";
		break;
		case 16076:
		param = "1,3,3,Focus,9";
		break;
		case 16077:
		param = "1,3,3,Charm,9";
		break;
		case 16078:
		param = "1,3,3,Guidance,9";
		break;
		case 16079:
		param = "1,3,3,Hold,9";
		break;
		case 16080:
		param = "1,3,3,Prayer,9";
		break;
		case 16081:
		param = "1,3,3,Heal,9";
		break;
		case 16082:
		param = "1,3,3,Empower,9";
		break;
		case 16083:
		param = "1,3,3,Wild Magic,9";
		break;
		case 16084:
		param = "1,3,3,Cheer,9";
		break;
		case 16085:
		param = "1,3,3,Blessed Body,9";
		break;
		case 16086:
		param = "1,3,3,Blessed Soul,9";
		break;
		case 16087:
		param = "1,3,3,Magic Barrier,9";
		break;
		case 16088:
		param = "1,3,3,Might,9";
		break;
		case 16089:
		param = "1,3,3,Shield,9";
		break;
		case 16090:
		param = "1,3,3,Poison,9";
		break;
		case 16091:
		param = "1,3,3,Duel Weakness,9";
		break;
		case 16092:
		param = "1,3,3,Duel Might,9";
		break;
		case 16093:
		param = "1,3,3,Sleep,9";
		break;
		case 16094:
		param = "1,3,3,Slow,9";
		break;
		case 16095:
		param = "1,3,3,Magical Winter,9";
		break;
		case 16096:
		param = "1,3,3,Magical Bleed,9";
		break;
		case 16097:
		param = "1,3,3,Magical Fear,9";
		break;
		case 16098:
		param = "1,3,3,Magical Hold,9";
		break;
		case 16099:
		param = "1,3,3,Magical Poison,9";
		break;
		case 16100:
		param = "1,3,3,Magical Medusa,9";
		break;
		case 16101:
		param = "1,3,2,Heal Empower,9";
		break;
		case 16102:
		param = "1,3,2,Prayer,9";
		break;
		case 16103:
		param = "1,3,2,Empower,9";
		break;
		case 16104:
		param = "1,3,2,Magic Barrier,9";
		break;
		case 16105:
		param = "1,3,2,Might,9";
		break;
		case 16106:
		param = "1,3,2,Shield,9";
		break;
		case 16107:
		param = "1,3,2,Duel Might,9";
		break;
		case 16108:
		param = "1,3,2,Weight Limit,9";
		break;
		case 16109:
		param = "1,4,1,Refresh,2";
		break;
		case 16110:
		param = "1,4,1,Clarity,2";
		break;
		case 16111:
		param = "1,4,1,Focus,9";
		break;
		case 16112:
		param = "1,4,1,Reflect Damage,2";
		break;
		case 16113:
		param = "1,4,1,Doom,9";
		break;
		case 16114:
		param = "1,4,1,Recall,2";
		break;
		case 16115:
		param = "1,4,1,Celestial Shield,1";
		break;
		case 16116:
		param = "1,4,1,Wild Magic,9";
		break;
		case 16117:
		param = "1,4,1,Party Recall,2";
		break;
		case 16118:
		param = "1,4,1,Silence,9";
		break;
		case 16119:
		param = "1,4,1,Skill Refresh,2";
		break;
		case 16120:
		param = "1,4,1,Skill Clarity,2";
		break;
		case 16121:
		param = "1,4,1,Music Refresh,2";
		break;
		case 16122:
		param = "1,4,1,Music Clarity,2";
		break;
		case 16123:
		param = "1,4,1,Spell Refresh,2";
		break;
		case 16124:
		param = "1,4,1,Spell Clarity,2";
		break;
		case 16125:
		param = "1,4,1,Stealth,2";
		break;
		case 16126:
		param = "1,4,1,Vampiric Rage,9";
		break;
		case 16127:
		param = "1,4,3,Physical Doom,9";
		break;
		case 16128:
		param = "1,4,3,Physical Mana Burn,9";
		break;
		case 16129:
		param = "1,4,3,Physical Paralyze,9";
		break;
		case 16130:
		param = "1,4,3,Physical Silence,9";
		break;
		case 16131:
		param = "1,4,3,Physical Sleep,9";
		break;
		case 16132:
		param = "1,4,3,Physical Stun,9";
		break;
		case 16133:
		param = "1,4,3,Critical Doom,9";
		break;
		case 16134:
		param = "1,4,3,Critical Mana Burn,9";
		break;
		case 16135:
		param = "1,4,3,Critical Paralyze,9";
		break;
		case 16136:
		param = "1,4,3,Critical Silence,9";
		break;
		case 16137:
		param = "1,4,3,Critical Sleep,9";
		break;
		case 16138:
		param = "1,4,3,Critical Stun,9";
		break;
		case 16139:
		param = "1,4,3,Doom,9";
		break;
		case 16140:
		param = "1,4,3,Fear,9";
		break;
		case 16141:
		param = "1,4,3,Mana Gain,9";
		break;
		case 16142:
		param = "1,4,3,Recharge,9";
		break;
		case 16143:
		param = "1,4,3,Paralyze,9";
		break;
		case 16144:
		param = "1,4,3,Silence,9";
		break;
		case 16145:
		param = "1,4,3,Stun,9";
		break;
		case 16146:
		param = "1,4,3,Medusa,9";
		break;
		case 16147:
		param = "1,4,3,Magical Doom,9";
		break;
		case 16148:
		param = "1,4,3,Magical Mana Burn,9";
		break;
		case 16149:
		param = "1,4,3,Magical Paralyze,9";
		break;
		case 16150:
		param = "1,4,3,Magical Silence,9";
		break;
		case 16151:
		param = "1,4,3,Magical Sleep,9";
		break;
		case 16152:
		param = "1,4,3,Magical Stun,9";
		break;
		case 16153:
		param = "1,4,2,Clarity,2";
		break;
		case 16154:
		param = "1,4,2,Agility,9";
		break;
		case 16155:
		param = "1,4,2,Focus,9";
		break;
		case 16156:
		param = "1,4,2,Reflect Damage,2";
		break;
		case 16157:
		param = "1,4,2,Guidance,9";
		break;
		case 16158:
		param = "1,4,2,Wild Magic,9";
		break;
		case 16159:
		param = "1,4,2,Mana Gain,9";
		break;
		case 16160:
		param = "1,4,2,Skill Clarity,2";
		break;
		case 16161:
		param = "1,4,2,Music Clarity,2";
		break;
		case 16162:
		param = "1,4,2,Spell Clarity,2";
		break;
		case 16180:
		param = "1,3,1,Winter,10";
		break;
		case 16181:
		param = "1,3,1,Agility,10";
		break;
		case 16182:
		param = "1,3,1,Bleed,10";
		break;
		case 16183:
		param = "1,3,1,Ritual,10";
		break;
		case 16184:
		param = "1,3,1,Stone,10";
		break;
		case 16185:
		param = "1,3,1,Fear,10";
		break;
		case 16186:
		param = "1,3,1,Prominence,10";
		break;
		case 16187:
		param = "1,3,1,Peace,10";
		break;
		case 16188:
		param = "1,3,1,Charm,10";
		break;
		case 16189:
		param = "1,3,1,Aggression,10";
		break;
		case 16190:
		param = "1,3,1,Guidance,10";
		break;
		case 16191:
		param = "1,3,1,Hold,10";
		break;
		case 16192:
		param = "1,3,1,Solar Flare,10";
		break;
		case 16193:
		param = "1,3,1,Heal Empower,10";
		break;
		case 16194:
		param = "1,3,1,Prayer,10";
		break;
		case 16195:
		param = "1,3,1,Heal,10";
		break;
		case 16196:
		param = "1,3,1,Empower,10";
		break;
		case 16197:
		param = "1,3,1,Cheer,10";
		break;
		case 16198:
		param = "1,3,1,Battle Roar,10";
		break;
		case 16199:
		param = "1,3,1,Blessed Body,10";
		break;
		case 16200:
		param = "1,3,1,Blessed Soul,10";
		break;
		case 16201:
		param = "1,3,1,Magic Barrier,10";
		break;
		case 16202:
		param = "1,3,1,Mana Burn,10";
		break;
		case 16203:
		param = "1,3,1,Mana Gain,10";
		break;
		case 16204:
		param = "1,3,1,Recharge,10";
		break;
		case 16205:
		param = "1,3,1,Aura Flare,10";
		break;
		case 16206:
		param = "1,3,1,Might,10";
		break;
		case 16207:
		param = "1,3,1,Paralyze,10";
		break;
		case 16208:
		param = "1,3,1,Shield,10";
		break;
		case 16209:
		param = "1,3,1,Poison,10";
		break;
		case 16210:
		param = "1,3,1,Duel Weakness,10";
		break;
		case 16211:
		param = "1,3,1,Duel Might,10";
		break;
		case 16212:
		param = "1,3,1,Recall,1";
		break;
		case 16213:
		param = "1,3,1,Resurrection,9";
		break;
		case 16214:
		param = "1,3,1,Self Stone,10";
		break;
		case 16215:
		param = "1,3,1,Self Prominence,10";
		break;
		case 16216:
		param = "1,3,1,Self Solar Flare,10";
		break;
		case 16217:
		param = "1,3,1,Self Aura Flare,10";
		break;
		case 16218:
		param = "1,3,1,Self Shadow Flare,10";
		break;
		case 16219:
		param = "1,3,1,Self Hydro Blast,10";
		break;
		case 16220:
		param = "1,3,1,Self Hurricane,10";
		break;
		case 16221:
		param = "1,3,1,Sleep,10";
		break;
		case 16222:
		param = "1,3,1,Slow,10";
		break;
		case 16223:
		param = "1,3,1,Stun,10";
		break;
		case 16224:
		param = "1,3,1,Ae Stone,10";
		break;
		case 16225:
		param = "1,3,1,Ae Prominence,10";
		break;
		case 16226:
		param = "1,3,1,Ae Solar Flare,10";
		break;
		case 16227:
		param = "1,3,1,Ae Aura Flare,10";
		break;
		case 16228:
		param = "1,3,1,Ae Shadow Flare,10";
		break;
		case 16229:
		param = "1,3,1,Ae Hydro Blast,10";
		break;
		case 16230:
		param = "1,3,1,Ae Hurricane,10";
		break;
		case 16231:
		param = "1,3,1,Trick,10";
		break;
		case 16232:
		param = "1,3,1,Medusa,10";
		break;
		case 16233:
		param = "1,3,1,Shadow Flare,10";
		break;
		case 16234:
		param = "1,3,1,Unlock,10";
		break;
		case 16235:
		param = "1,3,1,Vampiric Touch,10";
		break;
		case 16236:
		param = "1,3,1,Hydro Blast,10";
		break;
		case 16237:
		param = "1,3,1,Hurricane,10";
		break;
		case 16238:
		param = "1,3,3,Physical Winter,10";
		break;
		case 16239:
		param = "1,3,3,Physical Bleed,10";
		break;
		case 16240:
		param = "1,3,3,Physical Fear,10";
		break;
		case 16241:
		param = "1,3,3,Physical Hold,10";
		break;
		case 16242:
		param = "1,3,3,Physical Poison,10";
		break;
		case 16243:
		param = "1,3,3,Physical Medusa,10";
		break;
		case 16244:
		param = "1,3,3,Critical Winter,10";
		break;
		case 16245:
		param = "1,3,3,Critical Bleed,10";
		break;
		case 16246:
		param = "1,3,3,Critical Fear,10";
		break;
		case 16247:
		param = "1,3,3,Critical Hold,10";
		break;
		case 16248:
		param = "1,3,3,Critical Poison,10";
		break;
		case 16249:
		param = "1,3,3,Critical Medusa,10";
		break;
		case 16250:
		param = "1,3,3,Winter,10";
		break;
		case 16251:
		param = "1,3,3,Agility,10";
		break;
		case 16252:
		param = "1,3,3,Bleed,10";
		break;
		case 16253:
		param = "1,3,3,Ritual,10";
		break;
		case 16254:
		param = "1,3,3,Focus,10";
		break;
		case 16255:
		param = "1,3,3,Charm,10";
		break;
		case 16256:
		param = "1,3,3,Guidance,10";
		break;
		case 16257:
		param = "1,3,3,Hold,10";
		break;
		case 16258:
		param = "1,3,3,Prayer,10";
		break;
		case 16259:
		param = "1,3,3,Heal,10";
		break;
		case 16260:
		param = "1,3,3,Empower,10";
		break;
		case 16261:
		param = "1,3,3,Wild Magic,10";
		break;
		case 16262:
		param = "1,3,3,Cheer,10";
		break;
		case 16263:
		param = "1,3,3,Blessed Body,10";
		break;
		case 16264:
		param = "1,3,3,Blessed Soul,10";
		break;
		case 16265:
		param = "1,3,3,Magic Barrier,10";
		break;
		case 16266:
		param = "1,3,3,Might,10";
		break;
		case 16267:
		param = "1,3,3,Shield,10";
		break;
		case 16268:
		param = "1,3,3,Poison,10";
		break;
		case 16269:
		param = "1,3,3,Duel Weakness,10";
		break;
		case 16270:
		param = "1,3,3,Duel Might,10";
		break;
		case 16271:
		param = "1,3,3,Sleep,10";
		break;
		case 16272:
		param = "1,3,3,Slow,10";
		break;
		case 16273:
		param = "1,3,3,Magical Winter,10";
		break;
		case 16274:
		param = "1,3,3,Magical Bleed,10";
		break;
		case 16275:
		param = "1,3,3,Magical Fear,10";
		break;
		case 16276:
		param = "1,3,3,Magical Hold,10";
		break;
		case 16277:
		param = "1,3,3,Magical Poison,10";
		break;
		case 16278:
		param = "1,3,3,Magical Medusa,10";
		break;
		case 16279:
		param = "1,3,2,Heal Empower,10";
		break;
		case 16280:
		param = "1,3,2,Prayer,10";
		break;
		case 16281:
		param = "1,3,2,Empower,10";
		break;
		case 16282:
		param = "1,3,2,Magic Barrier,10";
		break;
		case 16283:
		param = "1,3,2,Might,10";
		break;
		case 16284:
		param = "1,3,2,Shield,10";
		break;
		case 16285:
		param = "1,3,2,Duel Might,10";
		break;
		case 16286:
		param = "1,3,2,Weight Limit,10";
		break;
		case 16287:
		param = "1,4,1,Refresh,3";
		break;
		case 16288:
		param = "1,4,1,Clarity,3";
		break;
		case 16289:
		param = "1,4,1,Focus,10";
		break;
		case 16290:
		param = "1,4,1,Reflect Damage,3";
		break;
		case 16291:
		param = "1,4,1,Doom,10";
		break;
		case 16292:
		param = "1,4,1,Recall,2";
		break;
		case 16293:
		param = "1,4,1,Celestial Shield,1";
		break;
		case 16294:
		param = "1,4,1,Wild Magic,10";
		break;
		case 16295:
		param = "1,4,1,Party Recall,2";
		break;
		case 16296:
		param = "1,4,1,Silence,10";
		break;
		case 16297:
		param = "1,4,1,Skill Refresh,3";
		break;
		case 16298:
		param = "1,4,1,Skill Clarity,3";
		break;
		case 16299:
		param = "1,4,1,Music Refresh,3";
		break;
		case 16300:
		param = "1,4,1,Music Clarity,3";
		break;
		case 16301:
		param = "1,4,1,Spell Refresh,3";
		break;
		case 16302:
		param = "1,4,1,Spell Clarity,3";
		break;
		case 16303:
		param = "1,4,1,Stealth,3";
		break;
		case 16304:
		param = "1,4,1,Vampiric Rage,10";
		break;
		case 16305:
		param = "1,4,3,Physical Doom,10";
		break;
		case 16306:
		param = "1,4,3,Physical Mana Burn,10";
		break;
		case 16307:
		param = "1,4,3,Physical Paralyze,10";
		break;
		case 16308:
		param = "1,4,3,Physical Silence,10";
		break;
		case 16309:
		param = "1,4,3,Physical Sleep,10";
		break;
		case 16310:
		param = "1,4,3,Physical Stun,10";
		break;
		case 16311:
		param = "1,4,3,Critical Doom,10";
		break;
		case 16312:
		param = "1,4,3,Critical Mana Burn,10";
		break;
		case 16313:
		param = "1,4,3,Critical Paralyze,10";
		break;
		case 16314:
		param = "1,4,3,Critical Silence,10";
		break;
		case 16315:
		param = "1,4,3,Critical Sleep,10";
		break;
		case 16316:
		param = "1,4,3,Critical Stun,10";
		break;
		case 16317:
		param = "1,4,3,Doom,10";
		break;
		case 16318:
		param = "1,4,3,Fear,10";
		break;
		case 16319:
		param = "1,4,3,Mana Gain,10";
		break;
		case 16320:
		param = "1,4,3,Recharge,10";
		break;
		case 16321:
		param = "1,4,3,Paralyze,10";
		break;
		case 16322:
		param = "1,4,3,Silence,10";
		break;
		case 16323:
		param = "1,4,3,Stun,10";
		break;
		case 16324:
		param = "1,4,3,Medusa,10";
		break;
		case 16325:
		param = "1,4,3,Magical Doom,10";
		break;
		case 16326:
		param = "1,4,3,Magical Mana Burn,10";
		break;
		case 16327:
		param = "1,4,3,Magical Paralyze,10";
		break;
		case 16328:
		param = "1,4,3,Magical Silence,10";
		break;
		case 16329:
		param = "1,4,3,Magical Sleep,10";
		break;
		case 16330:
		param = "1,4,3,Magical Stun,10";
		break;
		case 16331:
		param = "1,4,2,Clarity,3";
		break;
		case 16332:
		param = "1,4,2,Agility,10";
		break;
		case 16333:
		param = "1,4,2,Focus,10";
		break;
		case 16334:
		param = "1,4,2,Reflect Damage,3";
		break;
		case 16335:
		param = "1,4,2,Guidance,10";
		break;
		case 16336:
		param = "1,4,2,Wild Magic,10";
		break;
		case 16337:
		param = "1,4,2,Mana Gain,10";
		break;
		case 16338:
		param = "1,4,2,Skill Clarity,3";
		break;
		case 16339:
		param = "1,4,2,Music Clarity,3";
		break;
		case 16340:
		param = "1,4,2,Spell Clarity,3";
		break;
		case 16341:
		param = "1,4,4,STR +1,1";
		break;
		case 16342:
		param = "1,4,4,CON +1,1";
		break;
		case 16343:
		param = "1,4,4,INT +1,1";
		break;
		case 16344:
		param = "1,4,4,MEN +1,1";
		break;
		case 16345:
		param = "1,4,4,STR +1,1";
		break;
		case 16346:
		param = "1,4,4,CON +1,1";
		break;
		case 16347:
		param = "1,4,4,INT +1,1";
		break;
		case 16348:
		param = "1,4,4,MEN +1,1";
		break;
		case 16349:
		param = "1,4,4,STR +1,1";
		break;
		case 16350:
		param = "1,4,4,CON +1,1";
		break;
		case 16351:
		param = "1,4,4,INT +1,1";
		break;
		case 16352:
		param = "1,4,4,MEN +1,1";
		break;
		case 16353:
		param = "1,4,4,STR +1,1";
		break;
		case 16354:
		param = "1,4,4,CON +1,1";
		break;
		case 16355:
		param = "1,4,4,INT +1,1";
		break;
		case 16356:
		param = "1,4,4,MEN +1,1";
		break;
		case 16357:
		param = "1,4,4,STR +1,1";
		break;
		case 16358:
		param = "1,4,4,CON +1,1";
		break;
		case 16359:
		param = "1,4,4,INT +1,1";
		break;
		case 16360:
		param = "1,4,4,MEN +1,1";
		break;
		case 16361:
		param = "1,4,4,STR +1,1";
		break;
		case 16362:
		param = "1,4,4,CON +1,1";
		break;
		case 16363:
		param = "1,4,4,INT +1,1";
		break;
		case 16364:
		param = "1,4,4,MEN +1,1";
		break;
		case 16365:
		param = "1,4,4,STR +1,1";
		break;
		case 16366:
		param = "1,4,4,CON +1,1";
		break;
		case 16367:
		param = "1,4,4,INT +1,1";
		break;
		case 16368:
		param = "1,4,4,MEN +1,1";
		break;
		case 16369:
		param = "1,4,4,STR +1,1";
		break;
		case 16370:
		param = "1,4,4,CON +1,1";
		break;
		case 16371:
		param = "1,4,4,INT +1,1";
		break;
		case 16372:
		param = "1,4,4,MEN +1,1";
		break;
		case 16373:
		param = "1,4,4,STR +1,1";
		break;
		case 16374:
		param = "1,4,4,CON +1,1";
		break;
		case 16375:
		param = "1,4,4,INT +1,1";
		break;
		case 16376:
		param = "1,4,4,MEN +1,1";
		break;
		case 16377:
		param = "1,4,4,STR +1,1";
		break;
		case 16378:
		param = "1,4,4,CON +1,1";
		break;
		case 16379:
		param = "1,4,4,INT +1,1";
		break;
		case 16380:
		param = "1,4,4,MEN +1,1";
		break;
		default:
		param = ",,,,";
		break;
	}
	ResultParam = param;
}

function string GetClassIconCustom (int ClassIDCustom)
{
	local string tempString;

	tempString = "";
	switch (ClassIDCustom)
	{
		case 0:
		tempString = "Icon.skill0141";
		break;
		case 1:
		tempString = "Icon.skill0078";
		break;
		case 2:
		tempString = "Icon.skill0008";
		break;
		case 3:
		tempString = "Icon.skill0286";
		break;
		case 4:
		tempString = "Icon.skill0110";
		break;
		case 5:
		tempString = "Icon.skill0406";
		break;
		case 6:
		tempString = "Icon.skill0283";
		break;
		case 7:
		tempString = "Icon.skill0111";
		break;
		case 8:
		tempString = "Icon.skill0263";
		break;
		case 9:
		tempString = "Icon.skill0313";
		break;
		case 10:
		tempString = "Icon.skill0146";
		break;
		case 11:
		tempString = "Icon.skill1220";
		break;
		case 12:
		tempString = "Icon.skill1289";
		break;
		case 13:
		tempString = "Icon.skill1263";
		break;
		case 14:
		tempString = "Icon.skill1331";
		break;
		case 15:
		tempString = "Icon.skill1016";
		break;
		case 16:
		tempString = "Icon.skill1307";
		break;
		case 17:
		tempString = "Icon.skill1062";
		break;
		case 18:
		tempString = "Icon.skill0141";
		break;
		case 19:
		tempString = "Icon.skill0110";
		break;
		case 20:
		tempString = "Icon.skill0067";
		break;
		case 21:
		tempString = "Icon.skill0098";
		break;
		case 22:
		tempString = "Icon.skill0111";
		break;
		case 23:
		tempString = "Icon.skill0321";
		break;
		case 24:
		tempString = "Icon.skill0416";
		break;
		case 25:
		tempString = "Icon.skill0146";
		break;
		case 26:
		tempString = "Icon.skill1175";
		break;
		case 27:
		tempString = "Icon.skill1290";
		break;
		case 28:
		tempString = "Icon.skill1332";
		break;
		case 29:
		tempString = "Icon.skill1013";
		break;
		case 30:
		tempString = "Icon.skill1430";
		break;
		case 31:
		tempString = "Icon.skill0141";
		break;
		case 32:
		tempString = "Icon.skill0110";
		break;
		case 33:
		tempString = "Icon.skill0022";
		break;
		case 34:
		tempString = "Icon.skill0408";
		break;
		case 35:
		tempString = "Icon.skill0111";
		break;
		case 36:
		tempString = "Icon.skill0321";
		break;
		case 37:
		tempString = "Icon.skill0314";
		break;
		case 38:
		tempString = "Icon.skill0141";
		break;
		case 39:
		tempString = "Icon.skill1178";
		break;
		case 40:
		tempString = "Icon.skill1291";
		break;
		case 41:
		tempString = "Icon.skill1333";
		break;
		case 42:
		tempString = "Icon.skill1059";
		break;
		case 43:
		tempString = "Icon.skill1430";
		break;
		case 44:
		tempString = "Icon.skill0146";
		break;
		case 45:
		tempString = "Icon.skill0176";
		break;
		case 46:
		tempString = "Icon.skill0176";
		break;
		case 47:
		tempString = "Icon.skill0050";
		break;
		case 48:
		tempString = "Icon.skill0222";
		break;
		case 49:
		tempString = "Icon.skill0141";
		break;
		case 50:
		tempString = "Icon.skill1090";
		break;
		case 51:
		tempString = "Icon.skill1283";
		break;
		case 52:
		tempString = "Icon.skill1001";
		break;
		case 53:
		tempString = "Icon.skill0146";
		break;
		case 54:
		tempString = "Icon.skill0254";
		break;
		case 55:
		tempString = "Icon.skill0302";
		break;
		case 56:
		tempString = "Icon.skill0025";
		break;
		case 57:
		tempString = "Icon.skill0301";
		break;
		case 88:
		tempString = "Icon.skill0442";
		break;
		case 89:
		tempString = "Icon.skill0361";
		break;
		case 90:
		tempString = "Icon.skill0341";
		break;
		case 91:
		tempString = "Icon.skill0342";
		break;
		case 92:
		tempString = "Icon.skill0131";
		break;
		case 93:
		tempString = "Icon.skill0445";
		break;
		case 94:
		tempString = "Icon.skill1339";
		break;
		case 95:
		tempString = "Icon.skill1343";
		break;
		case 96:
		tempString = "Icon.skill1406";
		break;
		case 97:
		tempString = "Icon.skill1335";
		break;
		case 98:
		tempString = "Icon.skill1356";
		break;
		case 99:
		tempString = "Icon.skill0341";
		break;
		case 100:
		tempString = "Icon.skill0437";
		break;
		case 101:
		tempString = "Icon.skill0355";
		break;
		case 102:
		tempString = "Icon.skill0413";
		break;
		case 103:
		tempString = "Icon.skill1342";
		break;
		case 104:
		tempString = "Icon.skill1407";
		break;
		case 105:
		tempString = "Icon.skill1355";
		break;
		case 106:
		tempString = "Icon.skill0342";
		break;
		case 107:
		tempString = "Icon.skill0367";
		break;
		case 108:
		tempString = "Icon.skill0355";
		break;
		case 109:
		tempString = "Icon.skill0414";
		break;
		case 110:
		tempString = "Icon.skill1341";
		break;
		case 111:
		tempString = "Icon.skill1408";
		break;
		case 112:
		tempString = "Icon.skill1357";
		break;
		case 113:
		tempString = "Icon.skill0094";
		break;
		case 114:
		tempString = "Icon.skill0443";
		break;
		case 115:
		tempString = "Icon.skill1416";
		break;
		case 116:
		tempString = "Icon.skill1413";
		break;
		case 117:
		tempString = "Icon.skill0348";
		break;
		case 118:
		tempString = "Icon.skill0013";
		break;
		default:
	}
	return tempString;
}

function bool isSongDanceCustom (int Id)
{
	local bool ResultBool;

	switch (Id)
	{
		case 276:
		case 273:
		case 365:
		case 275:
		case 274:
		case 271:
		case 272:
		case 310:
		case 264:
		case 265:
		case 266:
		case 267:
		case 268:
		case 269:
		case 349:
		case 270:
		case 304:
		case 305:
		case 306:
		case 308:
		case 363:
		case 364:
		case 529:
		case 277:
		case 307:
		case 309:
		case 311:
		case 366:
		case 530:
		case 915:
		ResultBool = True;
		break;
		default:
	}
	return ResultBool;
}

function bool isNoblesseCustom (int Id)
{
	local bool ResultBool;

	ResultBool = False;
	switch (Id)
	{
		case 1323:
		ResultBool = True;
		break;
		default:
	}
	return ResultBool;
}

function bool isDebuffCustom (int Id)
{
	local bool ResultBool;

	ResultBool = False;
	switch (Id)
	{
		case 28:
		case 92:
		case 101:
		case 102:
		case 105:
		case 115:
		case 129:
		case 1069:
		case 1083:
		case 1160:
		case 1164:
		case 1167:
		case 1168:
		case 1184:
		case 1201:
		case 1206:
		case 1222:
		case 1223:
		case 1224:
		case 100:
		case 95:
		case 96:
		case 120:
		case 223:
		case 1092:
		case 1095:
		case 1096:
		case 1097:
		case 1099:
		case 1100:
		case 1101:
		case 1102:
		case 1107:
		case 1208:
		case 1209:
		case 18:
		case 48:
		case 65:
		case 84:
		case 97:
		case 98:
		case 103:
		case 106:
		case 107:
		case 116:
		case 122:
		case 127:
		case 260:
		case 279:
		case 281:
		case 1042:
		case 1049:
		case 1064:
		case 1071:
		case 1072:
		case 1074:
		case 1104:
		case 1108:
		case 1169:
		case 1170:
		case 1183:
		case 1210:
		case 1231:
		case 1233:
		case 1236:
		case 1237:
		case 1244:
		case 1246:
		case 1247:
		case 1248:
		case 286:
		case 1263:
		case 1269:
		case 1272:
		case 1289:
		case 1290:
		case 1291:
		case 1298:
		case 342:
		case 352:
		case 353:
		case 354:
		case 358:
		case 361:
		case 362:
		case 367:
		case 1336:
		case 1337:
		case 1338:
		case 1339:
		case 1340:
		case 1341:
		case 1342:
		case 1343:
		case 1358:
		case 1359:
		case 1360:
		case 1361:
		case 1366:
		case 1367:
		case 1375:
		case 1376:
		case 400:
		case 401:
		case 402:
		case 403:
		case 404:
		case 407:
		case 408:
		case 412:
		case 1380:
		case 1381:
		case 1382:
		case 1383:
		case 1384:
		case 1385:
		case 1386:
		case 1394:
		case 1396:
		case 437:
		case 452:
		case 485:
		case 1435:
		case 494:
		case 495:
		case 501:
		case 1437:
		case 1445:
		case 1446:
		case 1447:
		case 1448:
		case 509:
		case 522:
		case 523:
		case 531:
		case 537:
		case 1452:
		case 1454:
		case 1455:
		case 1458:
		case 1462:
		case 1467:
		case 1468:
		case 559:
		case 564:
		case 571:
		case 573:
		case 578:
		case 581:
		case 582:
		case 588:
		case 1481:
		case 1482:
		case 1483:
		case 1484:
		case 1485:
		case 1486:
		case 627:
		case 680:
		case 681:
		case 682:
		case 683:
		case 686:
		case 688:
		case 692:
		case 695:
		case 696:
		case 708:
		case 716:
		case 730:
		case 732:
		case 736:
		case 741:
		case 747:
		case 749:
		case 752:
		case 762:
		case 763:
		case 774:
		case 775:
		case 776:
		case 1495:
		case 1508:
		case 1509:
		case 1511:
		case 1512:
		case 791:
		case 792:
		case 793:
		case 794:
		case 798:
		case 808:
		case 1524:
		case 1525:
		case 835:
		case 1529:
		case 877:
		case 879:
		case 883:
		case 886:
		case 887:
		case 899:
		case 904:
		case 905:
		case 909:
		case 910:
		case 927:
		case 1539:
		case 1540:
		case 1541:
		case 949:
		case 954:
		case 1546:
		case 969:
		case 973:
		case 974:
		case 977:
		case 978:
		case 979:
		case 980:
		case 981:
		case 985:
		case 991:
		case 1554:
		case 1555:
		case 995:
		case 996:
		case 997:
		case 2074:
		case 2234:
		case 2239:
		case 2399:
		case 2839:
		case 3005:
		case 3016:
		case 3020:
		case 3021:
		case 3024:
		case 3040:
		case 3041:
		case 3052:
		case 3053:
		case 3054:
		case 3055:
		case 3061:
		case 3062:
		case 3070:
		case 3074:
		case 3075:
		case 3078:
		case 3079:
		case 3571:
		case 3574:
		case 3577:
		case 3579:
		case 3584:
		case 3586:
		case 3588:
		case 3590:
		case 3594:
		case 3083:
		case 3084:
		case 3085:
		case 3086:
		case 3087:
		case 3088:
		case 3089:
		case 3090:
		case 3091:
		case 3092:
		case 3093:
		case 3094:
		case 3096:
		case 3097:
		case 3098:
		case 3099:
		case 3100:
		case 3101:
		case 3102:
		case 3103:
		case 3104:
		case 3105:
		case 3106:
		case 3107:
		case 3111:
		case 3112:
		case 3113:
		case 3114:
		case 3115:
		case 3116:
		case 3117:
		case 3118:
		case 3119:
		case 3120:
		case 3121:
		case 3122:
		case 3137:
		case 3187:
		case 3188:
		case 3189:
		case 3190:
		case 3191:
		case 3192:
		case 3193:
		case 3194:
		case 3195:
		case 3196:
		case 3197:
		case 3198:
		case 3331:
		case 8240:
		case 8276:
		case 8357:
		case 7007:
		case 4018:
		case 4019:
		case 4034:
		case 4035:
		case 4036:
		case 4037:
		case 4038:
		case 4046:
		case 4047:
		case 4052:
		case 4053:
		case 4054:
		case 4055:
		case 4063:
		case 4064:
		case 4070:
		case 4072:
		case 4073:
		case 4075:
		case 4076:
		case 4082:
		case 4088:
		case 4098:
		case 4102:
		case 4104:
		case 4106:
		case 4107:
		case 4108:
		case 4109:
		case 4111:
		case 4117:
		case 4118:
		case 4119:
		case 4120:
		case 4126:
		case 4131:
		case 4140:
		case 4145:
		case 4146:
		case 4148:
		case 4149:
		case 4150:
		case 4153:
		case 4162:
		case 4164:
		case 4165:
		case 4166:
		case 4167:
		case 4182:
		case 4183:
		case 4184:
		case 4185:
		case 4186:
		case 4187:
		case 4188:
		case 4189:
		case 4190:
		case 4196:
		case 4197:
		case 4198:
		case 4199:
		case 4200:
		case 4201:
		case 4202:
		case 4203:
		case 4204:
		case 4205:
		case 4206:
		case 4215:
		case 4219:
		case 4236:
		case 4237:
		case 4238:
		case 4243:
		case 4245:
		case 4249:
		case 4258:
		case 4259:
		case 4315:
		case 4319:
		case 4320:
		case 4321:
		case 4361:
		case 4362:
		case 4363:
		case 4382:
		case 4515:
		case 4533:
		case 4534:
		case 4535:
		case 4536:
		case 4537:
		case 4538:
		case 4539:
		case 4540:
		case 4541:
		case 4547:
		case 4577:
		case 4578:
		case 4579:
		case 4580:
		case 4581:
		case 4582:
		case 4583:
		case 4584:
		case 4586:
		case 4587:
		case 4589:
		case 4590:
		case 4591:
		case 4592:
		case 4593:
		case 4594:
		case 4596:
		case 4597:
		case 4598:
		case 4599:
		case 4600:
		case 4602:
		case 4603:
		case 4604:
		case 4605:
		case 4606:
		case 4615:
		case 4620:
		case 4624:
		case 4625:
		case 4640:
		case 4643:
		case 4649:
		case 4657:
		case 4658:
		case 4659:
		case 4660:
		case 4661:
		case 4662:
		case 4670:
		case 4683:
		case 4684:
		case 4688:
		case 4689:
		case 4694:
		case 4695:
		case 4696:
		case 4705:
		case 4706:
		case 4708:
		case 4710:
		case 4169:
		case 4724:
		case 4725:
		case 4726:
		case 4727:
		case 4728:
		case 4172:
		case 4180:
		case 4744:
		case 4745:
		case 4746:
		case 4747:
		case 4748:
		case 4208:
		case 4759:
		case 4760:
		case 4761:
		case 4762:
		case 4763:
		case 4496:
		case 4769:
		case 4770:
		case 4771:
		case 4772:
		case 4773:
		case 4463:
		case 4464:
		case 4465:
		case 4466:
		case 4467:
		case 4473:
		case 4480:
		case 4481:
		case 4482:
		case 4483:
		case 4486:
		case 4487:
		case 4488:
		case 4492:
		case 4991:
		case 4992:
		case 5004:
		case 5012:
		case 5016:
		case 5020:
		case 5022:
		case 5023:
		case 5024:
		case 5037:
		case 5068:
		case 5069:
		case 5070:
		case 5071:
		case 5072:
		case 5081:
		case 5083:
		case 5085:
		case 5086:
		case 5092:
		case 5112:
		case 5114:
		case 5116:
		case 5117:
		case 5120:
		case 5134:
		case 5137:
		case 5138:
		case 5140:
		case 5145:
		case 5160:
		case 5166:
		case 5167:
		case 5168:
		case 5169:
		case 5170:
		case 5171:
		case 5172:
		case 5173:
		case 5174:
		case 5175:
		case 5176:
		case 5177:
		case 5183:
		case 5196:
		case 5197:
		case 5198:
		case 5199:
		case 5202:
		case 5203:
		case 5206:
		case 5207:
		case 5219:
		case 5220:
		case 7066:
		case 7067:
		case 7076:
		case 7077:
		case 7080:
		case 5229:
		case 5230:
		case 5231:
		case 5232:
		case 5238:
		case 5240:
		case 5241:
		case 5242:
		case 5243:
		case 5247:
		case 5250:
		case 5251:
		case 5252:
		case 5253:
		case 5254:
		case 5255:
		case 5256:
		case 5258:
		case 5259:
		case 5260:
		case 5261:
		case 5264:
		case 5266:
		case 5268:
		case 5269:
		case 5270:
		case 5271:
		case 5301:
		case 5302:
		case 5303:
		case 5304:
		case 5305:
		case 5306:
		case 5307:
		case 5308:
		case 5309:
		case 5333:
		case 5362:
		case 5363:
		case 5364:
		case 5365:
		case 5366:
		case 5367:
		case 5368:
		case 5369:
		case 5370:
		case 5394:
		case 5399:
		case 5401:
		case 5422:
		case 5423:
		case 5424:
		case 5431:
		case 5434:
		case 5435:
		case 5443:
		case 5444:
		case 5447:
		case 5456:
		case 5459:
		case 5460:
		case 5481:
		case 5482:
		case 5495:
		case 5496:
		case 5497:
		case 5500:
		case 5501:
		case 5502:
		case 5505:
		case 5506:
		case 5507:
		case 5508:
		case 5509:
		case 5510:
		case 5511:
		case 5512:
		case 5523:
		case 5529:
		case 5530:
		case 5551:
		case 5565:
		case 5566:
		case 5567:
		case 5568:
		case 5569:
		case 5581:
		case 5583:
		case 5584:
		case 5585:
		case 5592:
		case 5594:
		case 5595:
		case 5596:
		case 5600:
		case 5602:
		case 5623:
		case 5624:
		case 5625:
		case 5660:
		case 5661:
		case 5665:
		case 5666:
		case 5667:
		case 5668:
		case 5669:
		case 5670:
		case 5671:
		case 5672:
		case 5673:
		case 5679:
		case 5683:
		case 5687:
		case 5688:
		case 5693:
		case 5696:
		case 5697:
		case 5703:
		case 5706:
		case 5707:
		case 5715:
		case 5716:
		case 5733:
		case 5735:
		case 5747:
		case 5764:
		case 5778:
		case 5794:
		case 5795:
		case 5796:
		case 5797:
		case 5798:
		case 5799:
		case 5800:
		case 5801:
		case 5802:
		case 5803:
		case 5804:
		case 5806:
		case 5807:
		case 5808:
		case 5809:
		case 5810:
		case 5811:
		case 5812:
		case 5813:
		case 5814:
		case 5831:
		case 5832:
		case 5843:
		case 5846:
		case 5849:
		case 5851:
		case 5854:
		case 5855:
		case 5860:
		case 5861:
		case 5866:
		case 5867:
		case 5868:
		case 5869:
		case 5870:
		case 5871:
		case 5872:
		case 5873:
		case 5874:
		case 5875:
		case 5876:
		case 5877:
		case 5878:
		case 5879:
		case 5880:
		case 5881:
		case 5882:
		case 5883:
		case 5884:
		case 5885:
		case 5886:
		case 5887:
		case 5888:
		case 5889:
		case 5890:
		case 5891:
		case 5892:
		case 5893:
		case 5894:
		case 5895:
		case 5896:
		case 5897:
		case 5898:
		case 5899:
		case 5900:
		case 5901:
		case 5903:
		case 5904:
		case 5905:
		case 5907:
		case 5908:
		case 5912:
		case 5914:
		case 5919:
		case 5921:
		case 5922:
		case 5937:
		case 5941:
		case 5942:
		case 5943:
		case 5944:
		case 5945:
		case 5960:
		case 5961:
		case 5967:
		case 5969:
		case 5981:
		case 5984:
		case 5992:
		case 5993:
		case 5994:
		case 6024:
		case 6033:
		case 6090:
		case 6091:
		case 6092:
		case 6095:
		case 6125:
		case 6126:
		case 6129:
		case 6130:
		case 6131:
		case 6132:
		case 6133:
		case 6134:
		case 6135:
		case 6140:
		case 6141:
		case 6142:
		case 6146:
		case 6148:
		case 6149:
		case 6150:
		case 6151:
		case 6152:
		case 6153:
		case 6154:
		case 6155:
		case 6166:
		case 6167:
		case 6168:
		case 6169:
		case 6187:
		case 6189:
		case 6190:
		case 6205:
		case 6206:
		case 6237:
		case 6238:
		case 6240:
		case 6250:
		case 6263:
		case 6266:
		case 6269:
		case 6273:
		case 6274:
		case 6275:
		case 6276:
		case 6280:
		case 6281:
		case 6283:
		case 6299:
		case 6300:
		case 6304:
		case 6306:
		case 6307:
		case 6308:
		case 6309:
		case 6312:
		case 6314:
		case 6320:
		case 6326:
		case 6328:
		case 6331:
		case 6332:
		case 6333:
		case 6334:
		case 6335:
		case 6336:
		case 6339:
		case 6340:
		case 6342:
		case 6370:
		case 6373:
		case 6374:
		case 6375:
		case 6378:
		case 6379:
		case 6380:
		case 6381:
		case 6382:
		case 6383:
		case 6384:
		case 6385:
		case 6386:
		case 6389:
		case 6390:
		case 6391:
		case 6392:
		case 6395:
		case 6396:
		case 6397:
		case 6398:
		case 6400:
		case 6402:
		case 6403:
		case 6404:
		case 6406:
		case 6407:
		case 6408:
		case 6410:
		case 6414:
		case 6416:
		case 6417:
		case 6418:
		case 6423:
		case 6428:
		case 6435:
		case 6436:
		case 6437:
		case 6438:
		case 6439:
		case 6440:
		case 6441:
		case 6618:
		case 6619:
		case 6622:
		case 6624:
		case 6650:
		case 6651:
		case 6662:
		case 6677:
		case 6688:
		case 6690:
		case 6697:
		case 6698:
		case 6705:
		case 6733:
		case 6734:
		case 6735:
		case 6738:
		case 6743:
		case 6744:
		case 6746:
		case 6748:
		case 6750:
		case 6751:
		case 6754:
		case 6757:
		case 6760:
		case 6761:
		case 6763:
		case 6768:
		case 6769:
		case 6772:
		case 6774:
		case 6775:
		case 6776:
		case 6777:
		case 6779:
		case 6815:
		case 6816:
		case 6819:
		case 6821:
		case 6822:
		case 6825:
		case 6827:
		case 6828:
		case 6830:
		case 6836:
		case 6840:
		case 6853:
		case 6854:
		case 6862:
		case 6863:
		case 6865:
		case 6873:
		case 6875:
		case 6878:
		case 6880:
		case 6882:
		case 6890:
		case 6897:
		case 6912:
		case 23069:
		case 23070:
		case 23071:
		case 23124:
		case 23169:
		case 23170:
		case 6921:
		case 23298:
		case 23299:
		case 23300:
		case 23319:
		case 23320:
		case 23321:
		case 23322:
		case 1213:
		case 23323:
		ResultBool = True;
		break;
		default:
	}
	return ResultBool;
}

static final function string ReplaceText (coerce string Text, coerce string Replace, coerce string With)
{
	local int i;
	local string output;

	i = UnknownFunction126(Text,Replace);
	if ( UnknownFunction155(i,-1) )
	{
		output = UnknownFunction112(UnknownFunction112(output,UnknownFunction128(Text,i)),With);
		Text = UnknownFunction127(Text,UnknownFunction146(i,UnknownFunction125(Replace)));
		i = UnknownFunction126(Text,Replace);
		goto JL0012;
	}
	output = UnknownFunction112(output,Text);
	return output;
}

function string lowerDigitNumber (int idx)
{
	local string resultStr;

	switch (idx)
	{
		case 1:
		resultStr = "q";
		break;
		case 2:
		resultStr = "w";
		break;
		case 3:
		resultStr = "e";
		break;
		case 4:
		resultStr = "r";
		break;
		case 5:
		resultStr = "t";
		break;
		case 6:
		resultStr = "y";
		break;
		case 7:
		resultStr = "u";
		break;
		case 8:
		resultStr = "i";
		break;
		case 9:
		resultStr = "o";
		break;
		case 10:
		resultStr = "p";
		break;
		case 11:
		resultStr = "a";
		break;
		case 12:
		resultStr = "s";
		break;
		case 13:
		resultStr = "d";
		break;
		case 14:
		resultStr = "f";
		break;
		case 15:
		resultStr = "g";
		break;
		case 16:
		resultStr = "h";
		break;
		case 17:
		resultStr = "j";
		break;
		case 18:
		resultStr = "k";
		break;
		case 19:
		resultStr = "l";
		break;
		case 20:
		resultStr = "z";
		break;
		case 21:
		resultStr = "x";
		break;
		case 22:
		resultStr = "c";
		break;
		case 23:
		resultStr = "v";
		break;
		case 24:
		resultStr = "b";
		break;
		case 25:
		resultStr = "n";
		break;
		case 26:
		resultStr = "m";
		break;
		case 27:
		resultStr = "1";
		break;
		case 28:
		resultStr = "2";
		break;
		case 29:
		resultStr = "3";
		break;
		case 30:
		resultStr = "4";
		break;
		case 31:
		resultStr = "5";
		break;
		case 32:
		resultStr = "6";
		break;
		case 33:
		resultStr = "7";
		break;
		case 34:
		resultStr = "8";
		break;
		case 35:
		resultStr = "9";
		break;
		case 36:
		resultStr = "0";
		break;
		case 37:
		resultStr = ".";
		break;
		case 38:
		resultStr = " ";
		break;
		case 39:
		resultStr = ":";
		case 40:
		resultStr = "-";
		break;
		case 41:
		resultStr = "#";
		break;
		case 42:
		resultStr = "~";
		break;
		case 43:
		resultStr = "!";
		break;
		case 44:
		resultStr = "[";
		break;
		case 45:
		resultStr = "]";
		break;
		case 46:
		resultStr = "/";
		break;
		default:
	}
	return resultStr;
}

function string upperDigit (int idx)
{
	local string resultStr;

	switch (idx)
	{
		case 1:
		resultStr = "Q";
		break;
		case 2:
		resultStr = "W";
		break;
		case 3:
		resultStr = "E";
		break;
		case 4:
		resultStr = "R";
		break;
		case 5:
		resultStr = "T";
		break;
		case 6:
		resultStr = "Y";
		break;
		case 7:
		resultStr = "U";
		break;
		case 8:
		resultStr = "I";
		break;
		case 9:
		resultStr = "O";
		break;
		case 10:
		resultStr = "P";
		break;
		case 11:
		resultStr = "A";
		break;
		case 12:
		resultStr = "S";
		break;
		case 13:
		resultStr = "D";
		break;
		case 14:
		resultStr = "F";
		break;
		case 15:
		resultStr = "G";
		break;
		case 16:
		resultStr = "H";
		break;
		case 17:
		resultStr = "J";
		break;
		case 18:
		resultStr = "K";
		break;
		case 19:
		resultStr = "L";
		break;
		case 20:
		resultStr = "Z";
		break;
		case 21:
		resultStr = "X";
		break;
		case 22:
		resultStr = "C";
		break;
		case 23:
		resultStr = "V";
		break;
		case 24:
		resultStr = "B";
		break;
		case 25:
		resultStr = "N";
		break;
		case 26:
		resultStr = "M";
		break;
		default:
	}
	return resultStr;
}

function bool IsConsumable (int idx)
{
	local bool ResultBool;

	ResultBool = False;
	switch (idx)
	{
		case 2039:
		case 2150:
		case 2151:
		case 2152:
		case 2153:
		case 2154:
		case 2047:
		case 2155:
		case 2156:
		case 2157:
		case 2158:
		case 2159:
		case 2061:
		case 2160:
		case 2161:
		case 2162:
		case 2163:
		case 2164:
		case 26060:
		case 26061:
		case 26062:
		case 26063:
		case 26064:
		case 22036:
		case 22037:
		case 22038:
		case 2033:
		case 2008:
		case 2009:
		case 26050:
		case 26051:
		case 26052:
		case 26053:
		case 26054:
		case 26055:
		case 26056:
		case 26057:
		case 26058:
		case 26059:
		case 22369:
		case 728:
		case 2240:
		case 2498:
		case 2499:
		case 2359:
		case 2166:
		case 2034:
		case 2037:
		case 2035:
		case 2036:
		case 2011:
		case 2032:
		case 2864:
		case 2398:
		case 2402:
		case 2403:
		case 2395:
		case 2401:
		case 2169:
		case 2397:
		case 2396:
		case 2012:
		case 2074:
		case 2077:
		case 2592:
		case 2038:
		case 2627:
		case 2289:
		case 2287:
		case 2288:
		case 2169:
		case 2076:
		case 22042:
		case 2903:
		case 2901:
		case 2900:
		case 2902:
		case 2897:
		case 22029:
		case 2899:
		case 22031:
		case 22164:
		case 2898:
		case 22030:
		case 22163:
		case 22162:
		case 22158:
		case 2282:
		case 2283:
		case 2284:
		case 2514:
		case 2513:
		case 2244:
		case 2278:
		case 2485:
		case 2247:
		case 2281:
		case 2486:
		case 2245:
		case 2279:
		case 2246:
		case 2280:
		case 2285:
		case 2512:
		case 2580:
		ResultBool = True;
		break;
		default:
	}
	return ResultBool;
}

function bool UnknownID1234 (int idx)
{
	local bool resultInt;

	resultInt = False;
	switch (idx)
	{
		case 347:
		case 28:
		case 92:
		case 101:
		case 102:
		case 105:
		case 115:
		case 129:
		case 1069:
		case 1083:
		case 1160:
		case 1164:
		case 1167:
		case 1168:
		case 1184:
		case 1201:
		case 1206:
		case 1222:
		case 1223:
		case 1224:
		case 100:
		case 95:
		case 96:
		case 120:
		case 223:
		case 1092:
		case 1095:
		case 1096:
		case 1097:
		case 1099:
		case 1100:
		case 1101:
		case 1102:
		case 1107:
		case 1208:
		case 1209:
		case 18:
		case 48:
		case 65:
		case 84:
		case 97:
		case 98:
		case 103:
		case 106:
		case 107:
		case 116:
		case 122:
		case 127:
		case 260:
		case 279:
		case 281:
		case 1042:
		case 1049:
		case 1064:
		case 1071:
		case 1072:
		case 1074:
		case 1104:
		case 1108:
		case 1169:
		case 1170:
		case 1183:
		case 1210:
		case 1231:
		case 1233:
		case 1236:
		case 1237:
		case 1244:
		case 1246:
		case 1247:
		case 1248:
		case 286:
		case 1263:
		case 1269:
		case 1272:
		case 1289:
		case 1290:
		case 1291:
		case 1298:
		case 342:
		case 352:
		case 353:
		case 354:
		case 358:
		case 361:
		case 362:
		case 367:
		case 1336:
		case 1337:
		case 1338:
		case 1339:
		case 1340:
		case 1341:
		case 1342:
		case 1343:
		case 1358:
		case 1359:
		case 1360:
		case 1361:
		case 1366:
		case 1367:
		case 1375:
		case 1376:
		case 400:
		case 401:
		case 402:
		case 403:
		case 404:
		case 407:
		case 408:
		case 412:
		case 1380:
		case 1381:
		case 1382:
		case 1383:
		case 1384:
		case 1385:
		case 1386:
		case 1394:
		case 1396:
		case 437:
		case 452:
		case 485:
		case 1435:
		case 494:
		case 495:
		case 501:
		case 1437:
		case 1445:
		case 1446:
		case 1447:
		case 1448:
		case 509:
		case 522:
		case 523:
		case 531:
		case 537:
		case 1452:
		case 1454:
		case 1455:
		case 1458:
		case 1462:
		case 1467:
		case 1468:
		case 559:
		case 564:
		case 571:
		case 573:
		case 578:
		case 581:
		case 582:
		case 588:
		case 1481:
		case 1482:
		case 1483:
		case 1484:
		case 1485:
		case 1486:
		case 627:
		case 680:
		case 681:
		case 682:
		case 683:
		case 686:
		case 688:
		case 692:
		case 695:
		case 696:
		case 708:
		case 716:
		case 730:
		case 732:
		case 736:
		case 741:
		case 747:
		case 749:
		case 752:
		case 762:
		case 763:
		case 774:
		case 775:
		case 776:
		case 1495:
		case 1508:
		case 1509:
		case 1511:
		case 1512:
		case 791:
		case 792:
		case 793:
		case 794:
		case 798:
		case 808:
		case 1524:
		case 1525:
		case 835:
		case 1529:
		case 877:
		case 879:
		case 883:
		case 886:
		case 887:
		case 899:
		case 904:
		case 905:
		case 909:
		case 910:
		case 927:
		case 1539:
		case 1540:
		case 1541:
		case 949:
		case 954:
		case 1546:
		case 969:
		case 973:
		case 974:
		case 977:
		case 978:
		case 979:
		case 980:
		case 981:
		case 985:
		case 991:
		case 1554:
		case 1555:
		case 995:
		case 996:
		case 997:
		case 2074:
		case 2234:
		case 2239:
		case 2399:
		case 2839:
		case 3005:
		case 3016:
		case 3020:
		case 3021:
		case 3024:
		case 3040:
		case 3041:
		case 3052:
		case 3053:
		case 3054:
		case 3055:
		case 3061:
		case 3062:
		case 3070:
		case 3074:
		case 3075:
		case 3078:
		case 3079:
		case 3571:
		case 3574:
		case 3577:
		case 3579:
		case 3584:
		case 3586:
		case 3588:
		case 3590:
		case 3594:
		case 3083:
		case 3084:
		case 3085:
		case 3086:
		case 3087:
		case 3088:
		case 3089:
		case 3090:
		case 3091:
		case 3092:
		case 3093:
		case 3094:
		case 3096:
		case 3097:
		case 3098:
		case 3099:
		case 3100:
		case 3101:
		case 3102:
		case 3103:
		case 3104:
		case 3105:
		case 3106:
		case 3107:
		case 3111:
		case 3112:
		case 3113:
		case 3114:
		case 3115:
		case 3116:
		case 3117:
		case 3118:
		case 3119:
		case 3120:
		case 3121:
		case 3122:
		case 3137:
		case 3187:
		case 3188:
		case 3189:
		case 3190:
		case 3191:
		case 3192:
		case 3193:
		case 3194:
		case 3195:
		case 3196:
		case 3197:
		case 3198:
		case 3331:
		case 8240:
		case 8276:
		case 8357:
		case 7007:
		case 4018:
		case 4019:
		case 4034:
		case 4035:
		case 4036:
		case 4037:
		case 4038:
		case 4046:
		case 4047:
		case 4052:
		case 4053:
		case 4054:
		case 4055:
		case 4063:
		case 4064:
		case 4070:
		case 4072:
		case 4073:
		case 4075:
		case 4076:
		case 4082:
		case 4088:
		case 4098:
		case 4102:
		case 4104:
		case 4106:
		case 4107:
		case 4108:
		case 4109:
		case 4111:
		case 4117:
		case 4118:
		case 4119:
		case 4120:
		case 4126:
		case 4131:
		case 4140:
		case 4145:
		case 4146:
		case 4148:
		case 4149:
		case 4150:
		case 4153:
		case 4162:
		case 4164:
		case 4165:
		case 4166:
		case 4167:
		case 4182:
		case 4183:
		case 4184:
		case 4185:
		case 4186:
		case 4187:
		case 4188:
		case 4189:
		case 4190:
		case 4196:
		case 4197:
		case 4198:
		case 4199:
		case 4200:
		case 4201:
		case 4202:
		case 4203:
		case 4204:
		case 4205:
		case 4206:
		case 4215:
		case 4219:
		case 4236:
		case 4237:
		case 4238:
		case 4243:
		case 4245:
		case 4249:
		case 4258:
		case 4259:
		case 4315:
		case 4319:
		case 4320:
		case 4321:
		case 4361:
		case 4362:
		case 4363:
		case 4382:
		case 4515:
		case 4533:
		case 4534:
		case 4535:
		case 4536:
		case 4537:
		case 4538:
		case 4539:
		case 4540:
		case 4541:
		case 4547:
		case 4577:
		case 4578:
		case 4579:
		case 4580:
		case 4581:
		case 4582:
		case 4583:
		case 4584:
		case 4586:
		case 4587:
		case 4589:
		case 4590:
		case 4591:
		case 4592:
		case 4593:
		case 4594:
		case 4596:
		case 4597:
		case 4598:
		case 4599:
		case 4600:
		case 4602:
		case 4603:
		case 4604:
		case 4605:
		case 4606:
		case 4615:
		case 4620:
		case 4624:
		case 4625:
		case 4640:
		case 4643:
		case 4649:
		case 4657:
		case 4658:
		case 4659:
		case 4660:
		case 4661:
		case 4662:
		case 4670:
		case 4683:
		case 4684:
		case 4688:
		case 4689:
		case 4694:
		case 4695:
		case 4696:
		case 4705:
		case 4706:
		case 4708:
		case 4710:
		case 4169:
		case 4724:
		case 4725:
		case 4726:
		case 4727:
		case 4728:
		case 4172:
		case 4180:
		case 4744:
		case 4745:
		case 4746:
		case 4747:
		case 4748:
		case 4208:
		case 4759:
		case 4760:
		case 4761:
		case 4762:
		case 4763:
		case 4496:
		case 4769:
		case 4770:
		case 4771:
		case 4772:
		case 4773:
		case 4463:
		case 4464:
		case 4465:
		case 4466:
		case 4467:
		case 4473:
		case 4480:
		case 4481:
		case 4482:
		case 4483:
		case 4486:
		case 4487:
		case 4488:
		case 4492:
		case 4991:
		case 4992:
		case 5004:
		case 5012:
		case 5016:
		case 5020:
		case 5022:
		case 5023:
		case 5024:
		case 5037:
		case 5068:
		case 5069:
		case 5070:
		case 5071:
		case 5072:
		case 5081:
		case 5083:
		case 5085:
		case 5086:
		case 5092:
		case 5112:
		case 5114:
		case 5116:
		case 5117:
		case 5120:
		case 5134:
		case 5137:
		case 5138:
		case 5140:
		case 5145:
		case 5160:
		case 5166:
		case 5167:
		case 5168:
		case 5169:
		case 5170:
		case 5171:
		case 5172:
		case 5173:
		case 5174:
		case 5175:
		case 5176:
		case 5177:
		case 5183:
		case 5196:
		case 5197:
		case 5198:
		case 5199:
		case 5202:
		case 5203:
		case 5206:
		case 5207:
		case 5219:
		case 5220:
		case 7066:
		case 7067:
		case 7076:
		case 7077:
		case 7080:
		case 5229:
		case 5230:
		case 5231:
		case 5232:
		case 5238:
		case 5240:
		case 5241:
		case 5242:
		case 5243:
		case 5247:
		case 5250:
		case 5251:
		case 5252:
		case 5253:
		case 5254:
		case 5255:
		case 5256:
		case 5258:
		case 5259:
		case 5260:
		case 5261:
		case 5264:
		case 5266:
		case 5268:
		case 5269:
		case 5270:
		case 5271:
		case 5301:
		case 5302:
		case 5303:
		case 5304:
		case 5305:
		case 5306:
		case 5307:
		case 5308:
		case 5309:
		case 5333:
		case 5362:
		case 5363:
		case 5364:
		case 5365:
		case 5366:
		case 5367:
		case 5368:
		case 5369:
		case 5370:
		case 5394:
		case 5399:
		case 5401:
		case 5422:
		case 5423:
		case 5424:
		case 5431:
		case 5434:
		case 5435:
		case 5443:
		case 5444:
		case 5447:
		case 5456:
		case 5459:
		case 5460:
		case 5481:
		case 5482:
		case 5495:
		case 5496:
		case 5497:
		case 5500:
		case 5501:
		case 5502:
		case 5505:
		case 5506:
		case 5507:
		case 5508:
		case 5509:
		case 5510:
		case 5511:
		case 5512:
		case 5523:
		case 5529:
		case 5530:
		case 5551:
		case 5565:
		case 5566:
		case 5567:
		case 5568:
		case 5569:
		case 5581:
		case 5583:
		case 5584:
		case 5585:
		case 5592:
		case 5594:
		case 5595:
		case 5596:
		case 5600:
		case 5602:
		case 5623:
		case 5624:
		case 5625:
		case 5660:
		case 5661:
		case 5665:
		case 5666:
		case 5667:
		case 5668:
		case 5669:
		case 5670:
		case 5671:
		case 5672:
		case 5673:
		case 5679:
		case 5683:
		case 5687:
		case 5688:
		case 5693:
		case 5696:
		case 5697:
		case 5703:
		case 5706:
		case 5707:
		case 5715:
		case 5716:
		case 5733:
		case 5735:
		case 5747:
		case 5764:
		case 5778:
		case 5794:
		case 5795:
		case 5796:
		case 5797:
		case 5798:
		case 5799:
		case 5800:
		case 5801:
		case 5802:
		case 5803:
		case 5804:
		case 5806:
		case 5807:
		case 5808:
		case 5809:
		case 5810:
		case 5811:
		case 5812:
		case 5813:
		case 5814:
		case 5831:
		case 5832:
		case 5843:
		case 5846:
		case 5849:
		case 5851:
		case 5854:
		case 5855:
		case 5860:
		case 5861:
		case 5866:
		case 5867:
		case 5868:
		case 5869:
		case 5870:
		case 5871:
		case 5872:
		case 5873:
		case 5874:
		case 5875:
		case 5876:
		case 5877:
		case 5878:
		case 5879:
		case 5880:
		case 5881:
		case 5882:
		case 5883:
		case 5884:
		case 5885:
		case 5886:
		case 5887:
		case 5888:
		case 5889:
		case 5890:
		case 5891:
		case 5892:
		case 5893:
		case 5894:
		case 5895:
		case 5896:
		case 5897:
		case 5898:
		case 5899:
		case 5900:
		case 5901:
		case 5903:
		case 5904:
		case 5905:
		case 5907:
		case 5908:
		case 5912:
		case 5914:
		case 5919:
		case 5921:
		case 5922:
		case 5937:
		case 5941:
		case 5942:
		case 5943:
		case 5944:
		case 5945:
		case 5960:
		case 5961:
		case 5967:
		case 5969:
		case 5981:
		case 5984:
		case 5992:
		case 5993:
		case 5994:
		case 6024:
		case 6033:
		case 6090:
		case 6091:
		case 6092:
		case 6095:
		case 6125:
		case 6126:
		case 6129:
		case 6130:
		case 6131:
		case 6132:
		case 6133:
		case 6134:
		case 6135:
		case 6140:
		case 6141:
		case 6142:
		case 6146:
		case 6148:
		case 6149:
		case 6150:
		case 6151:
		case 6152:
		case 6153:
		case 6154:
		case 6155:
		case 6166:
		case 6167:
		case 6168:
		case 6169:
		case 6187:
		case 6189:
		case 6190:
		case 6205:
		case 6206:
		case 6237:
		case 6238:
		case 6240:
		case 6250:
		case 6263:
		case 6266:
		case 6269:
		case 6273:
		case 6274:
		case 6275:
		case 6276:
		case 6280:
		case 6281:
		case 6283:
		case 6299:
		case 6300:
		case 6304:
		case 6306:
		case 6307:
		case 6308:
		case 6309:
		case 6312:
		case 6314:
		case 6320:
		case 6326:
		case 6328:
		case 6331:
		case 6332:
		case 6333:
		case 6334:
		case 6335:
		case 6336:
		case 6339:
		case 6340:
		case 6342:
		case 6370:
		case 6373:
		case 6374:
		case 6375:
		case 6378:
		case 6379:
		case 6380:
		case 6381:
		case 6382:
		case 6383:
		case 6384:
		case 6385:
		case 6386:
		case 6389:
		case 6390:
		case 6391:
		case 6392:
		case 6395:
		case 6396:
		case 6397:
		case 6398:
		case 6400:
		case 6402:
		case 6403:
		case 6404:
		case 6406:
		case 6407:
		case 6408:
		case 6410:
		case 6414:
		case 6416:
		case 6417:
		case 6418:
		case 6423:
		case 6428:
		case 6435:
		case 6436:
		case 6437:
		case 6438:
		case 6439:
		case 6440:
		case 6441:
		case 6618:
		case 6619:
		case 6622:
		case 6624:
		case 6650:
		case 6651:
		case 6662:
		case 6677:
		case 6688:
		case 6690:
		case 6697:
		case 6698:
		case 6705:
		case 6733:
		case 6734:
		case 6735:
		case 6738:
		case 6743:
		case 6744:
		case 6746:
		case 6748:
		case 6750:
		case 6751:
		case 6754:
		case 6757:
		case 6760:
		case 6761:
		case 6763:
		case 6768:
		case 6769:
		case 6772:
		case 6774:
		case 6775:
		case 6776:
		case 6777:
		case 6779:
		case 6815:
		case 6816:
		case 6819:
		case 6821:
		case 6822:
		case 6825:
		case 6827:
		case 6828:
		case 6830:
		case 6836:
		case 6840:
		case 6853:
		case 6854:
		case 6862:
		case 6863:
		case 6865:
		case 6873:
		case 6875:
		case 6878:
		case 6880:
		case 6882:
		case 6890:
		case 6897:
		case 6912:
		case 23069:
		case 23070:
		case 23071:
		case 23124:
		case 23169:
		case 23170:
		case 6921:
		case 23298:
		case 23299:
		case 23300:
		case 23319:
		case 23320:
		case 23321:
		case 23322:
		case 23323:
		resultInt = True;
		case 1323:
		if ( BoolEquals(GetOptionBool("Custom","ShowNoble"),True) )
		{
			resultInt = True;
		}
		break;
		default:
	}
	return resultInt;
}

function string s_GetCustomClassIcon (int ClassID, int idx)
{
	local string resultString;

	resultString = "";
	switch (ClassID)
	{
		case 46:
		case 113:
		resultString = "InterfaceTextures.Image_0";
		break;
		case 9:
		case 92:
		case 24:
		case 102:
		case 37:
		case 109:
		resultString = "InterfaceTextures.Image_1";
		break;
		case 2:
		case 88:
		resultString = "InterfaceTextures.Image_2";
		break;
		case 3:
		case 89:
		resultString = "InterfaceTextures.Image_3";
		break;
		case 5:
		case 90:
		case 6:
		case 91:
		case 20:
		case 99:
		case 33:
		case 106:
		resultString = "InterfaceTextures.Image_4";
		break;
		case 8:
		case 93:
		case 23:
		case 101:
		case 36:
		case 108:
		resultString = "InterfaceTextures.Image_5";
		break;
		case 11:
		case 94:
		resultString = "InterfaceTextures.Image_6";
		break;
		case 13:
		case 95:
		resultString = "InterfaceTextures.Image_7";
		break;
		case 14:
		case 96:
		case 28:
		case 104:
		case 41:
		case 111:
		resultString = "InterfaceTextures.Image_8";
		break;
		case 17:
		case 98:
		case 30:
		case 105:
		case 43:
		case 112:
		resultString = "InterfaceTextures.Image_9";
		break;
		case 16:
		case 97:
		resultString = "InterfaceTextures.Image_10";
		break;
		case 21:
		case 100:
		resultString = "InterfaceTextures.Image_11";
		break;
		case 34:
		case 107:
		resultString = "InterfaceTextures.Image_12";
		break;
		case 27:
		case 103:
		resultString = "InterfaceTextures.Image_13";
		break;
		case 40:
		case 110:
		resultString = "InterfaceTextures.Image_14";
		break;
		case 48:
		case 114:
		resultString = "InterfaceTextures.Image_15";
		break;
		case 51:
		case 52:
		case 115:
		case 116:
		resultString = "InterfaceTextures.Image_16";
		break;
		case 55:
		case 56:
		case 118:
		case 117:
		resultString = "InterfaceTextures.Image_17";
		break;
		default:
	}
	return resultString;
}

function string s_GetCustomClassIconTooltipText (int ClassID, int idx)
{
	local string resultString;

	resultString = "";
	switch (ClassID)
	{
		case 46:
		case 113:
		resultString = "Destroyer";
		break;
		case 9:
		case 92:
		case 24:
		case 102:
		case 37:
		case 109:
		resultString = "Ranger";
		break;
		case 2:
		case 88:
		resultString = "Gladiator";
		break;
		case 3:
		case 89:
		resultString = "Poller";
		break;
		case 5:
		case 90:
		case 6:
		case 91:
		case 20:
		case 99:
		case 33:
		case 106:
		resultString = "Tank";
		break;
		case 8:
		case 93:
		case 23:
		case 101:
		case 36:
		case 108:
		resultString = "Lethal";
		break;
		case 11:
		case 94:
		resultString = "Fire";
		break;
		case 13:
		case 95:
		resultString = "Dark";
		break;
		case 14:
		case 96:
		case 28:
		case 104:
		case 41:
		case 111:
		resultString = "Summoner";
		break;
		case 17:
		case 98:
		case 30:
		case 105:
		case 43:
		case 112:
		resultString = "Elder";
		break;
		case 16:
		case 97:
		resultString = "Bishop";
		break;
		case 21:
		case 100:
		resultString = "Songer";
		break;
		case 34:
		case 107:
		resultString = "Dancer";
		break;
		case 27:
		case 103:
		resultString = "Water";
		break;
		case 40:
		case 110:
		resultString = "Wind";
		break;
		case 48:
		case 114:
		resultString = "Tyrant";
		break;
		case 51:
		case 52:
		case 115:
		case 116:
		resultString = "Shaman";
		break;
		case 55:
		case 56:
		case 118:
		case 117:
		resultString = "Maestro";
		break;
		default:
	}
	return resultString;
}

function int GetMacroNum (string param)
{
	local int idx;

	GetINIInt("MacroList",param,idx,"MacroGrp");
	return idx;
}

function string StrCat (string param, string Param2)
{
	return UnknownFunction112(param,Param2);
}

function bool LessOrEqual (string param, string Param2)
{
	return UnknownFunction120(param,Param2);
}

function bool GreaterOrEqual (string param, string Param2)
{
	return UnknownFunction121(param,Param2);
}

function bool StrEquals (string param, string Param2)
{
	return UnknownFunction122(param,Param2);
}

function bool NotEquals (string param, string Param2)
{
	return UnknownFunction123(param,Param2);
}

function bool StrNotEquals2 (string param, string Param2)
{
	return UnknownFunction124(param,Param2);
}

function int StrLen (string param)
{
	return UnknownFunction125(param);
}

function string StrLeft (string param, int i)
{
	return UnknownFunction128(param,i);
}

function string StrRight (string param, int i)
{
	return UnknownFunction234(param,i);
}

function bool LogicalAND (bool param, bool Param2)
{
	return UnknownFunction130(param,Param2);
}

function bool LogicalOR (bool param, bool Param2)
{
	return UnknownFunction132(param,Param2);
}

function bool LessThan (int param, int Param2)
{
	return UnknownFunction150(param,Param2);
}

function bool GreaterThan (int param, int Param2)
{
	return UnknownFunction151(param,Param2);
}

function IntIncrement (out int param)
{
	UnknownFunction165(param);
}

function int DoAdd (int param, int Param2)
{
	return UnknownFunction146(param,Param2);
}

function bool NotBool (bool param)
{
	return UnknownFunction129(param);
}

function bool Equals (int param, int Param2)
{
	return UnknownFunction154(param,Param2);
}

function int IntMod (int param, int Param2)
{
	return int(UnknownFunction173(param,Param2));
}

function bool BoolEquals (bool param, bool Param2)
{
	return UnknownFunction242(param,Param2);
}

function IntDec (out int param)
{
	UnknownFunction166(param);
}

function IntPreIncrement (out int param)
{
	UnknownFunction163(param);
}

function bool IntNotEquals (int param, int Param2)
{
	return UnknownFunction155(param,Param2);
}

function int IntSub (int param, int Param2)
{
	return UnknownFunction147(param,Param2);
}

function bool IntGreaterOrEqual (int param, int Param2)
{
	return UnknownFunction153(param,Param2);
}

function int IntMul (int param, int Param2)
{
	return UnknownFunction144(param,Param2);
}

function int IntDiv (int param, int Param2)
{
	return UnknownFunction145(param,Param2);
}

function bool IntLessOrEqual (int param, int Param2)
{
	return UnknownFunction152(param,Param2);
}

function float FloatAdd (float param, float Param2)
{
	return UnknownFunction174(param,Param2);
}

function float FloatSub (float param, float Param2)
{
	return UnknownFunction175(param,Param2);
}

function float FloatMul (float param, float Param2)
{
	return UnknownFunction171(param,Param2);
}

function float FloatDiv (float param, float Param2)
{
	return UnknownFunction172(param,Param2);
}

function bool FloatLessThan (float param, float Param2)
{
	return UnknownFunction176(param,Param2);
}

function bool FloatGreaterThan (float param, float Param2)
{
	return UnknownFunction177(param,Param2);
}

function bool NameEquals (name param, name Param2)
{
	return UnknownFunction254(param,Param2);
}

function bool ChatWindowEquals (ChatWindowHandle param, ChatWindowHandle Param2)
{
	return UnknownFunction119(param,Param2);
}

function string StrCat2 (string param, string Param2)
{
	return UnknownFunction168(param,Param2);
}

function bool ItemWindowEquals (ItemWindowHandle param, ItemWindowHandle Param2)
{
	return UnknownFunction114(param,Param2);
}

function bool BoolNotEquals (bool param, bool Param2)
{
	return UnknownFunction243(param,Param2);
}

function DoLog (string param)
{
	UnknownFunction231(param);
}

function FloatParamAdd (out float Param1, float Param2)
{
	UnknownFunction184(Param1,Param2);
}

function OpenHideWindow (string param)
{
	if ( IsShowWindow(param) )
	{
		HideWindow(param);
	} else {
		ShowWindow(param);
		Class'UIAPI_WINDOW'.SetFocus(param);
	}
}

function Color SetColor (string Colors)
{
	local Color RGB;

	RGB.A = 255;
	switch (Colors)
	{
		case "Green":
		RGB.R = 59;
		RGB.G = 255;
		RGB.B = 0;
		break;
		case "Cyan":
		RGB.R = 0;
		RGB.G = 205;
		RGB.B = 255;
		break;
		case "Blue":
		RGB.R = 0;
		RGB.G = 0;
		RGB.B = 255;
		break;
		case "Yellow":
		RGB.R = 255;
		RGB.G = 255;
		RGB.B = 0;
		break;
		case "Orange":
		RGB.R = 230;
		RGB.G = 153;
		RGB.B = 77;
		break;
		case "System":
		RGB.R = 176;
		RGB.G = 155;
		RGB.B = 121;
		break;
		case "Amber":
		RGB.R = 218;
		RGB.G = 165;
		RGB.B = 32;
		break;
		case "White":
		RGB.R = 255;
		RGB.G = 255;
		RGB.B = 255;
		break;
		case "Dim":
		RGB.R = 177;
		RGB.G = 173;
		RGB.B = 172;
		break;
		case "Magenta":
		RGB.R = 255;
		RGB.G = 0;
		RGB.B = 255;
		break;
		case "Brown":
		RGB.R = 176;
		RGB.G = 155;
		RGB.B = 121;
		break;
		case "Red":
		RGB.R = 255;
		RGB.G = 0;
		RGB.B = 0;
		break;
		case "DamageRed":
		RGB.R = 226;
		RGB.G = 41;
		RGB.B = 41;
		break;
		case "LightRed":
		RGB.R = 255;
		RGB.G = 43;
		RGB.B = 106;
		break;
		case "LightBlue":
		RGB.R = 0;
		RGB.G = 160;
		RGB.B = 255;
		break;
		default:
		RGB.R = 255;
		RGB.G = 255;
		RGB.B = 255;
		break;
	}
	return RGB;
}

function ChatSystemMsg (string param, Color Color)
{
	if ( GetOptionBool("Game","SystemMsgWnd") )
	{
		Class'UIAPI_TEXTLISTBOX'.AddString("SystemMsgWnd.SystemMsgList",param,Color);
	} else {
		Class'UIAPI_TEXTLISTBOX'.AddString("ChatWnd.NormalChat",param,Color);
		Class'UIAPI_TEXTLISTBOX'.AddString("ChatWnd.TradeChat",param,Color);
		Class'UIAPI_TEXTLISTBOX'.AddString("ChatWnd.PartyChat",param,Color);
		Class'UIAPI_TEXTLISTBOX'.AddString("ChatWnd.ClanChat",param,Color);
		Class'UIAPI_TEXTLISTBOX'.AddString("ChatWnd.AllyChat",param,Color);
	}
}

function ChatOlyMsg (string param, Color Color)
{
	Class'UIAPI_TEXTLISTBOX'.AddString("OlympiadMsgWnd.OlympiadMsgList",param,Color);
}

function bool StrContains (string needle, string haystack)
{
	return UnknownFunction155(UnknownFunction126(StrToLower(haystack),StrToLower(needle)),-1);
}

function bool StartsWith (string needle, string haystack)
{
	return UnknownFunction154(UnknownFunction126(StrToLower(haystack),StrToLower(needle)),0);
}

function string StrToLower (string Source)
{
	local int i;
	local string Result;
	local int curAscii;
	local string curChar;

	Result = "";
	i = 0;
	if ( UnknownFunction150(i,UnknownFunction125(Source)) )
	{
		curChar = UnknownFunction127(Source,i,1);
		curAscii = UnknownFunction237(curChar);
		if ( UnknownFunction130(UnknownFunction153(curAscii,65),UnknownFunction152(curAscii,90)) )
		{
			UnknownFunction161(curAscii,32);
		}
		Result = UnknownFunction112(Result,string(curAscii));
		UnknownFunction165(i);
		goto JL000F;
	}
	return Result;
}

function Debug2 (string Msg)
{
	ChatSystemMsg(UnknownFunction112("DEBUG: ",Msg),SetColor("Amber"));
}

function bool IsTargetSelf ()
{
	return Equals(Class'UIDATA_PLAYER'.GetPlayerID(),Class'UIDATA_TARGET'.GetTargetID());
}

