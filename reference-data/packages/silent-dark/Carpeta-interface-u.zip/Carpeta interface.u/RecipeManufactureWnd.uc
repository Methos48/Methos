//================================================================================
// RecipeManufactureWnd.
//================================================================================

class RecipeManufactureWnd extends UIScript;

var int m_RecipeID;
var int m_SuccessRate;
var int m_RecipeBookClass;
var int m_MaxMP;
var int m_PlayerID;
const RECIPEWND_MAX_MP_WIDTH= 165.0f;

function OnLoad ()
{
	RegisterEvent(840);
	RegisterEvent(210);
	RegisterEvent(2600);
	RegisterEvent(2610);
}

function OnEvent (int Event_ID, string param)
{
	local Rect rectWnd;
	local int ServerID;
	local int MPValue;
	local int RecipeID;
	local int currentMP;
	local int maxMP;
	local int MakingResult;
	local int Type;

	if ( UnknownFunction154(Event_ID,840) )
	{
		Class'UIAPI_WINDOW'.HideWindow("RecipeBookWnd");
		Clear();
		rectWnd = Class'UIAPI_WINDOW'.GetRect("RecipeBookWnd");
		Class'UIAPI_WINDOW'.MoveTo("RecipeManufactureWnd",rectWnd.nX,rectWnd.nY);
		Class'UIAPI_WINDOW'.ShowWindow("RecipeManufactureWnd");
		Class'UIAPI_WINDOW'.SetFocus("RecipeManufactureWnd");
		ParseInt(param,"RecipeID",RecipeID);
		ParseInt(param,"CurrentMP",currentMP);
		ParseInt(param,"MaxMP",maxMP);
		ParseInt(param,"MakingResult",MakingResult);
		ParseInt(param,"Type",Type);
		ReceiveRecipeItemMakeInfo(RecipeID,currentMP,maxMP,MakingResult,Type);
	} else {
		if ( UnknownFunction154(Event_ID,210) )
		{
			ParseInt(param,"ServerID",ServerID);
			ParseInt(param,"CurrentMP",MPValue);
			if ( UnknownFunction130(UnknownFunction154(m_PlayerID,ServerID),UnknownFunction151(m_PlayerID,0)) )
			{
				SetMPBar(MPValue);
			}
		} else {
			if ( UnknownFunction132(UnknownFunction154(Event_ID,2600),UnknownFunction154(Event_ID,2610)) )
			{
				HandleInventoryItem(param);
			}
		}
	}
}

function OnClickButton (string strID)
{
	local string param;

	switch (strID)
	{
		case "btnClose":
		CloseWindow();
		break;
		case "btnPrev":
		Class'RecipeAPI'.RequestRecipeBookOpen(m_RecipeBookClass);
		CloseWindow();
		break;
		case "btnRecipeTree":
		if ( Class'UIAPI_WINDOW'.IsShowWindow("RecipeTreeWnd") )
		{
			Class'UIAPI_WINDOW'.HideWindow("RecipeTreeWnd");
		} else {
			ParamAdd(param,"RecipeID",string(m_RecipeID));
			ParamAdd(param,"SuccessRate",string(m_SuccessRate));
			ExecuteEvent(810,param);
		}
		break;
		case "btnManufacture":
		Class'RecipeAPI'.RequestRecipeItemMakeSelf(m_RecipeID);
		break;
		default:
	}
}

function CloseWindow ()
{
	Clear();
	Class'UIAPI_WINDOW'.HideWindow("RecipeManufactureWnd");
	PlayConsoleSound(6);
}

function Clear ()
{
	m_RecipeID = 0;
	m_SuccessRate = 0;
	m_RecipeBookClass = 0;
	m_MaxMP = 0;
	m_PlayerID = 0;
	Class'UIAPI_ITEMWINDOW'.Clear("RecipeManufactureWnd.ItemWnd");
}

function ReceiveRecipeItemMakeInfo (int RecipeID, int currentMP, int maxMP, int MakingResult, int Type)
{
	local int i;
	local string strTmp;
	local int nTmp;
	local int ProductID;
	local int ProductNum;
	local string ItemName;
	local ParamStack param;
	local ItemInfo infItem;

	m_RecipeID = RecipeID;
	m_SuccessRate = Class'UIDATA_RECIPE'.GetRecipeSuccessRate(RecipeID);
	m_RecipeBookClass = Type;
	m_MaxMP = maxMP;
	m_PlayerID = Class'UIDATA_PLAYER'.GetPlayerID();
	ProductID = Class'UIDATA_RECIPE'.GetRecipeProductID(RecipeID);
	strTmp = Class'UIDATA_ITEM'.GetItemTextureName(ProductID);
	Class'UIAPI_TEXTURECTRL'.SetTexture("RecipeManufactureWnd.texItem",strTmp);
	ItemName = MakeFullItemName(ProductID);
	nTmp = Class'UIDATA_RECIPE'.GetRecipeCrystalType(RecipeID);
	strTmp = GetItemGradeString(nTmp);
	if ( UnknownFunction151(UnknownFunction125(strTmp),0) )
	{
		strTmp = UnknownFunction112(UnknownFunction112("`",strTmp),"`");
	}
	Class'UIAPI_TEXTBOX'.SetText("RecipeManufactureWnd.txtName",UnknownFunction112(UnknownFunction112(ItemName," "),strTmp));
	nTmp = Class'UIDATA_RECIPE'.GetRecipeMpConsume(RecipeID);
	Class'UIAPI_TEXTBOX'.SetText("RecipeManufactureWnd.txtMPConsume",UnknownFunction112("",string(nTmp)));
	Class'UIAPI_TEXTBOX'.SetText("RecipeManufactureWnd.txtSuccessRate",UnknownFunction112(string(m_SuccessRate),"%"));
	ProductNum = Class'UIDATA_RECIPE'.GetRecipeProductNum(RecipeID);
	Class'UIAPI_TEXTBOX'.SetText("RecipeManufactureWnd.txtResultValue",UnknownFunction112("",string(ProductNum)));
	SetMPBar(currentMP);
	Class'UIAPI_TEXTBOX'.SetText("RecipeManufactureWnd.txtCountValue",UnknownFunction112("",string(GetInventoryItemCount(ProductID))));
	strTmp = "";
	if ( UnknownFunction154(MakingResult,0) )
	{
		strTmp = MakeFullSystemMsg(GetSystemMessage(960),ItemName,"");
	} else {
		if ( UnknownFunction154(MakingResult,1) )
		{
			strTmp = MakeFullSystemMsg(GetSystemMessage(959),ItemName,UnknownFunction112("",string(ProductNum)));
		}
	}
	Class'UIAPI_TEXTBOX'.SetText("RecipeManufactureWnd.txtMsg",strTmp);
	param = Class'UIDATA_RECIPE'.GetRecipeMaterialItem(RecipeID);
	nTmp = param.GetInt();
	i = 0;
	if ( UnknownFunction150(i,nTmp) )
	{
		infItem.ClassID = param.GetInt();
		infItem.Reserved = param.GetInt();
		infItem.Name = Class'UIDATA_ITEM'.GetItemName(infItem.ClassID);
		infItem.AdditionalName = Class'UIDATA_ITEM'.GetItemAdditionalName(infItem.ClassID);
		infItem.IconName = Class'UIDATA_ITEM'.GetItemTextureName(infItem.ClassID);
		infItem.Description = Class'UIDATA_ITEM'.GetItemDescription(infItem.ClassID);
		infItem.ItemNum = GetInventoryItemCount(infItem.ClassID);
		if ( UnknownFunction151(infItem.Reserved,infItem.ItemNum) )
		{
			infItem.bDisabled = True;
		} else {
			infItem.bDisabled = False;
		}
		Class'UIAPI_ITEMWINDOW'.AddItem("RecipeManufactureWnd.ItemWnd",infItem);
		UnknownFunction165(i);
		goto JL035E;
	}
}

function SetMPBar (int currentMP)
{
	local int nTmp;
	local int nMPWidth;

	nTmp = UnknownFunction144(165,currentMP);
	nMPWidth = UnknownFunction145(nTmp,m_MaxMP);
	if ( UnknownFunction177(nMPWidth,165.0) )
	{
		nMPWidth = 165;
	}
	Class'UIAPI_WINDOW'.SetWindowSize("RecipeManufactureWnd.texMPBar",nMPWidth,12);
}

function HandleInventoryItem (string param)
{
	local int ClassID;
	local int idx;
	local ItemInfo infItem;

	if ( ParseInt(param,"classID",ClassID) )
	{
		idx = Class'UIAPI_ITEMWINDOW'.FindItemWithClassID("RecipeManufactureWnd.ItemWnd",ClassID);
		if ( UnknownFunction151(idx,-1) )
		{
			Class'UIAPI_ITEMWINDOW'.GetItem("RecipeManufactureWnd.ItemWnd",idx,infItem);
			infItem.ItemNum = GetInventoryItemCount(infItem.ClassID);
			if ( UnknownFunction151(infItem.Reserved,infItem.ItemNum) )
			{
				infItem.bDisabled = True;
			} else {
				infItem.bDisabled = False;
			}
			Class'UIAPI_ITEMWINDOW'.SetItem("RecipeManufactureWnd.ItemWnd",idx,infItem);
		}
	}
}

